# Thông báo bên thứ ba

SonicRec dùng các thành phần mã nguồn mở dưới đây. Bản quyền thuộc về tác giả từng thành phần; văn bản giấy phép đầy đủ nằm trong thư mục `dist-info` của từng gói Python trong bản cài (tệp LICENSE), và ở địa chỉ ghi dưới đây. Tệp này lập từ `GIAY_PHEP_THANH_PHAN.md` (4/10/2026) và chưa được luật sư xem; các dòng "chưa kiểm" phải điền xong trước khi đưa vào bản cài.

## Thư viện Python

| Gói | Bản | Giấy phép |
|---|---|---|
| annotated-doc | 0.0.5 | MIT |
| annotated-types | 0.8.0 | MIT License |
| anyio | 4.15.1 | MIT |
| bottle | 0.13.4 | chưa kiểm |
| certifi | 2026.7.22 | Mozilla Public License 2.0 (MPL 2.0) |
| cffi | 2.1.1 | MIT-0 |
| click | 8.5.0 | BSD-3-Clause |
| clr-loader | 0.3.1 | chưa kiểm |
| fastapi | 0.141.1 | MIT |
| filelock | 3.32.7 | MIT |
| greenlet | 3.5.6 | MIT AND PSF-2.0 |
| h11 | 0.16.0 | MIT License |
| httpcore | 1.0.9 | BSD-3-Clause |
| httpx | 0.28.1 | BSD License |
| idna | 3.20 | BSD-3-Clause |
| imageio-ffmpeg | 0.6.0 | BSD License |
| lxml | 6.1.3 | BSD-3-Clause |
| markdown-it-py | 4.2.0 | MIT License |
| mdurl | 0.1.2 | MIT License |
| notebooklm-py | 0.8.3 | MIT License |
| playwright | 1.63.0 | Apache-2.0 |
| proxy-tools | 0.1.0 | chưa kiểm |
| pycparser | 3.0 | BSD-3-Clause |
| pydantic | 2.13.5 | MIT |
| pydantic-core | 2.46.5 | MIT |
| pyee | 13.0.1 | MIT License |
| pygments | 2.21.0 | BSD-2-Clause |
| pyobjc-core | 12.2.2 | chưa kiểm |
| pyobjc-framework-cocoa | 12.2.2 | chưa kiểm |
| pyobjc-framework-quartz | 12.2.2 | chưa kiểm |
| pyobjc-framework-security | 12.2.2 | chưa kiểm |
| pyobjc-framework-uniformtypeidentifiers | 12.2.2 | chưa kiểm |
| pyobjc-framework-webkit | 12.2.2 | chưa kiểm |
| python-docx | 1.2.0 | MIT License |
| python-multipart | 0.0.32 | Apache-2.0 |
| pythonnet | 3.2.0 | chưa kiểm |
| pywebview | 6.2.1 | chưa kiểm |
| rich | 15.0.0 | MIT License |
| segno | 1.6.6 | BSD License |
| sherpa-onnx | 1.13.8 | Apache (theo dòng License, cần xem tệp LICENSE) |
| sherpa-onnx-core | 1.13.8 | Apache-2.0 |
| starlette | 1.7.0 | BSD-3-Clause |
| typing-extensions | 4.16.0 | PSF-2.0 |
| typing-inspection | 0.4.4 | MIT |
| uvicorn | 0.54.0 | BSD-3-Clause |

## ffmpeg

SonicRec chạy ffmpeg như một chương trình riêng để ghi âm. Bản đi kèm gói `imageio-ffmpeg` (bản Linux đã kiểm là ffmpeg 7.0.2 của johnvansickle.com) được dựng với `--enable-gpl --enable-version3`, nên theo GNU General Public License v3. ffmpeg: https://ffmpeg.org (mã nguồn và giấy phép tại đó). Khi phát hành chính thức phải ghi thêm: văn bản GPL v3 và cách lấy mã nguồn đúng bản đã đi kèm. Bản Mac và Windows: chưa kiểm. Văn bản GPL v3 ở `GPL-3.0.txt`, thông báo và cách lấy mã nguồn ở `NOTICE-ffmpeg.md`.

## Mô hình chép lời và nhận giọng (tải lúc dùng, chạy tại máy)

- Chép lời tiếng Việt: sherpa-onnx-zipformer-vi-int8-2025-04-20, gốc `zzasdf/viet_iter3_pseudo_label`, Apache-2.0. https://huggingface.co/zzasdf/viet_iter3_pseudo_label
- Tách đoạn người nói: pyannote/segmentation-3.0, MIT, chuyển sang ONNX bởi k2-fsa. https://huggingface.co/pyannote/segmentation-3.0
- Dò tiếng nói (khung Lời nói, từ v2.8): Silero VAD, MIT, tệp `silero_vad.onnx` do k2-fsa phát hành. https://github.com/snakers4/silero-vad
- Dấu giọng: CAM++ của 3D-Speaker (`iic/speech_campplus_sv_zh-cn_16k-common`), Apache-2.0. https://github.com/modelscope/3D-Speaker
- Thư viện chạy mô hình: sherpa-onnx, Apache-2.0. https://github.com/k2-fsa/sherpa-onnx

## Phông chữ

- Be Vietnam Pro, SIL Open Font License 1.1 (văn bản đầy đủ trong `tai_nguyen/phong/BeVietnamPro-OFL.txt`).

## Ghi chú riêng

- certifi: Mozilla Public License 2.0, giữ nguyên, không sửa.
- Apache-2.0: nếu gói có tệp NOTICE thì chép kèm vào bản cài.
