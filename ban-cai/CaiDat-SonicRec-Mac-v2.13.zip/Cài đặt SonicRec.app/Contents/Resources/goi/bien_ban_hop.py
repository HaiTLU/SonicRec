# SonicRec: tệp mốc để máy cài bản v1.6 trở xuống nhận ra gói cài này. Không phải mã ứng
# dụng (mã đã dịch nằm ở bien_ban_hop.pyc); trình cài không chép tệp này vào máy.
SO_BAN = "2.13"
MA_NGUON = "1fc3a8dd29c1f178a068d66eb932ecb6337c765f"
