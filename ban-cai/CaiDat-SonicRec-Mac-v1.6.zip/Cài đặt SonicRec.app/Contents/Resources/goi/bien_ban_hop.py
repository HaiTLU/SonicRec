#!/usr/bin/env python3
"""Máy chủ của ứng dụng SonicRec (trước 28/9/2026 tên Biên bản họp), chỉ chạy và
chỉ nghe trên chính laptop (Mac hoặc Windows).

Ghi âm thẳng trên máy (hoặc nhận tệp ghi âm kéo thả vào), chép lời, soạn biên
bản, xuất tệp Word. Giao diện là giao_dien.html, mở trong cửa sổ riêng do
ung_dung.py dựng. Máy chủ chỉ nghe ở 127.0.0.1: máy khác trong wifi không vào
được, nên không cần mã truy cập.

Hai lựa chọn ở thẻ Cài đặt (khoá cach_go_chu trong thong_tin_cuoc_hop.json):

  notebooklm  (mặc định, PM chọn 24/9/2026) Tải bản ghi lên một sổ NotebookLM
              riêng cho mỗi cuộc họp, lấy bản chép lời, nhờ NotebookLM soạn biên
              bản. Sổ được GIỮ LẠI trên NotebookLM (PM chọn). Dữ liệu họp đi lên
              Google qua đường nội bộ CHƯA công bố (thư viện notebooklm-py), có
              thể hỏng bất cứ lúc nào: hỏng hoặc chưa đăng nhập thì dừng ở Lỗi,
              GIỮ bản ghi để bấm Làm lại, và nói rõ vì sao.

  whisper     Tên khoá cũ, nay nghĩa là KHÔNG gửi lên mạng: chỉ ghi âm, giữ bản ghi
              trên máy và dựng khung biên bản, không chép lời; thư ký nghe lại để
              viết. PM chốt 26/9/2026 bỏ Whisper tại máy vì nặng máy (mô hình
              1,5 GB, chiếm khoảng 6 GB bộ nhớ lúc chạy). Giữ tên khoá để đọc được
              cài đặt và các cuộc họp cũ.

Chạy không có cửa sổ riêng (để dò lỗi):
    .venv/bin/python bien_ban_hop.py      rồi mở http://127.0.0.1:8787
"""

import asyncio
import contextlib
import hashlib
import io
import ipaddress
import json
import os
import re
import secrets
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import unicodedata
import uuid
import zipfile
from datetime import date, datetime, timedelta
from pathlib import Path
from urllib.parse import quote

import httpx
from fastapi import FastAPI, File, Header, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, JSONResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles

import ghi_am
import kich_hoat

THU_MUC_GOC = Path(__file__).resolve().parent
LA_WINDOWS = os.name == "nt"
AN_CUA_SO = ghi_am.AN_CUA_SO  # Windows: gọi ffmpeg không bật cửa sổ lệnh đen


CONG = int(os.environ.get("CONG", "8787"))  # đổi nếu cổng 8787 đã có thứ khác dùng

# Soạn tại máy qua Ollama (nếu máy có), chỉ dùng khi đã có bản chép lời mà
# NotebookLM soạn hỏng; không có Ollama thì máy trả khung biên bản
OLLAMA_URL = os.environ.get("OLLAMA_URL", "http://127.0.0.1:11434").rstrip("/")
OLLAMA_MODEL = os.environ.get("OLLAMA_MODEL", "")

GIOI_HAN_BYTE = 500 * 1024 * 1024  # chạy tại máy nên không bị trần 200 MB
TEP_MAC_DINH = Path(__file__).parent / "thong_tin_cuoc_hop.json"

# Mỗi cuộc họp một thư mục riêng ở đây: bản ghi, bản chép lời, biên bản, tệp Word.
# Trình cài cho chọn thư mục (PM yêu cầu 27/9/2026) và ghi vào cau-hinh-may.json;
# chưa chọn thì dùng cac-cuoc-hop cạnh mã. Trình cài KHÔNG nhận thư mục có thể đang
# đồng bộ lên mạng (Tài liệu, Màn hình, iCloud, OneDrive...): máy Mac bật đồng bộ
# iCloud cho Tài liệu thì bản ghi bị đẩy lên mạng, trái với lời hứa chủ trì đọc đầu buổi.
TEP_CAU_HINH_MAY = THU_MUC_GOC / "cau-hinh-may.json"


def thu_muc_luu_da_chon() -> Path | None:
    """Thư mục lưu trình cài đã ghi vào cau-hinh-may.json; không có thì None."""
    try:
        chon = str(json.loads(TEP_CAU_HINH_MAY.read_text(encoding="utf-8"))
                   .get("thu_muc_luu") or "").strip()
    except (OSError, ValueError, AttributeError):
        return None
    return Path(chon) if chon else None


THU_MUC_LUU = Path(os.environ.get("THU_MUC_LUU") or thu_muc_luu_da_chon()
                   or THU_MUC_GOC / "cac-cuoc-hop")

TRUONG_TIN = ["ten_cuoc_hop", "thoi_gian", "dia_diem", "chu_tri", "thu_ky",
              "tham_du", "chuong_trinh",
              # Tên loại họp chọn ở hộp Khai báo, quyết định mẫu biên bản (28/9/2026)
              "loai_hop",
              # Mục đích, vấn đề chính cần bàn: điền ở hộp Khai báo buổi họp (28/9/2026)
              "noi_dung",
              # Dán việc tuần trước vào đây thì biên bản có mục kiểm điểm
              "viec_tuan_truoc",
              # Đầu văn bản Word. Bỏ trống thì lấy mặc định trong tao_word.py:
              # Trường, Trung tâm, BB-TTC, Hà Nội
              "co_quan_chu_quan", "co_quan_ban_hanh", "ky_hieu", "dia_danh"]
# Sửa trong thẻ Cài đặt, cùng lưu vào thong_tin_cuoc_hop.json. micro_da_chon chỉ
# có khi người dùng TỰ chọn một micro; để trống là tự chọn micro gắn trong máy.
KHOA_CAI_DAT = TRUONG_TIN + ["micro_da_chon", "cach_go_chu", "nhip_tro_ly"]
# "whisper" nay nghĩa là KHÔNG gửi lên mạng (xem đầu tệp); giữ tên để đọc được việc cũ
CACH_GO_CHU = ("notebooklm", "whisper")
XONG = ("Xong", "Lỗi", "Bị gián đoạn")

app = FastAPI(title="SonicRec")
VIEC: dict[str, dict] = {}
THU_TU: list[str] = []  # mã các việc theo thứ tự nhận, để lấy việc gần nhất

# Những khoá ghi vào viec.json. Bản chép lời và biên bản ghi ra tệp chữ riêng
# để thư ký mở đọc được bằng bất kỳ trình soạn thảo nào.
KHOA_LUU = ["ma", "trang_thai", "loi", "canh_bao", "tt", "tep_ghi_am", "nhan_luc",
            "bat_dau", "ket_thuc", "thoi_luong_giay", "am_thanh_giay", "da_ky", "tep_word",
            "buoc", "nhat_ky", "cach", "cach_da_bao", "so_nlm", "tro_ly"]
# Cờ chỉ có nghĩa lúc đang chạy, không ghi xuống ổ (xem Trợ lý trong buổi họp)
TAM_THOI_TRO_LY = ("dang_gui", "yeu_cau", "dang_cho_google", "thoi_cho_google", "thu_lai",
                   "nen_da_thu_lai")
MAY_GHI = ghi_am.MayGhi()
# Tệp chữ trong thư mục mỗi cuộc họp: (tên tệp, khoá, tên cũ trước 27/9/2026). PM bỏ chữ
# "gỡ chữ", thay bằng "chép lời"; đọc tên cũ để cuộc họp cũ vẫn mở được.
# ghi-chu-thu-ky.txt: ô Ghi chú của thư ký, từ 27/9/2026 gửi làm ngữ cảnh (khoi_ngu_canh)
TEP_CHU = (("ban-chep-loi.txt", "ban_go_chu", "ban-go-chu.txt"), ("bien-ban.txt", "ket_qua", ""),
           ("ghi-chu-thu-ky.txt", "ghi_chu_rieng", "ghi-chu-rieng.txt"))


def _ghi_an_toan(duong: Path, noi_dung: str) -> None:
    """Ghi ra tệp tạm rồi đổi tên: tắt máy giữa chừng không để lại tệp dở."""
    tam = duong.with_name(duong.name + ".tam")
    tam.write_text(noi_dung, encoding="utf-8")
    tam.replace(duong)


def luu_viec(viec: dict) -> None:
    thu_muc = Path(viec["thu_muc"])
    for ten_tep, khoa, _ in TEP_CHU:
        if viec.get(khoa):
            _ghi_an_toan(thu_muc / ten_tep, viec[khoa])
    luu = {k: viec.get(k) for k in KHOA_LUU}
    if isinstance(luu["tro_ly"], dict):
        luu["tro_ly"] = {k: v for k, v in luu["tro_ly"].items() if k not in TAM_THOI_TRO_LY}
        if luu["tro_ly"].get("the") or luu["tro_ly"].get("ghi_nhanh"):
            _ghi_an_toan(thu_muc / "tro-ly.txt", chu_tro_ly(viec))
    _ghi_an_toan(thu_muc / "viec.json", json.dumps(luu, ensure_ascii=False, indent=1))


def nap_lai_lich_su() -> int:
    """Đọc lại các cuộc họp đã lưu lúc bật máy chủ. Việc nào đang chạy dở khi
    máy chủ tắt thì đánh dấu Bị gián đoạn, để bấm Làm lại từ bản ghi đã lưu."""
    if not THU_MUC_LUU.is_dir():
        return 0
    cac_viec = []
    for thu_muc in sorted(THU_MUC_LUU.iterdir()):
        tep = thu_muc / "viec.json"
        if not tep.is_file():
            continue
        try:
            cac_viec.append((json.loads(tep.read_text(encoding="utf-8")), thu_muc))
        except (OSError, ValueError):
            print(f"Bỏ qua {thu_muc.name}: viec.json hỏng")
    # Xếp theo giờ bắt đầu họp như tên thư mục, nhưng tính cả giây: tên thư mục chỉ tới
    # phút, hai cuộc họp cùng một phút thì theo mã ngẫu nhiên, và "biên bản buổi trước"
    # mới nhất có thể chọn nhầm cuộc họp cũ hơn
    cac_viec.sort(key=lambda x: (str(x[0].get("bat_dau") or x[0].get("nhan_luc") or ""),
                                 str(x[0].get("nhan_luc") or ""), x[1].name))
    for viec, thu_muc in cac_viec:
        viec["thu_muc"] = str(thu_muc)
        viec["ma"] = viec.get("ma") or thu_muc.name
        for ten_tep, khoa, ten_cu in TEP_CHU:
            f = thu_muc / ten_tep
            if ten_cu and not f.is_file() and (thu_muc / ten_cu).is_file():
                with contextlib.suppress(OSError):  # đổi sang tên mới; không được thì đọc tên cũ
                    (thu_muc / ten_cu).rename(f)
                f = f if f.is_file() else thu_muc / ten_cu
            viec[khoa] = f.read_text(encoding="utf-8") if f.is_file() else None
        viec["ban_go_chu"] = viec["ban_go_chu"] or ""
        if viec.get("trang_thai") == "Đang ghi âm":
            # Máy sập giữa buổi: các đoạn ADTS vẫn đọc được, nối lại để cứu
            tep = ghi_am.noi_doan(thu_muc)
            viec["tep_ghi_am"] = tep.name if tep else None
            viec["trang_thai"] = "Bị gián đoạn"
            viec["loi"] = ("Ứng dụng tắt khi đang ghi âm. Phần đã ghi vẫn còn, bấm Làm "
                           "lại để soạn biên bản từ phần đó." if tep else
                           "Ứng dụng tắt khi đang ghi âm và chưa kịp ghi được gì.")
            luu_viec(viec)
        elif viec.get("trang_thai") not in ("Xong", "Lỗi"):
            viec["trang_thai"] = "Bị gián đoạn"
            viec["loi"] = ("Ứng dụng tắt khi việc này đang chạy. Bấm Làm lại, máy "
                           "chạy tiếp từ bản ghi đã lưu.")
            luu_viec(viec)
        VIEC[viec["ma"]] = viec
        THU_TU.append(viec["ma"])
    return len(THU_TU)


def them_canh_bao(viec: dict, chu: str) -> None:
    viec["canh_bao"] = f"{viec['canh_bao']} {chu}" if viec.get("canh_bao") else chu


def ghi_nhat_ky(viec: dict, chu: str) -> None:
    """Dòng nhật ký hiện trên màn hình Đang xử lý và lưu vào viec.json. Ghi cả
    lúc bắt đầu một bước, để việc treo giữa chừng vẫn lộ ra là treo ở đâu."""
    viec["nhat_ky"] = (viec.get("nhat_ky") or []) + [[f"{datetime.now():%H:%M}", chu]]


def ngay_nd30(d) -> str:
    """Ngày dưới 10 và tháng 1, 2 thêm số 0 phía trước, theo Nghị định 30.
    Giống tao_word.ngay_thang_nam; để riêng vì tao_word cần python-docx."""
    ngay = f"{d.day:02d}" if d.day < 10 else str(d.day)
    thang = f"{d.month:02d}" if d.month < 3 else str(d.month)
    return f"ngày {ngay} tháng {thang} năm {d.year}"


def _dau_tep(duong_dan: Path, han: int) -> str:
    """Phần đầu ffmpeg in ra khi mở tệp: siêu dữ liệu của cả tệp và thời lượng (trước
    dòng "Stream #" đầu tiên). Rỗng nếu không đọc được.

    Dùng chính ffmpeg thay ffprobe: máy Mac cài từ 28/9/2026 chỉ có ffmpeg đi kèm gói
    imageio-ffmpeg, không có ffprobe."""
    if not shutil.which("ffmpeg"):
        return ""
    try:
        ra = subprocess.run(["ffmpeg", "-hide_banner", "-i", str(duong_dan)],
                            capture_output=True, encoding="utf-8", errors="replace",
                            timeout=han, **AN_CUA_SO)
    except (subprocess.SubprocessError, OSError):
        return ""
    return (ra.stderr or "").split("Stream #", 1)[0]


def thoi_diem_bat_dau(duong_dan: Path) -> datetime | None:
    """Giờ bắt đầu ghi, đọc từ siêu dữ liệu creation_time trong tệp ghi âm.

    Trước đây máy lấy giờ nhận tệp, tức giờ đã họp XONG, nên biên bản luôn lệch
    cả buổi. Không đọc được hoặc giờ vô lý thì trả None, để trống cho thư ký
    điền chứ không đoán, cùng tinh thần với quy tắc không đoán tên người nói."""
    m = re.search(r"^\s*creation_time\s*:\s*(\S+)", _dau_tep(duong_dan, 30), re.MULTILINE)
    if not m:
        return None
    try:
        t = datetime.fromisoformat(m[1].replace("Z", "+00:00"))
        t = t.astimezone().replace(tzinfo=None) if t.tzinfo else t
    except ValueError:
        return None
    bay_gio = datetime.now()
    if not bay_gio - timedelta(days=60) <= t <= bay_gio + timedelta(minutes=10):
        return None
    return t


# Giờ đọc từ siêu dữ liệu chưa được đối chiếu với tệp thật của ứng dụng Ghi Âm,
# nên ghi kèm dấu này cho thư ký soát. Đối chiếu đúng vài buổi thì bỏ dấu đi.
DAU_KIEM_GIO = " [cần kiểm tra]"


def dinh_dang_thoi_gian(bat_dau: datetime | None, nhan_luc: datetime,
                        chac: bool = False) -> str:
    """chac=True khi ghi âm ngay trên máy: giờ bắt đầu là giờ đồng hồ máy thật."""
    if bat_dau:
        dau = "" if chac else DAU_KIEM_GIO
        return (f"{bat_dau.hour} giờ {bat_dau.minute:02d} phút{dau}, "
                f"{ngay_nd30(bat_dau)}")
    return f"..... giờ ..... phút, {ngay_nd30(nhan_luc)}"


def tao_tep_word(viec: dict) -> None:
    """Dựng tệp Word theo mẫu Văn phòng Trường. Hỏng ở bước này thì chỉ cảnh báo,
    không làm hỏng cả việc, vì biên bản dạng chữ vẫn còn nguyên."""
    try:
        import tao_word  # cần python-docx; cài bằng trình cài
    except ImportError:
        them_canh_bao(viec, "Chưa cài python-docx nên chưa tạo được tệp Word. "
                            "Chạy lại trình cài đặt SonicRec.")
        return
    try:
        bat_dau = datetime.fromisoformat(viec["bat_dau"]) if viec.get("bat_dau") else None
        ngay = (bat_dau or datetime.fromisoformat(viec["nhan_luc"])).date()
        gio_ket_thuc = None
        if viec.get("ket_thuc"):  # ghi ngay trên máy: giờ bấm Dừng, có tính cả lúc tạm dừng
            kt = datetime.fromisoformat(viec["ket_thuc"])
            gio_ket_thuc = f"{kt.hour} giờ {kt.minute:02d} phút"
        elif bat_dau and viec.get("thoi_luong_giay"):
            kt = bat_dau + timedelta(seconds=viec["thoi_luong_giay"])
            gio_ket_thuc = f"{kt.hour} giờ {kt.minute:02d} phút{DAU_KIEM_GIO}"
        ten = tao_word.ten_tep_word(viec["tt"], ngay)
        tao_word.dung_bien_ban(viec.get("ket_qua") or "", viec["tt"], ngay,
                               gio_ket_thuc, Path(viec["thu_muc"]) / ten)
        viec["tep_word"] = ten
    except Exception as loi:  # noqa: BLE001 - mọi lỗi ở đây chỉ nên là cảnh báo
        them_canh_bao(viec, f"Không tạo được tệp Word ({ly_do_loi(loi)})")


def thong_tin_mac_dinh() -> dict:
    """Thông tin cuộc họp cố định trong thong_tin_cuoc_hop.json, sửa ở thẻ Cài đặt."""
    if not TEP_MAC_DINH.exists():
        return {}
    try:
        return json.loads(TEP_MAC_DINH.read_text(encoding="utf-8"))
    except ValueError:
        return {}


def tt_mac_dinh() -> dict:
    """Thông tin họp cho một cuộc họp mới, chụp lại ngay lúc bắt đầu."""
    mac_dinh = thong_tin_mac_dinh()
    tt = {k: str(mac_dinh.get(k) or "").strip() for k in TRUONG_TIN}
    tt["ten_cuoc_hop"] = tt["ten_cuoc_hop"] or "Cuộc họp"
    tt["loai_hop"] = loai_hop_cua(tt)["ten"]  # chưa chọn hay loại đã xoá: loại đầu danh sách
    return tt


def bo_noi_dung_da_dung() -> None:
    """Nội dung chính là của riêng từng buổi, như tệp liên quan: cuộc họp đã chụp vào tt
    thì bỏ khỏi thông tin mặc định, để buổi sau hộp Khai báo không điền sẵn trọng tâm cũ
    (trợ lý sẽ hiểu sai cả buổi). Các ô khác giữ làm mặc định như cũ."""
    tep = thong_tin_mac_dinh()
    if tep.get("noi_dung"):
        tep["noi_dung"] = ""
        with contextlib.suppress(OSError):
            _ghi_an_toan(TEP_MAC_DINH, json.dumps(tep, ensure_ascii=False, indent=2) + "\n")


# ----------------------------------------------------------------------------
# Loại họp và mẫu biên bản (PM duyệt tối 28/9/2026, cách (a): sửa ở thẻ Cài đặt)
# ----------------------------------------------------------------------------

# Mỗi dòng của "muc" là một mục của biên bản: tên mục, sau dấu hai chấm là lời dặn cho
# mục đó; mục cần bảng thì ghi "bảng gồm Cột 1 | Cột 2 | Cột 3". Họp giao ban giữ đúng
# các mục như trước nay; Buổi học nội bộ theo 5 mục PM duyệt.
LOAI_HOP_GOC = (
    {"ten": "Họp giao ban", "tieu_de": "BIÊN BẢN HỌP GIAO BAN",
     "muc": ("THÀNH PHẦN THAM DỰ\n"
             "NỘI DUNG: tách theo từng vấn đề, mỗi vấn đề ghi các ý kiến chính. Giữ nguyên "
             "con số, ngày tháng, tên riêng.\n"
             "KẾT LUẬN CỦA CHỦ TRÌ\n"
             "PHÂN CÔNG: bảng gồm Việc | Người phụ trách | Hạn hoàn thành. Đây là phần quan "
             "trọng nhất của họp giao ban, đừng bỏ sót việc nào."),
     "dan": ""},
    {"ten": "Buổi học nội bộ", "tieu_de": "BIÊN BẢN BUỔI HỌC NỘI BỘ",
     "muc": ("THÀNH PHẦN THAM DỰ: người trình bày, người tham gia\n"
             "NỘI DUNG CHUYÊN ĐỀ: ý chính người trình bày nói, theo từng phần\n"
             "THẢO LUẬN, HỎI ĐÁP: câu hỏi và câu trả lời, ghi tên người hỏi khi rõ\n"
             "KẾT LUẬN, ĐIỀU RÚT RA\n"
             "VIỆC CẦN LÀM SAU BUỔI HỌC: bảng gồm Việc | Người phụ trách | Hạn"),
     "dan": ""},
)
KHOA_LOAI_HOP = ("ten", "tieu_de", "muc", "dan")
TOI_DA_LOAI_HOP = 20
TOI_DA_MUC = 15
BANG_GOM = re.compile(r"bảng gồm\s*([^.\n]*)\.?\s*", re.IGNORECASE)
SO_DAU_DONG = re.compile(r"^\s*(?:[-*•+]\s*)?(?:\d+\s*[.)]\s*)?")
MUC_KIEM_DIEM = ("KIỂM ĐIỂM VIỆC TUẦN TRƯỚC: lấy đúng danh sách việc ở dưới, mỗi việc ghi "
                 "tình trạng theo lời trong cuộc họp (xong, đang làm, chưa làm, vướng gì). "
                 "Việc nào cuộc họp không nhắc tới thì ghi [không nhắc trong cuộc họp].")


def cac_muc(loai: dict) -> list[tuple[str, str, list[str]]]:
    """Các mục của một mẫu: (tên mục viết hoa, lời dặn, các cột nếu mục là bảng). Số thứ
    tự người dùng tự gõ thì bỏ, máy tự đánh số."""
    ra = []
    for dong in str(loai.get("muc") or "").splitlines():
        ten, _, dan = SO_DAU_DONG.sub("", dong, count=1).partition(":")
        ten, dan = " ".join(ten.split()), dan.strip()
        if ten:
            m = BANG_GOM.search(dan)
            ra.append((ten.upper(), dan,
                       [c.strip() for c in m.group(1).split("|") if c.strip()] if m else []))
    return ra


def kiem_loai_hop(x) -> tuple[dict | None, str]:
    """Một loại họp đã chuẩn hoá, hoặc (None, lý do không nhận)."""
    if not isinstance(x, dict) or any(not isinstance(x.get(k, ""), str) for k in KHOA_LOAI_HOP):
        return None, "Dữ liệu loại họp không hợp lệ"
    chu = {k: unicodedata.normalize("NFC", x.get(k) or "").strip() for k in KHOA_LOAI_HOP}
    chu["ten"] = " ".join(chu["ten"].split())
    chu["tieu_de"] = " ".join(chu["tieu_de"].split()).upper() or f"BIÊN BẢN {chu['ten'].upper()}"
    ten = chu["ten"]
    if not ten:
        return None, "Điền tên loại họp"
    if len(ten) > 60 or len(chu["tieu_de"]) > 120:
        return None, f"Tên hay tiêu đề của loại họp \"{ten[:40]}\" dài quá"
    muc = cac_muc(chu)
    if not muc:
        return None, f"Loại họp \"{ten}\" chưa có mục nào"
    if len(muc) > TOI_DA_MUC or len(chu["muc"]) > 4000 or len(chu["dan"]) > 2000:
        return None, f"Loại họp \"{ten}\" dài quá (tối đa {TOI_DA_MUC} mục)"
    sai = next((m[0] for m in muc if "|" in m[0]), "")
    if sai:
        return None, (f"Loại họp \"{ten}\", mục \"{sai[:40]}\": ghi dấu hai chấm sau tên mục, "
                      "rồi mới tới chữ bảng gồm")
    return chu, ""


def cac_loai_hop() -> list[dict]:
    """Các loại họp lưu ở thẻ Cài đặt; chưa lưu hay tệp hỏng thì dùng mẫu gốc."""
    ds = thong_tin_mac_dinh().get("cac_loai_hop")
    if isinstance(ds, list):
        sach = [x for x in (kiem_loai_hop(y)[0] for y in ds[:TOI_DA_LOAI_HOP]) if x]
        if sach:
            return sach
    return [dict(x) for x in LOAI_HOP_GOC]


def loai_hop_cua(tt: dict) -> dict:
    """Mẫu của cuộc họp: loại thư ký chọn ở hộp Khai báo. Đọc lúc soạn, nên sửa mẫu rồi
    bấm Làm lại thì dùng mẫu mới. Cuộc họp cũ (chưa có loại), loại đã xoá hay đổi tên thì
    dùng loại đầu danh sách."""
    ds = cac_loai_hop()
    ten = " ".join(str(tt.get("loai_hop") or "").split()).casefold()
    return next((x for x in ds if x["ten"].casefold() == ten), ds[0])


def cau_truc_bien_ban(loai: dict, co_tuan_truoc: bool, o_nguon: bool = False) -> str:
    """Khối "Cấu trúc bắt buộc" của câu lệnh soạn: các mục của mẫu, đánh số. Có việc tuần
    trước thì chèn mục kiểm điểm ngay sau mục đầu, như họp giao ban trước nay. o_nguon:
    danh sách việc tuần trước nằm ở nguồn Thông tin buổi họp chứ không ở trong câu lệnh."""
    dong = []
    for ten, dan, cot in cac_muc(loai):
        if cot:
            con = BANG_GOM.sub("", dan, count=1).strip()
            dong.append(f"{ten}: bảng {len(cot)} cột gồm {', '.join(cot)}."
                        + (f" {con}" if con else ""))
        else:
            dong.append(f"{ten}: {dan}" if dan else ten)
    if co_tuan_truoc:
        dong.insert(1, MUC_KIEM_DIEM.replace("ở dưới", f'trong nguồn "{TEN_THONG_TIN}"')
                    if o_nguon else MUC_KIEM_DIEM)
    return "\n".join(f"{i}. {d}" for i, d in enumerate(dong, 1))


def cau_lenh_soan(tt: dict, ban_go_chu: str | None = None, them: str = "",
                  o_nguon: bool = False) -> str:
    """Câu lệnh soạn biên bản theo mẫu Nghị định 30, theo mẫu của loại họp đã chọn
    (loai_hop_cua). Không kèm bản chép lời thì dùng cho NotebookLM: nội dung nằm sẵn
    trong nguồn được chọn. them: lời dặn thêm, ví dụ bản chép lời chỉ có phần đầu cuộc họp.
    o_nguon: danh sách việc tuần trước dài (xem viec_cu_qua_dai) nên nằm ở nguồn Thông tin
    buổi họp được chọn kèm, câu lệnh chỉ trỏ tới đó."""
    # Sổ của bản 3 có nhiều nguồn (từng đoạn, tài liệu...), nhưng lúc soạn chỉ chọn
    # MỘT nguồn: bản chép lời (hoặc bản ghi âm) của cả buổi (PM chốt 28/9/2026)
    if ban_go_chu:
        nguon = "Bản chép lời của cuộc họp:\n\n" + ban_go_chu
    elif o_nguon:
        # Buổi 28/9/2026 chọn nhiều nguồn thì biên bản lệch: nói rõ nguồn nào là lời nói
        nguon = (f'Nội dung cuộc họp nằm trong nguồn được chọn của sổ này, trừ nguồn "{TEN_THONG_TIN}": '
                 "nguồn đó là phần thư ký khai báo trước khi ghi âm, không phải lời nói trong cuộc "
                 "họp, chỉ dùng để lấy danh sách việc tuần trước")
    else:
        nguon = "Nội dung cuộc họp nằm trong nguồn được chọn của sổ này"
    them = f"\n{them.strip()}\n" if them.strip() else ""
    loai = loai_hop_cua(tt)
    # Có danh sách việc tuần trước thì biên bản có mục kiểm điểm (cau_truc_bien_ban)
    if not tt.get("viec_tuan_truoc"):
        khoi_tuan_truoc = ""
    elif o_nguon:
        khoi_tuan_truoc = (f'\nViệc đã phân công tuần trước: danh sách nằm trong nguồn "{TEN_THONG_TIN}", '
                           "mục Việc tuần trước. Kiểm điểm từng việc trong danh sách đó.\n")
    else:
        khoi_tuan_truoc = f"\nViệc đã phân công tuần trước:\n{tt['viec_tuan_truoc']}\n"
    # Thư ký khai báo trước khi ghi (28/9/2026); cuộc họp cũ không có mục này
    noi_dung = (f"- Nội dung chính (thư ký khai báo, chỉ để biết trọng tâm): {tt['noi_dung']}\n"
                if (tt.get("noi_dung") or "").strip() else "")
    dan = f"\nLời dặn riêng cho loại họp này: {loai['dan']}\n" if loai["dan"] else ""
    return f"""{nguon}

Soạn {loai['tieu_de']} bằng tiếng Việt từ nội dung trên.

Thông tin cố định, dùng đúng như ghi dưới đây, không tự sửa:
- Loại họp: {loai['ten']}
- Tên cuộc họp: {tt['ten_cuoc_hop']}
- Thời gian: {tt['thoi_gian']}
- Địa điểm: {tt['dia_diem']}
- Chủ trì: {tt['chu_tri']}
- Thư ký: {tt['thu_ky']}
- Tham dự: {tt['tham_du']}
- Chương trình dự kiến: {tt['chuong_trinh']}
{noi_dung}{khoi_tuan_truoc}{them}
Cấu trúc bắt buộc:
{cau_truc_bien_ban(loai, bool(tt.get("viec_tuan_truoc")), o_nguon)}
{dan}
Quy tắc:
- QUAN TRỌNG NHẤT: bản chép lời KHÔNG phân biệt được ai đang nói. Chỉ ghi tên người
  nêu ý kiến khi chính họ tự giới thiệu, hoặc khi người khác gọi tên họ ngay trong
  đoạn đó. Không chắc thì ghi [chưa rõ ai nói]. TUYỆT ĐỐI không đoán tên bằng cách
  lấy từ danh sách tham dự ở trên. Biên bản này sẽ được ký, gán sai tên là lỗi nặng.
- Chỉ ghi điều có trong nội dung trên. Không suy đoán, không thêm ý.
- Chỗ nghe không rõ thì ghi [nghe không rõ].
- Con số hoặc hạn hoàn thành không chắc thì ghi kèm [cần kiểm tra].
- Không dùng biểu tượng, không dùng gạch dài. Chỉ dùng gạch ngắn.
- Viết đầy đủ, không tóm tắt quá ngắn."""


def ngu_canh_bien_ban(viec: dict, tt: dict, truoc: float | None = None, luu_y: str = "") -> str:
    """Lời dặn thêm (luu_y) và ghi chú của thư ký gửi kèm câu lệnh soạn biên bản cuối, vừa
    trần TRAN_CAU_HOI. Ghi chú nhiều quá thì chỉ gửi các dòng gần nhất và nhắc thư ký đối
    chiếu các dòng đầu buổi."""
    con = tran_cau_hoi(viec) - so_byte(cau_lenh_soan(tt, them=luu_y, o_nguon=viec_cu_qua_dai(viec, tt))) - 8
    nc = khoi_ngu_canh(viec, truoc=truoc, toi_da=con) if con > 200 else ""
    if nc != khoi_ngu_canh(viec, truoc=truoc):
        them_canh_bao(viec, "Ghi chú của thư ký dài quá giới hạn gửi kèm nên máy chỉ gửi phần "
                            "gần nhất: đối chiếu lại biên bản với các ghi chú đầu buổi.")
    return "\n\n".join(x for x in (luu_y, nc) if x)


# ----------------------------------------------------------------------------
# Việc làm tại máy: đo bản ghi, soạn từ bản chép lời đã có
# ----------------------------------------------------------------------------

def do_dai_ban_ghi(duong_dan: Path) -> float:
    """Số giây của bản ghi, để đoán thời gian chờ. Trả 0 nếu không đo được."""
    m = re.search(r"^\s*Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", _dau_tep(duong_dan, 60),
                  re.MULTILINE)
    return int(m[1]) * 3600 + int(m[2]) * 60 + float(m[3]) if m else 0.0


# Tiếng nói thường to nhất cỡ -20 dB. Micro bị chặn quyền thì toàn số 0 (-91 dB);
# micro bị che hay đặt quá xa thì dưới -45 dB. Khi đó máy chép lời không nghe ra gì đúng.
NGUONG_IM_LANG_DB = -45.0


def muc_to_nhat(duong_dan: Path) -> float | None:
    """Mức to nhất của cả bản ghi (dB). None nếu không đo được."""
    if not shutil.which("ffmpeg"):
        return None
    try:
        ra = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-i", str(duong_dan),
                             "-af", "volumedetect", "-f", "null", "-"],
                            capture_output=True, encoding="utf-8", errors="replace",
                            timeout=600, **AN_CUA_SO)
    except (subprocess.SubprocessError, OSError):
        return None
    for dong in ra.stderr.splitlines():
        if "max_volume:" in dong:
            try:
                return float(dong.split("max_volume:")[1].split("dB")[0])
            except ValueError:
                return None
    return None


async def soan_bang_ollama(ban_go_chu: str, tt: dict) -> str | None:
    """Soạn biên bản bằng mô hình chạy tại máy. Trả None nếu không dùng được."""
    try:
        async with httpx.AsyncClient(timeout=1800) as c:
            ten = OLLAMA_MODEL
            if not ten:
                dap = await c.get(f"{OLLAMA_URL}/api/tags", timeout=10)
                cac_mo_hinh = (dap.json() or {}).get("models") or []
                if not cac_mo_hinh:
                    return None
                ten = cac_mo_hinh[0].get("name") or cac_mo_hinh[0].get("model")
            if not ten:
                return None
            dap = await c.post(f"{OLLAMA_URL}/api/generate", json={
                "model": ten, "stream": False,
                "prompt": cau_lenh_soan(tt, ban_go_chu),
                # keep_alive 0: nha bo nho ngay sau khi soan xong, quan trong
                # tren may 16 GB vi mac dinh Ollama giu mo hinh lai 5 phut
                "keep_alive": 0,
                "options": {"num_ctx": 32768, "temperature": 0.2},
            })
            if dap.status_code >= 400:
                return None
            chu = (dap.json() or {}).get("response") or ""
            return chu.strip() or None
    except (httpx.HTTPError, ValueError, KeyError):
        return None


GHI_CHU_KHUNG = ("Chưa có mô hình chạy tại máy để soạn nháp, nên phần dưới là bản chép lời "
                 "nguyên văn kèm mốc thời gian. Thư ký viết lại thành từng vấn đề rồi xoá "
                 "phần này.")
GHI_CHU_KHONG_GUI = ("Cuộc họp chọn Không gửi lên mạng nên máy không chép lời. Thư ký nghe lại "
                     "bản ghi để viết phần này thành từng vấn đề rồi xoá dòng này.")


def khung_bien_ban(ban_go_chu: str, tt: dict, ghi_chu: str = GHI_CHU_KHUNG) -> str:
    """Khung biên bản sẵn để sửa: khi không có mô hình soạn tại máy (kèm bản chép lời),
    hoặc cuộc họp Không gửi lên mạng (không có bản chép lời, thư ký nghe lại bản ghi).
    Các mục theo mẫu của loại họp; ghi chú và bản chép lời nằm ở mục chữ đầu tiên."""
    loai = loai_hop_cua(tt)
    phan = [f"{loai['tieu_de']}\n{tt['ten_cuoc_hop']}\n\nThời gian: {tt['thoi_gian']}\n"
            f"Địa điểm: {tt['dia_diem']}\nChủ trì: {tt['chu_tri']}\nThư ký: {tt['thu_ky']}",
            f"THÀNH PHẦN THAM DỰ\n{tt['tham_du']}", f"CHƯƠNG TRÌNH\n{tt['chuong_trinh']}"]
    if tt.get("viec_tuan_truoc"):
        phan.append(f"KIỂM ĐIỂM VIỆC TUẦN TRƯỚC\n{tt['viec_tuan_truoc']}")
    noi_dung = f"{ghi_chu}\n\n{ban_go_chu}"
    for ten, _, cot in cac_muc(loai):
        if ten.startswith("THÀNH PHẦN"):
            continue  # đã có ở trên, kèm danh sách tham dự
        if cot:  # bảng để thư ký điền: hàng tên cột và một hàng trống
            phan.append(f"{ten}\n\n{' | '.join(cot)}\n{' | '.join([''] * len(cot))}")
        else:
            phan.append(f"{ten}\n\n{noi_dung}\n" if noi_dung else f"{ten}\n")
            noi_dung = ""
    if noi_dung:  # mẫu chỉ có bảng: vẫn giữ chỗ cho ghi chú và bản chép lời
        phan.append(f"NỘI DUNG\n\n{noi_dung}")
    phan.append("Biên bản kết thúc. Biên bản được lập thành ... bản./.\n\n"
                "THƯ KÝ                              CHỦ TRÌ\n"
                "(Ký, ghi rõ họ tên)                 (Ký, ghi rõ họ tên)")
    return "\n\n".join(phan) + "\n"


async def soan_tu_ban_go_chu(ban_go_chu: str, tt: dict, viec: dict) -> None:
    viec["trang_thai"] = "Bước 2/2: đang soạn biên bản tại máy"
    viec["buoc"] = 2
    ghi_nhat_ky(viec, "Đang soạn biên bản tại máy")
    # Các dòng ghi nhanh của thư ký đi kèm (soạn tại máy, không gửi đi đâu)
    bien_ban = await soan_bang_ollama(
        "\n\n".join(x for x in (khoi_ngu_canh(viec), ban_go_chu) if x), tt)
    if bien_ban:
        viec["ket_qua"] = bien_ban
        ghi_nhat_ky(viec, "Soạn xong bản nháp")
    else:
        ghi_nhat_ky(viec, "Không có mô hình soạn nháp, dùng khung biên bản kèm bản chép lời")
        # Cộng thêm chứ không ghi đè: có thể đã có cảnh báo NotebookLM hỏng ở trước
        them_canh_bao(viec, "Không dùng được mô hình tại máy qua Ollama, nên trả về "
                            "khung biên bản kèm bản chép lời để thư ký viết lại.")
        viec["ket_qua"] = khung_bien_ban("\n\n".join(
            x for x in (khoi_ngu_canh(viec, cho_may=False), ban_go_chu) if x), tt)


# ----------------------------------------------------------------------------
# Đường 2: NotebookLM, qua thư viện notebooklm-py
#
# NotebookLM CHƯA có API công khai; thư viện này đi qua đường nội bộ của Google
# và có thể hỏng bất cứ lúc nào. Vì vậy mọi lỗi ở đây đều được bắt ở chay_viec:
# máy dừng ở Lỗi và GIỮ bản ghi để bấm Làm lại, không để cuộc họp nào mất bản ghi.
# ----------------------------------------------------------------------------

# Đồng hồ phía mình cho từng lời gọi Google (nguyên tắc a trong CLAUDE.md). Để ở
# đây để bộ kiểm thử rút ngắn được. Chờ Google chép lời tối đa 20 phút, bản ghi dài
# mấy cũng vậy: trước đây hạn tính theo độ dài bản ghi, bản ghi 188 phút mà Google
# không nhận được thì máy đứng chờ gần 5 tiếng (25/9/2026).
HAN_NLM = {"ket_noi": 60, "tao_so": 120, "tai_len": 1800, "go_chu": 1200,
           "loi_keo_dai": 180, "nhip": 10, "lay_chu": 300, "soan": 900,
           # Một đoạn trong lúc họp (bản 3): quá 10 phút thì gửi lại cùng đoạn sau;
           # một câu hỏi của trợ lý (thẻ gợi ý, tổng kết, ô Hỏi): quá 3 phút thì thôi
           "doan": 600, "hoi": 180,
           # Đợt 3: một lần tìm trên mạng hay trong Drive; chờ Google đọc một tài liệu
           "tim": 120, "tai_lieu": 300}
# NotebookLM chèn số trích dẫn [1], [2, 3], [4-6] vào câu trả lời; biên bản không cần
TRICH_DAN = re.compile(r"[ \t]*\[\d+(?:\s*[,-]\s*\d+)*\]")
# Truyền loại tệp tường minh: thư viện đoán theo đuôi tệp, mà bảng đoán của Python
# không có .m4a
LOAI_TEP = {".m4a": "audio/mp4", ".mp4": "audio/mp4", ".mp3": "audio/mpeg",
            ".wav": "audio/wav", ".aac": "audio/aac"}


def cach_go_chu() -> str:
    cach = str(thong_tin_mac_dinh().get("cach_go_chu") or CACH_GO_CHU[0]).strip()
    return cach if cach in CACH_GO_CHU else CACH_GO_CHU[0]


# ----------------------------------------------------------------------------
# Nhiều tài khoản Google (v1.3, PM chọn 30/9/2026)
#
# Tài khoản chính là phiên đăng nhập sẵn có. Thêm được tối đa TOI_DA_TK_PHU tài khoản dự
# phòng, đều của chính người dùng máy. Chỉ dùng để soạn biên bản cuối (và Làm lại): tài khoản
# đang dùng hết lượt hỏi trong ngày thì máy tự thử tài khoản kế, xem soan_nhieu_tai_khoan.
# Mỗi tài khoản dự phòng là một hồ sơ (profile) riêng của thư viện NotebookLM, phiên đăng nhập
# nằm ở thư mục hồ sơ của thư viện chứ không ở thư mục cài. Thứ tự dùng là thứ tự thêm vào.
# ----------------------------------------------------------------------------

TK_CHINH = "chinh"
TOI_DA_TK_PHU = 2
MAU_MA_TK_PHU = re.compile(r"du-phong-[1-9]")
MAU_GMAIL = re.compile(r"[\w.+-]{1,64}@[\w-]+(?:\.[\w-]+)+")
TEP_TAI_KHOAN = THU_MUC_GOC / "tai-khoan-google.json"


def _doc_tai_khoan() -> dict:
    """Sổ tài khoản: tên hiện ra cho tài khoản chính và danh sách tài khoản dự phòng. Tệp hỏng
    hay sai dạng thì coi như chưa có tài khoản dự phòng nào."""
    try:
        d = json.loads(TEP_TAI_KHOAN.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        d = {}
    if not isinstance(d, dict):
        d = {}
    chinh = d.get("chinh") if isinstance(d.get("chinh"), dict) else {}
    phu = {}  # mỗi mã một tài khoản: tệp sửa tay mà trùng mã thì giữ bản đầu, khỏi soạn hai lần ở một tài khoản
    for x in (d.get("phu") if isinstance(d.get("phu"), list) else []):
        if isinstance(x, dict) and isinstance(x.get("ma"), str) and MAU_MA_TK_PHU.fullmatch(x["ma"]):
            phu.setdefault(x["ma"], {"ma": x["ma"], "ten": str(x.get("ten") or "")[:60],
                                     "gmail": str(x.get("gmail") or "")[:100]})
    return {"chinh": {"ten": str(chinh.get("ten") or "")[:60], "gmail": str(chinh.get("gmail") or "")[:100]},
            "phu": list(phu.values())[:TOI_DA_TK_PHU]}


def cac_tai_khoan() -> list[dict]:
    """Tài khoản chính rồi các tài khoản dự phòng theo thứ tự thêm vào: {ma, ten, gmail}."""
    d = _doc_tai_khoan()
    return [{"ma": TK_CHINH, "ten": d["chinh"]["ten"] or "Tài khoản chính", "gmail": d["chinh"]["gmail"]},
            *d["phu"]]


def tai_khoan_cua(ma: str | None) -> dict | None:
    return next((x for x in cac_tai_khoan() if x["ma"] == (ma or TK_CHINH)), None)


def them_tai_khoan_phu(ten: str, gmail: str) -> dict:
    """Thêm một tài khoản dự phòng vào sổ (chưa đăng nhập). Mã lấy số nhỏ nhất còn trống."""
    ten, gmail = " ".join(ten.split()), gmail.strip()
    if not ten or len(ten) > 60:
        raise LoiRo("Đặt tên gọi cho tài khoản, tối đa 60 chữ.")
    if not MAU_GMAIL.fullmatch(gmail) or len(gmail) > 100:
        raise LoiRo("Địa chỉ Gmail chưa đúng dạng, ví dụ ten@gmail.com.")
    d = _doc_tai_khoan()
    if len(d["phu"]) >= TOI_DA_TK_PHU:
        raise LoiRo(f"Chỉ thêm được tối đa {TOI_DA_TK_PHU} tài khoản dự phòng. Xoá bớt một tài khoản rồi thêm.")
    if any(x["gmail"].casefold() == gmail.casefold() for x in [d["chinh"], *d["phu"]]):
        raise LoiRo("Địa chỉ Gmail này đã có trong danh sách.")
    dung = {x["ma"] for x in d["phu"]}
    ma = next(f"du-phong-{i}" for i in range(1, TOI_DA_TK_PHU + 2) if f"du-phong-{i}" not in dung)
    moi = {"ma": ma, "ten": ten, "gmail": gmail}
    d["phu"].append(moi)
    _ghi_an_toan(TEP_TAI_KHOAN, json.dumps(d, ensure_ascii=False, indent=2) + "\n")
    return moi


def xoa_tai_khoan_phu(ma: str) -> None:
    """Bỏ một tài khoản dự phòng khỏi sổ và xoá luôn phiên đăng nhập của nó trên máy."""
    d = _doc_tai_khoan()
    if not MAU_MA_TK_PHU.fullmatch(ma or "") or ma not in {x["ma"] for x in d["phu"]}:
        raise LoiRo("Không có tài khoản dự phòng này.")
    d["phu"] = [x for x in d["phu"] if x["ma"] != ma]
    _ghi_an_toan(TEP_TAI_KHOAN, json.dumps(d, ensure_ascii=False, indent=2) + "\n")
    with contextlib.suppress(Exception):
        from notebooklm.paths import get_profile_dir
        thu_muc = get_profile_dir(ma)
        # Chỉ xoá đúng thư mục hồ sơ mang tên tài khoản dự phòng, không xoá gì khác
        if thu_muc.name == ma and thu_muc.parent.name == "profiles" and thu_muc.is_dir():
            shutil.rmtree(thu_muc, ignore_errors=True)


def da_dang_nhap_nlm(ma: str | None = None) -> bool:
    """Đã có phiên đăng nhập NotebookLM lưu trên máy chưa (ma: tài khoản dự phòng; bỏ trống là
    tài khoản chính). Có tệp chưa chắc còn hạn: nút Kiểm tra kết nối ở thẻ Cài đặt mới thử thật."""
    try:
        from notebooklm.paths import get_storage_path
        return (get_storage_path(ma) if ma and ma != TK_CHINH else get_storage_path()).is_file()
    except Exception:  # noqa: BLE001 - chưa cài thư viện, hoặc thư viện đổi cách lưu
        return False


def ket_noi_nlm(ma: str | None = None):
    """Kết nối NotebookLM bằng phiên đã đăng nhập của tài khoản ma (bỏ trống là tài khoản chính,
    đúng như trước bản v1.3). Bộ kiểm thử thay hàm này."""
    from notebooklm import NotebookLMClient
    if ma and ma != TK_CHINH:
        return NotebookLMClient.from_storage(profile=ma)
    return NotebookLMClient.from_storage()


def dia_chi_so_nlm(so_id: str, gmail: str | None = None) -> str:
    """Địa chỉ mở sổ trên trình duyệt. gmail: sổ nằm ở tài khoản dự phòng (v1.3) thì thêm
    authuser để trình duyệt đang đăng nhập nhiều tài khoản Google mở đúng tài khoản đó."""
    dia_chi = f"https://notebooklm.google.com/notebook/{so_id}"
    return f"{dia_chi}?authuser={quote(gmail, safe='@')}" if gmail else dia_chi


class LoiRo(RuntimeError):
    """Lỗi máy tự đặt, câu đã viết sẵn cho người dùng đọc: hiện nguyên văn."""


def ly_do_loi(loi: BaseException) -> str:
    """Câu hiện cho người dùng khi một bước xử lý trực tuyến hỏng.

    Lỗi máy tự đặt (LoiRo) hiện nguyên văn. Lỗi của thư viện hay của mạng thì chỉ
    nói chung chung theo loại: không nêu tên dịch vụ, không hiện nguyên văn tiếng
    Anh của thư viện (PM yêu cầu 27/9/2026: phần mềm chỉ hiện trạng thái chung
    chung). Thư viện có hơn 200 chỗ tự báo lỗi, nhiều chỗ bằng RuntimeError trơn,
    nên không được coi mọi RuntimeError là câu của mình. Chi tiết đầy đủ in vào
    nhat-ky-ung-dung.txt để người phụ trách kỹ thuật còn tra."""
    if isinstance(loi, LoiRo):
        return str(loi)
    print(f"Chi tiết lỗi xử lý trực tuyến: {type(loi).__name__}: {loi}", flush=True)
    chu = f"{type(loi).__name__} {loi}".lower()
    if la_het_luot(loi):
        return "Dịch vụ xử lý báo đã hết lượt hôm nay hoặc đang bị hạn chế"
    if (isinstance(loi, (TimeoutError, asyncio.TimeoutError))
            or any(x in chu for x in ("timeout", "timed out"))):
        return "Dịch vụ xử lý không trả lời kịp"
    if la_qua_dai(loi):
        return "Dịch vụ xử lý không nhận câu hỏi, thường vì câu hỏi gửi lên dài quá"
    if any(x in chu for x in ("auth", "login", "cookie", "credential", "unauthorized",
                              "expired", "sign in", "401", "403")):
        return ("Phiên đăng nhập Google đã hết hạn hoặc bị từ chối: vào thẻ Cài đặt, bấm "
                "Đăng nhập lại")
    if isinstance(loi, (httpx.TransportError, ConnectionError)) or any(
            x in chu for x in ("connect", "network", "dns", "unreachable", "ssl", "resolve")):
        return "Mất kết nối mạng hoặc chưa tới được dịch vụ xử lý"
    if isinstance(loi, PermissionError):
        return ("Máy không cho ghi tệp: tệp đang mở ở chương trình khác (Word chẳng hạn), "
                "hoặc thiếu quyền ghi vào thư mục lưu")
    if isinstance(loi, OSError):
        return f"Lỗi đọc ghi tệp trên máy ({loi.strerror or type(loi).__name__})"
    return "Có lỗi khi xử lý, chi tiết ghi trong tệp nhật ký của ứng dụng"


async def _co_han(viec_con, giay: float, ten: str):
    try:
        return await asyncio.wait_for(viec_con, giay)
    except asyncio.TimeoutError:
        raise LoiRo(f"Quá {max(1, round(giay / 60))} phút chưa xong bước {ten}") from None


def _ban_tai_len(duong_dan: Path, tam: Path, ten: str = "ghi-am") -> Path:
    """Bản ghi trên máy là AAC dạng ADTS. Đổi vỏ sang m4a (chép nguyên luồng âm,
    không mã hoá lại, vài giây) vì m4a là dạng NotebookLM chắc chắn nhận. ten: tên
    tệp tải lên, cũng là tên nguồn khi dịch vụ không nhận tên riêng (xem tai_doan)."""
    if duong_dan.suffix.lower() != ".aac":
        return duong_dan
    ra = tam / f"{ten}.m4a"
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", str(duong_dan), "-c", "copy", str(ra)],
                   check=True, capture_output=True, timeout=600, **AN_CUA_SO)
    return ra


class ThoiChoGoogle(LoiRo):
    """Người dùng bấm Thôi chờ trên màn Đang xử lý."""


class GoogleKhongNhan(LoiRo):
    """Google không nhận bản ghi đã tải lên: báo lỗi kéo dài (bản ghi hiện màu đỏ
    trong sổ), hoặc bản ghi không còn trong sổ (người dùng đã xoá bản đỏ)."""


async def cho_google_go_chu(nlm, so: dict, viec: dict, nguon_id: str | None = None,
                            han: float | None = None, bao=None) -> None:
    """Chờ Google chép lời bản ghi vừa tải lên, tự hỏi trạng thái theo từng nhịp.

    Không dùng hàm chờ của thư viện: với tệp âm thanh, nó chờ tiếp cả khi Google
    báo lỗi (Google có lúc báo lỗi thoáng qua), nên bản ghi Google không nhận được
    thì máy đứng chờ hết hạn mà màn hình không nói gì. Ở đây: Google báo lỗi liên
    tục quá HAN_NLM["loi_keo_dai"] thì thôi, quá hạn thì thôi, bấm Thôi chờ Google
    thì thôi ngay; màn hình hiện đã chờ bao lâu.

    Mặc định chờ bản ghi so["nguon"] trong HAN_NLM["go_chu"] và báo lên dòng trạng
    thái của việc. Trợ lý trong buổi họp chờ từng đoạn (nguon_id), hạn ngắn hơn, và
    báo qua hàm bao(số phút đã chờ) để không đè trạng thái Đang ghi âm."""
    nguon_id = nguon_id or so["nguon"]
    han = han or HAN_NLM["go_chu"]
    han_phut = max(1, round(han / 60))
    sau_han = "máy dừng lại và giữ bản ghi để bấm Làm lại"
    bao = bao or (lambda phut: viec.__setitem__("trang_thai", (
        f"Bước 1/2: đang chép lời, đã chờ {phut} phút. Quá {han_phut} "
        f"phút chưa xong thì {sau_han}")))
    bat_dau = time.monotonic()
    lan_hoi = None  # lúc hỏi Google gần nhất
    loi_tu = None   # lúc Google bắt đầu báo lỗi liên tục
    viec["dang_cho_google"] = True
    try:
        while True:
            bay_gio = time.monotonic()
            if viec.get("thoi_cho_google"):
                raise ThoiChoGoogle("Đã thôi chờ chép lời theo nút bấm")
            if bay_gio - bat_dau > han:
                raise LoiRo(f"Quá {han_phut} phút chưa chép lời xong")
            bao(int((bay_gio - bat_dau) // 60))
            if lan_hoi is None or bay_gio - lan_hoi >= HAN_NLM["nhip"]:
                lan_hoi = bay_gio
                nguon = await _co_han(nlm.sources.get_or_none(so["id"], nguon_id),
                                      HAN_NLM["ket_noi"], "xem chép lời tới đâu")
                if nguon is None:
                    raise GoogleKhongNhan("Bản ghi không còn trên dịch vụ xử lý")
                if getattr(nguon, "is_ready", False):
                    return
                if getattr(nguon, "is_error", False):
                    loi_tu = bay_gio if loi_tu is None else loi_tu
                    if bay_gio - loi_tu >= HAN_NLM["loi_keo_dai"]:
                        raise GoogleKhongNhan("Dịch vụ xử lý không nhận bản ghi này")
                else:
                    loi_tu = None
            await asyncio.sleep(min(1.0, HAN_NLM["nhip"]))
    finally:
        viec["dang_cho_google"] = False


async def tao_so(nlm, viec: dict, tt: dict, ma_tk: str | None = None) -> dict:
    """Tạo sổ NotebookLM mới cho cuộc họp và ghi nhớ vào việc. ma_tk: tài khoản dự phòng
    chủ sổ (v1.3); sổ của tài khoản chính không ghi tai_khoan, như trước nay."""
    moi = await _co_han(nlm.notebooks.create(
        f"Biên bản {tt['ten_cuoc_hop']} {datetime.now():%Y-%m-%d %H:%M}"),
        HAN_NLM["tao_so"], "tạo bản lưu trực tuyến")
    so = {"id": moi.id, "ten": moi.title}
    if ma_tk and ma_tk != TK_CHINH:
        # Ghi luôn Gmail của tài khoản lúc tạo: sau này tài khoản có bị xoá khỏi danh sách thì
        # nút Mở bản lưu trực tuyến vẫn biết mở đúng tài khoản
        so["tai_khoan"] = ma_tk
        so["gmail"] = (tai_khoan_cua(ma_tk) or {}).get("gmail", "")
    viec["so_nlm"] = so
    luu_viec(viec)
    ghi_nhat_ky(viec, "Đã tạo bản lưu trực tuyến cho cuộc họp")
    return so


async def dong_notebooklm(duong_dan: Path, tt: dict, viec: dict, them: str = "",
                          them_gon: str = "", ma_tk: str | None = None) -> None:
    """Một sổ NotebookLM cho mỗi cuộc họp: tải bản ghi lên, chờ Google chép lời, lấy
    bản chép lời về, nhờ soạn biên bản. Sổ được GIỮ LẠI (PM chọn 24/9/2026) để mở
    lại xem trên notebooklm.google.com. Làm lại thì dùng lại đúng sổ đó, và bước
    nào đã xong (đã tải lên, đã có bản chép lời) thì không làm lại. them: lời dặn
    thêm cho câu lệnh soạn (kèm ghi chú của thư ký, xem ngu_canh_bien_ban); them_gon:
    phần bắt buộc giữ lại khi Google không nhận câu lệnh vì dài quá và phải soạn lại.
    ma_tk: tài khoản Google dùng (v1.3; bỏ trống là tài khoản chính). Sổ của cuộc họp thuộc
    tài khoản khác thì tài khoản này không mở được, nên tạo sổ mới ở đây."""
    giay = viec.get("thoi_luong_giay") or await asyncio.to_thread(do_dai_ban_ghi, duong_dan)
    viec["thoi_luong_giay"] = giay
    viec["buoc"] = 1
    viec["trang_thai"] = "Bước 1/2: đang kết nối"
    ma_tk = ma_tk or TK_CHINH
    so = dict(viec.get("so_nlm") or {})
    if so.get("id") and (so.get("tai_khoan") or TK_CHINH) != ma_tk:
        so = {}
    so_moi = False
    async with contextlib.AsyncExitStack() as ngan:
        nlm = await _co_han(ngan.enter_async_context(ket_noi_nlm(ma_tk)), HAN_NLM["ket_noi"],
                            "kết nối")
        if so.get("id") and not await _co_han(nlm.notebooks.get_or_none(so["id"]),
                                               HAN_NLM["ket_noi"], "tìm bản lưu cũ"):
            so = {}  # sổ cũ đã bị xoá trên NotebookLM: tạo sổ mới
        if not so.get("id"):
            so = dict(await tao_so(nlm, viec, tt, ma_tk))
            so_moi = True
            # Ghi chú "Ghi chú trong buổi họp" nằm ở sổ cũ: sổ mới phải tạo ghi chú mới (ghi_so_tay)
            if isinstance(viec.get("tro_ly"), dict):
                viec["tro_ly"]["ghi_chu_so"] = None

        # Đã có bản chép lời mà bản ghi trong sổ chưa dùng được (đỏ, còn đang xử lý, hoặc
        # đã bị xoá). Thường gặp ở việc cũ có bản chép lời của Whisper (bản trước 26/9/2026),
        # sau khi Google không nhận hay quá hạn chờ. Soạn trên bản ghi đó thì NotebookLM không có gì để đọc, nên
        # bỏ nó, gửi chữ lên.
        if so.get("nguon") and viec.get("ban_go_chu"):
            cu = await _co_han(nlm.sources.get_or_none(so["id"], so["nguon"]),
                               HAN_NLM["ket_noi"], "xem bản ghi cũ")
            if not getattr(cu, "is_ready", False):
                with contextlib.suppress(Exception):
                    await _co_han(nlm.sources.delete(so["id"], so["nguon"]),
                                  HAN_NLM["ket_noi"], "xoá bản ghi cũ")
                so.pop("nguon", None)

        # Google không nhận bản tải lên (bản ghi hiện màu đỏ, báo "hãy thử lại") thì
        # bỏ bản đó và tải lên lại MỘT lần. 25/9/2026: tệp 188 phút tải qua ứng dụng
        # bị đỏ, PM tự tải lại đúng tệp đó lên NotebookLM thì được. Làm lại cũng đi
        # đường này: bản cũ đã đỏ hoặc đã bị xoá khỏi sổ thì tải lên lại.
        so_lan_tai = 0
        while True:
            if not so.get("nguon"):
                if viec.get("ban_go_chu"):
                    # Đã có bản chép lời (của Google, hoặc của Whisper ở việc cũ): gửi chữ,
                    # khỏi tải âm thanh lên
                    nguon = await _co_han(nlm.sources.add_text(
                        so["id"], "Bản chép lời cuộc họp", viec["ban_go_chu"], wait=True,
                        wait_timeout=300), 360, "nhận bản chép lời")
                else:
                    # Lưới an toàn cho lời hứa với người họp: cuộc họp đã chuyển sang
                    # Không gửi lên mạng giữa buổi thì không bao giờ tải bản ghi lên
                    if (viec.get("tro_ly") or {}).get("chuyen_luc") is not None:
                        raise LoiRo("Cuộc họp đã chuyển sang Không gửi lên mạng giữa "
                                    "buổi nên máy không tải bản ghi lên")
                    so_lan_tai += 1
                    viec["trang_thai"] = ("Bước 1/2: đang tải bản ghi lên"
                                          + (" lần nữa" if so_lan_tai > 1 else ""))
                    with tempfile.TemporaryDirectory() as tam:
                        tep = await asyncio.to_thread(_ban_tai_len, duong_dan, Path(tam))
                        nguon = await _co_han(nlm.sources.add_file(
                            so["id"], tep, LOAI_TEP.get(tep.suffix.lower())),
                            HAN_NLM["tai_len"], "tải bản ghi lên")
                    ghi_nhat_ky(viec, "Tải lên xong, đang chép lời")
                so["nguon"] = nguon.id
                viec["so_nlm"] = so
                luu_viec(viec)
            if viec.get("ban_go_chu"):
                break
            try:
                await cho_google_go_chu(nlm, so, viec)
                break
            except GoogleKhongNhan as loi:
                with contextlib.suppress(Exception):  # xoá bản đỏ khỏi sổ; không được thì thôi
                    await _co_han(nlm.sources.delete(so["id"], so["nguon"]),
                                  HAN_NLM["ket_noi"], "xoá bản ghi không được nhận")
                so.pop("nguon", None)
                viec["so_nlm"] = so
                luu_viec(viec)
                if so_lan_tai >= 2:
                    raise GoogleKhongNhan(f"{loi}. Đã tải lên {so_lan_tai} lần") from None
                ghi_nhat_ky(viec, "Bản ghi không được nhận, xoá bản đó và tải lên lại")

        if not viec.get("ban_go_chu"):
            ft = await _co_han(nlm.sources.get_fulltext(so["id"], so["nguon"]),
                               HAN_NLM["lay_chu"], "lấy bản chép lời")
            chu = (getattr(ft, "rendered_content", "") or ft.content or "").strip()
            if len(chu) < 20:
                raise LoiRo("Dịch vụ xử lý không trả về bản chép lời")
            viec["ban_go_chu"] = chu
            luu_viec(viec)  # lưu ngay: bước soạn có hỏng thì bản chép lời vẫn còn
            ghi_nhat_ky(viec, "Chép lời xong")

        viec["buoc"] = 2
        viec["trang_thai"] = "Bước 2/2: đang soạn biên bản"
        ghi_nhat_ky(viec, "Đang soạn biên bản")
        # Chỉ chọn bản chép lời (hoặc bản ghi âm) của cả buổi, không chọn tài liệu cho
        # trợ lý hay các đoạn (PM chốt 28/9/2026, thay quyết định 27/9). Buổi 28/9 máy chọn
        # thêm tài liệu và biên bản lệch từ giữa buổi; PM tự tích riêng bản chép lời trên
        # NotebookLM rồi gõ "làm biên bản họp" thì ra đúng. Ghi chú của thư ký vẫn đi kèm
        # trong câu lệnh (them).
        # Ngoại lệ: danh sách việc tuần trước dài tới mức chép vào câu lệnh thì hết chỗ cho ghi
        # chú của thư ký (PM chốt 30/9/2026). Khi đó chọn thêm nguồn Thông tin buổi họp, nơi đã
        # có danh sách, và câu lệnh chỉ trỏ tới đó
        nguon_chon, o_nguon = [so["nguon"]], False
        if viec_cu_qua_dai(viec, tt):
            them_nguon = await nguon_viec_cu(nlm, viec, so, so_moi)
            if them_nguon:
                nguon_chon, o_nguon = nguon_chon + them_nguon, True
                ghi_nhat_ky(viec, "Danh sách việc tuần trước dài: biên bản cuối đọc thêm nguồn "
                                  "Thông tin buổi họp")
            else:
                them_canh_bao(viec, "Danh sách việc tuần trước dài mà máy chưa đưa được lên nguồn "
                                    "Thông tin buổi họp nên chép thẳng vào câu lệnh: đối chiếu mục "
                                    "kiểm điểm với danh sách.")
        tinh_mot_luot(ma_tk)
        cau = cau_lenh_soan(tt, them=them, o_nguon=o_nguon)
        try:
            dap = await _co_han(nlm.chat.ask(so["id"], cau, source_ids=nguon_chon),
                                HAN_NLM["soan"], "soạn biên bản")
        except Exception as loi:
            if them == them_gon or not la_qua_dai(loi):
                raise
            # Google không nhận câu lệnh vì dài quá (xem TRAN_CAU_HOI): soạn lại một lần,
            # không kèm ghi chú của thư ký, và nhắc thư ký đối chiếu
            print(f"Câu lệnh soạn ({so_byte(cau)} byte) không được nhận, soạn lại không kèm ghi "
                  f"chú: {type(loi).__name__}: {loi}", flush=True)
            ghi_nhat_ky(viec, f"Câu lệnh soạn {so_byte(cau)} byte không được nhận, soạn lại "
                              "không kèm ghi chú của thư ký")
            ha_tran(viec, cau)  # Làm lại thì ghi chú gửi kèm được giữ ngắn hơn
            them_canh_bao(viec, "Câu lệnh soạn dài quá giới hạn của dịch vụ nên máy soạn lại "
                                "không kèm ghi chú của thư ký: đối chiếu tên người, con số và hạn "
                                "với ghi chú.")
            tinh_mot_luot(ma_tk)
            dap = await _co_han(nlm.chat.ask(so["id"], cau_lenh_soan(tt, them=them_gon, o_nguon=o_nguon),
                                             source_ids=nguon_chon),
                                HAN_NLM["soan"], "soạn biên bản")
        bien_ban = TRICH_DAN.sub("", dap.answer or "").strip()
        if len(bien_ban) < 50:
            raise LoiRo("Dịch vụ xử lý trả về biên bản rỗng")
        viec["ket_qua"] = bien_ban
        ghi_nhat_ky(viec, "Soạn xong bản nháp")


async def soan_nhieu_tai_khoan(duong_dan: Path, tt: dict, viec: dict, them: str = "",
                               them_gon: str = "") -> None:
    """Soạn biên bản cuối bằng tài khoản chính; tài khoản đó hết lượt hỏi thì thử lần lượt các
    tài khoản dự phòng đã đăng nhập, theo thứ tự thêm vào (v1.3, PM chọn 30/9/2026). Chỉ hết lượt
    mới chuyển; lỗi khác (mạng, đăng nhập hết hạn...) báo như trước nay. Tài khoản Google đã
    báo hết lượt hôm nay thì lần sau bỏ qua, trừ khi tài khoản nào cũng đã hết (khi đó thử hết,
    vì lượt của Google tính theo cửa sổ trượt nên có thể đã có lại). Sổ của cuộc họp nằm ở tài
    khoản nào thì các việc sau (ghi sổ tay, mở bản lưu trực tuyến) dùng đúng tài khoản đó."""
    dang_nhap = [x for x in cac_tai_khoan() if x["ma"] == TK_CHINH or da_dang_nhap_nlm(x["ma"])]
    thu = [x for x in dang_nhap if not da_het_luot_hom_nay(x["ma"])] or dang_nhap
    da_co = {x["ma"] for x in dang_nhap}
    chua_dn = [x["ten"] for x in cac_tai_khoan() if x["ma"] not in da_co]  # thêm rồi mà chưa đăng nhập
    loi_cuoi: BaseException | None = None
    for i, tk in enumerate(thu):
        try:
            await dong_notebooklm(duong_dan, tt, viec, them=them, them_gon=them_gon, ma_tk=tk["ma"])
        except Exception as loi:  # noqa: BLE001 - chỉ hết lượt mới chuyển, còn lại ném lên như cũ
            if not la_het_luot(loi):
                raise
            danh_dau_het_luot(tk["ma"])
            loi_cuoi = loi
            ghi_nhat_ky(viec, f'Tài khoản "{tk["ten"]}" hết lượt hỏi hôm nay'
                              + (", thử tài khoản kế" if i + 1 < len(thu) else ""))
            continue
        danh_dau_het_luot(tk["ma"], het=False)  # hỏi được nghĩa là tài khoản này còn lượt
        if tk["ma"] != TK_CHINH:
            ghi_nhat_ky(viec, f'Soạn biên bản bằng tài khoản dự phòng "{tk["ten"]}"')
            # Có trợ lý trong buổi họp thì các thẻ tóm tắt đã nằm ở sổ của tài khoản chính
            con_lai = ("; các đoạn tóm tắt trong lúc họp vẫn nằm ở tài khoản trước"
                       if (viec.get("tro_ly") or {}).get("doan") else "")
            them_canh_bao(viec, f'Biên bản này soạn bằng tài khoản dự phòng "{tk["ten"]}" vì tài '
                                "khoản dùng trước đó đã hết lượt hỏi hôm nay. Bản lưu trực tuyến "
                                f"của buổi họp nằm ở tài khoản này{con_lai}.")
        return
    assert loi_cuoi is not None
    if len(thu) > 1:
        them_canh_bao(viec, f"Đã thử {len(thu)} tài khoản, tất cả đều hết lượt hỏi hôm nay.")
    if chua_dn:
        them_canh_bao(viec, "Tài khoản dự phòng chưa đăng nhập nên chưa dùng được: "
                            + ", ".join(chua_dn) + ". Đăng nhập ở thẻ Cài đặt.")
    raise loi_cuoi


# ----------------------------------------------------------------------------
# Trợ lý trong buổi họp (bản 3, PM duyệt 26/9/2026)
#
# Trong lúc ghi, tới nhịp (mặc định 5 phút) hoặc khi bấm Tóm tắt ngay, máy cắt
# phần vừa ghi mà không ngắt ghi âm, gửi lên sổ NotebookLM của cuộc họp và lấy chữ
# về. Bấm Dừng thì chỉ còn đoạn cuối phải chờ, rồi soạn biên bản từ chữ các đoạn,
# nên biên bản ra nhanh dù họp dài. Hỏng gì ở đây cũng không đụng tới ghi âm: đoạn
# hỏng thì phần âm thanh đó đi cùng lần gửi sau; lúc Dừng mà còn quãng chưa có chữ
# thì máy lùi về cách cũ, tải cả bản ghi lên.
# ----------------------------------------------------------------------------

NHIP_TRO_LY = ("0", "5", "10")  # phút giữa hai lần gửi; "0" là chỉ khi bấm Tóm tắt ngay
NHIP_MAC_DINH = "5"             # PM chọn 26/9/2026
GIAY_MOI_PHUT = 60              # bộ kiểm thử rút ngắn
DOAN_NGAN_NHAT = 60             # giây: phần mới ngắn hơn thì chưa gửi
DOAN_NGAN_NHAT_NUT = 20         # giây: khi bấm Tóm tắt ngay
IT_CHU_NHAT = 5                 # chữ: bản chép lời một đoạn ít hơn thì coi là không nghe ra lời
NHIP_VONG = 2.0                 # giây giữa hai lần xem đã tới nhịp chưa
LOI_LIEN_TOI_DA = 3             # hỏng liền chừng này lần thì trợ lý tạm nghỉ
# Tự gửi hỏng thì không chờ tròn một nhịp (PM chọn 30/9/2026): thử lại sau chừng này phút
# ghi âm ở lần hỏng thứ nhất và thứ hai; từ lần thứ ba (đã tạm nghỉ) mỗi nhịp thử một lần
CACH_THU_LAI = (1, 2)
# Tài liệu nền gửi hỏng thì tự gửi lại, tối đa LAN_TOI_DA_NEN lần tính cả lần đầu, lần thử lại
# thứ nhất sau 0,5 phút và thứ hai sau 2 phút (giờ đồng hồ). Hết lần thì chờ bấm Tóm tắt ngay
LAN_TOI_DA_NEN = 3
CACH_THU_LAI_NEN = (0.5, 2)
TRAN_NGUON, GIU_NGUON = 50, 2   # 50 nguồn mỗi sổ; chừa 2 cho đoạn cuối và chữ ghép
# 50 lượt hỏi mỗi ngày với tài khoản thường (trang trợ giúp của Google, 9/2026)
TRAN_LUOT = 50
TEP_LUOT = THU_MUC_GOC / "luot-hoi-notebooklm.json"


def moi_tro_ly() -> dict:
    """Trạng thái trợ lý của một cuộc họp, lưu trong viec.json (khoá tro_ly).
    con_tro: vị trí byte đã gửi tới, tính trên các đoạn ghi nối liền; giay_da_cat:
    số giây âm thanh tương ứng; giay_xet: lúc xét gửi gần nhất (giây đã ghi);
    chuyen_luc: giây âm thanh lúc chuyển sang Không gửi lên mạng giữa buổi.
    the: các thẻ của trợ lý; ghi_nhanh: các dòng thư ký ghi nhanh vào biên bản;
    hoi_thoai_rieng: mã cuộc trò chuyện NotebookLM của ô Hỏi (thẻ mỗi đoạn hỏi không
    kèm mã và không kèm lịch sử, xem hoi_nlm). moc_am: mốc ghi chú và chuyen_luc tính theo
    giây âm thanh thật (từ 28/9/2026); cuộc họp cũ tính theo đồng hồ, xem ti_le_moc.
    thong_tin: nguồn chữ "Thông tin buổi họp" thư ký khai báo trước khi ghi. tran (chỉ có
    khi Google đã không nhận một câu hỏi vì dài quá): trần độ dài câu hỏi đã hạ, xem ha_tran."""
    return {"con_tro": 0, "giay_da_cat": 0.0, "giay_xet": 0.0, "doan": [], "loi_lien": 0,
            "tam_nghi": "", "chuyen_luc": None, "trang_thai": "", "the": [], "ghi_nhanh": [],
            "hoi_thoai_rieng": None, "het_luot": False, "moc_am": True,
            "thong_tin": None}


def nhip_tro_ly() -> int:
    """Số giây giữa hai lần gửi; 0 là chỉ gửi khi bấm Tóm tắt ngay."""
    nhip = str(thong_tin_mac_dinh().get("nhip_tro_ly") or NHIP_MAC_DINH).strip()
    return int(nhip if nhip in NHIP_TRO_LY else NHIP_MAC_DINH) * GIAY_MOI_PHUT


def moc(giay: float) -> str:
    """Mốc trong bản ghi, dạng phút:giây như bản chép lời cũ."""
    return f"{int(giay // 60):02d}:{int(giay % 60):02d}"


def ti_le_moc(viec: dict) -> float:
    """Hệ số đổi mốc ghi chú về mốc âm thanh. Cuộc họp ghi từ 28/9/2026 đã gắn mốc
    theo âm thanh thật (moc_am): hệ số 1. Cuộc họp cũ gắn mốc theo đồng hồ ghi, mà
    máy rớt tiếng thì âm thanh ngắn hơn đồng hồ: đổi theo tỉ lệ cả buổi (độ dài âm
    thanh trên độ dài đồng hồ), vì máy rớt đều suốt buổi."""
    if (viec.get("tro_ly") or {}).get("moc_am"):
        return 1.0
    am, dong_ho = viec.get("am_thanh_giay"), viec.get("thoi_luong_giay")
    if not am or not dong_ho:
        return 1.0
    ti_le = am / dong_ho
    return ti_le if 0.5 <= ti_le < 0.99 else 1.0


def _luot_hom_nay() -> dict:
    """Số lượt đã dùng hôm nay: da_dung là của tài khoản chính, tk của từng tài khoản dự phòng
    (v1.3); het là các tài khoản Google đã báo hết lượt hôm nay. Sang ngày mới thì đếm lại."""
    hom_nay = f"{datetime.now():%Y-%m-%d}"
    try:
        d = json.loads(TEP_LUOT.read_text(encoding="utf-8"))
        if d.get("ngay") == hom_nay and isinstance(d.get("da_dung"), int):
            tk = d.get("tk") if isinstance(d.get("tk"), dict) else {}
            het = d.get("het") if isinstance(d.get("het"), list) else []
            return {"ngay": hom_nay, "da_dung": d["da_dung"],
                    "tk": {k: v for k, v in tk.items() if isinstance(v, int)},
                    "het": [x for x in het if isinstance(x, str)]}
    except (OSError, ValueError, AttributeError):
        pass
    return {"ngay": hom_nay, "da_dung": 0, "tk": {}, "het": []}


def _ghi_luot(d: dict) -> None:
    with contextlib.suppress(OSError):
        _ghi_an_toan(TEP_LUOT, json.dumps(d))


def luot_con_lai(ma: str | None = None) -> int:
    """Lượt hỏi còn lại hôm nay của tài khoản ma (bỏ trống là tài khoản chính)."""
    d = _luot_hom_nay()
    da = d["da_dung"] if not ma or ma == TK_CHINH else d["tk"].get(ma, 0)
    return max(0, TRAN_LUOT - da)


def tinh_mot_luot(ma: str | None = None) -> None:
    """Đếm TRƯỚC khi hỏi, vì câu hỏi hỏng giữa đường vẫn có thể đã bị Google tính.
    Chỉ đếm được lượt của ứng dụng này: hỏi thêm trên trình duyệt cùng tài khoản thì
    Google vẫn tính mà máy không biết."""
    d = _luot_hom_nay()
    if not ma or ma == TK_CHINH:
        d["da_dung"] += 1
    else:
        d["tk"][ma] = d["tk"].get(ma, 0) + 1
    _ghi_luot(d)


def da_het_luot_hom_nay(ma: str | None = None) -> bool:
    """Google đã báo tài khoản này hết lượt hôm nay (khác với số lượt máy tự đếm)."""
    return (ma or TK_CHINH) in _luot_hom_nay()["het"]


def danh_dau_het_luot(ma: str | None = None, het: bool = True) -> None:
    """Ghi (het=True) hay bỏ (het=False) dấu "báo hết lượt hôm nay" của một tài khoản."""
    d = _luot_hom_nay()
    ma = ma or TK_CHINH
    if (ma in d["het"]) == het:
        return
    if het:
        d["het"].append(ma)
    else:
        d["het"].remove(ma)
    _ghi_luot(d)


def la_het_luot(loi: BaseException) -> bool:
    """Google báo hết lượt, hoặc bị hỏi dồn quá nhanh."""
    chu = f"{type(loi).__name__} {loi}".lower()
    return any(x in chu for x in ("ratelimit", "rate limit", "quota", "resource_exhausted"))


# Google không nhận câu hỏi dài hơn khoảng 5.500 (thư viện NotebookLM ghi ở mục #1472;
# thư viện báo "rejected by the server", không nói tới hết lượt). Buổi học tối 28/9/2026:
# thẻ hỏng từ đoạn 4, vì khối diễn biến gửi kèm dài thêm sau mỗi thẻ và câu hỏi đoạn 4 đã
# quá 5.000 byte. Mọi câu hỏi gửi lên (thẻ, Tổng kết, ô Hỏi, biên bản cuối) giữ dưới trần
# này. Tính theo byte UTF-8 (chữ có dấu chiếm 2 tới 3 byte) vì chưa rõ Google đếm theo ký
# tự hay theo byte; chừa khoảng 1.000 cho chắc
TRAN_CAU_HOI = 4500
TRAN_THAP_NHAT = 3000  # hạ trần không xuống dưới mức này: riêng khung câu hỏi thẻ đã tới 2.700


def so_byte(chu: str) -> int:
    return len(chu.encode("utf-8"))


def tran_cau_hoi(viec: dict) -> int:
    """Trần độ dài câu hỏi của cuộc họp này: TRAN_CAU_HOI, hoặc thấp hơn nếu Google đã
    không nhận một câu dưới trần đó (xem ha_tran)."""
    return min(TRAN_CAU_HOI, (viec.get("tro_ly") or {}).get("tran") or TRAN_CAU_HOI)


def ha_tran(viec: dict, cau: str) -> None:
    """Google không nhận câu hỏi cau vì dài quá dù đã dưới trần: trần thật thấp hơn đã biết,
    nên các câu sau của cuộc họp này (cả khi bấm lại, bấm Làm lại) giữ ngắn hơn câu đó 500
    byte. Không hạ thì thẻ nào cũng hỏi hai lần (lần đầu bị từ chối), tốn gấp đôi lượt hỏi
    trong ngày."""
    ty = viec.get("tro_ly")
    if isinstance(ty, dict):
        ty["tran"] = max(TRAN_THAP_NHAT, min(tran_cau_hoi(viec), so_byte(cau)) - 500)


def _cat_byte(chu: str, toi_da: int) -> str:
    """Cắt chữ cho vừa số byte, không cắt giữa một chữ có dấu."""
    if so_byte(chu) <= toi_da:
        return chu
    return chu.encode("utf-8")[:max(0, toi_da - 3)].decode("utf-8", "ignore").rstrip() + "..."


def la_qua_dai(loi: BaseException) -> bool:
    """Google không nhận câu hỏi, thường vì dài quá: thư viện báo "rejected by the
    server" hoặc "error frame" (mục #1472 của thư viện)."""
    chu = f"{type(loi).__name__} {loi}".lower()
    return any(x in chu for x in ("rejected by the server", "too large", "over-long",
                                  "error frame"))


def duoc_gui(viec: dict) -> bool:
    """Cuộc họp đã thông báo gửi lên NotebookLM và chưa chuyển sang Không gửi lên mạng."""
    return viec.get("cach_da_bao") == "notebooklm"


def cac_doan_lien(ty: dict) -> list[dict]:
    """Các đoạn đã có chữ, liền nhau từ đầu buổi (dừng ở đoạn đầu tiên chưa có chữ)."""
    ra = []
    for d in ty.get("doan") or []:
        if d.get("tt") != "xong":
            break
        ra.append(d)
    return ra


def ghep_chu_cac_doan(cac_doan: list[dict]) -> str:
    """Bản chép lời cả buổi từ chữ các đoạn, mỗi đoạn mở đầu bằng mốc thời gian."""
    return "\n\n".join(f"[{moc(d['tu'])}] {d['chu'].strip()}"
                       for d in cac_doan if (d.get("chu") or "").strip())


def chen_ghi_chu(bien_ban: str, ghi_chu: str) -> str:
    """Chèn một dòng ghi chú vào trước câu kết và khối chữ ký, vì tệp Word bỏ hẳn
    phần đó (tao_word.tach_than_bai); không có phần đó thì thêm vào cuối."""
    with contextlib.suppress(ImportError):
        from tao_word import PHAN_CUOI
        dong = bien_ban.split("\n")
        for i in range(len(dong) // 2, len(dong)):
            if PHAN_CUOI.match(dong[i]):
                return "\n".join(dong[:i] + [ghi_chu, ""] + dong[i:])
    return f"{bien_ban.rstrip()}\n\n{ghi_chu}"


async def im_lang(aac: Path) -> bool:
    """Phần vừa cắt gần như không có tiếng (giải lao, cả phòng ra ngoài): khỏi gửi."""
    to_nhat = await asyncio.to_thread(muc_to_nhat, aac)
    return to_nhat is not None and to_nhat < NGUONG_IM_LANG_DB


def gio_bat_dau(viec: dict) -> str:
    """Giờ đồng hồ (giờ:phút) lúc bắt đầu ghi cuộc họp."""
    try:
        return f"{datetime.fromisoformat(viec.get('bat_dau') or viec['nhan_luc']):%H:%M}"
    except (KeyError, TypeError, ValueError):
        return "--:--"


def moc_tep(giay: float) -> str:
    """Mốc trong bản ghi viết được vào tên tệp (Windows không nhận dấu hai chấm)."""
    return f"{int(giay // 60):02d}m{int(giay % 60):02d}s"


async def tai_doan(nlm, viec: dict, so: dict, aac: Path, giay: float, con_tro_moi: int) -> dict:
    """Tải một đoạn lên sổ. Chỉ dời con trỏ khi Google đã nhận đoạn.

    Mỗi đoạn một tên riêng: số thứ tự, vị trí trong bản ghi và giờ đồng hồ (PM yêu cầu
    28/9/2026), ở cả tên tệp. Thư viện NotebookLM đặt tên nguồn theo tên tệp rồi mới
    đổi sang tên riêng, đổi hỏng thì chỉ ghi cảnh báo và giữ tên tệp; trước đây mọi
    đoạn đều tải lên với tên ghi-am.m4a, nên sổ có thể có hàng chục nguồn cùng tên và
    câu hỏi "tóm tắt Đoạn 25" không trỏ được vào nguồn nào."""
    ty = viec["tro_ly"]
    tu = ty["giay_da_cat"]
    so_thu_tu = len(ty["doan"]) + 1
    gio_tu = ty.get("gio_cat") or gio_bat_dau(viec)
    gio_den = f"{datetime.now():%H:%M}"
    ten = f"Đoạn {so_thu_tu} ({moc(tu)}-{moc(tu + giay)}, {gio_tu}-{gio_den})"
    ten_tep = (f"Doan-{so_thu_tu:02d}_{moc_tep(tu)}-{moc_tep(tu + giay)}_"
               f"{gio_tu.replace(':', 'h')}-{gio_den.replace(':', 'h')}")
    tep = await asyncio.to_thread(_ban_tai_len, aac, aac.parent, ten_tep)
    nguon = await _co_han(nlm.sources.add_file(so["id"], tep, LOAI_TEP.get(tep.suffix.lower()),
                                               title=ten),
                          HAN_NLM["tai_len"], "tải đoạn lên")
    doan = {"ten": ten, "tu": tu, "den": tu + giay, "nguon": nguon.id, "tt": "dang", "chu": "",
            "con_tro_dau": ty["con_tro"], "gio_tu": gio_tu, "gio_den": gio_den,
            "tep": tep.name, "ten_so": getattr(nguon, "title", None) or tep.name}
    ty["doan"].append(doan)
    ty["con_tro"], ty["giay_da_cat"], ty["gio_cat"] = con_tro_moi, tu + giay, gio_den
    luu_viec(viec)
    return doan


async def lay_chu_doan(nlm, viec: dict, so: dict, doan: dict, co: dict, han: float,
                       bao) -> None:
    """Chờ Google chép lời một đoạn đã tải lên rồi lấy chữ về máy. co: nơi đặt cờ
    đang chờ và cờ thôi chờ; sau khi Dừng là chính việc, để nút Thôi chờ Google
    dùng được như mọi khi."""
    await cho_google_go_chu(nlm, so, co, nguon_id=doan["nguon"], han=han, bao=bao)
    if doan.get("ten_so") and doan["ten_so"] != doan["ten"]:
        # Lúc tải lên, dịch vụ chưa nhận tên riêng (nguồn còn mang tên tệp). Nguồn đã sẵn
        # sàng thì đổi tên lại; vẫn hỏng thì thôi, tên tệp cũng có số thứ tự và mốc
        with contextlib.suppress(Exception):
            await _co_han(nlm.sources.rename(so["id"], doan["nguon"], doan["ten"]),
                          HAN_NLM["ket_noi"], "đặt tên đoạn")
            doan["ten_so"] = doan["ten"]
    ft = await _co_han(nlm.sources.get_fulltext(so["id"], doan["nguon"]),
                       HAN_NLM["lay_chu"], "trả bản chép lời")
    doan["chu"] = (getattr(ft, "rendered_content", "") or ft.content or "").strip()
    doan["tt"] = "xong"
    luu_viec(viec)


async def bo_doan(nlm, viec: dict, so: dict, doan: dict) -> None:
    """Đoạn đã tải lên mà không lấy được chữ: bỏ khỏi sổ và lùi con trỏ về đầu đoạn,
    để phần âm thanh đó đi cùng lần gửi sau."""
    ty = viec["tro_ly"]
    with contextlib.suppress(Exception):
        await _co_han(nlm.sources.delete(so["id"], doan["nguon"]), HAN_NLM["ket_noi"],
                      "xoá đoạn hỏng")
    if ty["doan"] and ty["doan"][-1] is doan:
        ty["doan"].pop()
        ty["con_tro"], ty["giay_da_cat"] = doan["con_tro_dau"], doan["tu"]
        ty["gio_cat"] = doan.get("gio_tu") or ty.get("gio_cat")
    luu_viec(viec)


# Thẻ của trợ lý (Đợt 2): sau mỗi đoạn, hỏi NotebookLM MỘT câu để có tóm tắt, câu
# hỏi gợi ý, việc cần chốt, chương trình, việc tuần trước chưa ai nhắc, thông tin
# liên quan và cụm từ để tìm thêm. Nút Tổng kết và ô Hỏi cũng ra thẻ.

GIAN_NHIP_KHI_CON = 15  # còn dưới chừng này lượt hỏi trong ngày thì giãn nhịp sang 10 phút
GIU_LUOT = 3            # còn chừng này lượt thì thôi tự tóm tắt, giữ cho biên bản cuối
# Tên mục NotebookLM viết ra, và khoá tương ứng trong thẻ
MUC_THE = {"TÓM TẮT": "tom_tat", "CÂU HỎI GỢI Ý": "cau_hoi", "VIỆC CẦN CHỐT": "can_chot",
           "CHƯƠNG TRÌNH": "chuong_trinh", "VIỆC TUẦN TRƯỚC": "viec_cu",
           "LIÊN QUAN": "lien_quan", "CỤM TỪ TÌM": "cum_tu", "QUYẾT ĐỊNH": "quyet_dinh",
           "VIỆC ĐÃ GIAO": "viec_giao", "CÒN MỞ": "con_mo"}
NHAN_CAU_HOI = ("Làm rõ", "Gợi mở", "Cần chốt")
DAN_KHUON = ('Trả lời bằng tiếng Việt, đúng các mục dưới đây theo đúng thứ tự. Tên mục viết '
             'hoa trên một dòng riêng; mỗi ý một dòng bắt đầu bằng "- ". Mục nào không có gì '
             'thì ghi "- Không có".')
QUY_TAC_TRO_LY = ("Quy tắc: chỉ dựa trên các nguồn. Không đoán tên người nói, không chắc thì ghi "
                  "[chưa rõ ai nói]. Con số hay hạn không chắc thì ghi kèm [cần kiểm tra]. Không "
                  "dùng biểu tượng, không dùng gạch dài.")


TOI_DA_DIEN_BIEN = 6000  # byte của khối diễn biến khi không nêu trần (câu hỏi thẻ nêu trần riêng)
GAN_DAY = 6              # số thẻ gần nhất giữ dài hơn trong khối diễn biến
TRAN_NGU_CANH_THE = 1200  # byte ghi chú của thư ký trong câu hỏi thẻ; phần còn lại cho diễn biến
TIEU_DE_DIEN_BIEN = ("DIỄN BIẾN TỪ ĐẦU BUỔI (máy tóm từ các thẻ trước, để hiểu mạch cuộc họp; "
                     "không phải nội dung của nguồn cần tóm tắt):")


def _cat(chu: str, toi_da: int) -> str:
    return chu if len(chu) <= toi_da else chu[:toi_da - 3].rstrip() + "..."


def dien_bien(ty: dict, toi_da: int = TOI_DA_DIEN_BIEN) -> str:
    """Diễn biến từ đầu buổi, tóm từ các thẻ đã có trên máy (PM yêu cầu 28/9/2026: đoạn
    sau phải hiểu ngữ cảnh các đoạn trước). Gửi dạng chữ thay vì chọn cả các đoạn cũ
    làm nguồn: chọn cả 25 đoạn thì dịch vụ lấy lại nội dung đoạn cũ đưa vào tóm tắt đoạn
    mới. Kèm các danh sách của thẻ gần nhất (việc cần chốt, chương trình, việc tuần
    trước chưa ai nhắc) để thẻ mới cập nhật tiếp chứ không đếm lại từ đầu. toi_da: số byte
    tối đa; thiếu chỗ thì bỏ bớt các đoạn đầu (giữ đoạn gần nhất), rồi bớt cuối các danh
    sách, cuối cùng mới bỏ đoạn gần nhất."""
    the = [t for t in ty.get("the") or [] if t.get("loai") == "doan"]
    if not the:
        return ""
    dong = []
    for i, t in enumerate(the):
        y = "; ".join(t.get("tom_tat") or []) or _cat(t.get("tho") or "", 300) or "không có ý mới"
        dong.append(f"- {t.get('ten', '')}: {_cat(y, 240 if i >= len(the) - GAN_DAY else 120)}")
    cuoi = the[-1]
    them = []
    for khoa, nhan in (("can_chot", "Việc cần chốt đã ghi nhận"),
                       ("chuong_trinh", "Chương trình (theo thẻ trước)"),
                       ("viec_cu", "Việc tuần trước chưa ai nhắc (theo thẻ trước)")):
        if cuoi.get(khoa):
            them += [f"{nhan}:"] + [f"- {_cat(str(x), 200)}" for x in cuoi[khoa]]
    bo, dau_bo = False, "- (bỏ bớt các đoạn đầu)"

    def dai() -> int:
        return sum(so_byte(x) + 1 for x in dong + them) + (so_byte(dau_bo) + 1 if bo else 0)
    while len(dong) > 1 and dai() > toi_da:
        dong.pop(0)
        bo = True
    while them and dai() > toi_da:
        them.pop()
        if them and them[-1].endswith(":"):  # không để tên danh sách đứng trơ trọi
            them.pop()
    if dong and dai() > toi_da:
        dong.pop(0)
        bo = True
    if (not dong and not them) or dai() > toi_da:
        return ""
    return "\n".join(([dau_bo] if bo else []) + dong + them)


def cau_hoi_doan(tt: dict, doan: dict, truoc: dict | None = None, co_thong_tin: bool = False,
                 co_nen: bool = False, dien_bien_truoc: str = "", ngu_canh: str = "") -> str:
    """Câu hỏi làm thẻ gợi ý cho đoạn vừa gửi (PM duyệt 28/9/2026, phương án B). Nguồn
    được chọn chỉ gồm đoạn này, đoạn liền trước (nối mạch), Thông tin buổi họp và tài
    liệu nền; diễn biến các đoạn cũ đi kèm dạng chữ (dien_bien). Chương trình và việc
    tuần trước lấy từ phần khai báo, nên bám chương trình không tốn thêm lượt hỏi."""
    nguon = [f'Nguồn cần tóm tắt là "{doan["ten"]}": phần cuộc họp vừa diễn ra.']
    if truoc:
        nguon.append(f'Nguồn "{truoc["ten"]}" là phần ngay trước đó, chỉ để nối mạch, không '
                     'đưa ý của nó vào TÓM TẮT.')
    if co_thong_tin:
        nguon.append(f'Nguồn "{TEN_THONG_TIN}" do thư ký khai báo trước khi ghi: tên cuộc họp, '
                     "thành phần, chương trình, nội dung chính. Dùng để biết tên người, chức vụ "
                     "và trọng tâm, không phải lời nói trong cuộc họp.")
    if co_nen:
        nguon.append("Các nguồn còn lại là tài liệu nền.")
    dong = [" ".join(nguon)]
    if dien_bien_truoc:
        dong += ["", TIEU_DE_DIEN_BIEN, dien_bien_truoc]
    dong += ["", DAN_KHUON, "",
             "TÓM TẮT", "(3 đến 5 ý chính CHỈ có trong nguồn cần tóm tắt. Không lấy từ diễn "
             "biến, chương trình họp, ghi chú của thư ký hay nguồn khác. Nguồn cần tóm tắt nói "
             "gì thì ghi nấy, kể cả khi lạc đề hay trùng ý đã bàn)", "",
             "CÂU HỎI GỢI Ý", "(2 đến 4 câu chủ trì nên hỏi tiếp về nội dung vừa nói. Mỗi câu "
             "mở đầu bằng [Làm rõ] khi cần hỏi rõ ai, bao giờ, bao nhiêu; [Gợi mở] khi gợi "
             "phương án khác hoặc rủi ro; [Cần chốt] khi cần chủ trì quyết)", "",
             "VIỆC CẦN CHỐT", "(việc được nhắc từ đầu buổi tới giờ mà còn thiếu người phụ trách "
             "hoặc thiếu hạn: lấy danh sách đã ghi nhận ở diễn biến, bỏ việc đã đủ, thêm việc "
             "mới trong nguồn cần tóm tắt)", ""]
    # Chương trình và việc tuần trước đã có trong nguồn Thông tin buổi họp: trỏ tới đó, khỏi
    # chép lại vào câu hỏi cho ngắn (câu hỏi dài quá thì Google không nhận, xem TRAN_CAU_HOI)
    o_dau = f'trong mục đó của nguồn "{TEN_THONG_TIN}"' if co_thong_tin else "dưới đây"
    if tt.get("chuong_trinh"):
        dong += ["CHƯƠNG TRÌNH", f"(mỗi mục của chương trình {o_dau} ghi: đã bàn, đang bàn hoặc "
                 "chưa bàn, theo diễn biến và nguồn cần tóm tắt; chương trình chỉ là dự kiến, "
                 "không dùng nó để đoán nội dung hay người nói)"]
        dong += ([] if co_thong_tin else [_cat_byte(tt["chuong_trinh"], 600)]) + [""]
    if tt.get("viec_tuan_truoc"):
        dong += ["VIỆC TUẦN TRƯỚC", f"(những việc {o_dau} mà từ đầu buổi tới giờ chưa ai nhắc tới)"]
        dong += ([] if co_thong_tin else [_cat_byte(tt["viec_tuan_truoc"], 600)]) + [""]
    dong += ["LIÊN QUAN", "(tối đa 3 thông tin trong diễn biến từ đầu buổi, đoạn liền trước, "
             "Thông tin buổi họp hoặc tài liệu, liên quan tới nguồn cần tóm tắt; cuối mỗi dòng "
             "ghi tên đoạn hoặc tài liệu trong ngoặc đơn)", "",
             "CỤM TỪ TÌM", "(một cụm 3 đến 8 từ nói đúng vấn đề của nguồn cần tóm tắt, để tìm tài "
             "liệu liên quan)", "", QUY_TAC_TRO_LY]
    return "\n".join(dong + ([ngu_canh] if ngu_canh else []))


def cau_hoi_the(viec: dict, doan: dict, truoc: dict | None, gon: bool = False) -> str:
    """Câu hỏi thẻ của một đoạn, luôn dưới trần (tran_cau_hoi; buổi học tối 28/9/2026 hỏng
    thẻ từ đoạn 4 vì câu hỏi dài quá). Ghi chú của thư ký giữ tối đa nửa chỗ còn lại sau
    phần khung (và không quá TRAN_NGU_CANH_THE); phần còn lại cho khối diễn biến, thiếu chỗ
    thì bỏ bớt các đoạn đầu. gon: bản gọn để hỏi lại khi Google vẫn không nhận: không có
    diễn biến, ghi chú ngắn hơn."""
    ty = viec["tro_ly"]
    tran = tran_cau_hoi(viec)
    doi_so = (viec["tt"], doan, truoc, bool(nguon_thong_tin(ty)), co_nen(ty))
    con = min(TRAN_NGU_CANH_THE, (tran - so_byte(cau_hoi_doan(*doi_so, "", "")) - 8) // 2)
    nc = khoi_ngu_canh(viec, toi_da=con // 3 if gon else con) if con > 0 else ""
    khung = cau_hoi_doan(*doi_so, "", nc)
    if gon:
        return khung
    con = tran - so_byte(khung) - so_byte(TIEU_DE_DIEN_BIEN) - 8
    db = dien_bien(ty, toi_da=con) if con > 200 else ""
    return cau_hoi_doan(*doi_so, db, nc) if db else khung


def cau_hoi_tong_ket(ngu_canh: str = "") -> str:
    return "\n".join([
        'Tổng kết cuộc họp từ đầu tới giờ, dựa trên các nguồn tên "Đoạn ...", để chủ trì đọc lại '
        "cho cả phòng trước khi tan họp.", DAN_KHUON, "",
        "QUYẾT ĐỊNH", "(các quyết định đã chốt)", "",
        "VIỆC ĐÃ GIAO", "(mỗi việc ghi: việc, người phụ trách, hạn; thiếu thông tin nào thì ghi "
        "[chưa rõ])", "",
        "CÒN MỞ", "(vấn đề đã bàn mà chưa chốt)", "", QUY_TAC_TRO_LY]
        + ([ngu_canh] if ngu_canh else []))


def doc_the(tra_loi: str) -> dict:
    """Tách câu trả lời của NotebookLM thành các mục của thẻ. Không nhận ra mục nào
    thì giữ nguyên văn (khoá "tho") để vẫn hiện được."""
    chu = TRICH_DAN.sub("", tra_loi or "").replace("**", "").strip()
    the, muc = {}, None
    for dong in chu.splitlines():
        s = dong.strip()
        ten = re.sub(r"^\d+[.)]\s*", "", s.strip("#*_: ").strip()).strip(" :").upper()
        if ten in MUC_THE:
            muc = MUC_THE[ten]
            the.setdefault(muc, [])
            continue
        s = re.sub(r"^[-*•+]\s+", "", s).strip()
        if muc and s and s.lower().rstrip(".") not in ("không có", "không"):
            the[muc].append(s)
    if not the:
        return {"tho": chu}
    if "cau_hoi" in the:
        the["cau_hoi"] = [tach_nhan(x) for x in the["cau_hoi"]]
    if "cum_tu" in the:
        the["cum_tu"] = (the["cum_tu"] or [""])[0][:120]
    return the


def tach_nhan(cau: str) -> list[str]:
    """[Làm rõ] Ai phụ trách? thành ["Làm rõ", "Ai phụ trách?"]."""
    m = re.match(r"\[([^\]]+)\]\s*(.*)", cau)
    if m and m.group(1).strip() in NHAN_CAU_HOI:
        return [m.group(1).strip(), m.group(2).strip()]
    return ["", cau]


def them_the(viec: dict, loai: str, **noi_dung) -> dict:
    """Thêm một thẻ vào khung Trợ lý và lưu ngay (viec.json, tro-ly.txt)."""
    the = {"loai": loai, "luc": f"{datetime.now():%H:%M}", **noi_dung}
    viec["tro_ly"].setdefault("the", []).append(the)
    luu_viec(viec)
    return the


def nguon_thong_tin(ty: dict) -> list[str]:
    """Nguồn "Thông tin buổi họp" nếu đã lên sổ."""
    tin = ty.get("thong_tin") or {}
    return [tin["nguon"]] if tin.get("tt") == "xong" and tin.get("nguon") else []


def nguon_nen(ty: dict) -> list[str]:
    """Biên bản buổi trước và tài liệu đã lên sổ, dịch vụ đọc được (tài liệu nền)."""
    return [n["nguon"] for n in ty.get("nen") or [] if n.get("tt") == "xong" and n.get("nguon")]


def nguon_da_co(ty: dict) -> list[str]:
    """Mọi nguồn đã có chữ trong sổ của cuộc họp: các đoạn đã chép lời, tài liệu nền
    và Thông tin buổi họp. Dùng cho ô Hỏi và Tổng kết (hỏi về cả buổi)."""
    return ([d["nguon"] for d in ty.get("doan") or [] if d.get("tt") == "xong" and d.get("nguon")]
            + nguon_nen(ty) + nguon_thong_tin(ty))


def doan_truoc(ty: dict, doan: dict) -> dict | None:
    """Đoạn liền trước đoạn này, nếu đã có chữ."""
    ds = ty.get("doan") or []
    i = next((k for k, d in enumerate(ds) if d is doan), -1)
    truoc = ds[i - 1] if i > 0 else None
    return truoc if truoc and truoc.get("tt") == "xong" and truoc.get("nguon") else None


def nguon_the(ty: dict, doan: dict, truoc: dict | None) -> list[str]:
    """Nguồn chọn cho thẻ của một đoạn (PM duyệt 28/9/2026): Thông tin buổi họp, tài liệu
    nền, đoạn liền trước và chính đoạn đó. Không chọn các đoạn cũ hơn: chọn cả thì dịch
    vụ lấy nội dung đoạn cũ đưa vào tóm tắt đoạn mới (buổi giao ban 28/9/2026, Đoạn 25
    chép gần nguyên Đoạn 10). Mạch các đoạn cũ đi kèm dạng chữ, xem dien_bien."""
    return nguon_thong_tin(ty) + nguon_nen(ty) + ([truoc["nguon"]] if truoc else []) + [doan["nguon"]]


def co_nen(ty: dict) -> bool:
    return any(n.get("tt") == "xong" for n in ty.get("nen") or [])


TEN_THONG_TIN = "Thông tin buổi họp"
MUC_THONG_TIN = (("Loại họp", "loai_hop"), ("Tên cuộc họp", "ten_cuoc_hop"),
                 ("Thời gian", "thoi_gian"), ("Địa điểm", "dia_diem"), ("Chủ trì", "chu_tri"),
                 ("Thư ký", "thu_ky"),
                 ("Thành phần tham dự", "tham_du"), ("Chương trình", "chuong_trinh"),
                 ("Nội dung chính", "noi_dung"), ("Việc tuần trước", "viec_tuan_truoc"))


def chu_thong_tin(tt: dict) -> str:
    """Chữ của nguồn "Thông tin buổi họp": phần thư ký khai báo trước khi ghi âm (PM yêu
    cầu 28/9/2026), để dịch vụ có cơ sở tóm tắt đúng cả cuộc họp."""
    dong = ["THÔNG TIN BUỔI HỌP (thư ký khai báo trước khi ghi âm; không phải lời nói trong "
            "cuộc họp)", ""]
    for nhan, khoa in MUC_THONG_TIN:
        gia_tri = str(tt.get(khoa) or "").strip()
        if gia_tri:
            dong.append(f"{nhan}:\n{gia_tri}" if "\n" in gia_tri else f"{nhan}: {gia_tri}")
    return "\n".join(dong)


async def dua_thong_tin(nlm, viec: dict, so: dict) -> None:
    """Đưa nguồn "Thông tin buổi họp" lên sổ trước đoạn đầu (hay cùng lúc với tài liệu
    nền đầu buổi). Chỉ ở cuộc họp gửi lên mạng; sổ chỉ tạo khi có thứ cần gửi, nên
    cuộc họp im lặng hay quá ngắn vẫn không gọi Google. Hỏng thì thử lại ở lượt sau,
    tối đa 3 lần; thẻ vẫn chạy, chỉ thiếu nguồn này."""
    ty = viec["tro_ly"]
    tin = ty.get("thong_tin") or {}
    if tin.get("tt") == "xong" or tin.get("lan", 0) >= 3 or not duoc_gui(viec):
        return
    try:
        nguon = await _co_han(nlm.sources.add_text(so["id"], TEN_THONG_TIN, chu_thong_tin(viec["tt"]),
                                                   wait=True, wait_timeout=120),
                              150, "đưa thông tin buổi họp lên")
        ty["thong_tin"] = {"tt": "xong", "nguon": nguon.id}
    except Exception as loi:  # noqa: BLE001 - thiếu nguồn này thì thẻ vẫn chạy
        ty["thong_tin"] = {"tt": "loi", "loi": ly_do_loi(loi), "lan": tin.get("lan", 0) + 1}
    luu_viec(viec)


# Chừa cho lời dặn và ghi chú của thư ký trong câu lệnh soạn biên bản cuối. Chép danh sách việc
# tuần trước vào câu lệnh mà còn dưới chừng này byte trong trần TRAN_CAU_HOI thì coi là dài
CHO_GHI_CHU = 1200


def viec_cu_qua_dai(viec: dict, tt: dict) -> bool:
    """Danh sách việc tuần trước dài tới mức chép vào câu lệnh soạn biên bản cuối thì hết chỗ
    cho ghi chú của thư ký (PM chốt 30/9/2026: máy tự tính theo giới hạn của Google, danh
    sách ngắn vẫn chép thẳng như cũ). Tính theo trần của cuộc họp này (tran_cau_hoi)."""
    if not (tt.get("viec_tuan_truoc") or "").strip():
        return False
    return tran_cau_hoi(viec) - so_byte(cau_lenh_soan(tt)) < CHO_GHI_CHU


async def nguon_viec_cu(nlm, viec: dict, so: dict, so_moi: bool) -> list[str]:
    """Nguồn "Thông tin buổi họp" (nơi có sẵn danh sách việc tuần trước) để biên bản cuối chọn
    kèm khi danh sách dài. Chưa có trên sổ thì đưa lên bây giờ (cuộc họp ngắn chưa gửi đoạn
    nào thì chưa có). Sổ vừa tạo mới thì nguồn cũ không còn nữa. Không đưa được thì trả rỗng,
    biên bản vẫn soạn được với danh sách chép vào câu lệnh."""
    ty = viec.get("tro_ly")
    if not isinstance(ty, dict):
        return []
    tin = ty.get("thong_tin") or {}
    if so_moi:
        ty["thong_tin"] = None
    elif tin.get("tt") == "xong" and tin.get("nguon"):
        try:
            cu = await _co_han(nlm.sources.get_or_none(so["id"], tin["nguon"]),
                               HAN_NLM["ket_noi"], "xem nguồn thông tin buổi họp")
            if not getattr(cu, "is_ready", False):
                ty["thong_tin"] = None  # bị xoá hay hỏng trên sổ: đưa lên lại
        except Exception:  # noqa: BLE001 - không kiểm được thì cứ dùng nguồn đã ghi
            pass
    await dua_thong_tin(nlm, viec, so)
    return nguon_thong_tin(ty)


def ly_do_khong_hoi(viec: dict) -> str:
    """Vì sao lúc này trợ lý không hỏi NotebookLM; rỗng nghĩa là hỏi được."""
    if not duoc_gui(viec):
        return "Cuộc họp đã chuyển sang Không gửi lên mạng."
    if viec["tro_ly"].get("het_luot"):
        return "Dịch vụ xử lý báo đã hết lượt hỏi hôm nay, trợ lý thôi tóm tắt."
    if luot_con_lai() <= GIU_LUOT:
        return (f"Chỉ còn {luot_con_lai()} lượt hỏi trong ngày, trợ lý thôi tóm tắt để giữ lượt "
                "cho biên bản cuối.")
    return ""


def nhip_thuc() -> int:
    """Nhịp gửi đang dùng: còn ít lượt hỏi trong ngày thì giãn ra ít nhất 10 phút."""
    nhip = nhip_tro_ly()
    if nhip and luot_con_lai() < GIAN_NHIP_KHI_CON:
        nhip = max(nhip, 10 * GIAY_MOI_PHUT)
    return nhip


def hen_thu_lai(ty: dict, giay: float, nhip: int, nhanh: bool = True) -> float | None:
    """Sau một lần tự gửi hỏng: lúc máy tự thử lại, tính bằng giây ghi âm như nhịp gửi.
    Lần hỏng thứ nhất và thứ hai thử lại sớm (CACH_THU_LAI), từ lần thứ ba mỗi nhịp một
    lần. nhanh=False (Google báo hết lượt hay hạn chế) thì chờ tròn nhịp, khỏi hỏi dồn.
    Cuộc họp chọn Chỉ khi bấm nút (nhip = 0) thì máy không tự thử lại: trả None."""
    if not nhip:
        return None
    lan = ty.get("loi_lien", 0)
    if nhanh and 1 <= lan <= len(CACH_THU_LAI):
        return giay + min(nhip, CACH_THU_LAI[lan - 1] * GIAY_MOI_PHUT)
    return giay + nhip


async def hoi_nlm(nlm, viec: dict, cau: str, rieng: bool = False,
                  nguon: list[str] | None = None) -> str:
    """Hỏi NotebookLM. rieng: ô Hỏi, gửi kèm mã cuộc trò chuyện riêng của nó. Thẻ và Tổng
    kết thì không gửi mã (PM duyệt 28/9/2026). Thư viện (0.8.2, 0.8.3) khi không có mã thì
    ghi lượt hỏi vào cuộc trò chuyện gần nhất trên NotebookLM (khung trò chuyện trên web
    hiện đủ các thẻ) nhưng không gửi kèm lịch sử, nên mỗi thẻ chỉ đọc câu hỏi và nguồn
    được chọn. Muốn cuộc trò chuyện mới hẳn phải xoá cuộc cũ: không làm, vì mất lịch sử
    người dùng xem trên web. nguon: các nguồn được chọn; bỏ trống là mọi nguồn đã có chữ."""
    ty = viec["tro_ly"]
    tinh_mot_luot()
    try:
        dap = await _co_han(nlm.chat.ask(
            viec["so_nlm"]["id"], cau, source_ids=nguon_da_co(ty) if nguon is None else nguon,
            conversation_id=ty.get("hoi_thoai_rieng") if rieng else None),
            HAN_NLM["hoi"], "trả lời")
    except Exception as loi:
        if la_het_luot(loi):
            ty["het_luot"] = True
        raise
    if rieng:
        ty["hoi_thoai_rieng"] = getattr(dap, "conversation_id", None) or ty.get("hoi_thoai_rieng")
    return TRICH_DAN.sub("", dap.answer or "").strip()


async def hoi_the(nlm, viec: dict, doan: dict | None) -> None:
    """Thẻ gợi ý cho đoạn vừa gửi (doan), hoặc thẻ tổng kết (doan None). Hỏng thì ra
    thẻ báo hỏng; lượt gửi đoạn vẫn tính là xong vì chữ đã về máy."""
    ty = viec["tro_ly"]
    xong = f"Đã chép lời tới {moc(ty['giay_da_cat'])}, {len(ty['doan'])} đoạn."
    ly_do = ly_do_khong_hoi(viec)
    if ly_do:
        ty["trang_thai"] = f"{xong} {ly_do}"
        return
    ty["trang_thai"] = (f"Đang tóm tắt {doan['ten'].lower()}" if doan
                        else "Đang tổng kết cuộc họp")
    cau = ""
    try:
        if doan:
            truoc = doan_truoc(ty, doan)
            nguon = nguon_the(ty, doan, truoc)
            cau = cau_hoi_the(viec, doan, truoc)
            try:
                tra_loi = await hoi_nlm(nlm, viec, cau, nguon=nguon)
            except Exception as loi:
                if not la_qua_dai(loi):
                    raise
                # Google vẫn không nhận: trần thật thấp hơn đã biết. Hạ trần cho các câu sau,
                # rồi hỏi lại một lần bằng bản gọn, không có diễn biến
                print(f"Câu hỏi thẻ {doan['ten']} ({so_byte(cau)} byte) không được nhận, hỏi lại "
                      f"bản gọn: {type(loi).__name__}: {loi}", flush=True)
                ghi_nhat_ky(viec, f"{doan['ten']}: câu hỏi {so_byte(cau)} byte không được nhận, "
                                  "hỏi lại bản gọn")
                ha_tran(viec, cau)
                cau = cau_hoi_the(viec, doan, truoc, gon=True)
                tra_loi = await hoi_nlm(nlm, viec, cau, nguon=nguon)
            them_the(viec, "doan", ten=doan["ten"], tu=doan["tu"], den=doan["den"],
                     **doc_the(tra_loi))
        else:
            dau = cau_hoi_tong_ket()
            cau = cau_hoi_tong_ket(khoi_ngu_canh(viec, toi_da=tran_cau_hoi(viec) - so_byte(dau) - 8))
            them_the(viec, "tong_ket", **doc_the(await hoi_nlm(nlm, viec, cau)))
    except Exception as loi:  # noqa: BLE001 - thẻ hỏng không làm hỏng lượt gửi đoạn
        if cau and la_qua_dai(loi):
            ha_tran(viec, cau)  # đoạn sau, hay bấm Tổng kết lại, thì câu hỏi ngắn hơn
        them_the(viec, "loi", chu=(f"Chưa tóm tắt được {doan['ten'].lower()}" if doan
                                   else "Chưa tổng kết được") + f" ({ly_do_loi(loi)}).")
    ty["trang_thai"] = xong


async def mot_luot_tro_ly(viec: dict, yeu_cau: str | None = None) -> bool:
    """Một lượt trong buổi họp: cắt phần mới, gửi lên, lấy chữ về, rồi hỏi NotebookLM
    để có thẻ gợi ý. yeu_cau: "tom-tat" (nút Tóm tắt ngay) hay "tong-ket" (nút Tổng
    kết), không chờ tới nhịp. Trả True nếu đã gửi được một đoạn; phần mới còn ngắn
    hoặc im lặng thì chưa gửi, để lần sau."""
    ty = viec["tro_ly"]
    ty["giay_xet"] = MAY_GHI.trang_thai()["giay"]
    tong_ket = yeu_cau == "tong-ket"
    day = (sum(1 for d in ty["doan"] + (ty.get("nen") or []) if d.get("nguon"))
           + len(nguon_thong_tin(ty)) >= TRAN_NGUON - GIU_NGUON)
    if day:
        ty["tam_nghi"] = (f"Cuộc họp đã gửi gần đủ {TRAN_NGUON} phần, chạm mức tối đa nên trợ lý "
                          "thôi gửi. Bấm Dừng thì máy vẫn soạn biên bản như thường.")
        if not tong_ket:
            return False
    khung, con_tro, giay = ((b"", ty["con_tro"], 0.0) if day else
                            await asyncio.to_thread(MAY_GHI.cat_phan_moi, ty["con_tro"]))
    du = giay >= (DOAN_NGAN_NHAT_NUT if yeu_cau else DOAN_NGAN_NHAT)
    if not du and not tong_ket:
        if yeu_cau:
            ty["trang_thai"] = "Phần mới ghi còn ngắn quá nên chưa gửi. Chờ thêm chút rồi bấm lại."
        return False
    doan = None
    async with contextlib.AsyncExitStack() as ngan:
        aac = None
        if du:
            aac = Path(ngan.enter_context(tempfile.TemporaryDirectory())) / "doan.aac"
            aac.write_bytes(khung)
            # Xét im lặng TRƯỚC khi kết nối: bản ghi im lặng thì không gọi Google lần nào
            if await im_lang(aac):
                ty["trang_thai"] = (f"Từ {moc(ty['giay_da_cat'])} tới giờ gần như không có "
                                    "tiếng nên chưa gửi.")
                aac = None
        if not aac and not (tong_ket and any(d.get("tt") == "xong" for d in ty["doan"])):
            if tong_ket:
                ty["trang_thai"] = "Chưa gửi được đoạn nào nên chưa tổng kết được."
            return False
        nlm = await _co_han(ngan.enter_async_context(ket_noi_nlm()), HAN_NLM["ket_noi"], "kết nối")
        # Sổ chỉ tạo khi lần đầu có thứ cần gửi
        so = viec.get("so_nlm") or await tao_so(nlm, viec, viec["tt"])
        if not duoc_gui(viec):
            return False  # vừa chuyển sang Không gửi lên mạng: thôi gửi ngay
        if aac:
            await dua_thong_tin(nlm, viec, so)  # một lần, trước đoạn đầu
            if not duoc_gui(viec):
                return False
            ty["trang_thai"] = f"Đang gửi đoạn {len(ty['doan']) + 1}"
            doan = await tai_doan(nlm, viec, so, aac, giay, con_tro)

            def bao(phut: int) -> None:
                ty["trang_thai"] = f"Đang chép lời {doan['ten'].lower()}, đã chờ {phut} phút"

            try:
                await lay_chu_doan(nlm, viec, so, doan, ty, HAN_NLM["doan"], bao)
            except Exception:
                await bo_doan(nlm, viec, so, doan)
                raise
            ty["trang_thai"] = f"Đã chép lời tới {moc(ty['giay_da_cat'])}, {len(ty['doan'])} đoạn."
        if doan and not tong_ket and len(doan["chu"].split()) < IT_CHU_NHAT:
            # Không nghe ra lời: hỏi thì chỉ ra thẻ trống mà vẫn tốn một lượt. Thường do
            # ghi nhầm micro (thẻ trống sau Ghi tiếp, 27/9/2026), nên báo ngay trên thẻ.
            ghi_nhat_ky(viec, f"{doan['ten']} không nghe ra lời nói")
            them_the(viec, "loi", chu=f"{doan['ten']} không nghe ra lời nói.",
                     goi_y="Có thể máy đang ghi nhầm micro. Bấm Tạm dừng rồi Ghi tiếp để mở "
                           "lại micro.")
        else:
            await hoi_the(nlm, viec, None if tong_ket else doan)
    return doan is not None


async def tra_loi_o_hoi(viec: dict, the: dict) -> None:
    """Chạy nền cho ô Hỏi NotebookLM: hỏi trên các đoạn đã có, bằng cuộc trò chuyện
    riêng; câu trả lời điền vào đúng thẻ của câu hỏi đó."""
    cau = ""
    try:
        async with contextlib.AsyncExitStack() as ngan:
            nlm = await _co_han(ngan.enter_async_context(ket_noi_nlm()), HAN_NLM["ket_noi"],
                                "kết nối")
            dau = "\n\n".join((the["cau_hoi"], f"Trả lời ngắn gọn bằng tiếng Việt. {QUY_TAC_TRO_LY}"))
            cau = "\n\n".join(x for x in (
                dau, khoi_ngu_canh(viec, toi_da=tran_cau_hoi(viec) - so_byte(dau) - 8)) if x)
            the["tra_loi"] = await hoi_nlm(nlm, viec, cau, rieng=True)
    except Exception as loi:  # noqa: BLE001 - báo ngay trên thẻ
        if cau and la_qua_dai(loi):
            ha_tran(viec, cau)  # hỏi lại thì ghi chú gửi kèm ngắn hơn
        the["loi"] = f"Chưa hỏi được ({ly_do_loi(loi)})"
    finally:
        the["dang"] = False
        with contextlib.suppress(OSError):
            luu_viec(viec)


TOI_DA_GHI_CHU = 4000    # ký tự của ô Ghi chú của thư ký đưa vào mỗi câu hỏi
TOI_DA_NGU_CANH = 8000   # ký tự cả khối ngữ cảnh: dài quá thì bỏ bớt các dòng cũ nhất


def khoi_ngu_canh(viec: dict, truoc: float | None = None, cho_may: bool = True,
                  toi_da: int | None = None) -> str:
    """Ngữ cảnh thư ký ghi: các dòng Ghi nhanh, các dòng Ghi ngữ cảnh ở ô Hỏi, và ô Ghi
    chú của thư ký. PM chốt 27/9/2026: ghi chú của thư ký LUÔN gửi làm ngữ cảnh, để
    thẻ gợi ý, ô Hỏi và biên bản cuối chính xác hơn (trước đó ô này chỉ ở trên máy).

    cho_may: đưa vào câu hỏi gửi lên (chỉ ở cuộc họp gửi lên mạng); không thì vào
    khung biên bản để thư ký tự viết. truoc: chỉ lấy các dòng ghi trước mốc này và bỏ
    ô ghi chú (không có mốc, có thể viết sau lúc chuyển) - cuộc họp chuyển sang Không
    gửi lên mạng giữa buổi. toi_da: số byte tối đa của cả khối khi gửi kèm câu hỏi (xem
    TRAN_CAU_HOI): bỏ bớt các dòng cũ nhất, rồi mới cắt ô ghi chú; không đủ chỗ thì bỏ hẳn."""
    ty = viec.get("tro_ly") or {}
    doi = ti_le_moc(viec)  # mốc ghi chú về cùng thang với mốc các đoạn và bản chép lời
    dong = [(g["luc"] * doi, g["chu"]) for g in ty.get("ghi_nhanh") or []]
    dong += [((t.get("giay") or 0.0) * doi, t.get("chu") or "") for t in ty.get("the") or []
             if t.get("loai") == "ngu_canh"]
    dong = sorted((luc, chu) for luc, chu in dong if chu and (truoc is None or luc < truoc))
    ghi_chu = "" if truoc is not None else (viec.get("ghi_chu_rieng") or "").strip()
    if len(ghi_chu) > TOI_DA_GHI_CHU:
        ghi_chu = ghi_chu[:TOI_DA_GHI_CHU] + " [...]"
    dau = ("Ghi chú của thư ký (mốc là thời điểm trong bản ghi). Về tên người nói, con số "
           "và hạn hoàn thành, ưu tiên các ghi chú này hơn bản chép lời:"
           if cho_may else "Ghi chú của thư ký trong lúc họp:")
    while dong and len(dau) + len(ghi_chu) + sum(len(c) + 12 for _, c in dong) > TOI_DA_NGU_CANH:
        dong.pop(0)
    if not dong and not ghi_chu:
        return ""

    def ghep() -> str:
        return "\n".join([dau] + [f"- [{moc(luc)}] {chu}" for luc, chu in dong]
                         + ([f"- {ghi_chu}"] if ghi_chu else []))
    if toi_da is None or so_byte(ghep()) <= toi_da:
        return ghep()
    # Thiếu chỗ: ô ghi chú dài nhường chỗ cho các dòng ghi nhanh nhưng giữ ít nhất nửa phần;
    # rồi bỏ các dòng cũ nhất (dòng mới thường là chỗ thư ký vừa sửa tên người, con số);
    # cuối cùng mới cắt tiếp ô ghi chú
    cac_dong = so_byte(ghep()) - (so_byte(ghi_chu) + 3 if ghi_chu else 0)
    ghi_chu = _cat_byte(ghi_chu, max(toi_da // 2, toi_da - cac_dong - 3))
    while dong and so_byte(ghep()) > toi_da:
        dong.pop(0)
    if ghi_chu and so_byte(ghep()) > toi_da:
        ghi_chu = _cat_byte(ghi_chu, toi_da - so_byte(dau) - 3)
    if len(ghi_chu) <= 3:  # chỉ còn dấu ba chấm: không đủ chỗ cho chữ nào
        ghi_chu = ""
    if (not dong and not ghi_chu) or so_byte(ghep()) > toi_da:
        return ""
    return ghep()


# Các mục của thẻ theo thứ tự hiện, dùng cho tro-ly.txt (giao diện có bảng riêng)
NHAN_MUC = (("tom_tat", "Tóm tắt"), ("cau_hoi", "Câu hỏi gợi ý"), ("can_chot", "Việc cần chốt"),
            ("chuong_trinh", "Chương trình"), ("viec_cu", "Việc tuần trước chưa ai nhắc"),
            ("lien_quan", "Liên quan"), ("quyet_dinh", "Quyết định"),
            ("viec_giao", "Việc đã giao"), ("con_mo", "Còn mở"))


def chu_tro_ly(viec: dict) -> str:
    """Ghi chép trong buổi họp dạng chữ: các thẻ của trợ lý (cả các dòng Ghi ngữ
    cảnh) và các dòng ghi nhanh. Ô Ghi chú của thư ký lưu ở tệp riêng của nó."""
    ty = viec.get("tro_ly") or {}
    dong = [f"GHI CHÉP TRONG BUỔI HỌP: {(viec.get('tt') or {}).get('ten_cuoc_hop', '')}", ""]
    if ty.get("the"):
        dong += ["TRỢ LÝ (máy gợi ý, cần kiểm tra)", ""]
    for t in ty.get("the") or []:
        dau = {"doan": f"Tóm tắt {t.get('ten', '')}", "tong_ket": "Tổng kết",
               "hoi": f"Hỏi: {t.get('cau_hoi', '')}",
               "ngu_canh": f"Ngữ cảnh thư ký ghi: {t.get('chu', '')}"}.get(t["loai"],
                                                                              t.get("chu", ""))
        dong.append(f"[{t.get('luc', '')}] {dau}")
        for khoa, nhan in NHAN_MUC:
            # Chỉ các mục dạng danh sách; thẻ Hỏi có cau_hoi là một câu, đã in ở dòng đầu
            if isinstance(t.get(khoa), list) and t[khoa]:
                dong.append(f"{nhan}:")
                dong += [f"- [{x[0]}] {x[1]}" if isinstance(x, list) and x[0] else
                         f"- {x[1] if isinstance(x, list) else x}" for x in t[khoa]]
        for khoa, nhan in (("tho", ""), ("tra_loi", "Trả lời: "), ("loi", "")):
            if t.get(khoa):
                dong.append(nhan + t[khoa])
        dong.append("")
    if ty.get("ghi_nhanh"):
        doi = ti_le_moc(viec)
        dong += ["GHI NHANH CỦA THƯ KÝ"] + [f"- [{moc(g['luc'] * doi)}] {g['chu']}"
                                            for g in ty["ghi_nhanh"]]
    return "\n".join(dong).strip() + "\n"


async def ghi_so_tay(viec: dict) -> None:
    """Lưu ghi chép trong buổi họp (thẻ, dòng ngữ cảnh và ghi nhanh) thành
    một ghi chú trong sổ NotebookLM, chỉ ở cuộc họp gửi lên NotebookLM từ đầu tới
    cuối. Hỏng thì chỉ ghi nhật ký: tro-ly.txt trên máy vẫn còn."""
    ty = viec.get("tro_ly") or {}
    so = viec.get("so_nlm") or {}
    if not (ty.get("the") or ty.get("ghi_nhanh")) or not so.get("id") or not duoc_gui(viec):
        return
    try:
        async with contextlib.AsyncExitStack() as ngan:
            nlm = await _co_han(ngan.enter_async_context(ket_noi_nlm(so.get("tai_khoan"))),
                                HAN_NLM["ket_noi"], "kết nối")
            if ty.get("ghi_chu_so"):
                await _co_han(nlm.notes.update(so["id"], ty["ghi_chu_so"], chu_tro_ly(viec),
                                               "Ghi chú trong buổi họp"), HAN_NLM["ket_noi"],
                              "lưu ghi chép")
            else:
                ghi = await _co_han(nlm.notes.create(so["id"], "Ghi chú trong buổi họp",
                                                     chu_tro_ly(viec)), HAN_NLM["ket_noi"],
                                    "lưu ghi chép")
                ty["ghi_chu_so"] = getattr(ghi, "id", None)
        ghi_nhat_ky(viec, "Đã lưu ghi chép trong buổi họp vào bản lưu trực tuyến")
    except Exception as loi:  # noqa: BLE001 - tro-ly.txt trên máy vẫn còn
        ghi_nhat_ky(viec, f"Chưa lưu được ghi chép vào bản lưu trực tuyến ({ly_do_loi(loi)})")


def nen_den_luot(ty: dict) -> list[dict]:
    """Tài liệu nền đang chờ gửi và đã tới lúc gửi: lần đầu thì ngay, lần thử lại thì theo hẹn."""
    bay_gio = time.time()
    return [n for n in ty.get("nen") or [] if n.get("tt") == "cho" and n.get("sau", 0) <= bay_gio]


def gui_lai_nen(ty: dict) -> None:
    """Bấm Tóm tắt ngay: tài liệu nền còn hỏng, hay đang chờ tới hẹn thử lại, được thử ngay
    một lần nữa (PM chọn 30/9/2026). Một lần thôi: hỏng nữa thì lại chờ bấm."""
    bay_gio = time.time()
    for n in ty.get("nen") or []:
        if n.get("tt") == "loi" or (n.get("tt") == "cho" and n.get("sau", 0) > bay_gio):
            n.update(tt="cho", sau=0, lan=LAN_TOI_DA_NEN - 1)


def hong_nen(viec: dict, n: dict, ly: str) -> None:
    """Một tài liệu nền gửi hỏng: còn lần thì hẹn thử lại, hết lần thì chờ bấm Tóm tắt ngay."""
    n["lan"] = n.get("lan", 0) + 1
    n["loi"] = ly
    if n["lan"] < LAN_TOI_DA_NEN:
        n.update(tt="cho", sau=time.time() + CACH_THU_LAI_NEN[n["lan"] - 1] * GIAY_MOI_PHUT)
        ghi_nhat_ky(viec, f"Chưa gửi được tài liệu {n['ten']} ({ly}), máy sẽ thử lại")
    else:
        n["tt"] = "loi"
        ghi_nhat_ky(viec, f"Chưa gửi được tài liệu {n['ten']} ({ly}). Bấm Tóm tắt ngay để gửi lại")


async def dua_nen(viec: dict) -> None:
    """Đầu buổi: đưa biên bản buổi trước và tài liệu thả vào trước buổi họp lên sổ
    của cuộc họp, để thẻ gợi ý và ô Hỏi dùng được. Tệp nào hỏng thì làm tiếp tệp sau.
    Hỏng (mạng chớp, dịch vụ chậm) thì hẹn thử lại, xem hong_nen. Trước 30/9/2026 hỏng
    một lần là bỏ hẳn, nên một lần mạng chớp lúc mới bấm ghi làm thẻ gợi ý, Tổng kết và
    ô Hỏi thiếu tài liệu cả buổi. Tài liệu chỉ là phần thêm, không ảnh hưởng ghi âm hay
    biên bản cuối."""
    ty = viec["tro_ly"]
    cho = nen_den_luot(ty)
    chua = list(cho)  # chưa thử trong lượt này: kết nối hỏng thì cả nhóm này hẹn thử lại
    ty["dang_gui"] = True
    try:
        async with contextlib.AsyncExitStack() as ngan:
            nlm = await _co_han(ngan.enter_async_context(ket_noi_nlm()), HAN_NLM["ket_noi"],
                                "kết nối")
            so = viec.get("so_nlm") or await tao_so(nlm, viec, viec["tt"])
            await dua_thong_tin(nlm, viec, so)  # đã gọi Google đầu buổi thì đưa luôn
            for i, n in enumerate(cho, 1):
                if not duoc_gui(viec):
                    return
                ty["trang_thai"] = f"Đang gửi tài liệu ({i}/{len(cho)}): {n['ten']}"
                tep = Path(viec["thu_muc"]) / n["tep"]
                try:
                    if not n.get("nguon"):  # lần trước đã lên sổ mà chưa chờ xong thì chờ tiếp, khỏi tải trùng
                        nguon = await _co_han(nlm.sources.add_file(
                            so["id"], tep, LOAI_TAI_LIEU.get(tep.suffix.lower()), title=n["ten"]),
                            HAN_NLM["tai_len"], "tải tài liệu lên")
                        n["nguon"] = nguon.id
                    await cho_google_go_chu(nlm, so, ty, nguon_id=n["nguon"], han=HAN_NLM["tai_lieu"],
                                            bao=lambda phut: None)
                    n["tt"] = "xong"
                except Exception as loi:  # noqa: BLE001 - bỏ qua tệp hỏng, làm tiếp tệp sau
                    if isinstance(loi, GoogleKhongNhan) and n.get("nguon"):
                        # Nguồn đỏ hay đã mất: xoá khỏi sổ (như bo_doan) cho khỏi chiếm chỗ trong
                        # trần 50 nguồn, lần thử lại tải lên lại
                        with contextlib.suppress(Exception):
                            await _co_han(nlm.sources.delete(so["id"], n["nguon"]),
                                          HAN_NLM["ket_noi"], "xoá tài liệu hỏng")
                        n.pop("nguon", None)
                    hong_nen(viec, n, ly_do_loi(loi))
                chua.remove(n)
                luu_viec(viec)
    except Exception as loi:  # noqa: BLE001 - hỏng gì cũng không được làm ngừng ghi âm
        ly = ly_do_loi(loi)
        for n in chua:
            hong_nen(viec, n, ly)
    finally:
        ty["dang_gui"] = False
        with contextlib.suppress(OSError):
            luu_viec(viec)
    xong = sum(1 for n in cho if n["tt"] == "xong")
    ty["trang_thai"] = (f"Đã gửi {xong}/{len(cho)} tài liệu cho trợ lý."
                        + (" Máy sẽ tự gửi lại phần chưa được." if any(n["tt"] == "cho" for n in cho)
                           else " Có tài liệu chưa gửi được."
                           if any(n["tt"] == "loi" for n in cho) else "")
                        + ("" if ty["doan"] else " Trợ lý gửi đoạn đầu sau vài phút ghi âm."))


async def vong_tro_ly(viec: dict) -> None:
    """Chạy nền suốt lúc ghi một cuộc họp chọn NotebookLM. Mọi lỗi dừng lại ở đây,
    không bao giờ làm ngừng ghi âm."""
    ty = viec["tro_ly"]
    ty["trang_thai"] = "Trợ lý sẵn sàng, gửi lần đầu sau vài phút ghi âm."
    while MAY_GHI.ma == viec["ma"] and MAY_GHI.tt:
        await asyncio.sleep(NHIP_VONG)
        if not duoc_gui(viec):
            ty["trang_thai"] = "Đã chuyển sang Không gửi lên mạng: trợ lý thôi gửi."
            return
        yeu_cau = ty.pop("yeu_cau", None)
        da_thu_nen = ty.pop("nen_da_thu_lai", False)  # lần bấm này đã thử lại tài liệu ở vòng trước
        if not da_dang_nhap_nlm():
            ty["trang_thai"] = "Chưa đăng nhập Google nên trợ lý chưa gửi gì."
            continue
        if yeu_cau and not da_thu_nen:
            gui_lai_nen(ty)  # bấm nút là thử lại cả tài liệu nền còn hỏng, một lần cho mỗi lần bấm
        if nen_den_luot(ty):
            await dua_nen(viec)
            if yeu_cau:  # bấm nút trong lúc đưa tài liệu lên: làm ở vòng sau
                ty.setdefault("yeu_cau", yeu_cau)
                ty["nen_da_thu_lai"] = True
            continue
        giay, nhip = MAY_GHI.trang_thai()["giay"], nhip_thuc()
        # Lần tự gửi hỏng thì thử lại theo hẹn (hen_thu_lai), không chờ tròn nhịp. Đã tạm nghỉ
        # vì hỏng liền thì mỗi nhịp thử một lần, hết lỗi là tự chạy tiếp, khỏi bấm nút
        den_han = bool(nhip) and ty.get("thu_lai") is not None and giay >= ty["thu_lai"]
        if ty["tam_nghi"] and not yeu_cau and not den_han:
            continue
        if not yeu_cau and not den_han and (not nhip or giay - ty["giay_xet"] < nhip):
            continue
        ty["thu_lai"] = None
        ty["dang_gui"] = True
        try:
            if await mot_luot_tro_ly(viec, yeu_cau):
                if ty["loi_lien"]:
                    ghi_nhat_ky(viec, f"Trợ lý gửi lại được sau {ty['loi_lien']} lần hỏng liền")
                ty["loi_lien"], ty["tam_nghi"] = 0, ""
            elif ty["loi_lien"] >= LOI_LIEN_TOI_DA:
                # Đang nghỉ vì hỏng liền mà lần này chưa có gì để gửi (phần mới ngắn, im
                # lặng): vẫn hẹn nhịp sau, không thì nghỉ mãi tới khi bấm nút
                ty["thu_lai"] = hen_thu_lai(ty, MAY_GHI.trang_thai()["giay"], nhip_thuc(), False)
        except Exception as loi:  # noqa: BLE001 - hỏng gì cũng không được làm ngừng ghi âm
            print(f"Trợ lý hỏng ở việc {viec['ma']}: {type(loi).__name__}: {loi}", flush=True)
            ty["loi_lien"] += 1
            ly, nhip = ly_do_loi(loi), nhip_thuc()
            if ty["loi_lien"] <= LOI_LIEN_TOI_DA:  # nhật ký cuộc họp: ba lần đầu, khỏi lặp cả buổi
                ghi_nhat_ky(viec, f"Trợ lý gửi hỏng lần {ty['loi_lien']} ({ly})")
            ty["thu_lai"] = hen_thu_lai(ty, MAY_GHI.trang_thai()["giay"], nhip, not la_het_luot(loi))
            ty["trang_thai"] = f"Lần gửi vừa rồi hỏng ({ly}). Phần đó sẽ gửi cùng lần sau."
            if ty["loi_lien"] >= LOI_LIEN_TOI_DA:
                ty["tam_nghi"] = ("Hỏng 3 lần liền nên trợ lý tạm nghỉ"
                                  + (", mỗi nhịp chỉ thử lại một lần" if nhip else "")
                                  + ". Ghi âm vẫn chạy bình thường. Bấm Tóm tắt ngay để thử "
                                  + ("ngay." if nhip else "lại."))
        finally:
            ty["dang_gui"] = False
            with contextlib.suppress(OSError):
                luu_viec(viec)


async def dung_tro_ly(viec: dict) -> None:
    """Bấm Dừng: thôi lượt đang chạy dở. Đoạn đã tải lên mà chưa có chữ thì bước
    soạn biên bản chờ tiếp, có nút Thôi chờ Google như mọi khi."""
    task = viec.pop("task_tro_ly", None)
    if task and not task.done():
        task.cancel()
        await asyncio.wait([task], timeout=10)
    ty = viec.get("tro_ly")
    if ty:
        ty["dang_gui"] = False
        if ty.get("doan"):
            ghi_nhat_ky(viec, f"Trong lúc họp đã gửi {len(ty['doan'])} đoạn")


def _bao_cho(viec: dict, ten: str, sau_han: str):
    """Dòng trạng thái khi chờ Google chép lời một đoạn, sau khi đã Dừng."""
    han_phut = max(1, round(HAN_NLM["go_chu"] / 60))

    def bao(phut: int) -> None:
        viec["trang_thai"] = (f"Bước 1/2: đang chép lời {ten}, đã chờ {phut} phút. "
                              f"Quá {han_phut} phút chưa xong thì {sau_han}")
    return bao


async def hoan_tat_cac_doan(viec: dict, duong_dan: Path) -> None:
    """Sau khi Dừng, ở cuộc họp gửi lên NotebookLM: chờ nốt các đoạn đã gửi, gửi đoạn
    cuối, rồi ghép chữ các đoạn thành bản chép lời cả buổi. Hỏng ở đâu thì để trống
    bản chép lời, dong_notebooklm sẽ tải cả bản ghi lên như cách cũ. Riêng nút Thôi
    chờ Google thì dừng hẳn, như mọi khi."""
    ty = viec["tro_ly"]
    lui = "máy tải cả bản ghi lên như cách cũ"
    viec["buoc"] = 1
    viec["trang_thai"] = "Bước 1/2: đang kết nối"
    try:
        async with contextlib.AsyncExitStack() as ngan:
            nlm = await _co_han(ngan.enter_async_context(ket_noi_nlm()), HAN_NLM["ket_noi"],
                                "kết nối")
            so = viec["so_nlm"]
            for doan in ty["doan"]:
                if doan["tt"] != "xong":
                    await lay_chu_doan(nlm, viec, so, doan, viec, HAN_NLM["go_chu"],
                                       _bao_cho(viec, doan["ten"].lower(), lui))
            khung, con_tro, giay = await asyncio.to_thread(ghi_am.cat_tu_tep, duong_dan,
                                                           ty["con_tro"])
            if giay >= 1:
                aac = Path(ngan.enter_context(tempfile.TemporaryDirectory())) / "doan.aac"
                aac.write_bytes(khung)
                if await im_lang(aac):
                    ty["con_tro"], ty["giay_da_cat"] = con_tro, ty["giay_da_cat"] + giay
                else:
                    viec["trang_thai"] = "Bước 1/2: đang gửi đoạn cuối"
                    doan = await tai_doan(nlm, viec, so, aac, giay, con_tro)
                    await lay_chu_doan(nlm, viec, so, doan, viec, HAN_NLM["go_chu"],
                                       _bao_cho(viec, "đoạn cuối", lui))
    except ThoiChoGoogle:
        raise
    except Exception as loi:  # noqa: BLE001 - còn đường lùi: tải cả bản ghi lên
        print(f"Chưa ghép được chữ các đoạn ở việc {viec['ma']}: {type(loi).__name__}: {loi}",
              flush=True)
        ghi_nhat_ky(viec, f"Có đoạn chưa lấy được chữ ({ly_do_loi(loi)}), {lui}")
        return
    viec["ban_go_chu"] = ghep_chu_cac_doan(ty["doan"])
    luu_viec(viec)
    ghi_nhat_ky(viec, f"Đã có chữ cả buổi từ {len(ty['doan'])} đoạn")


async def soan_phan_da_gui(viec: dict, duong_dan: Path, tt: dict) -> None:
    """Cuộc họp chuyển sang Không gửi lên mạng giữa buổi khi đã gửi vài đoạn. PM chọn
    26/9/2026: giữ các đoạn đã gửi, thôi gửi phần sau. Máy chỉ lấy nốt chữ của những
    đoạn ĐÃ tải lên trước lúc chuyển, không tải thêm gì, rồi nhờ NotebookLM soạn nháp
    phần đó; phần sau thư ký nghe lại bản ghi để viết."""
    ty = viec["tro_ly"]
    so = viec.get("so_nlm") or {}
    if (not viec.get("ban_go_chu") and so.get("id") and da_dang_nhap_nlm()
            and any(d.get("tt") != "xong" for d in ty["doan"])):
        try:
            async with contextlib.AsyncExitStack() as ngan:
                nlm = await _co_han(ngan.enter_async_context(ket_noi_nlm()),
                                    HAN_NLM["ket_noi"], "kết nối")
                for doan in ty["doan"]:
                    if doan.get("tt") != "xong":
                        await lay_chu_doan(nlm, viec, so, doan, viec, HAN_NLM["go_chu"],
                                           _bao_cho(viec, doan["ten"].lower(), "máy bỏ đoạn đó"))
        except ThoiChoGoogle:
            raise
        except Exception as loi:  # noqa: BLE001 - soạn với những đoạn đã có chữ
            ghi_nhat_ky(viec, f"Chưa lấy được chữ một đoạn đã gửi ({ly_do_loi(loi)})")
    lien = cac_doan_lien(ty)
    viec["ban_go_chu"] = viec.get("ban_go_chu") or ghep_chu_cac_doan(lien)
    toi = moc(lien[-1]["den"]) if lien else "00:00"
    chuyen = ty["chuyen_luc"] * ti_le_moc(viec)
    them_canh_bao(viec, f"Cuộc họp chuyển sang Không gửi lên mạng giữa buổi (lúc "
                        f"{moc(chuyen)} của bản ghi). Máy chỉ soạn nháp phần đã gửi "
                        f"trước đó, tới {toi}; phần sau thư ký nghe lại bản ghi để viết.")
    ghi_chu = (f"[Từ {toi}, cuộc họp chuyển sang Không gửi lên mạng: thư ký nghe lại bản ghi "
               f"từ {toi} để viết phần còn lại]")
    if not viec["ban_go_chu"]:
        viec["ket_qua"] = khung_bien_ban(khoi_ngu_canh(viec, cho_may=False), tt,
                                         GHI_CHU_KHONG_GUI)
        return
    if da_dang_nhap_nlm():
        try:
            # Chỉ gửi kèm các dòng ghi nhanh ghi TRƯỚC lúc chuyển và thuộc phần đã gửi.
            # Lấy mốc sớm hơn trong hai mốc (lúc chuyển, cuối phần đã gửi): cuộc họp cũ
            # gắn mốc theo đồng hồ, quy đổi chỉ gần đúng
            luu_y = (f"Lưu ý: bản chép lời chỉ có phần đầu cuộc họp, tới {toi}. Phần sau không "
                     "có trong nguồn, không được đoán.")
            await soan_nhieu_tai_khoan(duong_dan, tt, viec, them=ngu_canh_bien_ban(
                viec, tt, truoc=min(chuyen, lien[-1]["den"]), luu_y=luu_y), them_gon=luu_y)
            viec["ket_qua"] = chen_ghi_chu(viec["ket_qua"], ghi_chu)
            return
        except Exception as loi:  # noqa: BLE001 - soạn tại máy từ chữ đã có
            them_canh_bao(viec, f"Chưa soạn được trực tuyến ({ly_do_loi(loi)}), nên máy soạn "
                                "tại máy từ phần đã chép lời.")
    await soan_tu_ban_go_chu(viec["ban_go_chu"], tt, viec)
    viec["ket_qua"] = chen_ghi_chu(viec["ket_qua"], ghi_chu)


def huong_dan_quyen_micro() -> str:
    """Cách xem lại micro và quyền dùng micro, đúng theo hệ điều hành của máy."""
    if LA_WINDOWS:
        return ("Xem ô Micro dưới nút đỏ có đúng micro gắn trong laptop không (không phải "
                "tai nghe Bluetooth hay Stereo Mix). Nếu đúng thì Windows chưa cho phép dùng "
                "micro: mở Cài đặt, Quyền riêng tư và bảo mật, Micrô, bật quyền truy cập micrô "
                "và bật cho ứng dụng trên máy tính (desktop apps).")
    return ("Xem ô Micro dưới nút đỏ có đúng micro của máy Mac không (không phải micro của "
            "iPhone). Nếu đúng thì máy chưa được phép dùng micro: Cài đặt hệ thống, Quyền "
            "riêng tư và bảo mật, Micrô, bật cho SonicRec.")


async def kiem_co_tieng(duong_dan: Path) -> None:
    """Bản ghi gần như im lặng thì dừng trước khi gửi đi chép lời, vì không máy
    chép lời nào nghe ra gì đúng từ đó (Whisper trước đây còn bịa chữ)."""
    to_nhat = await asyncio.to_thread(muc_to_nhat, duong_dan)
    if to_nhat is not None and to_nhat < NGUONG_IM_LANG_DB:
        raise LoiRo(
            f"Bản ghi gần như im lặng (tiếng to nhất chỉ {to_nhat:.0f} dB, tiếng nói "
            f"thường khoảng -20 dB), nên không chép lời để tránh máy bịa chữ. "
            f"{huong_dan_quyen_micro()} Rồi bấm Thử micro trước khi họp.")


# ----------------------------------------------------------------------------
# Khung việc chung
# ----------------------------------------------------------------------------

async def chay_viec(ma: str, duong_dan: Path, tt: dict) -> None:
    viec = VIEC[ma]
    try:
        if not viec.get("ban_go_chu"):
            await kiem_co_tieng(duong_dan)
        # Chỉ gửi lên Google khi CẢ lúc bấm ghi (lúc câu thông báo hiện cho chủ trì
        # đọc) LẪN bây giờ đều chọn NotebookLM. Cuộc họp đã hứa "không gửi lên mạng"
        # thì đổi sang NotebookLM rồi bấm Làm lại cũng không gửi. Cuộc họp ghi trước
        # khi có NotebookLM không có khoá này, và đều đã đọc câu xử lý tại máy.
        cach = ("notebooklm" if viec.get("cach_da_bao") == "notebooklm"
                and cach_go_chu() == "notebooklm" else "whisper")
        viec["cach"] = cach
        # Độ dài bản ghi, để tệp Word có giờ kết thúc cả với tệp kéo thả vào
        viec["thoi_luong_giay"] = (viec.get("thoi_luong_giay")
                                  or await asyncio.to_thread(do_dai_ban_ghi, duong_dan))
        ty = viec.get("tro_ly") or {}
        if (ty and not ty.get("moc_am") and not viec.get("am_thanh_giay")
                and duong_dan.suffix == ".aac" and duong_dan.is_file()):
            # Cuộc họp ghi trước 28/9/2026 bấm Làm lại: đo âm thanh thật để đổi mốc ghi
            # chú của thư ký (đồng hồ) về cùng thang với bản chép lời (ti_le_moc)
            viec["am_thanh_giay"] = round(await asyncio.to_thread(
                lambda: ghi_am.tach_khung_adts(duong_dan.read_bytes(), het=True)[2]), 1)
        # Không còn chép lời tại máy (PM bỏ Whisper 26/9/2026). Chỉ khi đã có bản chép lời
        # (Google chép lời xong mà hỏng ở bước soạn, hoặc việc cũ) thì máy soạn tại máy.
        if cach == "whisper" and ty.get("chuyen_luc") is not None and ty.get("doan"):
            # Chuyển sang Không gửi lên mạng giữa buổi khi trợ lý đã gửi vài đoạn
            await soan_phan_da_gui(viec, duong_dan, tt)
        elif cach == "whisper":
            if viec.get("ban_go_chu"):
                await soan_tu_ban_go_chu(viec["ban_go_chu"], tt, viec)
            else:
                # Không chép lời, chỉ dựng khung biên bản (kèm các dòng ghi nhanh). Việc Xong
                # nên còn nút Đã ký để xoá bản ghi, đúng lời hứa "xoá sau khi biên bản được duyệt".
                viec["ket_qua"] = khung_bien_ban(khoi_ngu_canh(viec, cho_may=False), tt,
                                                 GHI_CHU_KHONG_GUI)
                them_canh_bao(viec, "Cuộc họp này chọn Không gửi lên mạng: bản ghi chỉ giữ trên "
                                    "máy, máy không chép lời và chỉ dựng khung biên bản. Thư ký "
                                    "nghe lại bản ghi để viết phần nội dung.")
                ghi_nhat_ky(viec, "Không gửi lên mạng: dựng khung biên bản, không chép lời")
        elif not da_dang_nhap_nlm():
            if not viec.get("ban_go_chu"):
                raise LoiRo("Chưa đăng nhập Google. Bản ghi vẫn giữ nguyên: đăng nhập ở thẻ "
                            "Cài đặt rồi bấm Làm lại.")
            them_canh_bao(viec, "Chưa đăng nhập Google nên máy soạn tại máy từ bản chép lời "
                                "đã có. Đăng nhập ở thẻ Cài đặt.")
            await soan_tu_ban_go_chu(viec["ban_go_chu"], tt, viec)
        else:
            try:
                # Trợ lý đã gửi từng đoạn trong lúc họp: chỉ còn đoạn cuối, rồi soạn
                # từ chữ các đoạn. Chưa gửi đoạn nào (họp ngắn) thì đi đường cũ.
                if ty.get("doan") and not viec.get("ban_go_chu"):
                    await hoan_tat_cac_doan(viec, duong_dan)
                await soan_nhieu_tai_khoan(duong_dan, tt, viec, them=ngu_canh_bien_ban(viec, tt))
                await ghi_so_tay(viec)
            except Exception as loi:  # noqa: BLE001 - đường không chính thức, hỏng thì dừng
                print(f"Xử lý trực tuyến hỏng ở việc {ma}: {type(loi).__name__}: {loi}",
                      flush=True)
                ly_do = ly_do_loi(loi)
                if not viec.get("ban_go_chu"):
                    raise LoiRo(f"{ly_do}. Bản ghi vẫn giữ nguyên: bấm Làm lại sau ít "
                                "phút.") from None
                # Đã chép lời xong, chỉ hỏng ở bước soạn: soạn tại máy từ bản đó
                them_canh_bao(viec, f"{ly_do}, nên máy soạn tại máy từ bản chép lời đã có.")
                ghi_nhat_ky(viec, ("Thôi chờ" if isinstance(loi, ThoiChoGoogle)
                                   else "Xử lý trực tuyến hỏng")
                            + ", soạn tại máy từ bản chép lời đã có")
                await soan_tu_ban_go_chu(viec["ban_go_chu"], tt, viec)
        viec["trang_thai"] = "Đang tạo tệp Word"
        viec["buoc"] = 3
        await asyncio.to_thread(tao_tep_word, viec)
        if viec.get("tep_word"):
            ghi_nhat_ky(viec, "Đã tạo tệp Word")
        viec["trang_thai"] = "Xong"
        viec["buoc"] = 4
    except Exception as loi:  # noqa: BLE001 - dừng ở Lỗi, giữ bản ghi để bấm Làm lại
        viec["trang_thai"] = "Lỗi"
        # Lỗi tự đặt (LoiRo) đã có câu tiếng Việt; lỗi khác chỉ nói chung chung theo loại,
        # nguyên văn in vào nhat-ky-ung-dung.txt (ly_do_loi)
        print(f"Việc {ma} dừng vì lỗi: {type(loi).__name__}: {loi}", flush=True)
        viec["loi"] = ly_do_loi(loi)
        ghi_nhat_ky(viec, "Dừng vì lỗi")
    finally:
        # KHÔNG xoá bản ghi ở đây. Hỏng thì còn bấm Làm lại; xong thì giữ tới khi
        # bấm Đã ký, đúng lời hứa "xoá sau khi biên bản được duyệt".
        try:
            luu_viec(viec)
        except OSError as loi:
            print(f"Không lưu được việc {ma}: {loi}")




# ----------------------------------------------------------------------------
# Hàng rào: chỉ chính máy này, chỉ từ giao diện của ứng dụng
# ----------------------------------------------------------------------------

@app.middleware("http")
async def chi_ten_may_nay(request: Request, call_next):
    """Chặn kiểu tấn công đổi tên miền (DNS rebinding): một trang web lạ đang
    mở trên máy trỏ tên miền của nó về 127.0.0.1 để đọc biên bản. Trình duyệt
    vẫn gửi tên miền lạ đó ở dòng Host, nên chỉ nhận Host là chính máy này."""
    host = request.headers.get("host") or ""
    ten = host.split("]")[0] + "]" if host.startswith("[") else host.split(":")[0]
    if ten not in ("127.0.0.1", "localhost", "[::1]"):
        return PlainTextResponse("Chỉ mở được trên chính máy này", status_code=403)
    return await call_next(request)


def chi_tu_may_nay(request: Request) -> None:
    """Máy chủ vốn chỉ nghe ở 127.0.0.1; kiểm thêm lần nữa cho chắc."""
    tu = (request.client.host if request.client else "") or ""
    try:
        if not ipaddress.ip_address(tu).is_loopback:
            raise HTTPException(status_code=403, detail="Chỉ dùng được trên chính máy này")
    except ValueError:
        raise HTTPException(status_code=403, detail="Không xác định được nơi gọi")


def kiem_tra_nut(x_bang_dieu_khien: str | None) -> None:
    """Chặn trang web lạ đang mở trên chính laptop gửi lệnh (như xoá bản ghi) hộ.
    Trình duyệt không cho trang khác gắn tiêu đề riêng này nếu máy chủ không
    đồng ý trước, và máy chủ này không bao giờ đồng ý."""
    if x_bang_dieu_khien != "1":
        raise HTTPException(status_code=403, detail="Chỉ bấm được từ giao diện của ứng dụng")


def _chan(request: Request, x_bang_dieu_khien: str | None) -> None:
    chi_tu_may_nay(request)
    kiem_tra_nut(x_bang_dieu_khien)


# ----------------------------------------------------------------------------
# Khoá kích hoạt (kich_hoat.py, PM chốt 28/9/2026): máy chưa kích hoạt hoặc mã đã hết
# hạn thì không bắt đầu ghi âm, không nhận tệp ghi âm, không Làm lại. Xem các cuộc họp
# cũ, mở Word, Cài đặt, cập nhật vẫn được; cuộc họp đang ghi hay đang soạn thì chạy tới cùng.
# ----------------------------------------------------------------------------

def co_cuoc_hop_truoc_khoa() -> bool:
    """Máy đã dùng trước khi có khoá: có cuộc họp nhận trước ngày bản có khoá phát hành."""
    for v in VIEC.values():
        try:
            if datetime.fromisoformat(v.get("nhan_luc") or "").date() < kich_hoat.NGAY_BAT_KHOA:
                return True
        except (TypeError, ValueError):
            continue
    return False


def trang_thai_kich_hoat() -> dict:
    return kich_hoat.trang_thai(co_cuoc_hop_truoc_khoa)


def can_kich_hoat() -> None:
    """Chặn ở máy chủ, không chỉ ở giao diện: nút bị ẩn mà lời gọi vẫn chạy thì khoá vô nghĩa."""
    tt = trang_thai_kich_hoat()
    if tt["duoc_dung"]:
        return
    may = tt["ma_may"]
    if tt["tinh_trang"] == "het_han":
        chu = (f"Mã kích hoạt đã hết hạn ngày {tt['han']}. Gửi mã máy {may} cho người phát hành "
               "để xin mã mới, rồi nhập ở thẻ Cài đặt, mục Kích hoạt.")
    elif tt["tinh_trang"] == "het_dung_tiep":
        chu = (f"Đã hết thời gian dùng tiếp. Gửi mã máy {may} cho người phát hành để nhận mã "
               "kích hoạt, rồi nhập ở thẻ Cài đặt, mục Kích hoạt.")
    else:
        chu = (f"Máy này chưa được kích hoạt. Gửi mã máy {may} cho người phát hành để nhận mã "
               "kích hoạt, rồi nhập ở thẻ Cài đặt, mục Kích hoạt.")
    raise HTTPException(status_code=403, detail=chu + " Các cuộc họp đã ghi vẫn mở xem được.")


def mot_thang_sau(d: date) -> date:
    """Cùng ngày của tháng sau; tháng sau ngắn hơn thì lấy ngày cuối tháng (31/1 ra 28/2)."""
    import calendar
    nam, thang = (d.year + 1, 1) if d.month == 12 else (d.year, d.month + 1)
    return date(nam, thang, min(d.day, calendar.monthrange(nam, thang)[1]))


@app.post("/may/kich-hoat")
async def nhap_ma_kich_hoat(request: Request, x_bang_dieu_khien: str | None = Header(None)):
    """Người dùng dán mã kích hoạt (hoặc cả tin nhắn có mã) người phát hành gửi."""
    _chan(request, x_bang_dieu_khien)
    try:
        chu = str((await request.json()).get("ma") or "")
    except (ValueError, AttributeError):
        chu = ""
    try:
        nd, ly_do = await asyncio.to_thread(kich_hoat.nhap_ma, chu)
    except OSError as loi:
        raise HTTPException(status_code=500, detail=f"Không ghi được tệp kích hoạt trong thư mục cài: {loi}")
    if not nd:
        raise HTTPException(status_code=400, detail=ly_do)
    return JSONResponse(trang_thai_kich_hoat())


@app.get("/may/cap-ma")
async def xem_cap_ma(request: Request):
    """Mục Cấp mã ở thẻ Cài đặt: chỉ có trên máy có chìa khoá riêng của người phát hành."""
    chi_tu_may_nay(request)
    ph = await asyncio.to_thread(kich_hoat.may_phat_hanh)
    if not ph["co"]:
        raise HTTPException(status_code=404, detail="Máy này không cấp mã kích hoạt")
    return JSONResponse({**ph, "han_mac_dinh": mot_thang_sau(date.today()).isoformat(),
                         "da_cap": kich_hoat.ds_da_cap() if ph["khop"] else []})


@app.post("/may/cap-ma")
async def cap_ma_kich_hoat(request: Request, x_bang_dieu_khien: str | None = Header(None)):
    _chan(request, x_bang_dieu_khien)
    try:
        than = await request.json()
        han = date.fromisoformat(str(than.get("han") or ""))
    except (ValueError, AttributeError):
        raise HTTPException(status_code=400, detail="Chọn ngày hết hạn của mã.")
    cho = " ".join(str(than.get("cho") or "").split())
    try:
        ma = await asyncio.to_thread(kich_hoat.cap_ma, str(than.get("may") or ""), cho, han)
    except PermissionError as loi:
        raise HTTPException(status_code=403, detail=str(loi))
    except ValueError as loi:
        raise HTTPException(status_code=400, detail=str(loi))
    return JSONResponse({"ma": ma, "tin_nhan": (
        f"Mã kích hoạt SonicRec cho {cho}, dùng đến hết ngày {han:%d/%m/%Y}. Mở ứng dụng, "
        f"dán cả tin nhắn này vào ô Mã kích hoạt:\n{ma}")})


# ----------------------------------------------------------------------------
# Tạo cuộc họp: ghi âm trên máy, hoặc kéo thả tệp ghi âm vào
# ----------------------------------------------------------------------------

def moi_viec(nhan_luc: datetime, bat_dau: datetime | None, chac: bool, trang_thai: str) -> dict:
    ma = uuid.uuid4().hex[:8]
    thu_muc = THU_MUC_LUU / f"{(bat_dau or nhan_luc):%Y-%m-%d_%H%M}_{ma}"
    thu_muc.mkdir(parents=True, exist_ok=True)
    tt = tt_mac_dinh()
    tt["thoi_gian"] = tt["thoi_gian"] or dinh_dang_thoi_gian(bat_dau, nhan_luc, chac)
    return {"ma": ma, "trang_thai": trang_thai, "ket_qua": None, "loi": None,
            "ban_go_chu": "", "canh_bao": None, "tt": tt, "thu_muc": str(thu_muc),
            "tep_ghi_am": None, "nhan_luc": nhan_luc.isoformat(timespec="seconds"),
            "bat_dau": bat_dau.isoformat(timespec="seconds") if bat_dau else None,
            "ket_thuc": None, "thoi_luong_giay": None, "da_ky": False, "tep_word": None,
            "buoc": 0, "nhat_ky": [], "cach_da_bao": cach_go_chu()}


def dang_ky_viec(viec: dict) -> None:
    luu_viec(viec)  # lưu ngay: ứng dụng tắt lúc này vẫn còn dấu vết
    VIEC[viec["ma"]] = viec
    THU_TU.append(viec["ma"])


def bat_dau_xu_ly(viec: dict) -> None:
    # Giữ tham chiếu tới task trong VIEC, nếu không Python có thể thu hồi giữa đường
    viec["task"] = asyncio.create_task(
        chay_viec(viec["ma"], Path(viec["thu_muc"]) / viec["tep_ghi_am"], viec["tt"]))


@app.post("/may/tai-len")
async def nhan_ghi_am(request: Request, ghi_am_tep: UploadFile = File(..., alias="ghi_am"),
                      x_bang_dieu_khien: str | None = Header(None)):
    """Nhận tệp ghi âm kéo thả vào cửa sổ, ví dụ tệp AirDrop từ iPhone."""
    _chan(request, x_bang_dieu_khien)
    can_kich_hoat()
    nhan_luc = datetime.now()
    viec = moi_viec(nhan_luc, None, False, "Đã nhận tệp, đang chuẩn bị")
    thu_muc = Path(viec["thu_muc"])
    duong_dan = thu_muc / f"ghi-am{Path(ghi_am_tep.filename or 'x.m4a').suffix or '.m4a'}"

    tong = 0  # ghi theo từng khối để file dài không ngốn hết bộ nhớ
    with duong_dan.open("wb") as f:
        while khoi := await ghi_am_tep.read(1024 * 1024):
            tong += len(khoi)
            if tong > GIOI_HAN_BYTE:
                break
            f.write(khoi)
    if tong > GIOI_HAN_BYTE:
        shutil.rmtree(thu_muc, ignore_errors=True)
        raise HTTPException(status_code=413, detail="Tệp quá lớn, hãy chia nhỏ")

    bat_dau = await asyncio.to_thread(thoi_diem_bat_dau, duong_dan)
    if bat_dau:  # có giờ ghi trong tệp thì thay cho giờ nhận tệp
        viec["bat_dau"] = bat_dau.isoformat(timespec="seconds")
        if not thong_tin_mac_dinh().get("thoi_gian"):
            viec["tt"]["thoi_gian"] = dinh_dang_thoi_gian(bat_dau, nhan_luc)
    viec["tep_ghi_am"] = duong_dan.name
    ghi_nhat_ky(viec, f"Nhận tệp {ghi_am_tep.filename or duong_dan.name}")
    dang_ky_viec(viec)
    bat_dau_xu_ly(viec)
    return JSONResponse({"ma": viec["ma"], "so_byte": tong})


@app.get("/may/micro")
async def ds_micro(request: Request):
    chi_tu_may_nay(request)
    ds = await asyncio.to_thread(ghi_am.cac_micro)
    da_chon = str(thong_tin_mac_dinh().get("micro_da_chon") or "")
    chon = ghi_am.chon_micro(ds, da_chon)
    tu_dong = ghi_am.chon_micro(ds, None)
    return JSONResponse({"ds": [ten for _, ten in ds], "chon": chon[1] if chon else None,
                         "da_chon": da_chon, "tu_dong": tu_dong[1] if tu_dong else None})


async def _micro_dang_chon() -> tuple[int, str]:
    if not shutil.which("ffmpeg") and not ghi_am.nguon_thu():
        raise HTTPException(status_code=409, detail="Chưa có ffmpeg. Chạy lại trình cài đặt "
                            "SonicRec.")
    ds = await asyncio.to_thread(ghi_am.cac_micro)
    micro = ghi_am.chon_micro(ds, thong_tin_mac_dinh().get("micro_da_chon"))
    if not micro:
        raise HTTPException(status_code=409, detail="Không tìm thấy micro nào trên máy.")
    return micro


async def _micro_ghi_tiep() -> tuple | None:
    """Micro để ghi tiếp sau Tạm dừng: tìm lại theo TÊN micro đang ghi. Trên Mac, số
    thứ tự trong danh sách đổi khi iPhone lại gần hay tai nghe vừa nối; mở lại theo số
    cũ là ghi nhầm micro, phần sau chỉ có tiếng rè (thẻ trống sau Ghi tiếp, 27/9/2026).
    Micro đó đã rút thì chọn như lúc bấm ghi; không liệt kê được thì None (giữ như cũ)."""
    ds = await asyncio.to_thread(ghi_am.cac_micro)
    dang = MAY_GHI.micro
    for so, ten in ds:
        if dang and ten == dang[1]:
            return so, ten
    return ghi_am.chon_micro(ds, thong_tin_mac_dinh().get("micro_da_chon"))


@app.post("/may/ghi/thu-micro")
async def ghi_thu_micro(request: Request, x_bang_dieu_khien: str | None = Header(None)):
    _chan(request, x_bang_dieu_khien)
    if MAY_GHI.tt:
        raise HTTPException(status_code=409, detail="Đang ghi âm, không thử micro được")
    micro = await _micro_dang_chon()
    cao, loi = await asyncio.to_thread(ghi_am.thu_micro, micro[0])
    return JSONResponse({"micro": micro[1], "db": cao, "loi": loi,
                         "co_tieng": cao is not None and cao > ghi_am.IM_LANG_DB})


@app.post("/may/ghi/bat-dau")
async def ghi_bat_dau(request: Request, x_bang_dieu_khien: str | None = Header(None)):
    _chan(request, x_bang_dieu_khien)
    can_kich_hoat()
    if MAY_GHI.tt:
        raise HTTPException(status_code=409, detail="Đang ghi một cuộc họp khác")
    micro = await _micro_dang_chon()
    bat_dau = datetime.now()
    viec = moi_viec(bat_dau, bat_dau, True, "Đang ghi âm")
    viec["tro_ly"] = moi_tro_ly()
    ghi_nhat_ky(viec, f"Bắt đầu ghi âm, micro: {micro[1]}")
    dang_ky_viec(viec)
    try:
        await asyncio.to_thread(MAY_GHI.bat_dau, viec["ma"], Path(viec["thu_muc"]), micro)
    except Exception as loi:
        viec.update(trang_thai="Lỗi", loi=f"Không bật được ghi âm: {loi}")
        luu_viec(viec)
        raise HTTPException(status_code=500, detail=viec["loi"])
    bo_noi_dung_da_dung()
    if duoc_gui(viec):
        try:
            viec["tro_ly"]["nen"] = chuan_bi_nen(viec)
        except Exception as loi:  # noqa: BLE001 - tài liệu hỏng không được chặn ghi âm
            ghi_nhat_ky(viec, f"Chưa chuẩn bị được tài liệu cho trợ lý ({ly_do_loi(loi)})")
        luu_viec(viec)
        viec["task_tro_ly"] = asyncio.create_task(vong_tro_ly(viec))
    else:
        viec["tro_ly"]["trang_thai"] = "Cuộc họp chọn Không gửi lên mạng nên trợ lý không chạy."
    return JSONResponse({"ma": viec["ma"]})


def dong_hut_am_thanh(am: float, giay: float) -> str:
    """Âm thanh trong tệp ngắn hẳn thời gian ghi, tức máy thu âm bị rớt tiếng. Thấy trên
    máy Mac của PM 27/9/2026: mỗi nhịp 5 phút đồng hồ chỉ có khoảng 4 phút 15 giây âm
    thanh. Ghi vào nhật ký cuộc họp để đo chắc; rỗng là không hụt đáng kể."""
    if giay < 60 or am >= giay * 0.95:
        return ""
    return (f"Âm thanh trong tệp dài {moc(am)}, ngắn hơn thời gian ghi {moc(giay)} "
            f"(hụt {round(100 - 100 * am / giay)}%): máy thu âm bị rớt tiếng")


@app.post("/may/ghi/{lenh}")
async def ghi_dieu_khien(lenh: str, request: Request,
                         x_bang_dieu_khien: str | None = Header(None)):
    """tam-dung, tiep-tuc, dung."""
    _chan(request, x_bang_dieu_khien)
    viec = VIEC.get(MAY_GHI.ma or "")
    try:
        if lenh == "tam-dung":
            await asyncio.to_thread(MAY_GHI.tam_dung)
            if viec:
                ghi_nhat_ky(viec, "Tạm dừng ghi âm")
        elif lenh == "tiep-tuc":
            cu = MAY_GHI.micro
            micro = await _micro_ghi_tiep()
            await asyncio.to_thread(MAY_GHI.tiep_tuc, micro)
            if viec:
                ghi_nhat_ky(viec, "Ghi âm tiếp" + (f", đổi sang micro: {micro[1]}"
                                                   if micro and cu and micro[1] != cu[1] else ""))
        elif lenh == "dung":
            await tat_xem()  # bấm Dừng thì điện thoại của chủ trì thôi xem được
            if viec:
                await dung_tro_ly(viec)
            ma, tep, giay = await asyncio.to_thread(MAY_GHI.dung)
            viec = VIEC[ma]
            viec["ket_thuc"] = datetime.now().isoformat(timespec="seconds")
            if not tep:
                viec.update(trang_thai="Lỗi", loi="Chưa ghi được chút âm thanh nào.")
                luu_viec(viec)
                return JSONResponse({"ma": ma})
            viec.update(tep_ghi_am=tep.name, thoi_luong_giay=round(giay),
                        trang_thai="Đã dừng ghi, đang chuẩn bị")
            ghi_nhat_ky(viec, f"Dừng ghi, bản ghi dài {max(1, round(giay / 60))} phút")
            am = await asyncio.to_thread(lambda: ghi_am.tach_khung_adts(tep.read_bytes(), het=True)[2])
            viec["am_thanh_giay"] = round(am, 1)
            if hut := dong_hut_am_thanh(am, giay):
                ghi_nhat_ky(viec, hut)
            luu_viec(viec)
            bat_dau_xu_ly(viec)
            return JSONResponse({"ma": ma})
        else:
            raise HTTPException(status_code=404, detail="Không có lệnh này")
    except RuntimeError as loi:
        raise HTTPException(status_code=409, detail=str(loi))
    if viec:
        luu_viec(viec)
    return JSONResponse({"ok": True})


@app.get("/may/ghi/trang-thai")
async def ghi_trang_thai(request: Request):
    chi_tu_may_nay(request)
    return JSONResponse(MAY_GHI.trang_thai())


@app.get("/may/tro-ly")
async def xem_tro_ly(request: Request):
    """Tình trạng trợ lý của cuộc họp đang ghi, cho màn Đang ghi."""
    chi_tu_may_nay(request)
    viec = VIEC.get(MAY_GHI.ma or "")
    ty = (viec or {}).get("tro_ly")
    if not ty:
        return JSONResponse({"co": False})
    nhip = nhip_thuc()
    lien = cac_doan_lien(ty)
    return JSONResponse({
        "co": True, "ma": viec["ma"], "bat": duoc_gui(viec) and bool(viec.get("task_tro_ly")),
        "trang_thai": ty.get("trang_thai") or "", "tam_nghi": ty.get("tam_nghi") or "",
        "dang_gui": bool(ty.get("dang_gui")), "so_doan": len(ty.get("doan") or []),
        "go_chu_toi": lien[-1]["den"] if lien else 0, "nhip": nhip,
        "gian_nhip": bool(nhip) and nhip != nhip_tro_ly(),
        # Vừa gửi hỏng thì lần sau là lần thử lại theo hẹn, không phải tròn một nhịp
        "lan_sau": (None if not nhip else ty["thu_lai"] if ty.get("thu_lai") is not None
                    else ty.get("giay_xet", 0) + nhip),
        "luot_con": luot_con_lai(), "ly_do_khong_hoi": ly_do_khong_hoi(viec),
        "co_nguon": bool(nguon_da_co(ty)),
        "the": ty.get("the") or [], "ghim": ghim(ty), "ghi_nhanh": ty.get("ghi_nhanh") or [],
        "nen": [{"ten": n["ten"], "tt": n["tt"], "loi": n.get("loi") or "", "loai": n.get("loai"),
                 "lan": n.get("lan", 0)} for n in ty.get("nen") or []],
        "xem": trang_thai_xem(viec),
    })


def ghim(ty: dict) -> dict:
    """Khối ghim đầu khung Trợ lý, lấy từ thẻ gợi ý mới nhất: việc cần chốt, mục
    chương trình đã bàn hay chưa, việc tuần trước chưa ai nhắc."""
    for t in reversed(ty.get("the") or []):
        if t.get("loai") == "doan":
            return {k: t.get(k) or [] for k in ("can_chot", "chuong_trinh", "viec_cu")}
    return {}


def _viec_tro_ly(can_gui: bool = True) -> dict:
    """Cuộc họp đang ghi, cho các nút của khung Trợ lý. can_gui: nút đó cần gửi lên
    NotebookLM (Tóm tắt ngay, Tổng kết, Hỏi); ghi nhanh thì không cần."""
    viec = VIEC.get(MAY_GHI.ma or "")
    if not viec or not viec.get("tro_ly"):
        raise HTTPException(status_code=409, detail="Chỉ dùng được trong lúc đang ghi âm")
    if can_gui and (not duoc_gui(viec) or not viec.get("task_tro_ly")):
        raise HTTPException(status_code=409, detail="Trợ lý chỉ chạy khi đang ghi một cuộc "
                            "họp chọn gửi lên mạng")
    return viec


async def _doc_chu(request: Request, khoa: str, toi_da: int) -> str:
    try:
        than = await request.json()
    except ValueError:
        raise HTTPException(status_code=400, detail="Dữ liệu không đọc được")
    chu = than.get(khoa) if isinstance(than, dict) else None
    if not isinstance(chu, str) or not chu.strip():
        raise HTTPException(status_code=400, detail="Chưa có nội dung")
    if len(chu) > toi_da:
        raise HTTPException(status_code=400, detail=f"Dài quá {toi_da} ký tự")
    return chu.strip()


@app.post("/may/tro-ly/tom-tat-ngay")
async def tom_tat_ngay(request: Request, x_bang_dieu_khien: str | None = Header(None)):
    """Nút Tóm tắt ngay: gửi phần vừa ghi ở lượt kế tiếp của trợ lý (vài giây)."""
    _chan(request, x_bang_dieu_khien)
    _viec_tro_ly()["tro_ly"]["yeu_cau"] = "tom-tat"
    return JSONResponse({"ok": True})


@app.post("/may/tro-ly/tong-ket")
async def tong_ket(request: Request, x_bang_dieu_khien: str | None = Header(None)):
    """Nút Tổng kết: gửi nốt phần vừa ghi rồi nhờ NotebookLM tổng kết cả buổi."""
    _chan(request, x_bang_dieu_khien)
    _viec_tro_ly()["tro_ly"]["yeu_cau"] = "tong-ket"
    return JSONResponse({"ok": True})


TAC_VU_NEN: set = set()  # giữ tham chiếu tới việc chạy nền, không thì Python có thể thu hồi


@app.post("/may/tro-ly/hoi")
async def hoi_tro_ly(request: Request, x_bang_dieu_khien: str | None = Header(None)):
    """Ô Hỏi NotebookLM: câu trả lời hiện thành thẻ khi xong (chạy nền)."""
    _chan(request, x_bang_dieu_khien)
    viec = _viec_tro_ly()
    cau = await _doc_chu(request, "cau_hoi", 1000)
    if not (viec.get("so_nlm") or {}).get("id") or not nguon_da_co(viec["tro_ly"]):
        raise HTTPException(status_code=409, detail="Chưa gửi được đoạn nào. Chờ lần gửi đầu "
                            "rồi hỏi.")
    ly_do = ly_do_khong_hoi(viec)
    if ly_do:
        raise HTTPException(status_code=409, detail=ly_do)
    the = them_the(viec, "hoi", cau_hoi=cau, tra_loi="", dang=True)
    nen = asyncio.create_task(tra_loi_o_hoi(viec, the))
    TAC_VU_NEN.add(nen)
    nen.add_done_callback(TAC_VU_NEN.discard)
    return JSONResponse({"ok": True})


@app.post("/may/tro-ly/ghi-nhanh")
async def them_ghi_nhanh(request: Request, x_bang_dieu_khien: str | None = Header(None)):
    """Ô Ghi nhanh: một dòng, máy tự gắn mốc thời gian trong bản ghi."""
    _chan(request, x_bang_dieu_khien)
    viec = _viec_tro_ly(can_gui=False)
    chu = await _doc_chu(request, "chu", 500)
    # Mốc theo giây âm thanh thật, cùng thang với các đoạn (xem MayGhi.giay_am_thanh)
    luc = await asyncio.to_thread(MAY_GHI.giay_am_thanh)
    viec["tro_ly"].setdefault("ghi_nhanh", []).append({"luc": luc, "chu": chu})
    luu_viec(viec)
    return JSONResponse({"ok": True})


@app.post("/may/tro-ly/ngu-canh")
async def them_ngu_canh(request: Request, x_bang_dieu_khien: str | None = Header(None)):
    """Nút Ghi ngữ cảnh ở ô Hỏi (PM chốt 27/9/2026): một dòng thông tin, không phải câu
    hỏi, để trợ lý và biên bản cuối dùng (ví dụ: người nói ở phút 12 là anh Tuấn). Hiện
    thành thẻ trong khung Trợ lý, không hiện trên điện thoại chủ trì. Chỉ gửi đi trong
    câu hỏi của cuộc họp gửi lên mạng (khoi_ngu_canh)."""
    _chan(request, x_bang_dieu_khien)
    viec = _viec_tro_ly(can_gui=False)
    chu = await _doc_chu(request, "chu", 1000)
    them_the(viec, "ngu_canh", chu=chu, giay=await asyncio.to_thread(MAY_GHI.giay_am_thanh),
             id=uuid.uuid4().hex[:10])
    return JSONResponse({"ok": True})


@app.delete("/may/tro-ly/ngu-canh/{ma_the}")
async def xoa_ngu_canh(ma_the: str, request: Request,
                       x_bang_dieu_khien: str | None = Header(None)):
    _chan(request, x_bang_dieu_khien)
    viec = _viec_tro_ly(can_gui=False)
    ds = viec["tro_ly"].setdefault("the", [])
    for i, t in enumerate(ds):
        if t.get("loai") == "ngu_canh" and t.get("id") == ma_the:
            ds.pop(i)
            luu_viec(viec)
            return JSONResponse({"ok": True})
    raise HTTPException(status_code=404, detail="Không có dòng này")


@app.delete("/may/tro-ly/ghi-nhanh/{so}")
async def xoa_ghi_nhanh(so: int, request: Request, x_bang_dieu_khien: str | None = Header(None)):
    _chan(request, x_bang_dieu_khien)
    viec = _viec_tro_ly(can_gui=False)
    ds = viec["tro_ly"].setdefault("ghi_nhanh", [])
    if not 0 <= so < len(ds):
        raise HTTPException(status_code=404, detail="Không có dòng này")
    ds.pop(so)
    luu_viec(viec)
    return JSONResponse({"ok": True})


# ----------------------------------------------------------------------------
# Nguồn thêm cho trợ lý (bản 3, đợt 3): biên bản buổi trước, tài liệu thả vào
# trước buổi họp, tìm trên mạng và trong Google Drive. Chỉ gửi lên NotebookLM ở
# cuộc họp chọn gửi lên NotebookLM.
# ----------------------------------------------------------------------------

LOAI_TAI_LIEU = {".pdf": "application/pdf",
                 ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                 ".pptx": ("application/vnd.openxmlformats-officedocument.presentationml."
                           "presentation"),
                 ".txt": "text/plain", ".md": "text/markdown", ".csv": "text/csv"}
TOI_DA_TAI_LIEU = 5
TOI_DA_BYTE_TAI_LIEU = 50 * 1024 * 1024
TEP_BIEN_BAN_TRUOC = "bien-ban-buoi-truoc.txt"


def thu_muc_tai_lieu_cho() -> Path:
    """Tài liệu thả vào trước buổi họp, chờ cuộc họp gửi lên NotebookLM kế tiếp.
    Nằm trong thư mục lưu các cuộc họp, nhưng không có viec.json nên không bị đọc
    nhầm thành một cuộc họp."""
    return THU_MUC_LUU / "tai-lieu-cho-cuoc-hop-sau"


def ds_tai_lieu_cho() -> list[dict]:
    tm = thu_muc_tai_lieu_cho()
    if not tm.is_dir():
        return []
    return [{"ten": f.name, "kb": max(1, f.stat().st_size // 1024)} for f in sorted(tm.iterdir())
            if f.is_file() and f.suffix.lower() in LOAI_TAI_LIEU]


def ten_tep_an_toan(ten: str) -> str:
    """Tên tệp người dùng thả vào: bỏ đường dẫn và ký tự cấm, giữ chữ có dấu (đưa
    về chữ dựng sẵn NFC, vì tên tệp kéo từ máy Mac là chữ tổ hợp)."""
    ten = unicodedata.normalize("NFC", ten.replace("\\", "/").split("/")[-1])
    ten = re.sub(r'[\x00-\x1f<>:"|?*]', "_", ten).strip(" .")
    goc, duoi = os.path.splitext(ten)
    return (goc[:100].strip() or "tai-lieu") + duoi.lower()


@app.get("/may/tai-lieu")
async def xem_tai_lieu(request: Request):
    chi_tu_may_nay(request)
    return JSONResponse({"ds": ds_tai_lieu_cho(), "toi_da": TOI_DA_TAI_LIEU})


def ten_tai_lieu_hop_le(tep: UploadFile) -> str:
    ten = ten_tep_an_toan(tep.filename or "")
    if Path(ten).suffix not in LOAI_TAI_LIEU:
        raise HTTPException(status_code=400, detail="Chỉ nhận tệp PDF, Word (.docx), PowerPoint "
                            "(.pptx), .txt, .md hoặc .csv")
    return ten


async def luu_tai_lieu(tep: UploadFile, tm: Path, ten: str) -> Path:
    """Lưu tệp người dùng thả vào thư mục tm, trùng tên thì thêm số, quá 50 MB thì từ chối."""
    tm.mkdir(parents=True, exist_ok=True)
    dich, so = tm / ten, 2
    while dich.exists():
        dich, so = tm / f"{Path(ten).stem} ({so}){Path(ten).suffix}", so + 1
    tam, tong = dich.with_name(dich.name + ".tam"), 0
    with tam.open("wb") as f:
        while khoi := await tep.read(1024 * 1024):
            tong += len(khoi)
            if tong > TOI_DA_BYTE_TAI_LIEU:
                break
            f.write(khoi)
    if not 0 < tong <= TOI_DA_BYTE_TAI_LIEU:
        tam.unlink(missing_ok=True)
        raise HTTPException(status_code=413 if tong else 400,
                            detail="Tệp lớn quá 50 MB" if tong else "Tệp rỗng")
    tam.replace(dich)
    return dich


@app.post("/may/tai-lieu")
async def them_tai_lieu(request: Request, tep: UploadFile = File(...),
                        x_bang_dieu_khien: str | None = Header(None)):
    """Tài liệu cho trợ lý, thả vào trước buổi họp. Bấm ghi một cuộc họp gửi lên
    NotebookLM thì máy chuyển tài liệu vào thư mục cuộc họp rồi đưa lên sổ."""
    _chan(request, x_bang_dieu_khien)
    ten = ten_tai_lieu_hop_le(tep)
    if len(ds_tai_lieu_cho()) >= TOI_DA_TAI_LIEU:
        raise HTTPException(status_code=409, detail=f"Tối đa {TOI_DA_TAI_LIEU} tệp. Xoá bớt rồi "
                            "thả tiếp.")
    await luu_tai_lieu(tep, thu_muc_tai_lieu_cho(), ten)
    return JSONResponse({"ds": ds_tai_lieu_cho()})


@app.post("/may/tro-ly/tai-lieu")
async def them_tai_lieu_trong_hop(request: Request, tep: UploadFile = File(...),
                                  x_bang_dieu_khien: str | None = Header(None)):
    """Tài liệu thả vào NGAY TRONG buổi họp (PM yêu cầu 27/9/2026), để trợ lý hiểu thêm
    ngữ cảnh. Lưu vào thư mục cuộc họp; vòng trợ lý đưa lên sổ ở lượt kế tiếp, như tài
    liệu thả vào trước buổi họp. Chỉ ở cuộc họp gửi lên mạng (_viec_tro_ly kiểm)."""
    _chan(request, x_bang_dieu_khien)
    viec = _viec_tro_ly()
    nen = viec["tro_ly"].setdefault("nen", [])
    ten = ten_tai_lieu_hop_le(tep)
    if sum(1 for n in nen if n.get("loai") == "tai_lieu") >= TOI_DA_TAI_LIEU:
        raise HTTPException(status_code=409, detail=f"Tối đa {TOI_DA_TAI_LIEU} tài liệu mỗi cuộc họp.")
    dich = await luu_tai_lieu(tep, Path(viec["thu_muc"]) / "tai-lieu", ten)
    nen.append({"loai": "tai_lieu", "tep": f"tai-lieu/{dich.name}", "ten": dich.name, "tt": "cho"})
    ghi_nhat_ky(viec, f"Tài liệu thêm trong lúc họp: {dich.name}")
    luu_viec(viec)
    return JSONResponse({"ok": True})


@app.delete("/may/tai-lieu/{ten}")
async def xoa_tai_lieu(ten: str, request: Request, x_bang_dieu_khien: str | None = Header(None)):
    _chan(request, x_bang_dieu_khien)
    tep = thu_muc_tai_lieu_cho() / ten
    if ten != ten_tep_an_toan(ten) or not tep.is_file():  # chặn cả "../" lẫn tên lạ
        raise HTTPException(status_code=404, detail="Không có tệp này")
    tep.unlink()
    return JSONResponse({"ds": ds_tai_lieu_cho()})


def ds_bien_ban_truoc() -> list[dict]:
    """Các biên bản dùng được làm biên bản buổi trước, mới nhất lên đầu: cuộc họp đã
    Xong và gửi lên NotebookLM từ đầu tới cuối, tức người họp đã đồng ý gửi lên
    Google. Cuộc họp Không gửi lên mạng (kể cả chuyển giữa buổi) không bao giờ có."""
    return [{"ma": m, "ten": (v.get("tt") or {}).get("ten_cuoc_hop", ""), "luc": _luc(v)}
            for m in reversed(THU_TU) for v in [VIEC[m]]
            if v["trang_thai"] == "Xong" and v.get("cach_da_bao") == "notebooklm"
            and v.get("ket_qua")][:30]


def bien_ban_da_chon(tep: dict | None = None) -> str:
    """Biên bản buổi trước của cuộc họp sắp ghi. Thư ký đã chọn thì theo đó ("-" là
    đã chọn Không dùng). Chưa chọn thì lấy cuộc họp gần nhất trùng hẳn tên: có
    nhiều loại họp khác nhau nên không đoán theo tên gần giống (PM chốt 26/9/2026)."""
    tep = tep or thong_tin_mac_dinh()
    ds = ds_bien_ban_truoc()
    chon = str(tep.get("bien_ban_truoc") or "")
    if chon == "-":
        return ""
    if chon in [x["ma"] for x in ds]:
        return chon
    ten = str(tep.get("ten_cuoc_hop") or "").strip()
    return next((x["ma"] for x in ds if ten and x["ten"].strip() == ten), "")


def _la_bang_phan_cong(hang: list[list[str]]) -> bool:
    return bool(hang) and "phụ trách" in unicodedata.normalize("NFC", " ".join(hang[0])).lower()


def _chu_tu_word(tep: Path) -> tuple[str, list[list[str]]]:
    """Chữ của tệp Word theo đúng thứ tự đoạn và bảng, cùng bảng Phân công."""
    from docx import Document
    from docx.table import Table
    from docx.text.paragraph import Paragraph
    doc = Document(str(tep))
    dong, bang = [], []
    for el in doc.element.body.iterchildren():
        loai = el.tag.rsplit("}", 1)[-1]
        if loai == "p":
            dong.append(Paragraph(el, doc).text)
        elif loai == "tbl":
            hang = [[o.text.strip() for o in r.cells] for r in Table(el, doc).rows]
            dong += [" | ".join(h) for h in hang]
            if not bang and _la_bang_phan_cong(hang):
                bang = hang
    chu = re.sub(r"\n{3,}", "\n\n", unicodedata.normalize("NFC", "\n".join(dong))).strip()
    return chu, [[unicodedata.normalize("NFC", o) for o in h] for h in bang]


def chu_bien_ban_xong(v: dict) -> tuple[str, list[list[str]]]:
    """Chữ của một biên bản đã xong và các hàng của bảng Phân công. Đọc tệp Word
    trong thư mục cuộc họp vì thư ký thường sửa ở đó; không đọc được thì lấy bản
    nháp máy soạn."""
    tep = Path(v["thu_muc"]) / (v.get("tep_word") or "")
    if v.get("tep_word") and tep.is_file():
        try:
            return _chu_tu_word(tep)
        except Exception as loi:  # noqa: BLE001 - tệp Word hỏng thì lấy bản nháp
            print(f"Không đọc được {tep.name}: {loi}", flush=True)
    import tao_word
    khoi = tao_word.tach_than_bai(v.get("ket_qua") or "",
                                  (v.get("tt") or {}).get("ten_cuoc_hop", ""))
    bang = next((gt for loai, gt in khoi if loai == "bang" and _la_bang_phan_cong(gt)), [])
    return (v.get("ket_qua") or "").strip(), bang


def viec_tu_bang(bang: list[list[str]]) -> list[str]:
    """Bảng Phân công thành các dòng "- Việc (Người phụ trách, hạn ...)" cho ô Việc
    tuần trước. Nhận cả bảng thư ký đã sửa có thêm cột STT."""
    if not bang:
        return []
    dau = [o.lower() for o in bang[0]]

    def cot(*chu: str) -> int | None:
        return next((i for i, o in enumerate(dau) if any(c in o for c in chu)), None)

    nguoi, han = cot("phụ trách"), cot("hạn")
    viec = next((i for i, o in enumerate(dau) if i not in (nguoi, han)
                 and o.strip(" .") not in ("stt", "tt", "số tt")), None)
    def o(hang: list[str], i: int | None) -> str:
        return hang[i].strip() if i is not None and i < len(hang) else ""

    ra = []
    for hang in bang[1:]:
        if not o(hang, viec):
            continue
        phu = ", ".join(x for x in (o(hang, nguoi), "hạn " + o(hang, han) if o(hang, han) else "")
                        if x)
        ra.append(f"- {o(hang, viec)}" + (f" ({phu})" if phu else ""))
    return ra


@app.get("/may/bien-ban-truoc")
async def xem_bien_ban_truoc(request: Request):
    """Ô chọn Biên bản buổi trước ở màn Sẵn sàng. tu: biên bản mà ô Việc tuần
    trước đang lấy việc từ đó (rỗng nếu thư ký tự gõ)."""
    chi_tu_may_nay(request)
    tep = thong_tin_mac_dinh()
    return JSONResponse({"ds": ds_bien_ban_truoc(), "chon": bien_ban_da_chon(tep),
                         "tu": str(tep.get("viec_tuan_truoc_tu") or "")})


@app.put("/may/bien-ban-truoc")
async def chon_bien_ban_truoc(request: Request, x_bang_dieu_khien: str | None = Header(None)):
    """Chọn biên bản buổi trước cho cuộc họp sắp ghi (ma rỗng là Không dùng).
    dien_viec: điền ô Việc tuần trước từ bảng Phân công của biên bản đó (Không dùng
    thì xoá các việc máy đã điền). tu_dong: giao diện tự áp theo biên bản máy chọn
    sẵn, không ghi thành lựa chọn của thư ký."""
    _chan(request, x_bang_dieu_khien)
    try:
        than = await request.json()
    except ValueError:
        raise HTTPException(status_code=400, detail="Dữ liệu không đọc được")
    ma = than.get("ma") if isinstance(than, dict) else None
    if not isinstance(ma, str) or (ma and ma not in [x["ma"] for x in ds_bien_ban_truoc()]):
        raise HTTPException(status_code=404, detail="Không có biên bản này")
    tep = thong_tin_mac_dinh()
    if than.get("tu_dong") is not True:
        tep["bien_ban_truoc"] = ma or "-"
    so_viec = None
    if than.get("dien_viec") is True:
        viec_cu = (viec_tu_bang((await asyncio.to_thread(chu_bien_ban_xong, VIEC[ma]))[1])
                   if ma else [])
        so_viec = len(viec_cu)
        # Ô đang trống hay do máy điền thì thay luôn. Ô thư ký tự gõ thì chỉ thay bằng việc
        # mới khi thư ký đã đồng ý (giao diện hỏi trước), và không bao giờ bị xoá.
        if viec_cu or tep.get("viec_tuan_truoc_tu") or not tep.get("viec_tuan_truoc"):
            tep["viec_tuan_truoc"] = "\n".join(viec_cu)
            tep["viec_tuan_truoc_tu"] = ma
    _ghi_an_toan(TEP_MAC_DINH, json.dumps(tep, ensure_ascii=False, indent=2) + "\n")
    return JSONResponse({"ok": True, "so_viec": so_viec})


def chuan_bi_nen(viec: dict) -> list[dict]:
    """Lúc bấm ghi một cuộc họp gửi lên NotebookLM: chép chữ biên bản buổi trước và
    chuyển các tài liệu đang chờ vào thư mục cuộc họp (tai-lieu/), để trợ lý đưa
    lên sổ ngay đầu buổi. Máy sập giữa chừng thì các tệp vẫn nằm đó. Cuộc họp
    Không gửi lên mạng không gọi hàm này: tài liệu để dành cho cuộc họp sau."""
    tm = Path(viec["thu_muc"]) / "tai-lieu"
    tep_tt = thong_tin_mac_dinh()
    nen = []
    ma = bien_ban_da_chon(tep_tt)
    if ma:
        v = VIEC[ma]
        chu = chu_bien_ban_xong(v)[0]
        if chu:
            tm.mkdir(exist_ok=True)
            _ghi_an_toan(tm / TEP_BIEN_BAN_TRUOC, chu)
            nen.append({"loai": "bien_ban_truoc", "tep": f"tai-lieu/{TEP_BIEN_BAN_TRUOC}",
                        "ten": f"Biên bản buổi trước: {v['tt'].get('ten_cuoc_hop', '')} ({_luc(v)})",
                        "tt": "cho"})
    for t in ds_tai_lieu_cho():
        tm.mkdir(exist_ok=True)
        ten = t["ten"] if t["ten"] != TEP_BIEN_BAN_TRUOC else "tai-lieu-" + t["ten"]
        shutil.move(str(thu_muc_tai_lieu_cho() / t["ten"]), str(tm / ten))
        nen.append({"loai": "tai_lieu", "tep": f"tai-lieu/{ten}", "ten": ten, "tt": "cho"})
    if tep_tt.get("bien_ban_truoc"):  # đã dùng cho cuộc họp này; cuộc họp sau chọn lại
        tep_tt["bien_ban_truoc"] = ""
        _ghi_an_toan(TEP_MAC_DINH, json.dumps(tep_tt, ensure_ascii=False, indent=2) + "\n")
    if nen:
        ghi_nhat_ky(viec, "Tài liệu cho trợ lý: " + "; ".join(n["ten"] for n in nen))
    return nen


@app.post("/may/tro-ly/tim")
async def tim_them(request: Request, x_bang_dieu_khien: str | None = Header(None)):
    """Hai nút Tìm trên mạng và Tìm trong Drive dưới mỗi thẻ: nhờ NotebookLM tìm theo
    cụm từ của thẻ (sửa được). Kết quả chỉ hiện dưới thẻ, không đưa vào sổ."""
    _chan(request, x_bang_dieu_khien)
    viec = _viec_tro_ly()
    try:
        than = await request.json()
    except ValueError:
        raise HTTPException(status_code=400, detail="Dữ liệu không đọc được")
    ds = viec["tro_ly"].get("the") or []
    so, cum_tu, noi = ((than.get(k) for k in ("so", "cum_tu", "noi")) if isinstance(than, dict)
                       else (None, None, None))
    if (not isinstance(so, int) or isinstance(so, bool) or not 0 <= so < len(ds)
            or noi not in ("web", "drive") or not isinstance(cum_tu, str) or not cum_tu.strip()
            or len(cum_tu) > 200):
        raise HTTPException(status_code=400, detail="Yêu cầu tìm không hợp lệ")
    if not (viec.get("so_nlm") or {}).get("id"):
        raise HTTPException(status_code=409, detail="Cuộc họp chưa gửi được gì nên chưa tìm được")
    the = ds[so]
    if (the.get("tim") or {}).get("dang"):
        raise HTTPException(status_code=409, detail="Đang tìm, chờ xong đã")
    the["tim"] = {"noi": noi, "cum_tu": cum_tu.strip(), "dang": True}
    nen = asyncio.create_task(tim_nen(viec, the["tim"]))
    TAC_VU_NEN.add(nen)
    nen.add_done_callback(TAC_VU_NEN.discard)
    return JSONResponse({"ok": True})


async def tim_nen(viec: dict, tim: dict) -> None:
    """Chạy nền cho hai nút Tìm. Trên mạng: tính năng Khám phá nguồn của NotebookLM
    (vài giây, có đoạn tổng quan). Trong Drive: tìm nhanh trong Google Drive của
    tài khoản đã đăng nhập, chờ tới khi xong."""
    try:
        async with contextlib.AsyncExitStack() as ngan:
            nlm = await _co_han(ngan.enter_async_context(ket_noi_nlm()), HAN_NLM["ket_noi"],
                                "kết nối")
            rs = getattr(nlm, "research", None)
            if rs is None or not hasattr(rs, "discover"):
                raise LoiRo("thư viện xử lý trên máy đã cũ, chạy lại trình cài đặt để nâng cấp")
            so_id = viec["so_nlm"]["id"]
            if tim["noi"] == "web":
                kq = await _co_han(rs.discover(so_id, tim["cum_tu"]), HAN_NLM["tim"],
                                   "tìm trên mạng")
            else:
                bd = await _co_han(rs.start(so_id, tim["cum_tu"], source="drive", mode="fast"),
                                   HAN_NLM["ket_noi"], "tìm trong Drive")
                kq = await _co_han(rs.wait_for_completion(so_id, bd.task_id,
                                                          timeout=HAN_NLM["tim"]),
                                   HAN_NLM["tim"] + 30, "tìm trong Drive")
        if str(getattr(kq, "status", "")) == "failed":
            raise LoiRo("dịch vụ xử lý báo không tìm được")
        tim["tong_quan"] = TRICH_DAN.sub("", getattr(kq, "summary", "") or "").strip()[:1500]
        tim["ket_qua"] = [{"ten": (s.title or s.url)[:200], "url": s.url,
                           "mo_ta": (getattr(s, "hint", "") or "")[:300]}
                          for s in getattr(kq, "sources", None) or ()
                          if str(s.url).startswith(("http://", "https://"))][:8]
    except Exception as loi:  # noqa: BLE001 - báo ngay dưới thẻ
        tim["loi"] = f"Chưa tìm được ({ly_do_loi(loi)})"
    finally:
        tim["dang"] = False
        with contextlib.suppress(OSError):
            luu_viec(viec)


@app.post("/may/mo-lien-ket")
async def mo_lien_ket(request: Request, x_bang_dieu_khien: str | None = Header(None)):
    """Mở một link trong kết quả tìm bằng trình duyệt của máy. Chỉ mở link có trong
    kết quả tìm của trợ lý, để không ai nhờ được máy mở một địa chỉ bất kỳ."""
    _chan(request, x_bang_dieu_khien)
    url = await _doc_chu(request, "url", 2000)
    co = any(url == k.get("url") for v in VIEC.values()
             for t in (v.get("tro_ly") or {}).get("the") or []
             for k in (t.get("tim") or {}).get("ket_qua") or [])
    if not co or not url.startswith(("http://", "https://")):
        raise HTTPException(status_code=404, detail="Không có link này trong kết quả tìm")
    mo_bang_he_thong(url)
    return JSONResponse({"ok": True})


# ----------------------------------------------------------------------------
# Chủ trì xem khung Trợ lý trên điện thoại (bản 3, đợt 4). Máy chủ chính vẫn chỉ
# nghe trong laptop (127.0.0.1). Đây là một máy chủ phụ riêng, nghe trên mạng nội
# bộ ở một cổng khác, chỉ có trang xem và dữ liệu của khung Trợ lý: không bản ghi,
# không cài đặt, không ghi chú của thư ký hay ghi nhanh, không nút lệnh nào. Vào phải có
# mã ngẫu nhiên, mỗi lần bật một mã; tự tắt khi bấm Dừng hoặc thư ký bấm tắt.
# ----------------------------------------------------------------------------

XEM: dict = {"may": None, "task": None, "ma": None, "url": None, "qr": "", "viec": None}
# Các mục của thẻ được đưa ra điện thoại. Không có cum_tu vì điện thoại không tìm được
KHOA_THE_XEM = ("loai", "luc", "ten", "tom_tat", "cau_hoi", "lien_quan", "quyet_dinh",
                "viec_giao", "con_mo", "tho", "tra_loi", "dang", "loi", "chu", "tim")


def ip_mang_noi_bo() -> str:
    """Địa chỉ của laptop trong mạng Wi-Fi. Kết nối UDP không gửi gói nào đi, chỉ
    để hệ điều hành chọn đường ra mạng, nên không lộ gì ra ngoài."""
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
        s.connect(("10.255.255.255", 1))
        ip = s.getsockname()[0]
    if ip.startswith("127.") or ip == "0.0.0.0":
        raise OSError("không có mạng")
    return ip


def du_lieu_xem(viec: dict) -> dict:
    """Dữ liệu cho trang xem trên điện thoại: chỉ khung Trợ lý."""
    ty = viec.get("tro_ly") or {}
    return {"ten": (viec.get("tt") or {}).get("ten_cuoc_hop", ""),
            "dang_ghi": MAY_GHI.ma == viec["ma"] and bool(MAY_GHI.tt),
            "trang_thai": ty.get("tam_nghi") or ty.get("trang_thai") or "", "ghim": ghim(ty),
            "the": [{k: t[k] for k in KHOA_THE_XEM if k in t} for t in ty.get("the") or []
                    if t.get("loai") != "ngu_canh"]}


def tao_app_xem(ma_xem: str, ma_viec: str) -> FastAPI:
    # Không tự chuyển hướng /x sang /x/: đường nào không đúng hẳn trang xem thì báo không có
    xem = FastAPI(docs_url=None, redoc_url=None, openapi_url=None, redirect_slashes=False)

    def kiem_ma(ma: str) -> dict:
        viec = VIEC.get(ma_viec)
        if (not secrets.compare_digest(ma.encode(), ma_xem.encode()) or XEM["ma"] != ma_xem
                or not viec):
            raise HTTPException(status_code=404, detail="Không có trang này")
        return viec

    @xem.get("/{ma}/")
    async def trang_xem(ma: str):
        kiem_ma(ma)
        return FileResponse(THU_MUC_GOC / "xem_dien_thoai.html",
                            headers={"Cache-Control": "no-store"})

    @xem.get("/{ma}/du-lieu")
    async def du_lieu(ma: str):
        return JSONResponse(du_lieu_xem(kiem_ma(ma)), headers={"Cache-Control": "no-store"})

    return xem


def ma_qr(url: str) -> str:
    """Mã QR dạng SVG. Máy chưa có thư viện segno (cài bản cũ) thì chỉ hiện địa chỉ."""
    try:
        import segno
    except ImportError:
        return ""
    ra = io.BytesIO()
    segno.make(url, error="m").save(ra, kind="svg", scale=5, border=2, xmldecl=False)
    return ra.getvalue().decode("utf-8")


async def bat_xem(viec: dict) -> None:
    import uvicorn

    class MayChuPhu(uvicorn.Server):
        # Máy chủ chính lo tín hiệu tắt ứng dụng; máy chủ phụ không đụng vào
        @contextlib.contextmanager
        def capture_signals(self):
            yield

        def install_signal_handlers(self) -> None:  # uvicorn bản cũ
            pass

    await tat_xem()
    try:
        ip = ip_mang_noi_bo()
    except OSError:
        raise HTTPException(status_code=409, detail="Máy chưa nối mạng Wi-Fi. Nối cùng mạng "
                            "Wi-Fi với điện thoại rồi bấm lại.")
    o = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    o.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    # Chỉ nghe đúng địa chỉ Wi-Fi của laptop, ở một cổng trống bất kỳ. Bộ tự kiểm (chạy cả
    # lúc cài) dùng địa chỉ nội máy nên không làm máy hỏi quyền tường lửa giữa lúc cài
    o.bind((ip, 0))
    ma = secrets.token_urlsafe(12)
    may = MayChuPhu(uvicorn.Config(tao_app_xem(ma, viec["ma"]), lifespan="off", log_config=None,
                                   log_level="warning", access_log=False))
    url = f"http://{ip}:{o.getsockname()[1]}/{ma}/"
    XEM.update(may=may, task=asyncio.create_task(may.serve(sockets=[o])), ma=ma, url=url,
               qr=ma_qr(url), viec=viec["ma"])
    ghi_nhat_ky(viec, "Bật cho chủ trì xem khung Trợ lý trên điện thoại")


async def tat_xem() -> None:
    may, task, ma_viec = XEM["may"], XEM["task"], XEM["viec"]
    XEM.update(may=None, task=None, ma=None, url=None, qr="", viec=None)
    if may:
        may.should_exit = True
        with contextlib.suppress(Exception):
            await asyncio.wait_for(task, 5)
        if ma_viec in VIEC:
            ghi_nhat_ky(VIEC[ma_viec], "Tắt chế độ chủ trì xem trên điện thoại")


def trang_thai_xem(viec: dict | None) -> dict | None:
    if not viec or XEM["viec"] != viec.get("ma") or not XEM["url"]:
        return None
    return {"url": XEM["url"], "qr": XEM["qr"]}


@app.post("/may/tro-ly/xem-dien-thoai")
async def xem_dien_thoai(request: Request, x_bang_dieu_khien: str | None = Header(None)):
    """Nút Cho chủ trì xem: bật hay tắt trang xem khung Trợ lý trên điện thoại."""
    _chan(request, x_bang_dieu_khien)
    try:
        than = await request.json()
    except ValueError:
        raise HTTPException(status_code=400, detail="Dữ liệu không đọc được")
    if isinstance(than, dict) and than.get("bat") is True:
        viec = _viec_tro_ly()
        await bat_xem(viec)
        return JSONResponse({"xem": trang_thai_xem(viec)})
    await tat_xem()
    return JSONResponse({"xem": None})


# ----------------------------------------------------------------------------
# Thông tin cuộc họp cố định (thẻ Cài đặt)
# ----------------------------------------------------------------------------

@app.get("/may/thong-tin")
async def xem_thong_tin(request: Request):
    chi_tu_may_nay(request)
    mac_dinh = thong_tin_mac_dinh()
    return JSONResponse({"truong": {k: str(mac_dinh.get(k) or "") for k in KHOA_CAI_DAT},
                         "thu_muc_luu": str(THU_MUC_LUU)})


@app.put("/may/thong-tin")
async def luu_thong_tin(request: Request, x_bang_dieu_khien: str | None = Header(None)):
    _chan(request, x_bang_dieu_khien)
    try:
        moi = await request.json()
    except ValueError:
        raise HTTPException(status_code=400, detail="Dữ liệu không đọc được")
    if not isinstance(moi, dict) or any(
            k not in KHOA_CAI_DAT or not isinstance(v, str) or len(v) > 20000
            for k, v in moi.items()):
        raise HTTPException(status_code=400, detail="Dữ liệu không hợp lệ")
    if "cach_go_chu" in moi and moi["cach_go_chu"] not in CACH_GO_CHU:
        raise HTTPException(status_code=400, detail="Không có cách chép lời này")
    if "nhip_tro_ly" in moi and moi["nhip_tro_ly"] not in NHIP_TRO_LY:
        raise HTTPException(status_code=400, detail="Không có nhịp gửi này")
    if moi.get("loai_hop", "").strip() and not any(
            x["ten"].casefold() == " ".join(moi["loai_hop"].split()).casefold()
            for x in cac_loai_hop()):
        raise HTTPException(status_code=400, detail="Không có loại họp này. Xem thẻ Cài đặt")
    tep = thong_tin_mac_dinh()  # giữ nguyên các dòng ghi chú _ghi_chu_...
    if ("viec_tuan_truoc" in moi
            and moi["viec_tuan_truoc"].strip() != str(tep.get("viec_tuan_truoc") or "").strip()):
        tep["viec_tuan_truoc_tu"] = ""  # thư ký tự sửa: không còn là bản máy điền
    tep.update({k: v.strip() for k, v in moi.items()})
    # Khoá cũ "micro": bản trước lưu nhầm micro TỰ CHỌN thành lựa chọn của người
    # dùng mỗi lần bấm Lưu, nên đóng băng cả lựa chọn sai (micro của iPhone). Bỏ đi.
    tep.pop("micro", None)
    _ghi_an_toan(TEP_MAC_DINH, json.dumps(tep, ensure_ascii=False, indent=2) + "\n")
    # Đang ghi mà chuyển sang Không gửi lên mạng, thường vì có người không đồng ý
    # gửi lên Google: phần sau giữ trên máy luôn, lỡ chuyển lại cũng không gửi. Các
    # đoạn trợ lý đã gửi trước đó thì giữ lại để soạn nháp phần đầu (PM chọn 26/9/2026)
    dang_ghi = VIEC.get(MAY_GHI.ma or "")
    if (moi.get("cach_go_chu") == "whisper" and dang_ghi
            and dang_ghi.get("cach_da_bao") != "whisper"):
        dang_ghi["cach_da_bao"] = "whisper"
        luc = await asyncio.to_thread(MAY_GHI.giay_am_thanh)
        if dang_ghi.get("tro_ly") is not None:
            dang_ghi["tro_ly"]["chuyen_luc"] = luc
        ghi_nhat_ky(dang_ghi, f"Chuyển sang Không gửi lên mạng giữa buổi (lúc {moc(luc)} của "
                              "bản ghi): từ đây không gửi gì lên mạng")
        luu_viec(dang_ghi)
    return JSONResponse({"ok": True})


@app.get("/may/loai-hop")
async def xem_loai_hop(request: Request):
    chi_tu_may_nay(request)
    return JSONResponse({"ds": cac_loai_hop(), "toi_da": TOI_DA_LOAI_HOP})


@app.put("/may/loai-hop")
async def luu_loai_hop(request: Request, x_bang_dieu_khien: str | None = Header(None)):
    """Lưu cả danh sách loại họp sửa ở thẻ Cài đặt (thay danh sách cũ)."""
    _chan(request, x_bang_dieu_khien)
    try:
        ds = (await request.json()).get("ds")
    except (ValueError, AttributeError):
        raise HTTPException(status_code=400, detail="Dữ liệu không đọc được")
    if not isinstance(ds, list) or not ds or len(ds) > TOI_DA_LOAI_HOP:
        raise HTTPException(status_code=400,
                            detail=f"Cần từ 1 tới {TOI_DA_LOAI_HOP} loại họp")
    sach = []
    for x in ds:
        loai, ly_do = kiem_loai_hop(x)
        if not loai:
            raise HTTPException(status_code=400, detail=ly_do)
        if any(y["ten"].casefold() == loai["ten"].casefold() for y in sach):
            raise HTTPException(status_code=400, detail=f"Hai loại họp trùng tên \"{loai['ten']}\"")
        sach.append(loai)
    tep = thong_tin_mac_dinh()
    tep["cac_loai_hop"] = sach
    _ghi_an_toan(TEP_MAC_DINH, json.dumps(tep, ensure_ascii=False, indent=2) + "\n")
    return JSONResponse({"ok": True, "ds": sach})


# ----------------------------------------------------------------------------
# Đăng nhập NotebookLM (thẻ Cài đặt)
# ----------------------------------------------------------------------------

DANG_NHAP_NLM: dict = {"tien_trinh": None, "luc": 0.0, "qua_han": False, "ma": TK_CHINH,
                       "tai": False}  # tai: lần đăng nhập này có tải trình duyệt trước không
TEP_DANG_NHAP = THU_MUC_GOC / "nhat-ky-dang-nhap-notebooklm.txt"
HAN_DANG_NHAP_GIAY = 600  # thư viện tự chờ 540 giây; quá 10 phút thì mình tắt hẳn

LA_MAC = sys.platform == "darwin"
# Máy Mac chưa có Google Chrome thì cửa sổ đăng nhập dùng trình duyệt riêng của thư viện
# (Chromium, khoảng 150 MB). Từ v1.4 (PM chốt 30/9/2026) trình cài không tải nó nữa để cài
# nhanh: ở lần bấm Đăng nhập Google đầu tiên, máy tải nó trước rồi mới mở cửa sổ đăng nhập,
# có báo tiến độ ở thẻ Cài đặt. Cả hai bước chạy trong MỘT tiến trình (đoạn mã dưới tải
# xong thì thay chính nó bằng lệnh đăng nhập), nên đồng hồ và việc tắt vẫn như cũ.
DAU_TAI_TRINH_DUYET = "BBH-TAI-TRINH-DUYET"
DAU_XONG_TAI_TRINH_DUYET = "BBH-XONG-TAI-TRINH-DUYET"
HAN_TAI_TRINH_DUYET_GIAY = 900  # quá 15 phút thì thôi tải, sang bước đăng nhập (sẽ báo lỗi rõ)
MA_TAI_TRINH_DUYET = (
    "import os, subprocess, sys\n"
    f"print({DAU_TAI_TRINH_DUYET!r}, flush=True)\n"
    "try:\n"
    "    ma = subprocess.run([sys.executable, '-m', 'playwright', 'install', 'chromium'],\n"
    f"                        timeout={HAN_TAI_TRINH_DUYET_GIAY}).returncode\n"
    "except subprocess.TimeoutExpired:\n"
    "    ma = -2\n"
    f"print({DAU_XONG_TAI_TRINH_DUYET!r} + ' ma=' + str(ma), flush=True)\n"
    "os.execv(sys.argv[1], sys.argv[1:])\n")


def co_chrome() -> bool:
    """Máy Mac có Google Chrome (ở Applications của máy hoặc của người dùng) không."""
    return any(Path(p).exists() for p in ("/Applications/Google Chrome.app",
                                          Path.home() / "Applications" / "Google Chrome.app"))


def co_chromium_cua_thu_vien() -> bool:
    """Trình duyệt riêng của thư viện đã tải xong chưa: thư mục chromium-<số> có tệp
    INSTALLATION_COMPLETE (thư viện ghi khi tải xong)."""
    goc = os.environ.get("PLAYWRIGHT_BROWSERS_PATH", "")
    thu_muc = Path(goc) if goc and goc != "0" else Path.home() / "Library" / "Caches" / "ms-playwright"
    try:
        return any((d / "INSTALLATION_COMPLETE").is_file() for d in thu_muc.glob("chromium-*"))
    except OSError:
        return False


def can_tai_trinh_duyet() -> bool:
    """Máy Mac chưa có Chrome và chưa có trình duyệt riêng của thư viện: lần đăng nhập này
    phải tải nó trước. Windows dùng Edge có sẵn nên không bao giờ cần."""
    return LA_MAC and not co_chrome() and not co_chromium_cua_thu_vien()


def lenh_dang_nhap_nlm(ma: str | None = None) -> list[str]:
    """Mở cửa sổ đăng nhập Google của thư viện; đăng nhập xong nó tự lưu phiên,
    không phải gõ gì. Máy có Chrome thì dùng Chrome thật: bản Chromium kèm thư
    viện hay sập trên macOS 15 trở lên (thư viện tự ghi như vậy). ma: tài khoản dự phòng
    (v1.3) thì đăng nhập vào hồ sơ riêng của nó, không đè lên phiên của tài khoản chính."""
    lenh = [sys.executable, "-m", "notebooklm"]
    if ma and ma != TK_CHINH:
        lenh += ["-p", ma]
    lenh += ["login", "--browser-timeout", "540"]
    if LA_WINDOWS:
        # Windows nào cũng có sẵn Edge, khỏi tải trình duyệt riêng
        return lenh + ["--browser", "msedge"]
    if co_chrome():
        lenh += ["--browser", "chrome"]
    return lenh


def lenh_mo_dang_nhap(ma: str | None = None) -> tuple[list[str], bool]:
    """(lệnh mở cửa sổ đăng nhập, có phải tải trình duyệt trước không). Cần tải thì bọc lệnh
    đăng nhập trong đoạn mã nhỏ tải trình duyệt rồi mới chạy nó."""
    lenh = lenh_dang_nhap_nlm(ma)
    if can_tai_trinh_duyet():
        return [sys.executable, "-X", "utf8", "-c", MA_TAI_TRINH_DUYET, *lenh], True
    return lenh, False


def giai_doan_tai_trinh_duyet() -> tuple[bool, int | None]:
    """(đang tải trình duyệt, mã thoát của lần tải nếu đã xong), đọc từ nhật ký của lần đăng
    nhập này. Lần này không phải tải thì (False, None)."""
    if not DANG_NHAP_NLM.get("tai"):
        return False, None
    try:
        chu = TEP_DANG_NHAP.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return True, None  # chưa kịp ghi gì: đoạn mã tải mới bật
    m = re.search(DAU_XONG_TAI_TRINH_DUYET + r" ma=(-?\d+)", chu)
    return (m is None), (int(m[1]) if m else None)


async def _ma_tai_khoan(request: Request) -> str:
    """Mã tài khoản Google trong thân yêu cầu ({"ma": ...}). Không gửi thân, hoặc gửi mã của
    tài khoản chính, thì là tài khoản chính (đúng như trước bản v1.3). Mã lạ thì 404."""
    try:
        than = await request.json()
    except ValueError:
        return TK_CHINH
    ma = than.get("ma") if isinstance(than, dict) else None
    if ma in (None, "", TK_CHINH):
        return TK_CHINH
    if not isinstance(ma, str) or tai_khoan_cua(ma) is None:
        raise HTTPException(status_code=404, detail="Không có tài khoản này")
    return ma


@app.post("/may/notebooklm/dang-nhap")
async def dang_nhap_nlm(request: Request, x_bang_dieu_khien: str | None = Header(None)):
    """Mở cửa sổ đăng nhập Google. Thân {"ma": "du-phong-1"} thì đăng nhập tài khoản dự phòng
    đó; không gửi thân thì là tài khoản chính. Mỗi lúc chỉ mở một cửa sổ."""
    _chan(request, x_bang_dieu_khien)
    cu = DANG_NHAP_NLM["tien_trinh"]
    if cu is not None and cu.poll() is None:
        raise HTTPException(status_code=409, detail="Cửa sổ đăng nhập đang mở, đăng nhập ở đó")
    ma = await _ma_tai_khoan(request)
    lenh, tai = lenh_mo_dang_nhap(ma)
    try:
        with TEP_DANG_NHAP.open("w", encoding="utf-8") as nhat_ky:
            DANG_NHAP_NLM["tien_trinh"] = subprocess.Popen(
                lenh, stdout=nhat_ky, stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL, cwd=THU_MUC_GOC, **AN_CUA_SO)
    except OSError as loi:
        raise HTTPException(status_code=500, detail=f"Không mở được cửa sổ đăng nhập: {loi}")
    DANG_NHAP_NLM.update(luc=time.monotonic(), qua_han=False, da_ghi_loi=False, ma=ma, tai=tai)
    return JSONResponse({"ok": True, "tai_trinh_duyet": tai})


@app.get("/may/notebooklm")
async def tinh_trang_nlm(request: Request):
    chi_tu_may_nay(request)
    tien_trinh = DANG_NHAP_NLM["tien_trinh"]
    dang_mo = tien_trinh is not None and tien_trinh.poll() is None
    # Lần đăng nhập có tải trình duyệt thì cộng thêm hạn tải (đoạn mã tải tự có hạn riêng)
    han = HAN_DANG_NHAP_GIAY + (HAN_TAI_TRINH_DUYET_GIAY + 30 if DANG_NHAP_NLM.get("tai") else 0)
    if dang_mo and time.monotonic() - DANG_NHAP_NLM["luc"] > han:
        tien_trinh.kill()  # đồng hồ phía mình, nguyên tắc a
        # Chờ nó tắt hẳn (có hạn): không chờ thì máy bận có lúc vẫn thấy nó "đang
        # chạy", và tiến trình đã chết nằm lại chưa được dọn
        try:
            await asyncio.to_thread(tien_trinh.wait, 5)
        except subprocess.TimeoutExpired:
            pass
        DANG_NHAP_NLM["qua_han"] = True
        dang_mo = False
    loi = ""
    dang_tai, ma_tai = giai_doan_tai_trinh_duyet()
    if DANG_NHAP_NLM["qua_han"]:
        loi = "Quá 10 phút chưa đăng nhập xong nên đã đóng cửa sổ đăng nhập. Bấm đăng nhập lại."
    elif tien_trinh is not None and not dang_mo and tien_trinh.returncode:
        # Chữ thư viện in ra (tiếng Anh, nêu tên dịch vụ) chỉ vào nhật ký máy; màn hình
        # chỉ nói chung chung (PM yêu cầu 27/9/2026)
        if ma_tai not in (None, 0):
            loi = ("Chưa tải được trình duyệt để đăng nhập. Kiểm tra mạng rồi bấm Đăng nhập lại, "
                   "hoặc cài Google Chrome.")
        else:
            loi = ("Đăng nhập chưa xong. Bấm Đăng nhập lại, rồi đăng nhập Gmail trong cửa sổ trình "
                   "duyệt hiện ra cho tới khi cửa sổ đó tự đóng.")
        if not DANG_NHAP_NLM.get("da_ghi_loi"):
            DANG_NHAP_NLM["da_ghi_loi"] = True
            with contextlib.suppress(OSError):
                cuoi = TEP_DANG_NHAP.read_text(encoding="utf-8", errors="replace").strip()
                print(f"Đăng nhập chưa xong (mã thoát {tien_trinh.returncode}): {cuoi[-1500:]}",
                      flush=True)
    ma_dn = DANG_NHAP_NLM.get("ma") or TK_CHINH
    if loi and ma_dn != TK_CHINH:
        loi = f'Tài khoản "{(tai_khoan_cua(ma_dn) or {}).get("ten", "dự phòng")}": {loi}'
    return JSONResponse({
        "da_dang_nhap": da_dang_nhap_nlm(), "dang_mo": dang_mo, "loi": loi,
        "tai_trinh_duyet": bool(dang_mo and dang_tai),
        "dang_mo_ma": ma_dn if dang_mo else None, "loi_ma": ma_dn, "toi_da_phu": TOI_DA_TK_PHU,
        "tai_khoan": [{**x, "phu": x["ma"] != TK_CHINH, "da_dang_nhap": da_dang_nhap_nlm(x["ma"]),
                       "het_luot": da_het_luot_hom_nay(x["ma"])} for x in cac_tai_khoan()]})


@app.post("/may/notebooklm/kiem-tra")
async def kiem_tra_nlm(request: Request, x_bang_dieu_khien: str | None = Header(None)):
    """Kết nối thật tới NotebookLM để chắc phiên đăng nhập còn dùng được. Thân {"ma": ...}
    thì kiểm tài khoản dự phòng đó; không gửi thân thì kiểm tài khoản chính."""
    _chan(request, x_bang_dieu_khien)
    ma = await _ma_tai_khoan(request)
    if not da_dang_nhap_nlm(ma):
        return JSONResponse({"ok": False, "loi": "Chưa đăng nhập Google."})
    try:
        async with contextlib.AsyncExitStack() as ngan:
            nlm = await _co_han(ngan.enter_async_context(ket_noi_nlm(ma)),
                                HAN_NLM["ket_noi"], "kết nối")
            await _co_han(nlm.notebooks.list(), HAN_NLM["ket_noi"], "kiểm tra tài khoản")
    except Exception as loi:  # noqa: BLE001 - câu chung chung; nguyên văn vào nhật ký máy
        return JSONResponse({"ok": False, "loi": ly_do_loi(loi)})
    return JSONResponse({"ok": True})


@app.post("/may/notebooklm/tai-khoan")
async def them_tai_khoan(request: Request, x_bang_dieu_khien: str | None = Header(None)):
    """Thêm một tài khoản Google dự phòng (chưa đăng nhập; bấm Đăng nhập ở dòng của nó sau)."""
    _chan(request, x_bang_dieu_khien)
    try:
        than = await request.json()
    except ValueError:
        raise HTTPException(status_code=400, detail="Dữ liệu không đọc được")
    ten, gmail = ((than.get(k) for k in ("ten", "gmail")) if isinstance(than, dict) else (None, None))
    if not isinstance(ten, str) or not isinstance(gmail, str):
        raise HTTPException(status_code=400, detail="Cần tên gọi và địa chỉ Gmail")
    try:
        moi = them_tai_khoan_phu(ten, gmail)
    except LoiRo as loi:
        raise HTTPException(status_code=400, detail=str(loi))
    return JSONResponse({"ok": True, "tai_khoan": moi})


@app.delete("/may/notebooklm/tai-khoan/{ma}")
async def xoa_tai_khoan(ma: str, request: Request, x_bang_dieu_khien: str | None = Header(None)):
    """Bỏ một tài khoản dự phòng và xoá phiên đăng nhập của nó trên máy. Bản lưu trực tuyến
    đã tạo ở tài khoản đó thì vẫn còn trên Google."""
    _chan(request, x_bang_dieu_khien)
    cu = DANG_NHAP_NLM["tien_trinh"]
    if cu is not None and cu.poll() is None and DANG_NHAP_NLM.get("ma") == ma:
        raise HTTPException(status_code=409, detail="Cửa sổ đăng nhập của tài khoản này đang mở. "
                            "Đăng nhập xong hoặc đóng cửa sổ đó rồi mới xoá.")
    try:
        xoa_tai_khoan_phu(ma)
    except LoiRo as loi:
        raise HTTPException(status_code=404, detail=str(loi))
    return JSONResponse({"ok": True})


# ----------------------------------------------------------------------------
# Danh sách, chi tiết và các nút của từng cuộc họp
# ----------------------------------------------------------------------------

# Tên phiên bản người dùng thấy (PM chốt 30/9/2026): bản lớn là số tròn v1, v2, v3...; bản
# nhỏ thêm số sau dấu chấm v1.1, v1.2, v2.1... Bản lớn hay nhỏ do người phát hành quyết khi
# đặt SO_BAN. Sau bản v1 chỉ có thể là v1.1 hoặc v2; sau v1.1 là v1.2 hoặc v2; không nhảy
# cóc, không lùi (dong_goi.py --xuat-ban kiểm bằng la_ban_ke_tiep). v1.4 (30/9/2026): đóng gói
# cài nhanh, không đổi cách dùng. v1.5 (30/9/2026): trợ lý tự gửi lại khi gửi hỏng, không đổi
# cách dùng. v1.6 (1/10/2026): sửa Windows cài xong không mở được ứng dụng (biểu tượng cửa sổ
# phải là .ico), không đổi cách dùng. Dấu mã nguồn bên dưới
# (PHIEN_BAN, 7 ký tự tính từ các tệp mã) vẫn là khoá nhận biết bên trong: gói có đúng bản
# không, bản đang chạy có phải bản đã phát hành không. Dòng SO_BAN được đọc lại bằng chữ từ
# trong gói (so_ban_cua): giữ đúng dạng 'SO_BAN = "<số>"' ở đầu dòng.
MAU_SO_BAN = r"[1-9][0-9]{0,2}(?:\.[1-9][0-9]?)?"  # "1", "2", "1.1", "2.10"; không "1.0", "01"
SO_BAN = "1.6"
TEN_BAN = f"v{SO_BAN}"


def khoa_so_ban(so: str) -> tuple[int, int]:
    """Khoá so sánh giữa các bản: "1" là (1, 0), "1.1" là (1, 1), "1.10" là (1, 10), "2" là
    (2, 0). Nên v1 < v1.1 < v1.2 < v1.10 < v2 < v2.1."""
    lon, _, nho = so.partition(".")
    return int(lon), int(nho or 0)


def ban_ke_tiep(so: str) -> tuple[str, str]:
    """Hai bản có thể phát hành ngay sau bản `so`: (bản nhỏ kế, bản lớn kế). Ví dụ v1 thì
    (v1.1, v2), v1.1 thì (v1.2, v2), v2.2 thì (v2.3, v3)."""
    lon, nho = khoa_so_ban(so)
    return f"{lon}.{nho + 1}", f"{lon + 1}"


def la_ban_ke_tiep(cu: str | None, moi: str) -> bool:
    """`moi` có phát hành được ngay sau bản `cu` đang trên kho không. Kho chưa có bản đánh
    số (cu là None) thì chỉ v1."""
    if not re.fullmatch(MAU_SO_BAN, moi):
        return False
    return moi == "1" if cu is None else moi in ban_ke_tiep(cu)

# Các tệp tạo nên dấu phiên bản: mọi tệp mã chép sang máy người dùng (bộ tự kiểm cũng
# dựng gói thử từ danh sách này). Trước 27/9/2026 thiếu ba tệp cuối: sửa riêng kiem_thu.py
# thì gói mới vẫn mang số cũ, nút Cập nhật bản mới báo "không cần cập nhật"
#
# ĐỪNG THÊM tệp vào danh sách này khi còn máy chạy bản cũ: bản cũ tự tính dấu mã của gói mới
# bằng danh sách CỦA NÓ rồi so với ban-moi.json; danh sách khác nhau thì dấu mã khác nhau và
# nút Cập nhật báo "Tệp tải về là bản X, không phải bản Y". tu_kiem_nhanh.py (v1.4) vì vậy
# không nằm ở đây; mỗi lần phát hành đều đổi SO_BAN trong bien_ban_hop.py nên dấu mã vẫn đổi.
TEP_PHIEN_BAN = ("bien_ban_hop.py", "ghi_am.py", "tao_word.py", "giao_dien.html",
                 "xem_dien_thoai.html", "kiem_thu.py", "ung_dung.py", "tao_ung_dung.py",
                 "kich_hoat.py")


def so_ban_cua(doc_tep) -> str | None:
    """Số phiên bản ("1", "1.1", "2"...) của một gói: đọc dòng SO_BAN trong bien_ban_hop.py
    của gói (doc_tep đọc các tệp ở nơi khác, như dau_phien_ban). Không thấy thì None."""
    try:
        m = re.search(rb'^SO_BAN = "(' + MAU_SO_BAN.encode() + rb')"[ \t]*\r?$',
                      doc_tep("bien_ban_hop.py"), re.MULTILINE)
    except (OSError, KeyError):
        return None
    return m[1].decode() if m else None


def dau_phien_ban(doc_tep=None) -> str:
    """Dấu nhận biết bản mã đang chạy: 7 ký tự tính từ nội dung các tệp chính, tự
    đổi khi mã đổi. Hiện ở thẻ Cài đặt để biết máy đã chạy bản mới chưa.
    doc_tep đọc các tệp đó ở nơi khác, ví dụ trong tệp zip bản mới."""
    import hashlib
    doc_tep = doc_tep or (lambda ten: (THU_MUC_GOC / ten).read_bytes())
    bam = hashlib.sha1()
    for ten in TEP_PHIEN_BAN:
        try:
            bam.update(doc_tep(ten))
        except (OSError, KeyError):
            pass
    return bam.hexdigest()[:7]


PHIEN_BAN = dau_phien_ban()  # tính một lần lúc bật: đúng là bản đang nằm trong bộ nhớ


def tinh_trang_may() -> dict:
    """Ba thứ hay thiếu nhất, kiểm trước để không phát hiện muộn lúc đang họp."""
    return {
        "he": "windows" if LA_WINDOWS else "mac",
        "ffmpeg": shutil.which("ffmpeg") is not None,
        "cach": cach_go_chu(),
        "nlm": da_dang_nhap_nlm(),
        "phien_ban": PHIEN_BAN,
        "so_ban": SO_BAN,
        "ten_ban": TEN_BAN,
    }


async def co_ollama() -> bool:
    try:
        async with httpx.AsyncClient(timeout=3) as c:
            dap = await c.get(f"{OLLAMA_URL}/api/tags")
            return dap.status_code < 400 and bool((dap.json() or {}).get("models"))
    except (httpx.HTTPError, ValueError):
        return False


def _luc(viec: dict) -> str:
    try:
        d = datetime.fromisoformat(viec.get("bat_dau") or viec.get("nhan_luc") or "")
    except ValueError:
        return ""
    return f"{d:%H:%M} {d:%d/%m/%Y}"


@app.get("/may/trang-thai")
async def may_trang_thai(request: Request):
    chi_tu_may_nay(request)
    bat_vong_ban_moi()
    tt = tinh_trang_may()
    tt["ban_moi"] = dict(BAN_MOI) or None
    tt["kich_hoat"] = await asyncio.to_thread(trang_thai_kich_hoat)
    tt["ollama"] = await co_ollama()
    tt["ghi"] = MAY_GHI.trang_thai()
    tt["viec"] = [
        {"ma": m, "trang_thai": v["trang_thai"], "luc": _luc(v),
         "ten": (v.get("tt") or {}).get("ten_cuoc_hop", ""),
         "thoi_luong_giay": v.get("thoi_luong_giay"), "buoc": v.get("buoc"),
         "co_ket_qua": bool(v.get("ket_qua")), "co_word": bool(v.get("tep_word")),
         "con_ghi_am": bool(v.get("tep_ghi_am")), "da_ky": bool(v.get("da_ky")),
         "cach": v.get("cach") or "", "cach_da_bao": v.get("cach_da_bao") or "",
         "canh_bao": v.get("canh_bao") or "", "loi": v.get("loi") or ""}
        for m in reversed(THU_TU) for v in [VIEC[m]]
    ]
    return JSONResponse(tt)


def _viec_cua(ma: str, xong: bool = True) -> dict:
    viec = VIEC.get(ma)
    if not viec:
        raise HTTPException(status_code=404, detail="Không có cuộc họp này")
    if xong and viec["trang_thai"] not in XONG:
        raise HTTPException(status_code=409, detail="Việc đang chạy, chờ xong đã")
    return viec


@app.get("/may/viec/{ma}")
async def xem_viec(ma: str, request: Request):
    chi_tu_may_nay(request)
    # Bỏ các khoá task vì đối tượng task không chuyển được sang JSON
    viec = {k: v for k, v in _viec_cua(ma, xong=False).items()
            if k not in ("task", "task_tro_ly")}
    # Bản xem nhanh dùng CHÍNH bộ tách của tệp Word, để hai bên không lệch nhau
    try:
        import tao_word
        viec["khoi"] = tao_word.tach_than_bai(viec.get("ket_qua") or "",
                                             (viec.get("tt") or {}).get("ten_cuoc_hop", ""))
    except ImportError:
        viec["khoi"] = None
    # Sổ nằm ở tài khoản dự phòng thì màn Kết quả ghi rõ tên tài khoản cạnh nút mở sổ (v1.3)
    so = viec.get("so_nlm") or {}
    viec["ten_tai_khoan_so"] = ((tai_khoan_cua(so["tai_khoan"]) or {}).get("ten") or "Tài khoản dự phòng"
                                if so.get("tai_khoan") else None)
    return JSONResponse(viec)


@app.post("/may/viec/{ma}/lam-lai")
async def lam_lai(ma: str, request: Request,
                  x_bang_dieu_khien: str | None = Header(None)):
    """Chạy lại từ bản ghi đã lưu. Đã có bản chép lời thì khỏi chép lời lại."""
    _chan(request, x_bang_dieu_khien)
    can_kich_hoat()
    viec = _viec_cua(ma)
    if viec["trang_thai"] == "Xong":
        raise HTTPException(status_code=409, detail="Cuộc họp này đã xong, không cần làm lại")
    ghi_am_tep = Path(viec["thu_muc"]) / (viec.get("tep_ghi_am") or "")
    if not viec.get("tep_ghi_am") or not ghi_am_tep.is_file():
        raise HTTPException(status_code=409,
                            detail="Bản ghi của cuộc họp này đã bị xoá, không làm lại được")
    viec.update(trang_thai="Đang làm lại", loi=None, ket_qua=None, canh_bao=None,
                tep_word=None, buoc=0, thoi_cho_google=False)
    ghi_nhat_ky(viec, "Bấm Làm lại")
    bat_dau_xu_ly(viec)
    return JSONResponse({"ok": True})


@app.put("/may/viec/{ma}/ghi-chu-rieng")
async def luu_ghi_chu_rieng(ma: str, request: Request,
                            x_bang_dieu_khien: str | None = Header(None)):
    """Ô Ghi chú của thư ký, trong lúc họp hay sau khi họp. Lưu ở ghi-chu-thu-ky.txt.
    Từ 27/9/2026 (PM chốt) ô này LUÔN gửi làm ngữ cảnh cho trợ lý và biên bản cuối ở
    cuộc họp gửi lên mạng (khoi_ngu_canh); không hiện trên điện thoại chủ trì."""
    _chan(request, x_bang_dieu_khien)
    viec = _viec_cua(ma, xong=False)
    try:
        than = await request.json()
    except ValueError:
        raise HTTPException(status_code=400, detail="Dữ liệu không đọc được")
    chu = than.get("chu") if isinstance(than, dict) else None
    if not isinstance(chu, str) or len(chu) > 100_000:
        raise HTTPException(status_code=400, detail="Ghi chú không hợp lệ")
    viec["ghi_chu_rieng"] = chu
    tep = Path(viec["thu_muc"]) / TEP_CHU[2][0]
    (Path(viec["thu_muc"]) / TEP_CHU[2][2]).unlink(missing_ok=True)  # tên cũ
    if chu.strip():
        _ghi_an_toan(tep, chu)
    else:
        tep.unlink(missing_ok=True)
    return JSONResponse({"ok": True})


@app.post("/may/viec/{ma}/thoi-cho-google")
async def thoi_cho_google(ma: str, request: Request,
                          x_bang_dieu_khien: str | None = Header(None)):
    """Nút Thôi chờ Google: vòng chờ Google chép lời thấy cờ này thì dừng trong
    khoảng một giây, rồi máy xử lý như khi Google hỏng (dừng ở Lỗi, giữ bản ghi)."""
    _chan(request, x_bang_dieu_khien)
    viec = _viec_cua(ma, xong=False)
    if not viec.get("dang_cho_google"):
        raise HTTPException(status_code=409, detail="Cuộc họp này không còn chờ chép lời")
    viec["thoi_cho_google"] = True
    ghi_nhat_ky(viec, "Bấm Thôi chờ")
    return JSONResponse({"ok": True})


@app.post("/may/viec/{ma}/da-ky")
async def da_ky(ma: str, request: Request,
                x_bang_dieu_khien: str | None = Header(None)):
    """Biên bản đã ký thì xoá bản ghi âm, đúng lời hứa chủ trì đọc đầu buổi.
    Biên bản, bản chép lời và tệp Word vẫn giữ."""
    _chan(request, x_bang_dieu_khien)
    viec = _viec_cua(ma)
    if viec.get("tep_ghi_am"):
        (Path(viec["thu_muc"]) / viec["tep_ghi_am"]).unlink(missing_ok=True)
        viec["tep_ghi_am"] = None
    viec["da_ky"] = True
    luu_viec(viec)
    return JSONResponse({"ok": True})


def mo_bang_he_thong(dich: str) -> None:
    """Mở tệp, thư mục hoặc trang web bằng ứng dụng mặc định của máy: Word cho
    tệp .docx, Finder hay File Explorer cho thư mục, trình duyệt cho trang web."""
    if LA_WINDOWS:
        os.startfile(dich)  # noqa: S606 - chỉ mở đường dẫn do chính máy chủ dựng
    elif shutil.which("open"):
        subprocess.Popen(["open", dich])
    else:
        raise HTTPException(status_code=501, detail=f"Máy này không tự mở được. Mở tay: {dich}")


def _mo(dich: Path) -> None:
    if not dich.exists():
        raise HTTPException(status_code=404, detail=f"Không thấy {dich}")
    mo_bang_he_thong(str(dich))


@app.post("/may/viec/{ma}/mo")
async def mo_tep(ma: str, request: Request, cai: str = "thu-muc",
                 x_bang_dieu_khien: str | None = Header(None)):
    """Mở tệp Word, thư mục cuộc họp, hoặc sổ NotebookLM của cuộc họp (trong
    trình duyệt mặc định)."""
    _chan(request, x_bang_dieu_khien)
    viec = _viec_cua(ma)
    if cai == "word":
        if not viec.get("tep_word"):
            raise HTTPException(status_code=404, detail="Cuộc họp này chưa có tệp Word")
        _mo(Path(viec["thu_muc"]) / viec["tep_word"])
    elif cai == "notebooklm":
        so = viec.get("so_nlm") or {}
        if not so.get("id"):
            raise HTTPException(status_code=404, detail="Cuộc họp này không có bản lưu trực tuyến")
        mo_bang_he_thong(dia_chi_so_nlm(so["id"], so.get("gmail")))
    else:
        _mo(Path(viec["thu_muc"]))
    return JSONResponse({"ok": True})


@app.post("/may/mo-thu-muc-luu")
async def mo_thu_muc_luu(request: Request, x_bang_dieu_khien: str | None = Header(None)):
    _chan(request, x_bang_dieu_khien)
    THU_MUC_LUU.mkdir(parents=True, exist_ok=True)
    _mo(THU_MUC_LUU)
    return JSONResponse({"ok": True})


# ----------------------------------------------------------------------------
# Kiểm tra toàn bộ (thẻ Cài đặt)
# ----------------------------------------------------------------------------

# Từ v1.4 (PM chốt 30/9/2026) trình cài chỉ chạy tu_kiem_nhanh.py, vài giây. Bộ kiểm đầy đủ
# (kiem_thu.py, khoảng 5 phút) vẫn chạy ở luồng GitHub trên máy Mac và Windows thật trước
# mỗi bản phát hành; nút này cho chạy nó ngay trên máy này khi cần (máy nghi có lỗi, hay
# người phụ trách kỹ thuật cần biết). Chạy trong tiến trình riêng, thư mục tạm riêng, không
# đụng cuộc họp thật.
KIEM_DAY_DU: dict = {"tien_trinh": None, "luc": 0.0, "ket_qua": None}
TEP_KIEM_DAY_DU = THU_MUC_GOC / "nhat-ky-kiem-day-du.txt"
HAN_KIEM_DAY_DU_GIAY = 30 * 60  # máy nhanh mất 5 phút; máy chậm gấp vài lần vẫn xong


def lenh_kiem_day_du() -> list[str]:
    return [sys.executable, "-X", "utf8", str(THU_MUC_GOC / "kiem_thu.py")]


def doc_ket_qua_kiem_day_du(ma_thoat: int | None) -> dict:
    """Đọc dòng "N/M phép đạt" cuối nhật ký của bộ kiểm, và dòng "TRƯỢT: ..." nếu có."""
    try:
        chu = TEP_KIEM_DAY_DU.read_text(encoding="utf-8", errors="replace")
    except OSError:
        chu = ""
    cac_dong = re.findall(r"^(\d+)/(\d+) phép đạt$", chu, re.MULTILINE)
    if not cac_dong:
        return {"dat": False, "chu": "Chưa đọc được kết quả kiểm tra. Chụp màn hình này gửi người "
                                     "phụ trách kỹ thuật, kèm tệp nhat-ky-kiem-day-du.txt trong "
                                     "thư mục ứng dụng."}
    dat, tong = cac_dong[-1]
    if ma_thoat == 0 and dat == tong:
        return {"dat": True, "chu": f"Đạt {dat}/{tong} phép kiểm."}
    truot = re.findall(r"^TRƯỢT: (.*)$", chu, re.MULTILINE)
    return {"dat": False, "chu": f"Đạt {dat}/{tong} phép kiểm. Chưa đạt: "
                                 f"{truot[-1][:300] if truot else 'xem nhật ký'}. Chụp màn hình này "
                                 "gửi người phụ trách kỹ thuật."}


@app.post("/may/kiem-tra-day-du")
async def bat_dau_kiem_day_du(request: Request, x_bang_dieu_khien: str | None = Header(None)):
    """Nút Kiểm tra toàn bộ: chạy bộ kiểm đầy đủ trong tiến trình riêng. Không chạy lúc đang ghi
    âm hay soạn biên bản (máy chậm đi, có thể rớt tiếng)."""
    _chan(request, x_bang_dieu_khien)
    if dang_ban():
        raise HTTPException(status_code=409, detail="Đang ghi âm hoặc đang soạn biên bản. Chờ xong "
                            "rồi hãy kiểm tra.")
    cu = KIEM_DAY_DU["tien_trinh"]
    if cu is not None and cu.poll() is None:
        raise HTTPException(status_code=409, detail="Đang kiểm tra rồi, chờ kết quả.")
    if not (THU_MUC_GOC / "kiem_thu.py").is_file():
        raise HTTPException(status_code=404, detail="Máy này không có bộ kiểm đầy đủ.")
    try:
        with TEP_KIEM_DAY_DU.open("w", encoding="utf-8") as nhat_ky:
            KIEM_DAY_DU["tien_trinh"] = subprocess.Popen(
                lenh_kiem_day_du(), stdout=nhat_ky, stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL, cwd=THU_MUC_GOC, **AN_CUA_SO)
    except OSError as loi:
        raise HTTPException(status_code=500, detail=f"Không chạy được bộ kiểm: {loi}") from None
    KIEM_DAY_DU.update(luc=time.monotonic(), ket_qua=None)
    return JSONResponse({"ok": True})


@app.get("/may/kiem-tra-day-du")
async def tinh_trang_kiem_day_du(request: Request):
    chi_tu_may_nay(request)
    tien_trinh = KIEM_DAY_DU["tien_trinh"]
    dang_chay = tien_trinh is not None and tien_trinh.poll() is None
    if dang_chay and time.monotonic() - KIEM_DAY_DU["luc"] > HAN_KIEM_DAY_DU_GIAY:
        tien_trinh.kill()  # đồng hồ phía mình, nguyên tắc a
        with contextlib.suppress(subprocess.TimeoutExpired):
            await asyncio.to_thread(tien_trinh.wait, 5)
        KIEM_DAY_DU["ket_qua"] = {"dat": False, "chu": "Quá 30 phút chưa xong nên đã dừng bộ kiểm."}
        dang_chay = False
    if tien_trinh is not None and not dang_chay and KIEM_DAY_DU["ket_qua"] is None:
        KIEM_DAY_DU["ket_qua"] = doc_ket_qua_kiem_day_du(tien_trinh.returncode)
    return JSONResponse({"dang_chay": dang_chay, "ket_qua": KIEM_DAY_DU["ket_qua"],
                         "co_kiem_thu": (THU_MUC_GOC / "kiem_thu.py").is_file()})


# ----------------------------------------------------------------------------
# Tắt ứng dụng
# ----------------------------------------------------------------------------

def dang_ban() -> bool:
    """Đang ghi âm, hoặc có cuộc họp đang chép lời hay đang soạn biên bản."""
    return bool(MAY_GHI.tt or any(v["trang_thai"] not in XONG for v in VIEC.values()))


def don_dep() -> None:
    """Dừng ghi âm (các đoạn đã ghi nằm lại trên ổ, lần mở sau tự nối lại), để
    không còn gì chạy ngầm sau khi tắt."""
    if MAY_GHI.tt == "ghi":
        try:
            MAY_GHI.tam_dung()
        except RuntimeError:
            pass
    cu = KIEM_DAY_DU["tien_trinh"]  # bộ kiểm đầy đủ đang chạy thì tắt theo ứng dụng
    if cu is not None and cu.poll() is None:
        with contextlib.suppress(OSError):
            cu.kill()


def _thoat_han() -> None:
    os._exit(0)


KHI_TAT = _thoat_han  # ung_dung.py thay bằng hàm đóng cửa sổ


@app.post("/may/tat")
async def tat_ung_dung(request: Request, chac: int = 0,
                       x_bang_dieu_khien: str | None = Header(None)):
    _chan(request, x_bang_dieu_khien)
    if not chac and dang_ban():
        raise HTTPException(status_code=409, detail="Đang ghi âm hoặc đang soạn biên bản")
    await asyncio.to_thread(don_dep)
    asyncio.get_running_loop().call_later(0.3, lambda: KHI_TAT())
    return JSONResponse({"ok": True})


# ----------------------------------------------------------------------------
# Cập nhật bản mới từ tệp zip
# ----------------------------------------------------------------------------

GIOI_HAN_GOI = 50 * 1024 * 1024        # gói thật chỉ khoảng 1 MB
GIOI_HAN_GIAI_NEN = 200 * 1024 * 1024  # chặn tệp zip nhỏ mà giải nén ra hàng GB
# Mỗi lần cập nhật xoá rồi giải nén lại ở đây. Để trong thư mục ứng dụng chứ không
# ở thư mục tạm của máy, để người phụ trách kỹ thuật biết chỗ tìm khi cần mở tay.
THU_MUC_CAP_NHAT = THU_MUC_GOC / ".ban-cap-nhat"


def _ten_an_toan(ten: str) -> bool:
    """Tên tệp trong zip chỉ được trỏ vào bên trong thư mục giải nén: không đường
    dẫn tuyệt đối, không ổ đĩa (C:), không "..", không dấu gạch ngược."""
    return (bool(ten) and not ten.startswith("/") and "\\" not in ten and ":" not in ten
            and ".." not in ten.split("/"))


# Gói cài từ bản 4 (27/9/2026, dong_goi.py dựng): Mac là tệp zip chỉ chứa
# "Cài đặt SonicRec.app" (trước 28/9/2026 "Cài đặt Biên bản họp.app"; mã ứng dụng ở
# Contents/Resources/goi, tệp chạy Contents/MacOS/cai-dat); Windows là tệp
# CaiDat-SonicRec-Windows-v<số>.exe (trước 30/9/2026 mang dấu mã thay số; trước đó
# CaiDat-BienBanHop-...) dựng bằng NSIS, trong thông tin tệp có BBH-PHIEN-BAN=<dấu mã>
# và từ 30/9/2026 thêm ;BBH-SO-BAN=<số> (trinh_cai_windows.nsi ghi). Dấu mã đứng trước
# và đủ 7 ký tự, nên bản cũ vẫn đọc được tệp cài mới.
DUONG_GOI_MAC = "Contents/Resources/goi/"
TEP_CHAY_MAC = "Contents/MacOS/cai-dat"
DAU_GOI_WIN = "BBH-PHIEN-BAN=".encode("utf-16-le")
DAU_SO_BAN_WIN = "BBH-SO-BAN=".encode("utf-16-le")


def so_ban_trong_exe(du_lieu: bytes) -> str | None:
    """Số phiên bản ("1", "1.1"...) ghi trong thông tin tệp cài Windows. Không thấy hoặc
    sai dạng thì None."""
    i = du_lieu.find(DAU_SO_BAN_WIN)
    if i < 0:
        return None
    dau = i + len(DAU_SO_BAN_WIN)
    m = re.match(MAU_SO_BAN + r"(?![0-9.])", du_lieu[dau:dau + 16].decode("utf-16-le", "replace"))
    return m[0] if m else None


def giai_nen_goi(tep_zip) -> tuple[Path, str]:
    """Kiểm tệp zip có đúng gói cài SonicRec cho Mac không, rồi giải nén vào
    THU_MUC_CAP_NHAT. Trả (ứng dụng cài đặt trong gói, phiên bản của gói)."""
    try:
        z = zipfile.ZipFile(tep_zip)
    except zipfile.BadZipFile:
        raise HTTPException(status_code=400, detail="Tệp này không phải tệp zip, hoặc tải "
                            "về chưa trọn. Tải lại tệp rồi thử lại.") from None
    with z:
        cac_tep = z.infolist()
        ten = {t.filename for t in cac_tep}
        if not all(_ten_an_toan(t.filename) for t in cac_tep):
            raise HTTPException(status_code=400, detail="Tệp zip có tên tệp trỏ ra ngoài thư "
                                "mục giải nén. Không dùng tệp này.")
        if sum(t.file_size for t in cac_tep) > GIOI_HAN_GIAI_NEN:
            raise HTTPException(status_code=400, detail="Tệp zip giải nén ra quá lớn, không "
                                "phải gói cài SonicRec.")
        # Gốc là ứng dụng .app nông nhất có mã ứng dụng. Không so tên ứng dụng: nén lại
        # trên Mac thì chữ có dấu trong tên được ghi kiểu khác (NFD)
        duoi = DUONG_GOI_MAC + "bien_ban_hop.py"
        goc = min((t[:-len(duoi)] for t in ten if t.endswith(".app/" + duoi)),
                  key=len, default=None)
        if goc is None or goc + TEP_CHAY_MAC not in ten:
            raise HTTPException(status_code=400, detail="Tệp zip này không phải gói cài "
                                "SonicRec cho Mac (CaiDat-SonicRec-Mac-....zip).")
        phien_ban = dau_phien_ban(lambda t: z.read(goc + DUONG_GOI_MAC + t))
        if phien_ban == PHIEN_BAN:
            raise HTTPException(status_code=409, detail=f"Máy đang chạy đúng bản {TEN_BAN} "
                                f"(mã {PHIEN_BAN}) trong tệp này rồi, không cần cập nhật.")
        shutil.rmtree(THU_MUC_CAP_NHAT, ignore_errors=True)
        for t in cac_tep:
            if t.filename.startswith(goc) and not t.is_dir():
                ra = Path(z.extract(t, THU_MUC_CAP_NHAT))
                # zip giữ quyền chạy trong external_attr nhưng giải nén không tự đặt lại
                if (t.external_attr >> 16) & 0o111:
                    ra.chmod(0o755)
    app = THU_MUC_CAP_NHAT / goc
    (app / TEP_CHAY_MAC).chmod(0o755)  # gói nén lại mất quyền chạy thì vẫn chạy được
    return app, phien_ban


def nhan_goi_windows(du_lieu: bytes) -> tuple[Path, str]:
    """Kiểm tệp .exe có đúng trình cài SonicRec cho Windows không, rồi lưu vào
    THU_MUC_CAP_NHAT. Trả (tệp trình cài, phiên bản của gói)."""
    i = du_lieu.find(DAU_GOI_WIN) if du_lieu[:2] == b"MZ" else -1
    dau = i + len(DAU_GOI_WIN)
    phien_ban = du_lieu[dau:dau + 14].decode("utf-16-le", "replace") if i >= 0 else ""
    if not re.fullmatch(r"[0-9a-f]{7}", phien_ban):
        raise HTTPException(status_code=400, detail="Tệp này không phải tệp cài SonicRec "
                            "cho Windows (CaiDat-SonicRec-Windows-....exe).")
    if phien_ban == PHIEN_BAN:
        raise HTTPException(status_code=409, detail=f"Máy đang chạy đúng bản {TEN_BAN} "
                            f"(mã {PHIEN_BAN}) trong tệp này rồi, không cần cập nhật.")
    shutil.rmtree(THU_MUC_CAP_NHAT, ignore_errors=True)
    THU_MUC_CAP_NHAT.mkdir(parents=True)
    tep = THU_MUC_CAP_NHAT / f"CaiDat-SonicRec-Windows-{phien_ban}.exe"
    tep.write_bytes(du_lieu)
    return tep, phien_ban


def chay_trinh_cai(tep: Path) -> None:
    """Mở trình cài của gói mới ở chế độ cập nhật: bỏ lời chào và bước chọn thư mục,
    cài xong tự mở lại ứng dụng. Tệp do chính ứng dụng ghi ra nên không mang dấu
    "tải từ mạng về": Windows và macOS không chặn như lúc cài lần đầu."""
    if LA_WINDOWS:
        os.startfile(str(tep), arguments="/CAPNHAT")  # noqa: S606 - tệp vừa kiểm
    elif shutil.which("open"):
        subprocess.run(["open", "-n", str(tep), "--args", "--cap-nhat"], check=True,
                       timeout=30, capture_output=True)
    else:
        raise HTTPException(status_code=501, detail=f"Máy này không tự mở được trình cài. "
                            f"Mở tay {tep}")


@app.post("/may/cap-nhat")
async def cap_nhat(request: Request, goi_tep: UploadFile = File(..., alias="goi"),
                   x_bang_dieu_khien: str | None = Header(None)):
    """Cập nhật từ tệp cài bản mới (Mac: tệp zip, Windows: tệp .exe): kiểm gói, mở
    trình cài của gói ở chế độ cập nhật, rồi tự tắt để trình cài thay tệp. Cài xong,
    trình cài mở lại ứng dụng. Các cuộc họp và thông tin đã điền giữ nguyên, như khi
    chạy lại trình cài bằng tay."""
    _chan(request, x_bang_dieu_khien)
    if dang_ban():
        raise HTTPException(status_code=409, detail="Đang ghi âm hoặc đang soạn biên bản. "
                            "Chờ xong rồi hãy cập nhật.")
    bo_dem = io.BytesIO()
    while khoi := await goi_tep.read(1024 * 1024):
        if bo_dem.tell() + len(khoi) > GIOI_HAN_GOI:
            raise HTTPException(status_code=413, detail="Tệp quá lớn, không phải gói cài "
                                "SonicRec.")
        bo_dem.write(khoi)
    return await _cai_goi(bo_dem.getvalue())


async def _cai_goi(du_lieu: bytes, phai_la: str | None = None,
                   so_phai_la: str | None = None) -> JSONResponse:
    """Kiểm gói của máy này, mở trình cài ở chế độ cập nhật rồi hẹn tự tắt. phai_la và
    so_phai_la: dấu mã và số phiên bản ("1.1"...) gói phải mang (tải từ kho thì phải đúng
    bản ban-moi.json báo; sai số thì cài xong máy lại thấy "có bản mới" mãi)."""
    if LA_WINDOWS:
        tep, phien_ban = await asyncio.to_thread(nhan_goi_windows, du_lieu)
        so_goi = so_ban_trong_exe(du_lieu)
    else:
        tep, phien_ban = await asyncio.to_thread(giai_nen_goi, io.BytesIO(du_lieu))
        so_goi = so_ban_cua(lambda t: (tep / DUONG_GOI_MAC / t).read_bytes())
    if phai_la and phien_ban != phai_la:
        raise HTTPException(status_code=400, detail=f"Tệp tải về là bản {phien_ban}, không "
                            f"phải bản {phai_la}. Không cài; báo người phụ trách kỹ thuật.")
    if so_phai_la is not None and so_goi != so_phai_la:
        raise HTTPException(status_code=400, detail=f"Tệp tải về là bản "
                            f"{'v' + str(so_goi) if so_goi else 'không rõ số'}, không phải bản "
                            f"v{so_phai_la}. Không cài; báo người phụ trách kỹ thuật.")
    try:
        await asyncio.to_thread(chay_trinh_cai, tep)
    except (OSError, subprocess.SubprocessError) as loi:
        print(f"Không mở được trình cài {tep}: {loi}", flush=True)
        raise HTTPException(status_code=500, detail=f"Không mở được trình cài. Mở tay {tep}") \
            from None
    # Tắt sau một chút, để giao diện kịp nhận trả lời và hiện lời dặn
    asyncio.get_running_loop().call_later(1.5, lambda: KHI_TAT())
    # ten_moi, ten_cu: tên người dùng thấy (v2, v1). Gói cũ không ghi số thì hiện dấu mã
    return JSONResponse({"ok": True, "phien_ban": phien_ban, "cu": PHIEN_BAN,
                         "ten_moi": f"v{so_goi}" if so_goi else phien_ban, "ten_cu": TEN_BAN})


# ----------------------------------------------------------------------------
# Tự báo bản mới qua kho GitHub công khai HaiTLU/sonicrec (PM chốt 27/9/2026: dùng
# kho GitHub; có bản mới thì HỎI TRƯỚC, không tự khởi động lại).
#
# Kho chỉ chứa tệp cài mới nhất (ban-cai/) và ban-moi.json (dong_goi.py --xuat-ban viết).
# Ứng dụng xem ban-moi.json lúc giao diện mở và mỗi 6 giờ. Chỉ báo khi số phiên bản
# (so_ban, hiện ra là v1, v1.1, v2...) cao hơn bản đang chạy VÀ dấu mã bản đang chạy có trong
# "cac_ban_truoc", tức là một bản đã phát hành trước bản mới: bản thử chưa phát hành không
# bị mời cập nhật. Bấm Cập nhật thì tải đúng tệp của máy, kiểm cỡ và mã sha256 ghi trong
# ban-moi.json, kiểm gói có đúng dấu mã và số thứ tự, rồi cài như nút Cập nhật bản mới.
# ----------------------------------------------------------------------------

# Kho đặt theo tên ứng dụng SonicRec (PM đổi tên 28/9/2026); kho bien-ban-hop chưa từng tạo
KHO_MAC_DINH = "https://raw.githubusercontent.com/HaiTLU/sonicrec/main/"
# Chuỗi rỗng là không xem (bộ tự kiểm đặt vậy để không bao giờ gọi mạng thật)
KHO_BAN_MOI = os.environ.get("KHO_BAN_MOI", KHO_MAC_DINH)
NHIP_XEM_BAN_MOI = 6 * 3600
BAN_MOI: dict = {}                     # bản mới đang có; rỗng là không có hoặc chưa xem được
XEM_BAN_MOI: dict = {"task": None}
# Tên tệp cài trên kho, đúng tên dong_goi.py đặt. ban-moi.json ghi tên khác là sai dạng:
# máy không bao giờ tải một đường dẫn lạ do tệp trên mạng đưa tới
TEN_TEP_CAI = {"mac": "CaiDat-SonicRec-Mac-v{}.zip", "windows": "CaiDat-SonicRec-Windows-v{}.exe"}


async def tai_ve(url: str, gioi_han: int, han: float) -> bytes:
    """Tải một tệp qua mạng. Quá cỡ thì thôi ngay; quá hạn giờ thì thôi, hạn tính cho cả
    lần tải (hạn của httpx chỉ tính từng lần chờ, mạng rỉ rả thì không bao giờ hết)."""
    async def tai() -> bytes:
        async with httpx.AsyncClient(timeout=han, follow_redirects=True) as c:
            async with c.stream("GET", url) as dap:
                dap.raise_for_status()
                bo = bytearray()
                async for khoi in dap.aiter_bytes():
                    bo += khoi
                    if len(bo) > gioi_han:
                        raise LoiRo("Tệp tải về lớn hơn cỡ đã báo")
                return bytes(bo)
    return await asyncio.wait_for(tai(), han)


def doc_ban_moi(du_lieu: bytes) -> dict | None:
    """Đọc và kiểm ban-moi.json. Sai dạng ở bất kỳ chỗ nào thì None (coi như không có).
    phien_ban là dấu mã của gói (7 ký tự), so_ban là số phiên bản dạng chữ ("1", "1.1",
    "2"...; hiện ra là v1, v1.1, v2...) và quyết định tên tệp cài. Bản cũ (trước 30/9/2026)
    đặt tên tệp theo dấu mã nên đọc bảng mới này thành None: im lặng, không mời, không tải
    nhầm."""
    try:
        m = json.loads(du_lieu)
    except ValueError:
        return None
    if not isinstance(m, dict) or not re.fullmatch(r"[0-9a-f]{7}", str(m.get("phien_ban", ""))):
        return None
    if type(m.get("so_ban")) is not str or not re.fullmatch(MAU_SO_BAN, m["so_ban"]):
        return None
    if not isinstance(m.get("cac_ban_truoc", []), list):
        return None
    for he, ten in TEN_TEP_CAI.items():
        g = m.get(he)
        if not (isinstance(g, dict) and g.get("tep") == ten.format(m["so_ban"])
                and re.fullmatch(r"[0-9a-f]{64}", str(g.get("sha256", "")))
                and type(g.get("co")) is int and 0 < g["co"] <= GIOI_HAN_GOI):
            return None
    return m


def co_nen_bao(m: dict | None) -> bool:
    """Có bản mới để mời cập nhật: khác mã đang chạy, số phiên bản cao hơn bản đang chạy
    (v1.1 và v2 đều cao hơn v1), và bản đang chạy là bản đã phát hành (dấu mã có trong danh
    sách bản trước)."""
    return (bool(m) and m["phien_ban"] != PHIEN_BAN
            and khoa_so_ban(m["so_ban"]) > khoa_so_ban(SO_BAN)
            and PHIEN_BAN in m.get("cac_ban_truoc", []))


async def xem_ban_moi() -> dict | None:
    """Xem ban-moi.json trên kho, cập nhật BAN_MOI. Mất mạng hay kho hỏng thì im lặng."""
    try:
        m = doc_ban_moi(await tai_ve(KHO_BAN_MOI + "ban-moi.json", 64 * 1024, 15))
    except Exception as loi:  # noqa: BLE001 - không có mạng thì lần sau xem lại
        print(f"Chưa xem được bản mới: {type(loi).__name__}: {loi}", flush=True)
        m = None
    BAN_MOI.clear()
    if co_nen_bao(m):
        BAN_MOI.update(phien_ban=m["phien_ban"], so_ban=m["so_ban"], ten=f"v{m['so_ban']}",
                       ngay=str(m.get("ngay") or "")[:20],
                       ghi_chu=str(m.get("ghi_chu") or "")[:500])
    return m


async def vong_xem_ban_moi() -> None:
    while True:
        m = await xem_ban_moi()
        # Chưa xem được (máy vừa mở chưa vào mạng, Wi-Fi còn chờ đăng nhập) thì 30 phút sau
        # xem lại, không đợi hết 6 giờ
        await asyncio.sleep(NHIP_XEM_BAN_MOI if m else 30 * 60)


def bat_vong_ban_moi() -> None:
    """Bật việc xem bản mới một lần, lúc giao diện hỏi tình trạng máy lần đầu."""
    if KHO_BAN_MOI and XEM_BAN_MOI["task"] is None:
        XEM_BAN_MOI["task"] = asyncio.create_task(vong_xem_ban_moi())


@app.post("/may/cap-nhat-tu-mang")
async def cap_nhat_tu_mang(request: Request, x_bang_dieu_khien: str | None = Header(None)):
    """Nút Cập nhật ở dòng báo bản mới: tải tệp cài của máy này từ kho, kiểm cỡ và mã
    sha256 ghi trong ban-moi.json, rồi cài như nút Cập nhật bản mới."""
    _chan(request, x_bang_dieu_khien)
    if dang_ban():
        raise HTTPException(status_code=409, detail="Đang ghi âm hoặc đang soạn biên bản. "
                            "Chờ xong rồi hãy cập nhật.")
    if not KHO_BAN_MOI:
        raise HTTPException(status_code=409, detail="Máy này không xem bản mới qua mạng.")
    m = await xem_ban_moi()
    if not m:
        raise HTTPException(status_code=503, detail="Chưa xem được bản mới. Kiểm tra mạng "
                            "rồi thử lại.")
    if not co_nen_bao(m):
        raise HTTPException(status_code=409, detail="Máy đang chạy bản mới nhất rồi.")
    goi = m["windows" if LA_WINDOWS else "mac"]
    try:
        du_lieu = await tai_ve(KHO_BAN_MOI + "ban-cai/" + goi["tep"], goi["co"], 300)
    except Exception as loi:  # noqa: BLE001 - báo chung chung, nguyên văn vào nhật ký
        # Không dùng ly_do_loi: câu của nó viết cho dịch vụ xử lý (403 thành "đăng nhập
        # Google hết hạn"), đặt vào đây thì sai
        print(f"Tải bản mới hỏng: {type(loi).__name__}: {loi}", flush=True)
        ly_do = str(loi) if isinstance(loi, LoiRo) else "kiểm tra mạng"
        raise HTTPException(status_code=503, detail=f"Chưa tải được bản mới ({ly_do}). "
                            "Thử lại sau.") from None
    if len(du_lieu) != goi["co"] or hashlib.sha256(du_lieu).hexdigest() != goi["sha256"]:
        raise HTTPException(status_code=400, detail="Tệp tải về không khớp mã kiểm tra nên "
                            "không cài. Thử lại sau.")
    return await _cai_goi(du_lieu, phai_la=m["phien_ban"], so_phai_la=m["so_ban"])


# ----------------------------------------------------------------------------
# Giao diện
# ----------------------------------------------------------------------------

app.mount("/tai-nguyen", StaticFiles(directory=THU_MUC_GOC / "tai_nguyen"), name="tai-nguyen")


@app.get("/")
async def trang_chu(request: Request):
    chi_tu_may_nay(request)
    return FileResponse(THU_MUC_GOC / "giao_dien.html",
                        headers={"Cache-Control": "no-store"})


if __name__ == "__main__":
    import uvicorn

    so = nap_lai_lich_su()
    print(f"Mở trên máy này: http://127.0.0.1:{CONG}")
    print(f"Các cuộc họp lưu ở: {THU_MUC_LUU}" + (f" ({so} cuộc họp)" if so else ""))
    uvicorn.run(app, host="127.0.0.1", port=CONG)
