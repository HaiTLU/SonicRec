#!/usr/bin/env python3
"""Bộ kiểm thử thường trực cho máy chủ biên bản họp và phần xuất Word.

Chạy trên máy Mac hoặc Windows sau khi cài, không cần Ollama hay micro thật, và
không gọi Google thật (phần ghi âm dùng nguồn âm giả của ffmpeg; máy chưa có
ffmpeg thì bỏ qua phần đó). Trình cài tự chạy tệp này; chạy tay thì:

    cd ~/bien-ban-hop && .venv/bin/python kiem_thu.py
    (Windows: cd %USERPROFILE%\\bien-ban-hop  rồi  .venv\\Scripts\\python -X utf8 kiem_thu.py)

Mọi thứ chạy trong một thư mục tạm, không đụng tới các cuộc họp thật.
Phần Word đọc ngược tệp vừa dựng và đối chiếu từng số với mẫu của Văn phòng
Trường, để định dạng không trôi dần qua các lần sửa mã.
"""

import asyncio
import contextlib
import hashlib
import http.server
import io
import json
import os
import re
import struct
import sys
import tempfile
import threading
import time
import types
import unicodedata
from types import SimpleNamespace
import warnings
import zipfile
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

warnings.filterwarnings("ignore")  # tiếng ồn của thư viện, không liên quan

THU_MUC = Path(__file__).resolve().parent
TAM = Path(tempfile.mkdtemp(prefix="kiem-thu-bien-ban-"))
# NOTEBOOKLM_HOME trỏ vào thư mục tạm: bộ kiểm thử không bao giờ đọc phiên đăng
# nhập NotebookLM thật trên máy, và không gọi Google thật (xem NotebookLM giả ở đầu tệp).
# KHO_BAN_MOI rỗng: không xem bản mới trên kho GitHub thật (mục H dựng kho giả trên máy)
os.environ.update(THU_MUC_LUU=str(TAM / "cac-cuoc-hop"), NOTEBOOKLM_HOME=str(TAM / "nlm"),
                  KHO_BAN_MOI="")
os.environ.pop("GHI_AM_NGUON", None)
sys.path.insert(0, str(THU_MUC))

import bien_ban_hop as bbh  # noqa: E402
import ghi_am  # noqa: E402
import kich_hoat  # noqa: E402
import tao_ung_dung  # noqa: E402
import tao_word  # noqa: E402

# Khoá kích hoạt: bộ kiểm thử KHÔNG BAO GIỜ đọc hay ghi mã kích hoạt thật của máy (tệp
# kich-hoat.json cạnh mã) hay chìa khoá cấp mã thật của người phát hành
# (~/.bien-ban-hop-cap-ma). Các mục khác chạy như chưa bật khoá; mục N bật khoá bằng
# một cặp chìa khoá thử.
KHOA_THAT = kich_hoat.KHOA_CONG_KHAI
kich_hoat.TEP_KICH_HOAT = TAM / "kich-hoat.json"
kich_hoat.THU_MUC_CHIA_KHOA = TAM / "cap-ma"
kich_hoat.KHOA_CONG_KHAI = ()
from docx import Document  # noqa: E402
from docx.oxml.ns import qn  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

DAT = []
TRUOT = []


def kiem(ten: str, dieu_kien: bool, ghi_chu: str = "") -> None:
    (DAT if dieu_kien else TRUOT).append(ten)
    print(f"  [{'DAT ' if dieu_kien else 'TRUOT'}] {ten}" + (f": {ghi_chu}" if ghi_chu else ""))


# ----------------------------------------------------------------------------
# Thay các bước nặng bằng bản giả: không gọi Google thật, không gọi Ollama thật
# ----------------------------------------------------------------------------

BAN_NHAP = [None]  # None nghĩa là không có Ollama, máy trả khung biên bản


async def ollama_gia(ban_go_chu, tt):
    return BAN_NHAP[0]


bbh.soan_bang_ollama = ollama_gia
DO_DAI_THAT, THOI_DIEM_THAT = bbh.do_dai_ban_ghi, bbh.thoi_diem_bat_dau  # kiểm riêng ở mục F
bbh.do_dai_ban_ghi = lambda d: 3480.0  # 58 phút
bbh.thoi_diem_bat_dau = lambda d: datetime(2026, 9, 28, 8, 30)
bbh.KHI_TAT = lambda: None  # nút Tắt ứng dụng không được tắt bộ kiểm thử

CHU_GOOGLE = "Mời chị Lan báo cáo tuyển sinh. Khoá MOS có 32 học viên, hạn nộp hồ sơ 30/9."
TRA_LOI_GOOGLE = """## 2. NỘI DUNG
Chị Lan báo cáo khoá MOS có 32 học viên [1]. Hạn nộp hồ sơ ngày 30/9 [2, 3].
## 3. PHÂN CÔNG
| Việc | Người phụ trách | Hạn hoàn thành |
|---|---|---|
| Hoàn thiện hồ sơ khoá MOS | Chị Lan | 30/9 [4-6] |
"""


class NlmGia:
    """NotebookLM giả: ghi lại từng lời gọi; hỏng hoặc treo ở bước được chỉ định.
    `nguon` là các trạng thái Google lần lượt trả lời khi máy hỏi đã chép lời xong
    chưa ("xong", "dang", "loi"); hết danh sách thì lặp lại trạng thái cuối."""

    def __init__(self, hong=(), treo=(), so_da_xoa=(), nguon=("xong",), nguon_da_xoa=()):
        self.goi, self.hong, self.treo, self.so_da_xoa = [], set(hong), set(treo), set(so_da_xoa)
        self.nguon, self.nguon_da_xoa = list(nguon), set(nguon_da_xoa)
        self.notebooks = SimpleNamespace(create=self._tao, get_or_none=self._tim,
                                         list=self._ds, delete=self._xoa)
        self.sources = SimpleNamespace(add_file=self._them_tep, add_text=self._them_chu,
                                       get_or_none=self._cho, get_fulltext=self._chu,
                                       delete=self._xoa_nguon)
        self.chat = SimpleNamespace(ask=self._hoi)

    async def __aenter__(self):
        return self

    async def __aexit__(self, *loi):
        return False

    async def _buoc(self, ten, *doi_so):
        self.goi.append((ten,) + doi_so)
        if ten in self.treo:
            await asyncio.sleep(3600)
        if ten in self.hong:
            raise RuntimeError(f"{ten} hỏng giả lập")

    async def _tao(self, tieu_de):
        await self._buoc("tao", tieu_de)
        return SimpleNamespace(id="so1", title=tieu_de)

    async def _tim(self, so_id):
        await self._buoc("tim", so_id)
        return None if so_id in self.so_da_xoa else SimpleNamespace(id=so_id)

    async def _ds(self):
        await self._buoc("ds")
        return [1, 2, 3]

    async def _xoa(self, so_id):
        await self._buoc("xoa", so_id)

    async def _them_tep(self, so_id, tep, loai=None, **_):
        await self._buoc("them_tep", Path(tep).suffix, loai)
        return SimpleNamespace(id="nguon1")

    async def _them_chu(self, so_id, ten, chu, **_):
        await self._buoc("them_chu", chu[:20])
        return SimpleNamespace(id="nguon2")

    async def _cho(self, so_id, nguon_id):
        await self._buoc("cho", nguon_id)
        if nguon_id in self.nguon_da_xoa:
            return None
        tt = self.nguon.pop(0) if len(self.nguon) > 1 else self.nguon[0]
        return SimpleNamespace(is_ready=tt == "xong", is_error=tt == "loi")

    async def _xoa_nguon(self, so_id, nguon_id):
        await self._buoc("xoa_nguon", nguon_id)

    async def _chu(self, so_id, nguon_id):
        await self._buoc("chu", nguon_id)
        return SimpleNamespace(content=CHU_GOOGLE, rendered_content=CHU_GOOGLE)

    async def _hoi(self, so_id, cau_hoi, source_ids=None):
        await self._buoc("hoi", tuple(source_ids or ()))
        return SimpleNamespace(answer=TRA_LOI_GOOGLE)


def ten_goi(nlm):
    return [x[0] for x in nlm.goi]


# NotebookLM: mặc định đã đăng nhập và dùng NotebookLM giả ở trên
DA_DANG_NHAP_THAT, LENH_DANG_NHAP_THAT = bbh.da_dang_nhap_nlm, bbh.lenh_dang_nhap_nlm
KET_NOI_THAT = bbh.ket_noi_nlm  # mục P kiểm hồ sơ mà kết nối thật chọn
DA_DANG_NHAP = [True]
NLM = [NlmGia()]
# Tài khoản dự phòng (v1.3): mục P thêm tài khoản, đặt đã đăng nhập chưa và NotebookLM giả riêng
# cho từng tài khoản. Các mục trước không có tài khoản dự phòng nên không đụng tới hai bảng này.
DA_DANG_NHAP_TK, NLM_TK, KET_NOI_LOG = {}, {}, []
bbh.da_dang_nhap_nlm = lambda ma=None: (DA_DANG_NHAP[0] if not ma or ma == "chinh"
                                        else DA_DANG_NHAP_TK.get(ma, False))


def ket_noi_gia(ma=None):
    KET_NOI_LOG.append(ma or "chinh")
    return NLM[0] if not ma or ma == "chinh" else NLM_TK[ma]


bbh.ket_noi_nlm = ket_noi_gia
bbh.TEP_DANG_NHAP = TAM / "nhat-ky-dang-nhap-notebooklm.txt"  # không ghi vào thư mục mã
bbh.TEP_LUOT = TAM / "luot-hoi-notebooklm.json"
bbh.TEP_TAI_KHOAN = TAM / "tai-khoan-google.json"
# Các cuộc họp thử đều cùng tên nên máy sẽ tự chọn biên bản buổi trước và đưa lên sổ.
# Tắt ở các mục trước; mục K thử riêng phần này.
BIEN_BAN_DA_CHON_THAT = bbh.bien_ban_da_chon
bbh.bien_ban_da_chon = lambda tep=None: ""

# Thông tin họp cố định riêng cho kiểm thử, không đụng tệp thật.
bbh.TEP_MAC_DINH = TAM / "thong_tin_cuoc_hop.json"
bbh.TEP_MAC_DINH.write_text(bbh.json.dumps({
    "_ghi_chu_1": "dòng ghi chú phải còn sau khi lưu",
    "ten_cuoc_hop": "Họp giao ban tuần Trung tâm", "thoi_gian": "", "dia_diem": "Phòng họp",
    "chu_tri": "Nguyễn Nam Hải", "thu_ky": "Trần Thị B",
    "tham_du": "Nguyễn Nam Hải\nTrần Thị B", "cach_go_chu": "notebooklm"},
    ensure_ascii=False), encoding="utf-8")

NUT = {"x-bang-dieu-khien": "1"}
GOC = "http://127.0.0.1:8787"  # máy chủ chỉ nhận tên máy là chính máy này


def gui(c, noi_dung=b"am-thanh-gia"):
    """Kéo thả tệp ghi âm vào cửa sổ, rồi chờ xử lý xong."""
    dap = c.post("/may/tai-len", headers=NUT,
                 files={"ghi_am": ("ghiam.m4a", noi_dung, "audio/mp4")})
    if dap.status_code == 200:
        cho_xong(dap.json()["ma"])
    return dap


def viec_cuoi():
    return bbh.VIEC[bbh.THU_TU[-1]]


def cho_xong(ma: str, giay: float = 10) -> str:
    """Việc chạy nền trong vòng lặp của TestClient; chờ tới khi có kết quả."""
    het = time.monotonic() + giay
    while time.monotonic() < het:
        viec = bbh.VIEC[ma]
        # Chờ cả việc chạy nền kết thúc: nó ghi tệp xuống ổ SAU khi đặt trạng thái
        if viec["trang_thai"] in ("Xong", "Lỗi") and (
                not viec.get("task") or viec["task"].done()):
            break
        time.sleep(0.05)
    return bbh.VIEC[ma]["trang_thai"]


def cho_den(dieu_kien, giay: float = 15) -> bool:
    het = time.monotonic() + giay
    while time.monotonic() < het:
        if dieu_kien():
            return True
        time.sleep(0.1)
    return bool(dieu_kien())


# ----------------------------------------------------------------------------
print("\nA. Lưu dữ liệu, giữ bản ghi, nạp lại")
# ----------------------------------------------------------------------------

with TestClient(bbh.app, base_url=GOC, client=("127.0.0.1", 50000)) as c:
    dap = gui(c)
    kiem("gửi bản ghi thì xử lý xong", dap.status_code == 200 and
         viec_cuoi()["trang_thai"] == "Xong", f"{dap.status_code} {dap.text[:80]}")
    v = viec_cuoi()
    tm = Path(v["thu_muc"])
    kiem("thư mục cuộc họp nằm trong THU_MUC_LUU", tm.parent == bbh.THU_MUC_LUU)
    kiem("bản ghi KHÔNG bị xoá sau khi xử lý", (tm / "ghi-am.m4a").is_file())
    kiem("có bản chép lời trên ổ đĩa", (tm / "ban-chep-loi.txt").is_file())
    kiem("có biên bản dạng chữ trên ổ đĩa", (tm / "bien-ban.txt").is_file())
    kiem("có viec.json", (tm / "viec.json").is_file())
    kiem("tệp Word đặt tên đúng quy ước",
         v.get("tep_word") == "260928_TTC_BienBan_GiaoBanTuan.docx", str(v.get("tep_word")))
    kiem("tệp Word có thật trên ổ đĩa", (tm / (v.get("tep_word") or "?")).is_file())
    kiem("giờ bắt đầu lấy từ tệp, kèm dấu cần kiểm tra",
         v["tt"]["thoi_gian"] == "8 giờ 30 phút [cần kiểm tra], ngày 28 tháng 9 năm 2026",
         v["tt"]["thoi_gian"])
    kiem("NotebookLM chép lời và soạn trọn thì không có cảnh báo",
         v["cach"] == "notebooklm" and not v.get("canh_bao"), str(v.get("canh_bao")))
    ma_xong = v["ma"]

    # Nạp lại như lúc bật máy chủ lần sau
    bbh.VIEC.clear()
    bbh.THU_TU.clear()
    so = bbh.nap_lai_lich_su()
    kiem("bật lại máy chủ thì nạp lại được cuộc họp", so == 1 and ma_xong in bbh.VIEC)
    v2 = bbh.VIEC.get(ma_xong, {})
    kiem("nạp lại có đủ biên bản và bản chép lời",
         bool(v2.get("ket_qua")) and "MOS" in (v2.get("ban_go_chu") or ""))
    dap = c.get(f"/may/viec/{ma_xong}")
    kiem("mở lại ứng dụng vẫn xem được biên bản cũ",
         dap.status_code == 200 and "32 học viên" in (dap.json().get("ket_qua") or ""))
    kiem("bản xem nhanh dùng chung bộ tách của tệp Word",
         isinstance(dap.json().get("khoi"), list)
         and any(k[0] == "bang" for k in dap.json()["khoi"]))

    # Việc đang chạy dở lúc máy chủ tắt
    tm_do = bbh.THU_MUC_LUU / "2026-09-28_0900_dangdo01"
    tm_do.mkdir(parents=True)
    (tm_do / "ghi-am.m4a").write_bytes(b"am-thanh-gia")
    bbh._ghi_an_toan(tm_do / "viec.json", bbh.json.dumps({
        "ma": "dangdo01", "trang_thai": "Bước 1/2: đang chép lời", "tt": v2["tt"],
        "tep_ghi_am": "ghi-am.m4a", "nhan_luc": "2026-09-28T09:00:00"}))
    bbh.VIEC.clear()
    bbh.THU_TU.clear()
    bbh.nap_lai_lich_su()
    vd = bbh.VIEC.get("dangdo01", {})
    kiem("việc dở dang được đánh dấu Bị gián đoạn", vd.get("trang_thai") == "Bị gián đoạn")
    kiem("trạng thái Bị gián đoạn đã ghi xuống ổ đĩa",
         "Bị gián đoạn" in (tm_do / "viec.json").read_text(encoding="utf-8"))

    # Hai cuộc họp bắt đầu cùng một phút: tên thư mục chỉ tới phút, phần sau là mã ngẫu nhiên.
    # Nạp lại phải xếp theo giây bắt đầu, không theo mã (biên bản buổi trước mới nhất)
    for ma_t, giay_t in (("zzzz0001", "05"), ("aaaa0002", "40")):
        tm_t = bbh.THU_MUC_LUU / f"2026-09-28_1000_{ma_t}"
        tm_t.mkdir()
        bbh._ghi_an_toan(tm_t / "viec.json", bbh.json.dumps({
            "ma": ma_t, "trang_thai": "Lỗi", "tt": v2["tt"], "tep_ghi_am": None,
            "bat_dau": f"2026-09-28T10:00:{giay_t}", "nhan_luc": f"2026-09-28T10:00:{giay_t}"}))
    bbh.VIEC.clear()
    bbh.THU_TU.clear()
    bbh.nap_lai_lich_su()
    kiem("nạp lại: hai cuộc họp bắt đầu cùng một phút xếp theo giây, không theo mã trong tên "
         "thư mục", bbh.THU_TU.index("zzzz0001") < bbh.THU_TU.index("aaaa0002"), str(bbh.THU_TU))
    for ma_t in ("zzzz0001", "aaaa0002"):
        bbh.shutil.rmtree(bbh.THU_MUC_LUU / f"2026-09-28_1000_{ma_t}")
        bbh.VIEC.pop(ma_t, None)
        bbh.THU_TU.remove(ma_t)

    # ------------------------------------------------------------------------
    print("\nB. Hỏng thì giữ bản ghi, Làm lại, Đã ký")
    # ------------------------------------------------------------------------
    NLM[0] = NlmGia(hong={"them_tep"})
    gui(c)
    vh = viec_cuoi()
    kiem("gửi lên NotebookLM hỏng thì báo Lỗi", vh["trang_thai"] == "Lỗi", vh.get("loi") or "")
    kiem("gửi lên NotebookLM hỏng vẫn GIỮ bản ghi",
         (Path(vh["thu_muc"]) / "ghi-am.m4a").is_file())

    dap = c.post(f"/may/viec/{vh['ma']}/lam-lai")
    kiem("Làm lại thiếu tiêu đề bảng điều khiển thì bị chặn", dap.status_code == 403)
    dap = c.post(f"/may/viec/{vh['ma']}/lam-lai", headers=NUT)
    kiem("Làm lại được chấp nhận", dap.status_code == 200, dap.text[:80])
    kiem("Làm lại khi vẫn hỏng thì báo Lỗi lần nữa, không treo",
         cho_xong(vh["ma"]) == "Lỗi")
    NLM[0] = NlmGia()
    c.post(f"/may/viec/{vh['ma']}/lam-lai", headers=NUT)
    kiem("Làm lại sau khi hết hỏng thì Xong", cho_xong(vh["ma"]) == "Xong")

    dap = c.post(f"/may/viec/{vh['ma']}/lam-lai", headers=NUT)
    kiem("không cho Làm lại việc đã Xong", dap.status_code == 409)

    # Hỏng ở bước soạn: bản chép lời đã lưu thì Làm lại không chép lời lần nữa
    v3 = bbh.VIEC[vh["ma"]]
    v3["trang_thai"] = "Lỗi"
    NLM[0] = g = NlmGia()
    c.post(f"/may/viec/{vh['ma']}/lam-lai", headers=NUT)
    kiem("Làm lại dùng lại bản chép lời đã lưu, không tải lên và chép lời lại",
         cho_xong(vh["ma"]) == "Xong" and "them_tep" not in ten_goi(g)
         and "chu" not in ten_goi(g), str(ten_goi(g)))

    # Đã ký
    tm_xong = Path(bbh.VIEC[ma_xong]["thu_muc"])
    dap = c.post(f"/may/viec/{ma_xong}/da-ky")
    kiem("Đã ký thiếu tiêu đề bảng điều khiển thì bị chặn", dap.status_code == 403)
    dap = c.post(f"/may/viec/{ma_xong}/da-ky", headers=NUT)
    kiem("Đã ký được chấp nhận", dap.status_code == 200)
    kiem("Đã ký thì xoá bản ghi", not (tm_xong / "ghi-am.m4a").exists())
    kiem("Đã ký vẫn giữ biên bản, bản chép lời, tệp Word",
         all((tm_xong / f).is_file() for f in
             ("bien-ban.txt", "ban-chep-loi.txt", bbh.VIEC[ma_xong]["tep_word"])))
    kiem("trạng thái đã ký ghi xuống ổ đĩa",
         '"da_ky": true' in (tm_xong / "viec.json").read_text(encoding="utf-8"))
    dap = c.post(f"/may/viec/{ma_xong}/lam-lai", headers=NUT)
    kiem("đã xoá bản ghi thì không Làm lại được", dap.status_code == 409)

    # Mở tệp: gọi ứng dụng mặc định của máy đúng tệp Word
    goi = []
    that_mo = bbh.mo_bang_he_thong
    bbh.mo_bang_he_thong = goi.append
    dap = c.post(f"/may/viec/{ma_xong}/mo?cai=word", headers=NUT)
    bbh.mo_bang_he_thong = that_mo
    kiem("nút Mở Word mở đúng tệp", dap.status_code == 200 and goi and goi[0].endswith(".docx"))
    # Trên Mac lệnh mở là open (Windows kiểm ở mục G)
    goi = []
    that_popen, that_which, that_win = bbh.subprocess.Popen, bbh.shutil.which, bbh.LA_WINDOWS
    bbh.subprocess.Popen = lambda lenh: goi.append(lenh)
    bbh.shutil.which = lambda ten: "/usr/bin/open" if ten == "open" else that_which(ten)
    bbh.LA_WINDOWS = False
    bbh.mo_bang_he_thong("/tmp/a.docx")
    bbh.subprocess.Popen, bbh.shutil.which, bbh.LA_WINDOWS = that_popen, that_which, that_win
    kiem("trên Mac mở tệp bằng lệnh open", goi == [["open", "/tmp/a.docx"]], str(goi))

    # Bảng điều khiển chỉ mở từ laptop
    with TestClient(bbh.app, base_url=GOC, client=("192.168.1.20", 50000)) as la:
        kiem("máy lạ trong wifi không bấm được nút xoá",
             la.post(f"/may/viec/{vh['ma']}/da-ky", headers=NUT).status_code == 403)

    tt_may = c.get("/may/trang-thai").json()
    kiem("tình trạng máy có dấu phiên bản 7 ký tự để biết máy chạy bản nào",
         len(tt_may.get("phien_ban") or "") == 7 and tt_may["phien_ban"] == bbh.dau_phien_ban())
    kiem("tình trạng máy có số phiên bản (1, 1.1, 2...) và tên bản v<số> (PM chốt 30/9/2026), số "
         "đọc lại được từ chính tệp mã như ứng dụng đọc một gói",
         type(tt_may.get("so_ban")) is str and re.fullmatch(bbh.MAU_SO_BAN, tt_may["so_ban"]) is not None
         and tt_may.get("ten_ban") == f"v{tt_may['so_ban']}"
         and bbh.so_ban_cua(lambda t: (THU_MUC / t).read_bytes()) == tt_may["so_ban"], str(tt_may)[:120])
    mot = next((x for x in tt_may["viec"] if x["ma"] == ma_xong), {})
    kiem("danh sách có tên, giờ, tình trạng tệp Word và bản ghi",
         mot.get("ten") == "Họp giao ban tuần Trung tâm" and mot.get("luc") == "08:30 28/09/2026"
         and mot.get("co_word") is True and mot.get("con_ghi_am") is False
         and mot.get("da_ky") is True, str(mot)[:120])

    # Tệp quá lớn thì không để lại thư mục rác
    that_gioi_han = bbh.GIOI_HAN_BYTE
    bbh.GIOI_HAN_BYTE = 5
    so_thu_muc = len(list(bbh.THU_MUC_LUU.iterdir()))
    dap = gui(c, b"qua-nam-byte")
    bbh.GIOI_HAN_BYTE = that_gioi_han
    kiem("tệp quá lớn bị từ chối và không để lại thư mục",
         dap.status_code == 413 and len(list(bbh.THU_MUC_LUU.iterdir())) == so_thu_muc)

    # Thiếu python-docx: vẫn Xong, chỉ cảnh báo
    sys.modules["tao_word"] = None
    gui(c)
    sys.modules["tao_word"] = tao_word
    vw = viec_cuoi()
    kiem("thiếu python-docx thì vẫn Xong và nói rõ cách cài",
         vw["trang_thai"] == "Xong" and "python-docx" in (vw.get("canh_bao") or "")
         and not vw.get("tep_word"))


# ----------------------------------------------------------------------------
print("\nC. Tệp Word đúng mẫu Văn phòng Trường")
# ----------------------------------------------------------------------------

W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
BAN_NHAP_MO_HINH = """# BIÊN BẢN HỌP GIAO BAN
**Thời gian:** 8 giờ 30 phút
1. THÀNH PHẦN THAM DỰ
- Chủ trì: Nguyễn Nam Hải
2. NỘI DUNG
[chưa rõ ai nói] đề nghị bổ sung buổi thực hành, **gửi Ban Giám hiệu**.
[00:12] Mốc giờ này phải là chữ thường.
3. PHÂN CÔNG
| Việc | Người phụ trách | Hạn hoàn thành |
|---|---|---|
| Bổ sung buổi thực hành khoá Marketing số cho học viên | Lê Văn C | 02/10/2026 |
THƯ KÝ                              CHỦ TRÌ
(Ký, ghi rõ họ tên)                 (Ký, ghi rõ họ tên)
"""
tt = {"ten_cuoc_hop": "Họp giao ban tuần Trung tâm", "thoi_gian": "8 giờ 30 phút",
      "dia_diem": "Phòng họp", "chu_tri": "Nguyễn Nam Hải", "thu_ky": "Trần Thị B",
      "tham_du": "Nguyễn Nam Hải\nTrần Thị B"}
duong = TAM / "mau.docx"
tao_word.dung_bien_ban(BAN_NHAP_MO_HINH, tt, date(2026, 9, 28), "9 giờ 28 phút", duong)
doc = Document(duong)
s = doc.sections[0]
tw = lambda length: round(length.twips) if length is not None else None  # noqa: E731

kiem("khổ A4", (tw(s.page_width), tw(s.page_height)) == (11906, 16838))
kiem("lề trái 3cm, phải 1,5cm (851 twip), trên dưới 2cm",
     (tw(s.left_margin), tw(s.right_margin), tw(s.top_margin), tw(s.bottom_margin))
     == (1701, 851, 1134, 1134))
goc = doc.styles["Normal"].font
kiem("kiểu gốc Times New Roman 14pt chữ đen",
     goc.name == "Times New Roman" and goc.size.pt == 14 and str(goc.color.rgb) == "000000")

dau = doc.tables[0]._tbl
tblPr = dau.tblPr
kiem("bảng đầu văn bản rộng 10490, thụt âm 743",
     tblPr.find(W + "tblW").get(W + "w") == "10490"
     and tblPr.find(W + "tblInd").get(W + "w") == "-743")
kiem("bảng đầu văn bản bốn cột 8 / 0,5 / 9,75 / 0,25 cm",
     [g.get(W + "w") for g in dau.tblGrid.findall(W + "gridCol")]
     == [str(tao_word.cm(x)) for x in (8, 0.5, 9.75, 0.25)])
le = tblPr.find(W + "tblCellMar")
kiem("bảng đầu văn bản lề ô bằng 0 (cho quốc hiệu vừa một dòng)",
     le is not None and le.find(W + "left").get(W + "w") == "0"
     and le.find(W + "right").get(W + "w") == "0")

ke = [p for p in doc.element.body.iter(W + "p") if p.find(f"{W}pPr/{W}pBdr") is not None]
kiem("đủ ba đường kẻ", len(ke) == 3, str(len(ke)))
dai = []
for p in ke:
    ind = p.find(f"{W}pPr/{W}ind")
    dai.append(int(ind.get(W + "left")))
kiem("ba đường kẻ dài 2,78 / 5,95 / 4,5 cm",
     dai == [round((tao_word.COT_DAU[0] - tao_word.KE_DUOI_CO_QUAN) / 2),
             round((tao_word.COT_DAU[2] - tao_word.KE_DUOI_TIEU_NGU) / 2),
             round((tao_word.BE_NGANG_CHU - tao_word.KE_DUOI_TRICH_YEU) / 2)], str(dai))
kiem("đường kẻ dày 0,75pt",
     all(p.find(f"{W}pPr/{W}pBdr/{W}bottom").get(W + "sz") == "6" for p in ke))

chu_toan_bo = "\n".join(p.text for p in doc.paragraphs) + "\n" + "\n".join(
    c.text for t in doc.tables for r in t.rows for c in r.cells)
kiem("đầu văn bản đúng chữ",
     all(x in chu_toan_bo for x in ("TRƯỜNG ĐẠI HỌC THĂNG LONG", "CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM",
                                    "Độc lập - Tự do - Hạnh phúc", "Số:", "/BB-TTC",
                                    "Hà Nội, ngày 28 tháng 9 năm 2026")))
kiem("khung lấy từ thông tin họp, không lặp của mô hình",
     chu_toan_bo.count("Thời gian:") == 1 and chu_toan_bo.count("Chủ trì:") == 1)
kiem("mục THÀNH PHẦN của mô hình bị bỏ, các mục đánh số lại",
     "1. NỘI DUNG" in chu_toan_bo and "2. PHÂN CÔNG" in chu_toan_bo
     and "THÀNH PHẦN THAM DỰ" not in chu_toan_bo.upper().replace("THÀNH PHẦN THAM DỰ:", ""))
kiem("khối chữ ký của mô hình bị bỏ, chỉ còn khối của khung",
     chu_toan_bo.count("(Ký, ghi rõ họ tên)") == 2)
kiem("câu kết có giờ kết thúc", "Biên bản kết thúc vào 9 giờ 28 phút cùng ngày." in chu_toan_bo)
kiem("không có gạch dài hay gạch en", "—" not in chu_toan_bo and "–" not in chu_toan_bo)

than = [p for p in doc.paragraphs if p.text.startswith("Địa điểm:")][0]
pf = than.paragraph_format
kiem("thân bài giãn dòng 1,2, cách 3pt, thụt đầu dòng 1,25cm",
     round(pf.line_spacing, 2) == 1.2 and pf.space_before.pt == 3 and pf.space_after.pt == 3
     and tw(pf.first_line_indent) == tao_word.THUT_DAU_DONG)
kiem("thân bài căn đều hai bên", pf.alignment == 3)  # WD_ALIGN_PARAGRAPH.JUSTIFY

cac_run = [r for p in doc.paragraphs for r in p.runs]
dd = [r for r in cac_run if r.text.startswith("[chưa rõ")]
kiem("dấu [chưa rõ ai nói] in đậm nghiêng", bool(dd) and dd[0].bold and dd[0].italic)
mg = [r for p in doc.paragraphs if p.text.startswith("[00:12]") for r in p.runs]
kiem("mốc giờ [00:12] là chữ thường", bool(mg) and not any(r.bold or r.italic for r in mg))
kiem("chữ **...** thành chữ đậm",
     any(r.text == "gửi Ban Giám hiệu" and r.bold for r in cac_run))

bang_pc = doc.tables[1]
kiem("bảng Phân công đủ đầu bảng và dòng việc",
     len(bang_pc.rows) == 2 and bang_pc.cell(0, 0).text == "Việc")
kiem("đầu bảng in đậm, căn giữa",
     all(r.bold for r in bang_pc.cell(0, 1).paragraphs[0].runs)
     and bang_pc.cell(0, 1).paragraphs[0].alignment == 1)
kiem("ô chữ dài quá 30 ký tự căn trái, ô ngắn căn giữa",
     bang_pc.cell(1, 0).paragraphs[0].alignment == 0
     and bang_pc.cell(1, 1).paragraphs[0].alignment == 1)
vien = bang_pc._tbl.tblPr.find(W + "tblBorders")
kiem("bảng viền mảnh 0,5pt đen",
     all(vien.find(W + x).get(W + "sz") == "4" and vien.find(W + x).get(W + "color") == "000000"
         for x in ("top", "bottom", "left", "right", "insideH", "insideV")))
kiem("mọi ô bảng căn giữa theo chiều dọc",
     all(c.vertical_alignment == 1 for r in bang_pc.rows for c in r.cells))

with zipfile.ZipFile(duong) as z:
    xml = z.read("word/document.xml").decode("utf-8")
    dau_trang = "".join(z.read(n).decode("utf-8") for n in z.namelist()
                        if n.startswith("word/header"))
mau = set(re.findall(r'w:color w:val="([0-9A-Fa-f]{6}|auto)"', xml))
kiem("chữ chỉ có màu đen", mau <= {"000000"}, str(mau))
kiem("không tô nền ô nào", "<w:shd" not in xml)
kiem("số trang từ trang 2, cỡ 13", "PAGE" in dau_trang and "<w:titlePg" in xml)

# Thẻ con phải đúng thứ tự lược đồ, sai thì Word có thể báo tệp hỏng
sai_thu_tu = []
for cha, thu_tu in (("tblPr", tao_word.THU_TU_TBLPR), ("pPr", tao_word.THU_TU_PPR)):
    for e in doc.element.body.iter(W + cha):
        ten = [x.tag.split("}")[-1] for x in e]
        vi_tri = [thu_tu.index(n) for n in ten if n in thu_tu]
        if vi_tri != sorted(vi_tri):
            sai_thu_tu.append(f"{cha}: {ten}")
kiem("mọi thẻ con đúng thứ tự lược đồ OOXML", not sai_thu_tu, "; ".join(sai_thu_tu[:2]))

kiem("ngày theo Nghị định 30 (thêm số 0 cho ngày dưới 10, tháng 1 và 2)",
     tao_word.ngay_thang_nam(date(2026, 2, 5)) == "ngày 05 tháng 02 năm 2026"
     and tao_word.ngay_thang_nam(date(2026, 9, 28)) == "ngày 28 tháng 9 năm 2026"
     and bbh.ngay_nd30(date(2026, 1, 3)) == tao_word.ngay_thang_nam(date(2026, 1, 3)))

# Khung biên bản của máy chủ (lúc chưa có Ollama) cũng phải dựng được
khung = bbh.khung_bien_ban("[00:00] xin chào", dict(tt, viec_tuan_truoc="", chuong_trinh="1. A"))
khoi = tao_word.tach_than_bai(khung, tt["ten_cuoc_hop"])
bang_khung = [k for k in khoi if k[0] == "bang"]
kiem("khung biên bản giữ dòng trống trong bảng Phân công để thư ký điền",
     bool(bang_khung) and len(bang_khung[0][1]) == 2, str(bang_khung)[:80])
kiem("câu ghi chú của khung nằm trọn một đoạn",
     any(k[1].startswith("Chưa có mô hình") and k[1].endswith("xoá phần này.") for k in khoi))


# (Mục D cũ kiểm Whisper chạy tại máy; bỏ cùng Whisper ngày 26/9/2026.)


# ----------------------------------------------------------------------------
print("\nE. Ghi âm ngay trên máy, hàng rào, thông tin họp, dựng ứng dụng")
# ----------------------------------------------------------------------------

MAU_DS = """[AVFoundation indev @ 0x1] AVFoundation video devices:
[AVFoundation indev @ 0x1] [0] FaceTime HD Camera
[AVFoundation indev @ 0x1] AVFoundation audio devices:
[AVFoundation indev @ 0x1] [0] ZoomAudioDevice
[AVFoundation indev @ 0x1] [1] Micrô MacBook Air
[AVFoundation indev @ 0x1] [2] Tai nghe AirPods"""
ds = ghi_am.doc_danh_sach_micro(MAU_DS)
kiem("đọc đúng danh sách micro, bỏ qua camera",
     ds == [(0, "ZoomAudioDevice"), (1, "Micrô MacBook Air"), (2, "Tai nghe AirPods")], str(ds))
kiem("chưa chọn thì dùng micro gắn trong máy", ghi_am.chon_micro(ds, None) == (1, "Micrô MacBook Air"))
kiem("đã chọn thì theo TÊN, số thứ tự đổi cũng không sao",
     ghi_am.chon_micro(ds, "Tai nghe AirPods") == (2, "Tai nghe AirPods"))
kiem("không chọn nhầm micro ảo của Teams có chữ Micr trong tên",
     ghi_am.chon_micro([(0, "Microsoft Teams Audio"), (1, "ZoomAudioDevice"),
                        (2, "MacBook Air Microphone")], None) == (2, "MacBook Air Microphone"))
kiem("không tự chọn micro của iPhone để gần máy khi có micro của MacBook",
     ghi_am.chon_micro([(0, "Micrô iPhone của H"), (1, "Micrô MacBook Air")], None)
     == (1, "Micrô MacBook Air"))
kiem("chỉ có micro của iPhone thì vẫn dùng được",
     ghi_am.chon_micro([(0, "Micrô iPhone của H")], None) == (0, "Micrô iPhone của H"))
kiem("micro đã chọn bị rút ra thì quay về micro gắn trong",
     ghi_am.chon_micro(ds, "Micro đã rút") == (1, "Micrô MacBook Air"))

# Windows: ffmpeg mới ghi loại thiết bị sau tên, ffmpeg cũ chia mục
WIN_MOI = r"""[dshow @ 0000020b6c3e8d40] "Integrated Camera" (video)
[dshow @ 0000020b6c3e8d40]   Alternative name "@device_pnp_\\?\usb#vid_04f2&pid_b6d9#{65e8773d}\global"
[dshow @ 0000020b6c3e8d40] "Stereo Mix (Realtek(R) Audio)" (audio)
[dshow @ 0000020b6c3e8d40]   Alternative name "@device_cm_{33D9A762-90C8-11D0-BD43-00A0C911CE86}\wave_{A1}"
[dshow @ 0000020b6c3e8d40] "Headset (Jabra Evolve2 65 Hands-Free)" (audio)
[dshow @ 0000020b6c3e8d40]   Alternative name "@device_cm_{33D9A762-90C8-11D0-BD43-00A0C911CE86}\wave_{A2}"
[dshow @ 0000020b6c3e8d40] "Microphone Array (Realtek(R) Audio)" (audio)
[dshow @ 0000020b6c3e8d40]   Alternative name "@device_cm_{33D9A762-90C8-11D0-BD43-00A0C911CE86}\wave_{A3}"
[dshow @ 0000020b6c3e8d40] "Microphone (USB Audio Device)" (audio)
[dshow @ 0000020b6c3e8d40] "OBS Virtual Camera" (none)
[dshow @ 0000020b6c3e8d40]   Alternative name "@device_sw_{860BB310-5D01-11D0-BD3B-00A0C911CE86}\{A3FC}"
dummy: Immediate exit requested"""
ds_win = ghi_am.doc_danh_sach_micro_windows(WIN_MOI)
MA_CM = "@device_cm_{33D9A762-90C8-11D0-BD43-00A0C911CE86}\\wave_"
kiem("Windows: đọc đúng các micro, lấy tên thay thế làm mã, bỏ camera và thiết bị không có tiếng",
     ds_win == [(MA_CM + "{A1}", "Stereo Mix (Realtek(R) Audio)"),
                (MA_CM + "{A2}", "Headset (Jabra Evolve2 65 Hands-Free)"),
                (MA_CM + "{A3}", "Microphone Array (Realtek(R) Audio)"),
                ("Microphone (USB Audio Device)", "Microphone (USB Audio Device)")], str(ds_win))
kiem("Windows: tự chọn micro gắn trong laptop, không chọn Stereo Mix hay tai nghe Bluetooth",
     ghi_am.chon_micro(ds_win, None) == (MA_CM + "{A3}", "Microphone Array (Realtek(R) Audio)"))
WIN_CU = r"""[dshow @ 000001d8] DirectShow video devices (some may be both video and audio devices)
[dshow @ 000001d8]  "Integrated Webcam"
[dshow @ 000001d8]     Alternative name "@device_pnp_\\?\usb#vid_0c45"
[dshow @ 000001d8] DirectShow audio devices
[dshow @ 000001d8]  "Micrô (Realtek High Definition Audio)"
[dshow @ 000001d8]     Alternative name "@device_cm_{33D9A762-90C8-11D0-BD43-00A0C911CE86}\wave_{B1}"
"""
kiem("Windows: đọc được cả dòng in của ffmpeg bản cũ, tên có chữ có dấu",
     ghi_am.doc_danh_sach_micro_windows(WIN_CU)
     == [(MA_CM + "{B1}", "Micrô (Realtek High Definition Audio)")])
that_win_ga, that_run_ga, that_shutil_ga = ghi_am.LA_WINDOWS, ghi_am.subprocess.run, ghi_am.shutil
lenh_goi = []


def run_gia(lenh, **k):
    lenh_goi.append(lenh)
    return types.SimpleNamespace(stderr=WIN_MOI.encode("utf-8"), stdout=b"", returncode=1)


ghi_am.LA_WINDOWS, ghi_am.subprocess.run = True, run_gia
ghi_am.shutil = types.SimpleNamespace(which=lambda ten: "ffmpeg.exe")
ds_goi = ghi_am.cac_micro()
dau_vao = ghi_am._dau_vao(MA_CM + "{A3}")
ghi_am.LA_WINDOWS, ghi_am.subprocess.run, ghi_am.shutil = that_win_ga, that_run_ga, that_shutil_ga
kiem("Windows: liệt kê micro bằng dshow", ds_goi == ds_win
     and lenh_goi and lenh_goi[0][-6:] == ["-list_devices", "true", "-f", "dshow", "-i", "dummy"],
     str(lenh_goi))
kiem("Windows: ghi âm từ micro bằng dshow và mã tên thay thế",
     dau_vao == ["-f", "dshow", "-i", "audio=" + MA_CM + "{A3}"], str(dau_vao))
kiem("đường dẫn nhét vào mã C được thoát ký tự",
     tao_ung_dung.chuoi_c('/Users/a "b"/Hải') == r'"/Users/a \042b\042/H\341\272\243i"')
kiem("Info.plist có lời xin quyền micro, nói đúng bản ghi đi đâu",
     all(x in tao_ung_dung.info_plist(True)["NSMicrophoneUsageDescription"]
         for x in ("Google", "chỉ lưu trên máy"))
     and "NotebookLM" not in tao_ung_dung.info_plist(True)["NSMicrophoneUsageDescription"])

# Trình mở dựng sẵn (28/9/2026): máy người dùng không phải dịch gì, không cần công cụ của
# Apple. Giả thư mục cài với một trình mở giả (tệp lệnh in như trình mở thật khi chạy thử)
# để kiểm cách dựng ứng dụng quanh nó. Windows không chạy được tệp lệnh này, và không dùng.
if os.name != "nt":
    import plistlib  # noqa: E402
    gia_cai = TAM / "cai-gia"
    (gia_cai / ".venv" / "bin").mkdir(parents=True)
    (gia_cai / ".venv" / "bin" / "python").write_text("", encoding="utf-8")
    (gia_cai / "ung_dung.py").write_text("", encoding="utf-8")
    (gia_cai / "tai_nguyen" / "hinh").mkdir(parents=True)
    (gia_cai / "tai_nguyen" / "hinh" / "bieu-tuong.icns").write_bytes(b"icns")

    def trinh_mo_gia(kieu: str, dat: bool = True) -> None:
        san = gia_cai / tao_ung_dung.TEN_SAN
        san.write_text(f"#!/bin/sh\necho KIEU={kieu}\n"
                       + ("echo TU-KIEM-DAT gia\n" if dat else "echo hong >&2\nexit 3\n"), encoding="utf-8")
        san.chmod(0o755)

    def dung_thu(ten: str):
        try:
            app, kieu = tao_ung_dung.dung(TAM / ten)
            return app, kieu, plistlib.loads((app / "Contents" / "Info.plist").read_bytes()), ""
        except SystemExit as loi:
            return None, "", {}, str(loi)

    that_tm, that_ky, that_cc = tao_ung_dung.THU_MUC, tao_ung_dung.ky_ten, tao_ung_dung.co_cong_cu
    goi_dich = []
    that_dich = tao_ung_dung.dich
    tao_ung_dung.THU_MUC, tao_ung_dung.ky_ten = gia_cai, (lambda app: None)
    tao_ung_dung.dich = lambda *a: goi_dich.append(a) or "không được dịch trong phép thử"
    try:
        trinh_mo_gia("nhung")
        # Máy đã cài bản trước 28/9/2026: ứng dụng mang tên cũ Biên bản họp.app
        app_ten_cu = TAM / "Ung dung 1" / tao_ung_dung.TEN_APP_CU / "Contents"
        app_ten_cu.mkdir(parents=True)
        (app_ten_cu / "Info.plist").write_bytes(b"cu")
        app, kieu, ds, loi = dung_thu("Ung dung 1")
        kiem("có trình mở dựng sẵn: dùng đúng nó, không dịch gì; chạy kiểu nhúng thì Dock hiện SonicRec",
             kieu == "dựng sẵn, nhúng" and "LSUIElement" not in ds and not goi_dich
             and (app / "Contents" / "MacOS" / tao_ung_dung.TEN_CHAY).read_bytes()
             == (gia_cai / tao_ung_dung.TEN_SAN).read_bytes(), f"{kieu} {loi} {ds}")
        kiem("đổi tên (28/9/2026): dựng SonicRec.app, tên hiện là SonicRec, xoá ứng dụng tên cũ "
             "Biên bản họp.app để máy không còn hai biểu tượng",
             app is not None and app.name == "SonicRec.app" and ds.get("CFBundleName") == "SonicRec"
             and ds.get("CFBundleDisplayName") == "SonicRec"
             and not app_ten_cu.parent.exists(), f"{app} {ds.get('CFBundleName')}")
        trinh_mo_gia("goi-rieng")
        app, kieu, ds, loi = dung_thu("Ung dung 2")
        kiem("trình mở dựng sẵn không nạp được Python đi kèm (chạy kiểu gọi riêng): ẩn nó khỏi Dock",
             kieu == "dựng sẵn, gọi riêng" and ds.get("LSUIElement") is True, f"{kieu} {loi}")
        trinh_mo_gia("nhung", dat=False)
        tao_ung_dung.co_cong_cu = lambda: False
        app_ten_cu = TAM / "Ung dung 3" / tao_ung_dung.TEN_APP_CU / "Contents"
        app_ten_cu.mkdir(parents=True)
        (app_ten_cu / "Info.plist").write_bytes(b"cu")
        app, kieu, ds, loi = dung_thu("Ung dung 3")
        kiem("trình mở dựng sẵn chạy thử hỏng, máy không có công cụ của Apple: báo rõ, không gọi "
             "trình dịch (gọi là macOS bật hộp thoại đòi cài)",
             app is None and "công cụ dòng lệnh" in loi and "hong" in loi and not goi_dich
             and not (TAM / "Ung dung 3" / tao_ung_dung.TEN_APP).exists(), loi)
        kiem("dựng SonicRec.app hỏng thì giữ nguyên ứng dụng tên cũ, người dùng vẫn mở được như trước",
             (app_ten_cu / "Info.plist").read_bytes() == b"cu")
        tao_ung_dung.co_cong_cu = lambda: True
        app, kieu, ds, loi = dung_thu("Ung dung 4")
        kiem("trình mở dựng sẵn hỏng mà máy có công cụ của Apple: mới dịch lại trên máy như trước",
             len(goi_dich) >= 1 and app is None and "dựng sẵn: hong" in loi, loi)
    finally:
        tao_ung_dung.THU_MUC, tao_ung_dung.ky_ten = that_tm, that_ky
        tao_ung_dung.co_cong_cu, tao_ung_dung.dich = that_cc, that_dich
    kiem("dấu mã nguồn của trình mở đổi khi mã trình mở đổi",
         len(tao_ung_dung.dau_ma_nguon()) == 40 and tao_ung_dung.dau_ma_nguon()
         == hashlib.sha1(tao_ung_dung.MA_C.encode("utf-8")).hexdigest())

# Dock trên Mac: cửa sổ chạy bằng Python riêng thì hiện hình tên lửa và tên "Python" (PM
# gửi ảnh 27/9/2026). Giả thư viện của macOS để thấy ứng dụng đặt lại hình và tên.
import ung_dung  # noqa: E402

hinh_dock, info_gia = [], {"CFBundleName": "Python"}


class ChiDocGia(dict):
    def __setitem__(self, khoa, gia_tri):
        raise TypeError("bảng chỉ đọc")


class HinhGia:
    @staticmethod
    def alloc():
        return HinhGia()

    def initWithContentsOfFile_(self, duong_dan):
        self.duong_dan = duong_dan
        return self


mo_that = {k: sys.modules.get(k) for k in ("Foundation", "AppKit")}
sys.modules["Foundation"] = SimpleNamespace(NSBundle=SimpleNamespace(mainBundle=lambda: SimpleNamespace(
    infoDictionary=lambda: info_gia, localizedInfoDictionary=ChiDocGia)))
sys.modules["AppKit"] = SimpleNamespace(NSImage=HinhGia, NSApplication=SimpleNamespace(
    sharedApplication=lambda: SimpleNamespace(setApplicationIconImage_=hinh_dock.append)))
mac_that, ung_dung.LA_MAC = ung_dung.LA_MAC, True
try:
    ung_dung.dat_ten_ung_dung()
finally:
    ung_dung.LA_MAC = mac_that
    for k, m in mo_that.items():
        if m is None:
            sys.modules.pop(k, None)
        else:
            sys.modules[k] = m
kiem("Mac: cửa sổ chạy bằng Python riêng thì Dock hiện hình SonicRec, thanh trình đơn đúng tên",
     info_gia["CFBundleName"] == "SonicRec" and len(hinh_dock) == 1
     and hinh_dock[0].duong_dan.endswith("bieu-tuong.icns") and Path(hinh_dock[0].duong_dan).is_file(),
     f"{info_gia}; {[getattr(h, 'duong_dan', h) for h in hinh_dock]}")
if os.name != "nt":
    path_cu = os.environ.get("PATH", "")
    ung_dung.them_duong_tim()
    cac_duong = os.environ["PATH"].split(os.pathsep)
    os.environ["PATH"] = path_cu
    kiem("Mac: tìm ffmpeg đi kèm trong thư mục ứng dụng trước, sau đó mới tới Homebrew của máy cài bản cũ",
         cac_duong[:3] == [str(ung_dung.THU_MUC / "ffmpeg"), "/opt/homebrew/bin", "/usr/local/bin"],
         str(cac_duong[:3]))

# Máy Windows của PM (1/10/2026): cài xong không mở được vì ứng dụng đưa PNG làm biểu tượng cửa sổ,
# mà Windows chỉ nhận .ico (System.Drawing.Icon); .NET ném lỗi ở luồng riêng, sập cả ứng dụng
ico_cua_so = ung_dung.bieu_tuong_cua_so("win32")
dau_ico = ico_cua_so.read_bytes()[:6] if ico_cua_so.is_file() else b""
kiem("Windows: biểu tượng cửa sổ là tệp .ico thật (đầu tệp đúng dạng ICO), Mac và Linux vẫn dùng PNG",
     ico_cua_so.suffix == ".ico" and dau_ico[:4] == b"\x00\x00\x01\x00" and dau_ico[4] >= 1
     and ung_dung.bieu_tuong_cua_so("darwin").suffix == ".png" and ung_dung.bieu_tuong_cua_so("linux").suffix == ".png",
     f"{ico_cua_so.name}, đầu tệp {dau_ico.hex()}")

with TestClient(bbh.app, base_url=GOC, client=("127.0.0.1", 50000)) as c:
    kiem("tên máy lạ (tấn công đổi tên miền) bị chặn",
         c.get("/may/trang-thai", headers={"host": "evil.example"}).status_code == 403)
    kiem("trang giao diện mở được, tên ứng dụng là SonicRec",
         c.get("/").status_code == 200 and "<title>SonicRec</title>" in c.get("/").text
         and "<h1>SonicRec</h1>" in c.get("/").text)
    gd_goc = c.get("/").text
    # Chỉ tính khai báo còn hiệu lực: bỏ phần ghi chú CSS (kể cả ghi chú mở mà chưa đóng, nuốt luôn phần sau)
    css_sach = re.sub(r"/\*.*?(?:\*/|\Z)", "", gd_goc, flags=re.S)
    luoi_phong = []
    for khoi in re.findall(r"@font-face\s*\{([^}]*)\}", css_sach):
        tt = {k.strip(): v.strip() for k, v in re.findall(r"([\w-]+)\s*:\s*([^;]+)(?:;|$)", khoi)}
        tep = re.search(r"url\((/tai-nguyen/phong/BeVietnamPro-(\d+)-(latin|vietnamese)\.woff2)\)", tt.get("src", ""))
        if (tt.get("font-family") == '"Be Vietnam Pro"' and tep and tep.group(2) == tt.get("font-weight")
                and tt.get("unicode-range", "").startswith("U+")):
            luoi_phong.append((int(tep.group(2)), tep.group(3), tep.group(1)))
    luoi_phong.sort()
    urls_phong = [u for _, _, u in luoi_phong]
    kiem("biểu tượng phục vụ được; giao diện khai đủ lưới phông Be Vietnam Pro (5 độ đậm x 2 bộ ký tự, mỗi ô một "
         "khai báo còn hiệu lực, không nằm trong ghi chú CSS) và mọi tệp phông đã khai đều phục vụ được, đúng là "
         "tệp woff2",
         c.get("/tai-nguyen/hinh/bieu-tuong.png").status_code == 200
         and [(w, b) for w, b, _ in luoi_phong] == [(w, b) for w in (400, 500, 600, 700, 800) for b in ("latin", "vietnamese")]
         and all(c.get(u).status_code == 200 and c.get(u).content[:4] == b"wOF2" for u in urls_phong),
         str(luoi_phong)[:300])
    kiem("giao diện dùng Be Vietnam Pro cho cả tiêu đề lẫn nội dung, giấy phép OFL đi kèm; không còn "
         "logo hay phông riêng của Trường (PM yêu cầu bỏ 30/9/2026)",
         re.search(r'--tieu-de: "Be Vietnam Pro",', gd_goc) is not None
         and re.search(r'--than: "Be Vietnam Pro",', gd_goc) is not None
         and "logo-tlu" not in gd_goc and "Thang Long Sans" not in gd_goc and "Manrope" not in gd_goc
         and not [t for t in (THU_MUC / "tai_nguyen").rglob("*") if re.search(r"logo-tlu|ThangLong|Manrope", t.name)]
         and "SIL Open Font License" in (THU_MUC / "tai_nguyen/phong/BeVietnamPro-OFL.txt").read_text(encoding="utf-8"))
    ma_cu = ("#000066", "#1a1a80", "#f32409", "#cf1d05", "#f9f5f4", "#e4dedc", "#cfc7c4", "#fdf0ee",
             "#e8e8f6", "#f3f3fb", "#e9e4e2", "243,36,9")
    lot_mau = [(t, m) for t in ("giao_dien.html", "xem_dien_thoai.html", "ung_dung.py") for m in ma_cu
               if m in (THU_MUC / t).read_text(encoding="utf-8").lower()]
    kiem("bảng màu SonicRec (PM chọn 30/9/2026): dải trên xanh ngọc sáng #0abab5 chữ tối, màu chính xanh ngọc đậm "
         "#0c4a54, màu nhấn và nút ghi cam đỏ #f0532f; giao diện, trang xem trên điện thoại, cửa sổ ứng dụng "
         "không còn mã màu cũ (xanh chàm, đỏ tươi...)",
         "--dai-tren: #0abab5;" in gd_goc and "--chinh: #0c4a54;" in gd_goc and "--nhan: #f0532f;" in gd_goc
         and "--dai-tren-chu: #052f2e;" in gd_goc and not lot_mau, str(lot_mau))
    dai_tren = gd_goc[gd_goc.index('<header class="tren">'):gd_goc.index("</header>")]
    kiem("dải trên có logo mới là SVG nhúng sẵn (tô bằng biến màu, không cần tệp ảnh ngoài) đứng trước tên SonicRec; "
         "không còn thẻ ảnh nào",
         '<svg class="logo"' in dai_tren and dai_tren.index('<svg class="logo"') < dai_tren.index("<h1>SonicRec</h1>")
         and "var(--chinh)" in dai_tren and "<img" not in dai_tren and "khoi-do" not in gd_goc)

    # Ô tìm chữ trong các thẻ của trợ lý (PM chọn 30/9/2026, ra bản v1.1)
    khung_tl = gd_goc[gd_goc.index('id="khung-tro-ly"'):gd_goc.index('class="khung nhac"')]
    kiem("ô tìm chữ (v1.1): nằm trong khung Trợ lý, sau khối ghim và trước danh sách thẻ (khối ghim không bị lọc), "
         "ẩn khi chưa có thẻ, có dòng đếm và nút Xoá riêng (bỏ dấu x của trình duyệt cho khỏi trùng)",
         khung_tl.index('id="khoi-ghim"') < khung_tl.index('id="o-tim-the"') < khung_tl.index('id="ds-the"')
         and 'id="hop-tim-the" hidden' in khung_tl and 'id="dem-tim-the"' in khung_tl
         and 'id="nut-xoa-tim-the" hidden' in khung_tl and "::-webkit-search-cancel-button" in gd_goc
         and "mark.tim {" in gd_goc)
    kiem("ô tìm chữ (v1.1): vẽ lại danh sách thẻ thì lọc lại theo chữ đang tìm (chữ giữ trong biến, không mất khi thẻ "
         "mới tới); chữ ở nhãn đầu thẻ và hàng ô tìm thêm không bị tính; thẻ không khớp bị ẩn; màn Kết quả cũng có ô "
         "tìm và bỏ chữ đang tìm khi sang cuộc họp khác",
         re.search(r'\$\("ds-the"\)\.innerHTML = cuaMay\.length.*?timTheKhung\(\);', gd_goc, re.S) is not None
         and 'class="hang-o tim-hang" data-khong-tim' in gd_goc
         and gd_goc.count('<span class="nho" data-khong-tim>') == 3
         and 'closest("[data-khong-tim], input, textarea")' in gd_goc
         and "t.hidden = !co;" in gd_goc
         and 'querySelectorAll("mark.tim")' in gd_goc  # gỡ chỗ tô cũ trước khi tô lại, khỏi chồng lên nhau
         and '$("hop-tim-the").hidden = !cuaMay.length;' in gd_goc
         and 'e.key === "Escape" && o.value' in gd_goc
         and 'nutXoa.onclick = () => { o.value = ""; dat(""); chay(); o.focus(); };' in gd_goc
         and 'id="o-tim-kq"' in gd_goc and 'if (timKqMa !== v.ma) { timKqMa = v.ma; timKq = ""; }' in gd_goc)
    # Hàm tìm chữ chạy thử thật bằng Node khi máy có Node (máy dựng và luồng kiểm trên GitHub có); máy không có
    # thì phép này vẫn tính đạt để số phép ở mọi máy như nhau
    mo_tim = re.search(r"function boDau\(s\) \{.*?(?=// Tô các chỗ khớp)", gd_goc, re.S)
    nut_node = bbh.shutil.which("node")
    ok_tim, ra_tim = True, "máy này không có Node, bỏ qua phần chạy thử"
    if nut_node:
        js_tim = (mo_tim.group(0) if mo_tim else "throw new Error('không thấy hàm boDau')") + """
const ca = (chu, tu) => timKhop(chu, tu).map(([a, b]) => chu.slice(a, b));
const cham = String.fromCharCode(0x323), mu = String.fromCharCode(0x302), xd = String.fromCharCode(10);
console.log(JSON.stringify([
  ca("Học viên đăng ký khóa học", "HOC VIEN"),
  ca("Đào tạo, đào TẠO, dao tao", "dao tao"),
  ca("Ho" + cham + "c vie" + mu + "n", "vie"),
  ca("Hạn (dự kiến) 30/9", "(dự"),
  ca("aaa", "aa"),
  ca("Có  hai   dấu" + xd + "cách", "hai dấu cách"),
  ca("Ghi lạ <b>x</b>", "<b>"),
  ca("abc", "   "),
  ca("", "a"),
  ca("Cần chốt", "can chot"),
  ca("😀 học", "hoc"),
  ca(cham + "abc", "abc"),
  ca("Hai  dấu cách", "hai  dấu"),
]));"""
        chay_tim = bbh.subprocess.run([nut_node, "-e", js_tim], capture_output=True, text=True,
                                      encoding="utf-8", timeout=60)
        ra_tim = chay_tim.stdout.strip() or chay_tim.stderr.strip()[:300]
        mong_tim = [["Học viên"], ["Đào tạo", "đào TẠO", "dao tao"], ["vie" + chr(0x302)], ["(dự"], ["aa"],
                    ["hai   dấu\ncách"], ["<b>"], [], [], ["Cần chốt"], ["học"], ["abc"], ["Hai  dấu"]]
        try:
            ok_tim = bbh.json.loads(ra_tim) == mong_tim
        except ValueError:
            ok_tim = False
    kiem("ô tìm chữ (v1.1): hàm tìm không phân biệt hoa thường và dấu tiếng Việt (kể cả chữ đ), gộp dãy dấu cách và "
         "xuống dòng, không nhầm dấu rời, ký tự đặc biệt hay emoji, và trả đúng đoạn của chữ gốc để tô "
         "(chạy thử thật bằng Node)", ok_tim, str(ra_tim)[:300])

    kiem("lưu thông tin thiếu tiêu đề giao diện thì bị chặn",
         c.put("/may/thong-tin", json={"thu_ky": "X"}).status_code == 403)
    kiem("lưu thông tin có khoá lạ thì bị từ chối",
         c.put("/may/thong-tin", json={"la": "X"}, headers=NUT).status_code == 400)
    # Bản trước đóng băng micro tự chọn (micro của iPhone) vào khoá "micro" mỗi lần
    # bấm Lưu. Khoá đó phải bị bỏ qua, và bị xoá ở lần lưu kế tiếp.
    tep = bbh.json.loads(bbh.TEP_MAC_DINH.read_text(encoding="utf-8"))
    tep["micro"] = "Micrô iPhone của H"
    bbh.TEP_MAC_DINH.write_text(bbh.json.dumps(tep, ensure_ascii=False), encoding="utf-8")
    that_cac_micro = ghi_am.cac_micro
    ghi_am.cac_micro = lambda: [(0, "Micrô iPhone của H"), (1, "Micrô MacBook Air")]
    m = c.get("/may/micro").json()
    kiem("lựa chọn cũ bị đóng băng (micro iPhone) không còn tác dụng, dùng micro MacBook",
         m["chon"] == "Micrô MacBook Air" and m["tu_dong"] == "Micrô MacBook Air"
         and m["da_chon"] == "", str(m))
    kiem("lưu thông tin không nhận khoá micro cũ nữa",
         c.put("/may/thong-tin", json={"micro": "X"}, headers=NUT).status_code == 400)
    dap = c.put("/may/thong-tin", json={"thu_ky": "Lê Văn C"}, headers=NUT)
    tep = bbh.json.loads(bbh.TEP_MAC_DINH.read_text(encoding="utf-8"))
    kiem("lưu thông tin giữ dòng ghi chú và các ô khác",
         dap.status_code == 200 and tep.get("_ghi_chu_1") and tep["thu_ky"] == "Lê Văn C"
         and tep["chu_tri"] == "Nguyễn Nam Hải")
    kiem("lần lưu kế tiếp xoá khoá micro cũ", "micro" not in tep)
    c.put("/may/thong-tin", json={"micro_da_chon": "Micrô iPhone của H"}, headers=NUT)
    m = c.get("/may/micro").json()
    kiem("người dùng tự chọn micro iPhone thì máy theo đúng lựa chọn đó",
         m["chon"] == "Micrô iPhone của H" and m["da_chon"] == "Micrô iPhone của H")
    kiem("đọc lại thông tin thấy giá trị mới",
         c.get("/may/thong-tin").json()["truong"]["micro_da_chon"] == "Micrô iPhone của H")
    c.put("/may/thong-tin", json={"micro_da_chon": ""}, headers=NUT)
    kiem("chọn lại Tự động thì quay về micro MacBook",
         c.get("/may/micro").json()["chon"] == "Micrô MacBook Air")
    # Ghi tiếp sau Tạm dừng: tìm lại micro theo TÊN. Mở lại theo số cũ thì ghi nhầm
    # micro khi iPhone vừa lại gần (thẻ trống sau Ghi tiếp, 27/9/2026)
    # Đang ghi bằng micro rời: tự chọn sẽ ra micro MacBook, nên chỉ tìm theo tên mới ra đúng
    that_micro = bbh.MAY_GHI.micro
    bbh.MAY_GHI.micro = (0, "Micrô USB")
    ghi_am.cac_micro = lambda: [(0, "Micrô MacBook Air"), (1, "Micrô iPhone của H"), (2, "Micrô USB")]
    m1 = asyncio.run(bbh._micro_ghi_tiep())
    bbh.MAY_GHI.micro = (0, "Micrô MacBook Air")
    ghi_am.cac_micro = lambda: [(0, "Micrô iPhone của H"), (1, "Micrô USB")]
    m2 = asyncio.run(bbh._micro_ghi_tiep())
    ghi_am.cac_micro = lambda: []
    m3 = asyncio.run(bbh._micro_ghi_tiep())
    bbh.MAY_GHI.micro = that_micro
    kiem("ghi tiếp: danh sách micro đổi số thứ tự thì vẫn mở đúng micro đang ghi, theo tên",
         m1 == (2, "Micrô USB"), str(m1))
    kiem("ghi tiếp: micro đang ghi đã rút ra thì chọn như lúc bấm ghi, không chọn micro iPhone",
         m2 == (1, "Micrô USB"), str(m2))
    kiem("ghi tiếp: không liệt kê được micro thì giữ micro cũ", m3 is None, str(m3))
    ghi_am.cac_micro = that_cac_micro
    # Âm thanh trong tệp ngắn hơn thời gian ghi (máy Mac của PM 27/9/2026: 57 phút 50 giây âm
    # thanh trên 70 phút đồng hồ): ghi vào nhật ký; bản ghi ngắn hay hụt ít thì thôi
    hut = bbh.dong_hut_am_thanh(3470, 4200)
    kiem("bản ghi hụt âm thanh thì nhật ký nói rõ hụt bao nhiêu",
         "57:50" in hut and "70:00" in hut and "hụt 17%" in hut, hut)
    kiem("bản ghi đủ, hay quá ngắn để đo, thì không ghi gì",
         bbh.dong_hut_am_thanh(4190, 4200) == "" and bbh.dong_hut_am_thanh(20, 50) == "")

    if not bbh.shutil.which("ffmpeg"):
        print("  (bỏ qua phần ghi âm thật vì máy chưa có ffmpeg)")
    else:
        SONG = "-re -f lavfi -i sine=frequency=440:sample_rate=48000"
        IM = "-re -f lavfi -i anullsrc=r=48000:cl=mono"
        os.environ["GHI_AM_NGUON"] = SONG
        k = c.post("/may/ghi/thu-micro", headers=NUT).json()
        kiem("thử micro có tiếng thì báo nghe tốt", k.get("co_tieng") is True, str(k)[:80])
        os.environ["GHI_AM_NGUON"] = IM
        k = c.post("/may/ghi/thu-micro", headers=NUT).json()
        kiem("thử micro im bặt (bị chặn quyền) thì báo không có tiếng",
             k.get("co_tieng") is False, str(k)[:80])

        os.environ["GHI_AM_NGUON"] = SONG
        kiem("bắt đầu ghi thiếu tiêu đề giao diện thì bị chặn",
             c.post("/may/ghi/bat-dau").status_code == 403)
        dap = c.post("/may/ghi/bat-dau", headers=NUT)
        ma_ghi = dap.json().get("ma")
        kiem("bắt đầu ghi âm", dap.status_code == 200 and ma_ghi, dap.text[:80])
        kiem("đang ghi thì không bắt đầu cuộc thứ hai",
             c.post("/may/ghi/bat-dau", headers=NUT).status_code == 409)
        kiem("đang ghi thì không cho tắt ứng dụng nếu chưa xác nhận",
             c.post("/may/tat", headers=NUT).status_code == 409)
        time.sleep(2.0)
        g = c.get("/may/ghi/trang-thai").json()
        kiem("đồng hồ chạy và có mức âm", g["tt"] == "ghi" and g["giay"] >= 1.5
             and g["muc"] and max(g["muc"]) > -40, str(g)[:120])
        kiem("có tiếng thì không báo im lặng", g["im_lang"] is False)
        c.post("/may/ghi/tam-dung", headers=NUT)
        g1 = c.get("/may/ghi/trang-thai").json()
        time.sleep(0.8)
        g2 = c.get("/may/ghi/trang-thai").json()
        kiem("tạm dừng thì đồng hồ đứng", g1["tt"] == "tam-dung" and g1["giay"] == g2["giay"])
        # Trong lúc tạm dừng, danh sách micro đổi: micro đang ghi lùi xuống số 2, còn tự
        # chọn thì sẽ ra micro MacBook ở số 0
        ten_dang = bbh.MAY_GHI.micro[1]
        ghi_am.cac_micro = lambda: [(0, "Micrô MacBook Air"), (1, "Micrô iPhone của H"), (2, ten_dang)]
        c.post("/may/ghi/tiep-tuc", headers=NUT)
        micro_tiep = bbh.MAY_GHI.micro
        ghi_am.cac_micro = that_cac_micro
        kiem("bấm Ghi tiếp mở lại đúng micro đang ghi theo tên, dù số thứ tự đã đổi",
             micro_tiep == (2, ten_dang), str(micro_tiep))
        time.sleep(1.2)
        tm_ghi = Path(bbh.VIEC[ma_ghi]["thu_muc"])
        kiem("tạm dừng rồi ghi tiếp tạo đoạn thứ hai",
             sorted(x.name for x in tm_ghi.glob("doan-*.aac")) == ["doan-01.aac", "doan-02.aac"])
        dap = c.post("/may/ghi/dung", headers=NUT)
        kiem("dừng ghi được chấp nhận", dap.status_code == 200 and dap.json().get("ma") == ma_ghi)
        kiem("dừng thì nối các đoạn thành một tệp",
             (tm_ghi / "ghi-am.aac").is_file() and not list(tm_ghi.glob("doan-*.aac")))
        kiem("bản ghi nối lại đọc được", DO_DAI_THAT(tm_ghi / "ghi-am.aac") > 2)
        kiem("ghi trên máy thì tự xử lý tới Xong", cho_xong(ma_ghi) == "Xong")
        vg = bbh.VIEC[ma_ghi]
        kiem("giờ ghi trên máy là giờ thật, không kèm dấu cần kiểm tra",
             "giờ" in vg["tt"]["thoi_gian"] and "cần kiểm tra" not in vg["tt"]["thoi_gian"],
             vg["tt"]["thoi_gian"])
        kiem("độ dài tính cả hai đoạn, không tính lúc tạm dừng",
             3 <= (vg.get("thoi_luong_giay") or 0) <= 5, str(vg.get("thoi_luong_giay")))
        kiem("thông tin mới lưu được dùng cho cuộc họp mới", vg["tt"]["thu_ky"] == "Lê Văn C")
        chu_word = "\n".join(p.text for p in Document(tm_ghi / vg["tep_word"]).paragraphs)
        kt = datetime.fromisoformat(vg["ket_thuc"])
        kiem("tệp Word ghi giờ kết thúc thật",
             f"Biên bản kết thúc vào {kt.hour} giờ {kt.minute:02d} phút cùng ngày." in chu_word)
        kiem("nhật ký có đủ các bước",
             [x[1].split(",")[0] for x in vg["nhat_ky"]][:4]
             == ["Bắt đầu ghi âm", "Tạm dừng ghi âm", "Ghi âm tiếp", "Dừng ghi"],
             str(vg["nhat_ky"])[:160])

        # Micro bị chặn quyền: macOS đưa về toàn số 0
        os.environ["GHI_AM_NGUON"] = IM
        ghi_am.IM_LANG_GIAY = 1.0
        ma_im = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        time.sleep(2.0)
        kiem("micro im bặt thì báo ngay trong lúc ghi",
             c.get("/may/ghi/trang-thai").json()["im_lang"] is True)
        NLM[0] = g = NlmGia()
        c.post("/may/ghi/dung", headers=NUT)
        kiem("bản ghi im lặng thì dừng trước khi gửi lên Google chép lời",
             cho_xong(ma_im) == "Lỗi" and "im lặng" in (bbh.VIEC[ma_im]["loi"] or "")
             and not g.goi, str(bbh.VIEC[ma_im]["loi"])[:100])

        # Micro chọn nhầm (micro của iPhone): không im bặt, chỉ rè rất nhỏ khoảng -60 dB
        os.environ["GHI_AM_NGUON"] = SONG + ",volume=-40dB"
        c.post("/may/ghi/bat-dau", headers=NUT)
        time.sleep(2.0)
        g = c.get("/may/ghi/trang-thai").json()
        kiem("micro chỉ thu tiếng rè rất nhỏ (-61 dB) cũng báo trong lúc ghi",
             g["im_lang"] is True and g["muc"] and max(g["muc"]) < -55, str(g["muc"][-3:]))
        c.post("/may/ghi/dung", headers=NUT)
        ghi_am.IM_LANG_GIAY = 10.0

        # ffmpeg chết giữa chừng (rút micro): tự tạm dừng và nói ra
        os.environ["GHI_AM_NGUON"] = SONG
        ma_rut = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        time.sleep(1.0)
        bbh.MAY_GHI.tien_trinh.kill()
        time.sleep(0.8)
        g = c.get("/may/ghi/trang-thai").json()
        kiem("ffmpeg chết giữa chừng thì chuyển tạm dừng và báo lỗi",
             g["tt"] == "tam-dung" and "bị ngắt" in (g["loi"] or ""), str(g)[:120])
        c.post("/may/ghi/dung", headers=NUT)
        cho_xong(ma_rut)

        # Máy sập giữa buổi: lần mở sau nối các đoạn đã ghi và cho Làm lại
        tm_sap = bbh.THU_MUC_LUU / "2026-09-28_0830_dangghi1"
        tm_sap.mkdir()
        for i in (1, 2):
            bbh.subprocess.run(["ffmpeg", "-v", "error", "-f", "lavfi", "-i", "sine=duration=2",
                                "-ac", "1", "-c:a", "aac", "-f", "adts",
                                str(tm_sap / f"doan-0{i}.aac")], check=True, timeout=60)
        bbh._ghi_an_toan(tm_sap / "viec.json", bbh.json.dumps({
            "ma": "dangghi1", "trang_thai": "Đang ghi âm", "tt": vg["tt"], "tep_ghi_am": None,
            "nhan_luc": "2026-09-28T08:30:00", "bat_dau": "2026-09-28T08:30:00",
            "cach_da_bao": "notebooklm"}))
        bbh.VIEC.clear()
        bbh.THU_TU.clear()
        bbh.nap_lai_lich_su()
        vs = bbh.VIEC.get("dangghi1", {})
        kiem("máy sập giữa lúc ghi: lần mở sau nối lại phần đã ghi",
             vs.get("trang_thai") == "Bị gián đoạn" and vs.get("tep_ghi_am") == "ghi-am.aac"
             and (tm_sap / "ghi-am.aac").is_file() and not list(tm_sap.glob("doan-*.aac")),
             str(vs.get("loi"))[:80])
        c.post("/may/viec/dangghi1/lam-lai", headers=NUT)
        kiem("phần cứu được soạn thành biên bản bằng Làm lại", cho_xong("dangghi1") == "Xong")

    kiem("tắt ứng dụng có xác nhận thì được", c.post("/may/tat?chac=1", headers=NUT).status_code == 200)
    os.environ.pop("GHI_AM_NGUON", None)


# ----------------------------------------------------------------------------
print("\nF. NotebookLM: chép lời, soạn, giữ sổ; hỏng thì dừng ở Lỗi, giữ bản ghi để Làm lại")
# ----------------------------------------------------------------------------



with TestClient(bbh.app, base_url=GOC, client=("127.0.0.1", 50000)) as c:
    # Chưa đăng nhập: dừng ở Lỗi, giữ bản ghi, nói rõ phải đăng nhập rồi Làm lại
    DA_DANG_NHAP[0] = False
    NLM[0] = g = NlmGia()
    gui(c)
    v = viec_cuoi()
    kiem("chưa đăng nhập Google: dừng ở Lỗi, giữ bản ghi, báo đăng nhập rồi Làm lại",
         v["trang_thai"] == "Lỗi" and "Chưa đăng nhập Google" in (v["loi"] or "")
         and "Làm lại" in v["loi"] and not g.goi
         and (Path(v["thu_muc"]) / v["tep_ghi_am"]).is_file(), str(v.get("loi"))[:120])

    # Đã đăng nhập, NotebookLM chạy trọn
    DA_DANG_NHAP[0] = True
    NLM[0] = g = NlmGia()
    gui(c)
    v = viec_cuoi()
    kiem("NotebookLM chạy trọn: tạo sổ, tải lên, chờ chép lời, lấy chữ, soạn",
         v["trang_thai"] == "Xong" and ten_goi(g) == ["tao", "them_tep", "cho", "chu", "hoi"],
         str(ten_goi(g)))
    kiem("ghi nhận việc này làm bằng NotebookLM", v["cach"] == "notebooklm")
    kiem("bản chép lời lấy từ NotebookLM", v["ban_go_chu"] == CHU_GOOGLE)
    kiem("bỏ các số trích dẫn [1], [2, 3], [4-6] của NotebookLM",
         all(x not in v["ket_qua"] for x in ("[1]", "[2, 3]", "[4-6]"))
         and "32 học viên. Hạn nộp hồ sơ ngày 30/9." in v["ket_qua"], v["ket_qua"][:120])
    kiem("GIỮ sổ trên NotebookLM, không xoá (PM chọn)", "xoa" not in ten_goi(g))
    kiem("lưu mã sổ xuống ổ đĩa để mở lại",
         (v.get("so_nlm") or {}).get("id") == "so1" and (v["so_nlm"].get("nguon") == "nguon1")
         and '"so_nlm"' in (Path(v["thu_muc"]) / "viec.json").read_text(encoding="utf-8"))
    kiem("tệp .m4a gửi kèm đúng loại audio/mp4", g.goi[1][1:] == (".m4a", "audio/mp4"), str(g.goi[1]))
    kiem("soạn biên bản chỉ dựa trên đúng nguồn của cuộc họp này",
         g.goi[-1] == ("hoi", ("nguon1",)))
    kiem("tệp Word dựng từ biên bản của NotebookLM",
         bool(v.get("tep_word")) and (Path(v["thu_muc"]) / v["tep_word"]).is_file())
    ma_nlm = v["ma"]

    # NotebookLM soạn hỏng: máy soạn tại máy từ bản chép lời của Google, không gỡ lại
    NLM[0] = g = NlmGia(hong={"hoi"})
    gui(c)
    v = viec_cuoi()
    kiem("soạn trực tuyến hỏng thì vẫn Xong, dùng lại bản chép lời đã có, không hiện nguyên văn lỗi",
         v["trang_thai"] == "Xong" and ten_goi(g).count("chu") == 1
         and "32 học viên" in (v["ket_qua"] or "")
         and "soạn tại máy từ bản chép lời đã có" in (v.get("canh_bao") or "")
         and "hỏng giả lập" not in v["canh_bao"],
         str(v.get("canh_bao"))[:120])

    # Tải lên hỏng: dừng ở Lỗi, giữ bản ghi để Làm lại
    NLM[0] = g = NlmGia(hong={"them_tep"})
    so_nhat_ky = io.StringIO()
    with contextlib.redirect_stdout(so_nhat_ky):
        gui(c)
    v = viec_cuoi()
    kiem("tải lên hỏng: dừng ở Lỗi, giữ bản ghi, báo rõ để Làm lại",
         v["trang_thai"] == "Lỗi" and "Có lỗi khi xử lý" in (v["loi"] or "")
         and "Làm lại" in v["loi"] and (Path(v["thu_muc"]) / v["tep_ghi_am"]).is_file(),
         str(v.get("loi"))[:120])
    kiem("lỗi của thư viện: màn hình chỉ nói chung chung, nguyên văn ghi vào nhật ký máy",
         "hỏng giả lập" not in v["loi"] and "RuntimeError" not in v["loi"]
         and "them_tep hỏng giả lập" in so_nhat_ky.getvalue(), so_nhat_ky.getvalue()[-200:])

    # Chờ Google chép lời: hạn tối đa KHÔNG tính theo độ dài bản ghi. Bản ghi 188 phút
    # mà Google không nhận được từng làm máy đứng chờ gần 5 tiếng (25/9/2026).
    kiem("chờ Google chép lời tối đa 20 phút, bản ghi dài mấy cũng vậy",
         bbh.HAN_NLM["go_chu"] == 1200 and "go_chu_it_nhat" not in bbh.HAN_NLM)
    that_han = dict(bbh.HAN_NLM)
    bbh.HAN_NLM.update(go_chu=1, nhip=0.1)
    NLM[0] = g = NlmGia(nguon=("dang",))
    bat_dau_cho = time.monotonic()
    gui(c)
    v = viec_cuoi()
    het = time.monotonic() - bat_dau_cho
    kiem("Google chép lời mãi chưa xong: quá hạn thì dừng ở Lỗi, giữ bản ghi, không tải lên lại",
         v["trang_thai"] == "Lỗi" and "chưa chép lời xong" in (v["loi"] or "") and het < 8
         and ten_goi(g).count("them_tep") == 1,
         f"{het:.1f} giây; {ten_goi(g).count('them_tep')} lần tải; {str(v.get('loi'))[:100]}")

    bbh.HAN_NLM.update(go_chu=60, ket_noi=1)
    NLM[0] = g = NlmGia(treo={"cho"})
    bat_dau_cho = time.monotonic()
    gui(c)
    v = viec_cuoi()
    het = time.monotonic() - bat_dau_cho
    kiem("hỏi Google đã chép lời xong chưa mà treo thì đồng hồ phía mình cắt, dừng ở Lỗi",
         v["trang_thai"] == "Lỗi" and "chưa xong" in (v["loi"] or "") and het < 8,
         f"{het:.1f} giây; {str(v.get('loi'))[:100]}")
    bbh.HAN_NLM.update(ket_noi=that_han["ket_noi"])

    # Google báo lỗi (bản ghi hiện màu đỏ trong sổ): thôi sau ít phút, không chờ hết hạn
    bbh.HAN_NLM.update(loi_keo_dai=0.5)
    NLM[0] = g = NlmGia(nguon=("loi",))
    bat_dau_cho = time.monotonic()
    gui(c)
    v = viec_cuoi()
    het = time.monotonic() - bat_dau_cho
    kiem("Google không nhận cả hai lần tải lên: xoá bản đỏ, thôi sau ít phút, dừng ở Lỗi, "
         "nói rõ đã tải lên 2 lần",
         v["trang_thai"] == "Lỗi" and "không nhận bản ghi" in (v["loi"] or "")
         and "2 lần" in v["loi"] and ten_goi(g).count("them_tep") == 2
         and ten_goi(g).count("xoa_nguon") == 2 and het < 8,
         f"{het:.1f} giây; {ten_goi(g)}; {str(v.get('loi'))[:100]}")
    ma_do = v["ma"]
    bbh.HAN_NLM.update(loi_keo_dai=5)
    NLM[0] = g = NlmGia(nguon=("loi", "loi", "xong"))
    gui(c)
    v = viec_cuoi()
    kiem("Google báo lỗi thoáng qua rồi xong: vẫn chép lời và soạn bằng NotebookLM",
         v["trang_thai"] == "Xong" and v["cach"] == "notebooklm" and not v.get("canh_bao")
         and ten_goi(g).count("cho") == 3, f"{ten_goi(g)}; {v.get('canh_bao')}")

    # Google không nhận lần đầu, tải lại thì được (đúng chuyện 25/9/2026): vẫn NotebookLM
    bbh.HAN_NLM.update(loi_keo_dai=0)
    NLM[0] = g = NlmGia(nguon=("loi", "xong"))
    gui(c)
    v = viec_cuoi()
    kiem("Google không nhận lần đầu: xoá bản đỏ, tải lên lại một lần, được thì vẫn dùng NotebookLM",
         v["trang_thai"] == "Xong" and v["cach"] == "notebooklm" and not v.get("canh_bao")
         and ten_goi(g) == ["tao", "them_tep", "cho", "xoa_nguon", "them_tep", "cho", "chu", "hoi"]
         and any("tải lên lại" in x[1] for x in v["nhat_ky"]), str(ten_goi(g)))

    # Làm lại khi bản ghi trong sổ đã đỏ và người dùng đã xoá nó: tải lên lại, không
    # đứng chờ bản đã mất
    vd = bbh.VIEC[ma_do]
    vd.update(trang_thai="Lỗi", ban_go_chu="", ket_qua=None, so_nlm={"id": "so1", "nguon": "nguon-do"})
    NLM[0] = g = NlmGia(nguon_da_xoa={"nguon-do"})
    c.post(f"/may/viec/{ma_do}/lam-lai", headers=NUT)
    kiem("Làm lại khi bản ghi cũ trong sổ đã bị xoá: tải lên lại rồi chép lời, soạn bằng NotebookLM",
         cho_xong(ma_do) == "Xong" and vd["cach"] == "notebooklm"
         and ten_goi(g) == ["tim", "cho", "xoa_nguon", "them_tep", "cho", "chu", "hoi"],
         str(ten_goi(g)))

    # Làm lại khi đã có bản chép lời Whisper mà bản ghi trong sổ đỏ hoặc Google còn đang
    # xử lý (việc lưu từ bản cũ còn Whisper): gửi chữ lên, soạn trên chữ
    for nguon_cu, ta in (("loi", "đỏ"), ("dang", "Google còn đang xử lý")):
        vd.update(trang_thai="Lỗi", ban_go_chu="Bản chép lời của Whisper tại máy cho cuộc họp",
                  ket_qua=None, so_nlm={"id": "so1", "nguon": "nguon-do"})
        NLM[0] = g = NlmGia(nguon=(nguon_cu,))
        c.post(f"/may/viec/{ma_do}/lam-lai", headers=NUT)
        kiem(f"Làm lại khi đã có bản chép lời Whisper mà bản ghi trong sổ {ta}: bỏ bản ghi đó, "
             "gửi chữ, soạn trên chữ",
             cho_xong(ma_do) == "Xong" and vd["cach"] == "notebooklm"
             and ten_goi(g) == ["tim", "cho", "xoa_nguon", "them_chu", "hoi"]
             and g.goi[-1] == ("hoi", ("nguon2",)), str(g.goi))

    # Đang chờ Google: màn hình nói đã chờ bao lâu; bấm Thôi chờ Google thì dừng ngay
    NLM[0] = g = NlmGia(nguon=("dang",))
    dap = c.post("/may/tai-len", headers=NUT,
                 files={"ghi_am": ("ghiam.m4a", b"am-thanh-gia", "audio/mp4")})
    ma_cho = dap.json()["ma"]
    het = time.monotonic() + 5
    while not bbh.VIEC[ma_cho].get("dang_cho_google") and time.monotonic() < het:
        time.sleep(0.05)
    tt_cho = bbh.VIEC[ma_cho]["trang_thai"]
    kiem("đang chờ Google: màn hình hiện số phút đã chờ, quá bao lâu thì dừng và giữ bản ghi",
         "đã chờ 0 phút" in tt_cho and "Quá 1 phút" in tt_cho and "giữ bản ghi" in tt_cho
         and "Whisper" not in tt_cho, tt_cho)
    kiem("màn Đang xử lý biết lúc nào hiện nút Thôi chờ Google",
         c.get(f"/may/viec/{ma_cho}").json().get("dang_cho_google") is True)
    kiem("nút Thôi chờ Google thiếu tiêu đề giao diện thì bị chặn",
         c.post(f"/may/viec/{ma_cho}/thoi-cho-google").status_code == 403)
    bat_dau_cho = time.monotonic()
    dap = c.post(f"/may/viec/{ma_cho}/thoi-cho-google", headers=NUT)
    trang_thai_cuoi = cho_xong(ma_cho)
    het = time.monotonic() - bat_dau_cho
    v = bbh.VIEC[ma_cho]
    kiem("bấm Thôi chờ: dừng chờ ngay, dừng ở Lỗi, giữ bản ghi, nói rõ vì sao",
         dap.status_code == 200 and trang_thai_cuoi == "Lỗi"
         and "thôi chờ chép lời" in (v["loi"] or "") and "Có lỗi khi xử lý" not in v["loi"]
         and "Làm lại" in v["loi"] and het < 5
         and (Path(v["thu_muc"]) / v["tep_ghi_am"]).is_file()
         and any("Bấm Thôi chờ" in x[1] for x in v["nhat_ky"]),
         f"{het:.1f} giây; {str(v.get('loi'))[:100]}")
    kiem("cuộc họp không còn chờ Google thì nút Thôi chờ báo lại, không làm gì",
         c.post(f"/may/viec/{ma_cho}/thoi-cho-google", headers=NUT).status_code == 409)
    bbh.VIEC[ma_cho]["trang_thai"] = "Lỗi"
    NLM[0] = g = NlmGia()
    c.post(f"/may/viec/{ma_cho}/lam-lai", headers=NUT)
    kiem("Làm lại xoá cờ Thôi chờ Google của lần trước",
         bbh.VIEC[ma_cho].get("thoi_cho_google") is False)
    cho_xong(ma_cho)
    bbh.HAN_NLM.clear()
    bbh.HAN_NLM.update(that_han)

    # Làm lại: dùng lại đúng sổ cũ, bước nào xong rồi thì không làm lại
    bbh.VIEC[ma_nlm]["trang_thai"] = "Lỗi"
    NLM[0] = g = NlmGia()
    c.post(f"/may/viec/{ma_nlm}/lam-lai", headers=NUT)
    kiem("Làm lại dùng lại sổ cũ: không tạo sổ, không tải lại, chỉ soạn lại",
         cho_xong(ma_nlm) == "Xong" and ten_goi(g) == ["tim", "cho", "hoi"], str(ten_goi(g)))
    bbh.VIEC[ma_nlm]["trang_thai"] = "Lỗi"
    NLM[0] = g = NlmGia(so_da_xoa={"so1"})
    c.post(f"/may/viec/{ma_nlm}/lam-lai", headers=NUT)
    kiem("sổ cũ đã bị xoá trên NotebookLM thì tạo sổ mới và gửi bản chép lời đã có",
         cho_xong(ma_nlm) == "Xong" and ten_goi(g) == ["tim", "tao", "them_chu", "hoi"],
         str(ten_goi(g)))

    # Nút mở sổ trên NotebookLM
    goi_open = []
    that_mo = bbh.mo_bang_he_thong
    bbh.mo_bang_he_thong = goi_open.append
    dap = c.post(f"/may/viec/{ma_nlm}/mo?cai=notebooklm", headers=NUT)
    bbh.mo_bang_he_thong = that_mo
    kiem("nút mở sổ mở đúng địa chỉ sổ trên NotebookLM",
         dap.status_code == 200 and goi_open == ["https://notebooklm.google.com/notebook/so1"],
         str(goi_open))

    # Chọn cách chép lời trong thẻ Cài đặt
    kiem("tình trạng máy báo cách chép lời và đã đăng nhập chưa",
         c.get("/may/trang-thai").json().get("cach") == "notebooklm"
         and c.get("/may/trang-thai").json().get("nlm") is True)
    kiem("không nhận cách chép lời lạ",
         c.put("/may/thong-tin", json={"cach_go_chu": "abc"}, headers=NUT).status_code == 400)
    c.put("/may/thong-tin", json={"cach_go_chu": "whisper"}, headers=NUT)
    NLM[0] = g = NlmGia()
    gui(c)
    v = viec_cuoi()
    kiem("chọn Không gửi lên mạng: không gọi NotebookLM, không chép lời, giữ bản ghi trên máy",
         v["cach"] == "whisper" and not g.goi and not v.get("ban_go_chu")
         and (Path(v["thu_muc"]) / v["tep_ghi_am"]).is_file(), str(ten_goi(g)))
    kiem("cuộc họp Không gửi lên mạng vẫn Xong: có khung biên bản, tệp Word, nói rõ thư ký "
         "nghe lại để viết, còn nút Đã ký để xoá bản ghi",
         v["trang_thai"] == "Xong" and "Không gửi lên mạng" in (v.get("canh_bao") or "")
         and "nghe lại bản ghi" in (v.get("ket_qua") or "") and bool(v.get("tep_word"))
         and (Path(v["thu_muc"]) / v["tep_word"]).is_file(), str(v.get("canh_bao"))[:120])
    c.put("/may/thong-tin", json={"cach_go_chu": "notebooklm"}, headers=NUT)

    # Cách chép lời chốt lúc tạo cuộc họp, tức lúc câu thông báo đầu buổi hiện ra
    v = viec_cuoi()
    kiem("cuộc họp lưu cách đã thông báo xuống ổ đĩa",
         v["cach_da_bao"] == "whisper" and '"cach_da_bao": "whisper"'
         in (Path(v["thu_muc"]) / "viec.json").read_text(encoding="utf-8"))
    v["trang_thai"] = "Lỗi"
    NLM[0] = g = NlmGia()
    c.post(f"/may/viec/{v['ma']}/lam-lai", headers=NUT)
    kiem("đã hứa không gửi lên mạng thì đổi sang NotebookLM rồi Làm lại vẫn không gửi",
         cho_xong(v["ma"]) == "Xong" and not g.goi and v["cach"] == "whisper", str(ten_goi(g)))
    v.pop("cach_da_bao")
    v["trang_thai"] = "Lỗi"
    c.post(f"/may/viec/{v['ma']}/lam-lai", headers=NUT)
    kiem("cuộc họp ghi từ bản trước khi có NotebookLM không bao giờ bị gửi lên Google",
         cho_xong(v["ma"]) == "Xong" and not g.goi, str(ten_goi(g)))
    kiem("danh sách cuộc họp báo cách đã thông báo của từng cuộc",
         [x["cach_da_bao"] for x in c.get("/may/trang-thai").json()["viec"]
          if x["ma"] == ma_nlm] == ["notebooklm"])
    c.put("/may/thong-tin", json={"cach_go_chu": "whisper"}, headers=NUT)
    bbh.VIEC[ma_nlm]["trang_thai"] = "Lỗi"
    c.post(f"/may/viec/{ma_nlm}/lam-lai", headers=NUT)
    kiem("đã hứa NotebookLM nhưng giờ chọn Không gửi lên mạng: Làm lại soạn tại máy từ "
         "bản chép lời đã có",
         cho_xong(ma_nlm) == "Xong" and not g.goi and bbh.VIEC[ma_nlm]["cach"] == "whisper",
         str(ten_goi(g)))
    c.put("/may/thong-tin", json={"cach_go_chu": "notebooklm"}, headers=NUT)

    # Có người không đồng ý gửi lên Google giữa buổi: thư ký chuyển sang Không gửi lên mạng
    if bbh.shutil.which("ffmpeg"):
        os.environ["GHI_AM_NGUON"] = "-re -f lavfi -i sine=frequency=440:sample_rate=48000"
        ma_ghi = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        kiem("bấm ghi lúc đang chọn NotebookLM thì cuộc họp hứa gửi lên NotebookLM",
             bbh.VIEC[ma_ghi]["cach_da_bao"] == "notebooklm")
        c.put("/may/thong-tin", json={"cach_go_chu": "whisper"}, headers=NUT)
        c.put("/may/thong-tin", json={"cach_go_chu": "notebooklm"}, headers=NUT)
        time.sleep(1.5)
        c.post("/may/ghi/dung", headers=NUT)
        vg = bbh.VIEC[ma_ghi]
        kiem("đang ghi mà chuyển sang Không gửi lên mạng thì cuộc đó giữ trên máy, lỡ chuyển "
             "lại vẫn không gửi",
             cho_xong(ma_ghi) == "Xong" and not g.goi and vg["cach_da_bao"] == "whisper"
             and any("giữa buổi" in x[1] for x in vg["nhat_ky"]), str(ten_goi(g)))
        os.environ.pop("GHI_AM_NGUON", None)

    # Kiểm tra kết nối
    NLM[0] = NlmGia()
    k = c.post("/may/notebooklm/kiem-tra", headers=NUT).json()
    kiem("kiểm tra kết nối được thì báo được, không kể sổ", k == {"ok": True}, str(k))
    NLM[0] = NlmGia(hong={"ds"})
    k = c.post("/may/notebooklm/kiem-tra", headers=NUT).json()
    kiem("kiểm tra kết nối hỏng thì báo chung chung, không hiện nguyên văn của thư viện",
         k["ok"] is False and bool(k["loi"]) and "hỏng giả lập" not in k["loi"], str(k))
    DA_DANG_NHAP[0] = False
    k = c.post("/may/notebooklm/kiem-tra", headers=NUT).json()
    kiem("chưa đăng nhập thì kiểm tra báo chưa đăng nhập",
         k["ok"] is False and "Chưa đăng nhập" in k["loi"])

    # Đăng nhập: mở tiến trình đăng nhập, theo dõi, có hạn phía mình
    kiem("lệnh đăng nhập thật gọi đúng thư viện",
         LENH_DANG_NHAP_THAT()[:4] == [sys.executable, "-m", "notebooklm", "login"])
    kiem("đăng nhập thiếu tiêu đề giao diện thì bị chặn",
         c.post("/may/notebooklm/dang-nhap").status_code == 403)
    bbh.lenh_dang_nhap_nlm = lambda ma=None: [sys.executable, "-c", "import time; time.sleep(1.2)"]
    kiem("bấm đăng nhập mở được cửa sổ đăng nhập",
         c.post("/may/notebooklm/dang-nhap", headers=NUT).status_code == 200)
    kiem("đang mở cửa sổ đăng nhập thì không mở cái thứ hai",
         c.post("/may/notebooklm/dang-nhap", headers=NUT).status_code == 409)
    kiem("tình trạng báo đang chờ đăng nhập", c.get("/may/notebooklm").json()["dang_mo"] is True)
    # Chờ tới khi tiến trình đăng nhập xong, không chờ theo giờ cố định: trên Windows chậm, Python khởi
    # động lâu hơn 0,6 giây dư ra và phép thử trượt (luồng GitHub 1/10/2026)
    cho_den(lambda: not c.get("/may/notebooklm").json()["dang_mo"])
    n = c.get("/may/notebooklm").json()
    kiem("đăng nhập xong thì hết chờ, không báo lỗi", n["dang_mo"] is False and n["loi"] == "")
    bbh.lenh_dang_nhap_nlm = lambda ma=None: [sys.executable, "-c",
                                      "import sys; print('Dang nhap bi tu choi'); sys.exit(2)"]
    c.post("/may/notebooklm/dang-nhap", headers=NUT)
    so_nhat_ky = io.StringIO()
    with contextlib.redirect_stdout(so_nhat_ky):
        cho_den(lambda: c.get("/may/notebooklm").json()["loi"] != "")
        loi_dn = c.get("/may/notebooklm").json()["loi"]
    kiem("đăng nhập hỏng thì báo đăng nhập lại; chữ của thư viện chỉ vào nhật ký máy",
         "Đăng nhập chưa xong" in loi_dn and "Dang nhap bi tu choi" not in loi_dn
         and "Dang nhap bi tu choi" in so_nhat_ky.getvalue(), loi_dn)
    that_han_dn = bbh.HAN_DANG_NHAP_GIAY
    bbh.HAN_DANG_NHAP_GIAY = 0.5
    bbh.lenh_dang_nhap_nlm = lambda ma=None: [sys.executable, "-c", "import time; time.sleep(30)"]
    c.post("/may/notebooklm/dang-nhap", headers=NUT)
    time.sleep(1.0)
    n = c.get("/may/notebooklm").json()
    kiem("cửa sổ đăng nhập để quá hạn thì bị đóng và báo rõ",
         n["dang_mo"] is False and "đã đóng cửa sổ đăng nhập" in n["loi"]
         and bbh.DANG_NHAP_NLM["tien_trinh"].poll() is not None)
    bbh.HAN_DANG_NHAP_GIAY = that_han_dn
    bbh.lenh_dang_nhap_nlm = LENH_DANG_NHAP_THAT

# Hàm thật nhận ra đã đăng nhập hay chưa theo tệp phiên đăng nhập của thư viện
try:
    from notebooklm.paths import get_storage_path
    kiem("chưa có phiên đăng nhập thì biết là chưa đăng nhập", DA_DANG_NHAP_THAT() is False)
    get_storage_path().parent.mkdir(parents=True, exist_ok=True)
    get_storage_path().write_text("{}", encoding="utf-8")
    kiem("có phiên đăng nhập thì biết là đã đăng nhập", DA_DANG_NHAP_THAT() is True)
except ImportError:
    print("  (bỏ qua hai phép đăng nhập thật vì máy chưa cài notebooklm-py)")

if bbh.shutil.which("ffmpeg"):
    tep_aac = TAM / "thu-doi-vo.aac"
    bbh.subprocess.run(["ffmpeg", "-v", "error", "-f", "lavfi", "-i", "sine=duration=2", "-ac", "1",
                        "-c:a", "aac", "-f", "adts", str(tep_aac)], check=True, timeout=60)
    ra = bbh._ban_tai_len(tep_aac, TAM)
    do_dai = DO_DAI_THAT(ra)
    kiem("bản ghi AAC trên máy được đổi vỏ sang m4a trước khi tải lên, đủ độ dài",
         ra.suffix == ".m4a" and ra.is_file() and abs(do_dai - 2) < 0.5, str(do_dai))
    # Máy Mac cài từ 28/9/2026 chỉ có ffmpeg đi kèm, không có ffprobe: giờ bắt đầu ghi (tệp
    # của ứng dụng Ghi Âm trên iPhone) và độ dài phải đọc được bằng chính ffmpeg
    gio = (datetime.now(timezone.utc) - timedelta(hours=1)).replace(microsecond=0)
    tep_iphone = TAM / "Ghi âm iPhone" / "Họp giao ban 'thứ Hai'.m4a"
    tep_iphone.parent.mkdir(exist_ok=True)
    bbh.subprocess.run(["ffmpeg", "-v", "error", "-f", "lavfi", "-i", "sine=duration=3", "-c:a", "aac",
                        "-metadata", f"creation_time={gio:%Y-%m-%dT%H:%M:%S}.000000Z", str(tep_iphone)],
                       check=True, timeout=60)
    tep_rac = TAM / "khong-phai-am-thanh.m4a"
    tep_rac.write_bytes(b"khong phai am thanh " * 200)
    LENH_DA_GOI = []
    that_run = bbh.subprocess.run
    bbh.subprocess.run = lambda lenh, *a, **k: (LENH_DA_GOI.append(lenh[0]), that_run(lenh, *a, **k))[1]
    try:
        doc = (THOI_DIEM_THAT(tep_iphone), DO_DAI_THAT(tep_iphone),
               THOI_DIEM_THAT(tep_rac), DO_DAI_THAT(tep_rac))
    finally:
        bbh.subprocess.run = that_run
    kiem("giờ bắt đầu ghi và độ dài đọc bằng chính ffmpeg, không gọi ffprobe (tên tệp có dấu)",
         doc[0] == gio.astimezone().replace(tzinfo=None) and abs(doc[1] - 3) < 0.1
         and "ffmpeg" in LENH_DA_GOI and "ffprobe" not in LENH_DA_GOI, f"{doc[:2]} {LENH_DA_GOI}")
    kiem("tệp không phải âm thanh: không đoán giờ, độ dài 0, không báo lỗi",
         doc[2] is None and doc[3] == 0.0, str(doc[2:]))
    # Mẫu chữ ffmpeg in ra với tệp họp hơn 2 tiếng: độ dài tính cả giờ; giờ bắt đầu chỉ lấy
    # của cả tệp như ffprobe, không lấy của luồng âm thanh, của tên tệp hay của tiêu đề
    MAU_FFMPEG = (
        "Input #0, mov,mp4,m4a,3gp,3g2,mj2, from '/Họp/Duration: 00:00:01.00.m4a':\n"
        "  Metadata:\n"
        "    major_brand     : M4A \n"
        f"    title           : Duration: 99:59:59, creation_time : {gio - timedelta(days=1):%Y-%m-%dT%H:%M:%S}Z\n"
        "  Duration: 02:05:00.50, start: 0.000000, bitrate: 64 kb/s\n"
        "  Stream #0:0[0x1](und): Audio: aac (LC), 48000 Hz, mono, fltp, 64 kb/s (default)\n"
        "      Metadata:\n"
        f"        creation_time   : {gio:%Y-%m-%dT%H:%M:%S}.000000Z\n")
    bbh.subprocess.run = lambda lenh, *a, **k: (
        SimpleNamespace(returncode=1, stdout="", stderr=MAU_FFMPEG)
        if lenh[-1] == "mau-ffmpeg.m4a" else that_run(lenh, *a, **k))
    try:
        mau = (DO_DAI_THAT(Path("mau-ffmpeg.m4a")), THOI_DIEM_THAT(Path("mau-ffmpeg.m4a")))
    finally:
        bbh.subprocess.run = that_run
    kiem("độ dài hơn 1 tiếng đọc đúng; giờ bắt đầu chỉ lấy của cả tệp, không lấy của luồng âm "
         "thanh, tên tệp hay tiêu đề", mau == (7500.5, None), str(mau))


# ----------------------------------------------------------------------------
print("\nG. Máy Windows: đăng nhập bằng Edge, mở tệp")
# ----------------------------------------------------------------------------

that_win_bbh = bbh.LA_WINDOWS
bbh.LA_WINDOWS = True
kiem("Windows: cửa sổ đăng nhập NotebookLM dùng Edge có sẵn",
     LENH_DANG_NHAP_THAT()[-2:] == ["--browser", "msedge"], str(LENH_DANG_NHAP_THAT()))
kiem("Windows: chỉ đúng chỗ bật quyền micro của Windows, không nói tới iPhone",
     "desktop apps" in bbh.huong_dan_quyen_micro() and "iPhone" not in bbh.huong_dan_quyen_micro())
kiem("Windows: tình trạng máy báo đang chạy Windows", bbh.tinh_trang_may()["he"] == "windows")
goi = []
co_startfile = hasattr(bbh.os, "startfile")
that_startfile = getattr(bbh.os, "startfile", None)
bbh.os.startfile = goi.append
bbh.mo_bang_he_thong("C:\\cuoc-hop\\bien-ban.docx")
if co_startfile:
    bbh.os.startfile = that_startfile
else:
    del bbh.os.startfile
bbh.LA_WINDOWS = that_win_bbh
kiem("Windows: mở tệp bằng ứng dụng mặc định của Windows", goi == ["C:\\cuoc-hop\\bien-ban.docx"])


# ----------------------------------------------------------------------------
print("\nH. Cập nhật bản mới từ tệp cài (Mac: zip, Windows: .exe)")
# ----------------------------------------------------------------------------
# Tên ứng dụng đổi thành SonicRec 28/9/2026; bản đã cài nhận gói theo cấu tạo, không theo tên
APP_CAI = "Cài đặt SonicRec.app/"


def goi_zip(tep: dict, goc: str = APP_CAI, them: dict | None = None,
            quyen_chay: bool = True) -> bytes:
    """Tệp zip dựng trong bộ nhớ, như gói cài Mac do dong_goi.py dựng. `them` là các
    tệp nằm ngoài ứng dụng, ví dụ rác __MACOSX khi nén lại trên Mac. quyen_chay=False:
    zip không ghi quyền chạy (nén lại bằng công cụ khác)."""
    bo_dem = io.BytesIO()
    with zipfile.ZipFile(bo_dem, "w") as z:
        for ten, noi_dung in tep.items():
            thong_tin = zipfile.ZipInfo(goc + ten)
            chay = quyen_chay and ten == bbh.TEP_CHAY_MAC
            thong_tin.external_attr = (0o100755 if chay else 0o100644) << 16
            z.writestr(thong_tin, noi_dung)
        for ten, noi_dung in (them or {}).items():
            thong_tin = zipfile.ZipInfo("x")
            thong_tin.filename = ten  # gán sau cho dấu gạch ngược giữ nguyên trên mọi máy
            z.writestr(thong_tin, noi_dung)
    return bo_dem.getvalue()


def goi_mau(doi: dict | None = None) -> dict:
    """Các tệp của ứng dụng cài đặt trong gói Mac: mã chính lấy từ chính bản đang chạy,
    `doi` thay vài tệp của mã ứng dụng."""
    tep = {bbh.DUONG_GOI_MAC + t: (THU_MUC / t).read_bytes() for t in bbh.TEP_PHIEN_BAN}
    tep.update({bbh.TEP_CHAY_MAC: "#!/bin/bash\n", "Contents/Info.plist": b"<plist/>",
                bbh.DUONG_GOI_MAC + "tai_nguyen/hinh/logo.png": b"png"})
    tep.update({bbh.DUONG_GOI_MAC + t: du_lieu for t, du_lieu in (doi or {}).items()})
    return tep


def goi_exe(phien_ban: str, dau: bytes = b"MZ", so: str | None = None) -> bytes:
    """Tệp .exe giả: đầu MZ, dòng BBH-PHIEN-BAN=<dấu mã> ghi kiểu UTF-16 như thông tin tệp
    trình cài NSIS ghi. so: số phiên bản ("1", "1.1"...), ghi thêm ";BBH-SO-BAN=<số>" như
    NSIS (bỏ trống là tệp cài kiểu cũ, chưa có số)."""
    dong = phien_ban + (f";BBH-SO-BAN={so}" if so is not None else "")
    return (dau + b"\0" * 300 + "Comments\0BBH-PHIEN-BAN=".encode("utf-16-le")
            + dong.encode("utf-16-le") + b"\0\0" + b"x" * 300)


def ma_ban_so(so: str) -> bytes:
    """bien_ban_hop.py của chính máy này nhưng dòng SO_BAN đổi thành `so`: để dựng gói của
    một bản phát hành khác."""
    return re.sub(rb'^SO_BAN = "[^"\n]*"', f'SO_BAN = "{so}"'.encode(),
                  (THU_MUC / "bien_ban_hop.py").read_bytes(), count=1, flags=re.MULTILINE)


# Bản lớn kế và bản nhỏ kế của bản đang chạy (v1 thì v2 và v1.1): để dựng gói "bản mới" mà
# không ghi cứng số, đổi SO_BAN sau này bộ kiểm vẫn đúng
SO_LON_TIEP = bbh.ban_ke_tiep(bbh.SO_BAN)[1]
SO_NHO_TIEP = bbh.ban_ke_tiep(bbh.SO_BAN)[0]


def ban_lien_truoc(so: str) -> str | None:
    """Một bản mà `so` là bản kế tiếp hợp lệ của nó: v2.3 thì v2.2, v2.1 thì v2, v2 thì v1.
    v1 không có bản trước (None): kho lúc đó là bản cũ chưa đánh số."""
    lon, nho = bbh.khoa_so_ban(so)
    if nho > 1:
        return f"{lon}.{nho - 1}"
    return str(lon) if nho == 1 else (str(lon - 1) if lon > 1 else None)


def cap_nhat(c, du_lieu: bytes, ten: str = "CaiDat-SonicRec-Mac-moi.zip", tieu_de=NUT):
    return c.post("/may/cap-nhat", headers=tieu_de,
                  files={"goi": (ten, du_lieu, "application/octet-stream")})


def cho_tat(giay: float = 5) -> int:
    """Ứng dụng hẹn tự tắt sau khi mở trình cài; chờ tới lúc đó rồi đếm số lần tắt."""
    het = time.monotonic() + giay
    while not SO_LAN_TAT[0] and time.monotonic() < het:
        time.sleep(0.1)
    return SO_LAN_TAT[0]


bbh.THU_MUC_CAP_NHAT = TAM / "ban-cap-nhat"
CHAY_TRINH_CAI_THAT = bbh.chay_trinh_cai
MO_TRINH_CAI = []
bbh.chay_trinh_cai = MO_TRINH_CAI.append
SO_LAN_TAT = [0]
bbh.KHI_TAT = lambda: SO_LAN_TAT.__setitem__(0, SO_LAN_TAT[0] + 1)
BAN_MOI = {"giao_dien.html": "<html>bản mới</html>".encode("utf-8")}
# Gói zip là cách cập nhật của máy Mac: giả làm máy Mac cả khi bộ kiểm chạy trên Windows
# thật (máy Windows nhận tệp .exe, kiểm ở phần dưới). Thiếu dòng này thì cài trên Windows
# thật trượt mười mấy phép dù ứng dụng đúng (27/9/2026)
bbh.LA_WINDOWS = False

# Tên phiên bản (PM chốt 30/9/2026): bản lớn là số tròn v1, v2, v3...; bản nhỏ thêm số sau
# dấu chấm v1.1, v2.1, v2.2... Gói Mac mang số ở dòng SO_BAN của bien_ban_hop.py, gói
# Windows mang số trong thông tin tệp (BBH-SO-BAN=)
kiem("số phiên bản đọc được từ dòng SO_BAN (bản lớn và bản nhỏ), chịu được xuống dòng kiểu "
     "Windows và khoảng trắng cuối dòng",
     bbh.so_ban_cua(lambda t: b'x = 1\nSO_BAN = "12"  \nTEN = 2\n') == "12"
     and bbh.so_ban_cua(lambda t: b'SO_BAN = "3"\r\nx\r\n') == "3"
     and bbh.so_ban_cua(lambda t: b'SO_BAN = "2.1"\n') == "2.1"
     and bbh.so_ban_cua(lambda t: b'SO_BAN = "2.10"\n') == "2.10"
     and bbh.so_ban_cua(lambda t: b'SO_BAN = "999.99"\n') == "999.99")
lot = [ten for ten, ma in {
    "dòng bị chú thích": b'# SO_BAN = "3"\n', "dòng thụt vào": b'    SO_BAN = "3"\n',
    "không có dấu nháy (kiểu số nguyên cũ)": b"SO_BAN = 3\n", "nháy đơn": b"SO_BAN = '3'\n",
    "bản nhỏ .0": b'SO_BAN = "2.0"\n', "số 0 đứng đầu": b'SO_BAN = "02"\n',
    "số 0": b'SO_BAN = "0"\n', "ba cấp": b'SO_BAN = "2.1.1"\n', "thừa chữ v": b'SO_BAN = "v3"\n',
    "rỗng": b'SO_BAN = ""\n', "bản lớn quá 3 chữ số": b'SO_BAN = "1000"\n',
    "bản nhỏ quá 2 chữ số": b'SO_BAN = "1.100"\n', "có phép tính": b'SO_BAN = "2" + "1"\n',
    "khai kiểu có chú thích": b'SO_BAN: str = "3"\n', "không có dòng": b"x = 1\n"}.items()
       if bbh.so_ban_cua(lambda t, ma=ma: ma) is not None]
kiem("dòng SO_BAN sai dạng thì không nhận, gói coi như không rõ số", not lot, str(lot))


def _goi_khong_co_ma(t):
    raise KeyError(t)


kiem("gói không có bien_ban_hop.py: không rõ số, không lỗi", bbh.so_ban_cua(_goi_khong_co_ma) is None)
kiem("số phiên bản đọc được từ thông tin tệp cài Windows (bản lớn và bản nhỏ)",
     bbh.so_ban_trong_exe(goi_exe("abc1234", so="7")) == "7"
     and bbh.so_ban_trong_exe(goi_exe("abc1234", so="7.1")) == "7.1"
     and bbh.so_ban_trong_exe(goi_exe("abc1234", so="999.99")) == "999.99")
lot = [ten for ten, du_lieu in {
    "tệp cài kiểu cũ, chưa có số": goi_exe("abc1234"), "số 0": goi_exe("abc1234", so="0"),
    "bản nhỏ .0": goi_exe("abc1234", so="2.0"), "số 0 đứng đầu": goi_exe("abc1234", so="02"),
    "ba cấp": goi_exe("abc1234", so="2.1.1"), "bản lớn quá 3 chữ số": goi_exe("abc1234", so="1000"),
    "bản nhỏ quá 2 chữ số": goi_exe("abc1234", so="1.100"),
    "ghi bằng chữ": goi_exe("abc1234", so="ba"), "rỗng": goi_exe("abc1234", so="")}.items()
       if bbh.so_ban_trong_exe(du_lieu) is not None]
kiem("tệp cài Windows chưa có số hoặc ghi sai dạng thì coi như không rõ số", not lot, str(lot))
# Thứ tự giữa các bản: v1 < v1.1 < v1.2 < v1.10 < v2 < v2.1 (so từng phần bằng số, không so chữ)
xep = ["1", "1.1", "1.2", "1.9", "1.10", "2", "2.1", "2.10", "10", "10.1"]
kiem("thứ tự bản: bản nhỏ đứng sau bản lớn cùng số và trước bản lớn kế (1.10 sau 1.9, 10 sau 2)",
     sorted(reversed(xep), key=bbh.khoa_so_ban) == xep
     and bbh.khoa_so_ban("2") == (2, 0) and bbh.khoa_so_ban("2.10") == (2, 10))
kiem("bản kế tiếp: sau bản lớn là bản nhỏ đầu hoặc bản lớn kế; sau bản nhỏ là bản nhỏ kế hoặc bản lớn kế",
     bbh.ban_ke_tiep("1") == ("1.1", "2") and bbh.ban_ke_tiep("1.1") == ("1.2", "2")
     and bbh.ban_ke_tiep("2.9") == ("2.10", "3") and bbh.ban_ke_tiep("9") == ("9.1", "10"))
DUOC_PHEP = [(None, "1"), ("1", "1.1"), ("1", "2"), ("1.1", "1.2"), ("1.1", "2"), ("2.2", "2.3"),
             ("2.2", "3"), ("1.9", "1.10")]
BI_CHAN = {"kho chưa có bản mà bản mới không phải v1": (None, "2"), "kho chưa có, bản mới v1.1": (None, "1.1"),
           "cùng số": ("1", "1"), "cùng số bản nhỏ": ("1.1", "1.1"), "lùi bản": ("2", "1.1"),
           "lùi từ bản nhỏ về bản lớn cùng số": ("1.1", "1"), "nhảy cóc bản lớn": ("1", "3"),
           "nhảy cóc bản nhỏ": ("1", "1.2"), "bản nhỏ nhảy cóc": ("1.1", "1.3"),
           "nhảy sang bản nhỏ của số lớn kế": ("1", "2.1"), "bản nhỏ .0": ("1", "2.0"),
           "sai dạng": ("1", "02")}
lot = [ten for ten, (cu, moi) in BI_CHAN.items() if bbh.la_ban_ke_tiep(cu, moi)]
kiem("bản kế tiếp hợp lệ được phép; cùng số, lùi, nhảy cóc, sai dạng đều bị chặn",
     all(bbh.la_ban_ke_tiep(cu, moi) for cu, moi in DUOC_PHEP) and not lot, str(lot))

with TestClient(bbh.app, base_url=GOC, client=("127.0.0.1", 50000)) as c:
    kiem("cập nhật thiếu tiêu đề giao diện thì bị chặn",
         cap_nhat(c, goi_zip(goi_mau(BAN_MOI)), tieu_de={}).status_code == 403)
    dap = cap_nhat(c, goi_zip(goi_mau()))
    kiem("gói đúng bản đang chạy: báo không cần cập nhật, nói rõ tên bản, không mở trình cài",
         dap.status_code == 409 and "không cần cập nhật" in dap.json()["detail"]
         and bbh.TEN_BAN in dap.json()["detail"] and not MO_TRINH_CAI, dap.text[:120])
    dap = cap_nhat(c, b"day khong phai tep zip")
    kiem("tệp không phải zip: báo rõ",
         dap.status_code == 400 and "không phải tệp zip" in dap.json()["detail"])
    dap = cap_nhat(c, goi_zip({"bao-cao.docx": b"x"}))
    kiem("tệp zip khác, không phải gói SonicRec: từ chối",
         dap.status_code == 400 and "không phải gói cài" in dap.json()["detail"])
    thieu = goi_mau(BAN_MOI)
    del thieu[bbh.TEP_CHAY_MAC]
    dap = cap_nhat(c, goi_zip(thieu))
    kiem("gói thiếu tệp chạy của trình cài: từ chối",
         dap.status_code == 400 and "không phải gói cài" in dap.json()["detail"])
    dap = cap_nhat(c, goi_zip({t.replace(bbh.DUONG_GOI_MAC, ""): v
                               for t, v in goi_mau(BAN_MOI).items()}, goc="BienBanHop/"))
    kiem("gói kiểu cũ (thư mục BienBanHop, không có ứng dụng cài đặt): từ chối",
         dap.status_code == 400 and "không phải gói cài" in dap.json()["detail"])
    dap = cap_nhat(c, goi_zip(goi_mau(BAN_MOI), goc="BienBanHop/"))
    kiem("đủ tệp nhưng không nằm trong ứng dụng .app (mở ra chỉ là một thư mục): từ chối",
         dap.status_code == 400 and "không phải gói cài" in dap.json()["detail"]
         and not MO_TRINH_CAI, dap.text[:120])
    for ten_la in (APP_CAI + "../../ngoai.txt", "/tmp/ngoai.txt", "C:/ngoai.txt",
                   "BienBanHop\\..\\..\\ngoai.txt"):
        dap = cap_nhat(c, goi_zip(goi_mau(BAN_MOI), them={ten_la: b"ghi de"}))
        kiem(f"tên tệp trỏ ra ngoài ({ten_la}): từ chối cả gói, không giải nén gì",
             dap.status_code == 400 and "trỏ ra ngoài" in dap.json()["detail"]
             and not bbh.THU_MUC_CAP_NHAT.exists() and not (TAM / "ngoai.txt").exists())
    bbh.GIOI_HAN_GIAI_NEN = 1000
    dap = cap_nhat(c, goi_zip(goi_mau(BAN_MOI)))
    kiem("zip giải nén ra quá lớn: từ chối",
         dap.status_code == 400 and "quá lớn" in dap.json()["detail"])
    bbh.GIOI_HAN_GIAI_NEN = 200 * 1024 * 1024
    bbh.GIOI_HAN_GOI = 100
    kiem("tệp tải lên quá lớn: từ chối", cap_nhat(c, goi_zip(goi_mau(BAN_MOI))).status_code == 413)
    bbh.GIOI_HAN_GOI = 50 * 1024 * 1024
    bbh.MAY_GHI.tt = "ghi"
    dap = cap_nhat(c, goi_zip(goi_mau(BAN_MOI)))
    bbh.MAY_GHI.tt = None
    kiem("đang ghi âm: không cập nhật",
         dap.status_code == 409 and "Đang ghi âm" in dap.json()["detail"])
    bbh.VIEC["dang-soan"] = {"trang_thai": "Đang soạn biên bản"}
    dap = cap_nhat(c, goi_zip(goi_mau(BAN_MOI)))
    del bbh.VIEC["dang-soan"]
    kiem("có cuộc họp đang soạn biên bản: không cập nhật", dap.status_code == 409)
    kiem("các lần từ chối không mở trình cài, không tắt ứng dụng",
         not MO_TRINH_CAI and SO_LAN_TAT[0] == 0)

    # Gói bản mới, có kèm rác __MACOSX như khi nén lại trên Mac
    dap = cap_nhat(c, goi_zip(goi_mau(BAN_MOI),
                              them={"__MACOSX/" + APP_CAI + "._Info.plist": b"rac"}))
    k = dap.json() if dap.status_code == 200 else {}
    app_cai = bbh.THU_MUC_CAP_NHAT / APP_CAI
    ma_moi = app_cai / bbh.DUONG_GOI_MAC
    kiem("gói bản mới: giải nén đủ ứng dụng cài đặt vào thư mục riêng, bỏ rác __MACOSX",
         dap.status_code == 200
         and (ma_moi / "giao_dien.html").read_text(encoding="utf-8") == "<html>bản mới</html>"
         and (ma_moi / "tai_nguyen" / "hinh" / "logo.png").is_file()
         and (app_cai / "Contents" / "Info.plist").is_file()
         and not (bbh.THU_MUC_CAP_NHAT / "__MACOSX").exists(), dap.text[:120])
    kiem("gói bản mới: báo đúng phiên bản sẽ hiện sau khi cài, khác bản đang chạy",
         k.get("cu") == bbh.PHIEN_BAN and k.get("phien_ban") != bbh.PHIEN_BAN
         and k.get("phien_ban") == bbh.dau_phien_ban(lambda t: (ma_moi / t).read_bytes()), str(k))
    kiem("gói bản mới: báo tên bản người dùng thấy (mã nguồn cùng số thứ tự thì cùng tên)",
         k.get("ten_moi") == bbh.TEN_BAN and k.get("ten_cu") == bbh.TEN_BAN, str(k))
    kiem("gói bản mới: mở đúng ứng dụng cài đặt của gói, một lần",
         MO_TRINH_CAI == [app_cai], str(MO_TRINH_CAI))
    if os.name != "nt":
        kiem("tệp chạy của trình cài giải nén ra có quyền chạy, tệp khác thì không",
             os.access(app_cai / bbh.TEP_CHAY_MAC, os.X_OK)
             and not os.access(ma_moi / "giao_dien.html", os.X_OK))
    kiem("mở trình cài xong thì ứng dụng tự tắt để trình cài thay tệp", cho_tat() == 1)

    # Gói của bản phát hành khác: người dùng thấy tên theo số (v1 lên v2 hay v1.1), dấu mã là
    # phần phụ
    for so_tiep, ten_loai in ((SO_LON_TIEP, "lớn"), (SO_NHO_TIEP, "nhỏ")):
        MO_TRINH_CAI.clear()
        SO_LAN_TAT[0] = 0
        dap = cap_nhat(c, goi_zip(goi_mau({"bien_ban_hop.py": ma_ban_so(so_tiep)})))
        k = dap.json() if dap.status_code == 200 else {}
        kiem(f"gói của bản {ten_loai} kế tiếp: báo lên v{so_tiep} từ bản đang chạy, kèm cả dấu mã",
             dap.status_code == 200 and k.get("ten_moi") == f"v{so_tiep}"
             and k.get("ten_cu") == bbh.TEN_BAN and k.get("cu") == bbh.PHIEN_BAN
             and k.get("phien_ban") != bbh.PHIEN_BAN, str(k))
        cho_tat()

    # Giải nén rồi nén lại: thư mục gốc khác, tên có dấu ghi kiểu NFD như Finder của Mac,
    # zip không giữ quyền chạy. Vẫn nhận; bản giải nén cũ bị xoá
    MO_TRINH_CAI.clear()
    SO_LAN_TAT[0] = 0
    goc_nfd = "CaiDat-SonicRec-Mac-abc1234/" + unicodedata.normalize("NFD", APP_CAI)
    dap = cap_nhat(c, goi_zip(goi_mau({"giao_dien.html": b"<html>2</html>"}), goc=goc_nfd,
                              quyen_chay=False))
    app2 = bbh.THU_MUC_CAP_NHAT / goc_nfd
    kiem("gói nén lại (thư mục gốc khác, tên kiểu NFD, mất quyền chạy) vẫn nhận và chạy được",
         dap.status_code == 200 and MO_TRINH_CAI == [app2]
         and (os.name == "nt" or os.access(app2 / bbh.TEP_CHAY_MAC, os.X_OK)), dap.text[:120])
    kiem("lần cập nhật sau xoá bản giải nén của lần trước", not app_cai.exists())
    cho_tat()

    # Không mở được trình cài: nói chỗ mở tay, ứng dụng KHÔNG tự tắt
    def mo_hong(tep):
        raise OSError("không mở được cửa sổ")
    bbh.chay_trinh_cai = mo_hong
    SO_LAN_TAT[0] = 0
    dap = cap_nhat(c, goi_zip(goi_mau({"giao_dien.html": b"<html>3</html>"})))
    time.sleep(2)
    kiem("không mở được trình cài: báo chỗ mở tay, ứng dụng vẫn mở",
         dap.status_code == 500 and "Mở tay" in dap.json()["detail"] and SO_LAN_TAT[0] == 0,
         dap.text[:150])
    bbh.chay_trinh_cai = MO_TRINH_CAI.append

    # Windows: tệp cài là .exe, bản ghi trong thông tin tệp
    bbh.LA_WINDOWS = True
    MO_TRINH_CAI.clear()
    SO_LAN_TAT[0] = 0
    dap = cap_nhat(c, goi_exe(bbh.PHIEN_BAN), "CaiDat-SonicRec-Windows-x.exe")
    kiem("Windows: tệp cài đúng bản đang chạy thì báo không cần cập nhật",
         dap.status_code == 409 and "không cần cập nhật" in dap.json()["detail"], dap.text[:120])
    for ten, du_lieu in (("zip", goi_zip(goi_mau(BAN_MOI))), ("exe khác", b"MZ" + b"\0" * 900),
                         ("không có đầu MZ", goi_exe("abc1234", b"PK")),
                         ("bản ghi sai dạng", goi_exe("abc 123"))):
        dap = cap_nhat(c, du_lieu, "tep.exe")
        kiem(f"Windows: {ten} thì từ chối, nói rõ tệp cần chọn",
             dap.status_code == 400 and "CaiDat-SonicRec-Windows" in dap.json()["detail"],
             dap.text[:120])
    kiem("Windows: các lần từ chối không mở trình cài", not MO_TRINH_CAI)
    exe = goi_exe("abc1234")
    dap = cap_nhat(c, exe, "CaiDat-SonicRec-Windows-abc1234.exe")
    tep_exe = bbh.THU_MUC_CAP_NHAT / "CaiDat-SonicRec-Windows-abc1234.exe"
    kiem("Windows: tệp cài bản mới được lưu nguyên vẹn, mở một lần, báo đúng bản",
         dap.status_code == 200 and dap.json().get("phien_ban") == "abc1234"
         and tep_exe.read_bytes() == exe and MO_TRINH_CAI == [tep_exe], dap.text[:120])
    kiem("Windows: tệp cài kiểu cũ chưa ghi số thì tên bản mới hiện bằng dấu mã",
         dap.json().get("ten_moi") == "abc1234" and dap.json().get("ten_cu") == bbh.TEN_BAN, dap.text[:120])
    kiem("Windows: mở trình cài xong thì ứng dụng tự tắt", cho_tat() == 1)
    MO_TRINH_CAI.clear()
    SO_LAN_TAT[0] = 0
    dap = cap_nhat(c, goi_exe("abc1234", so="7"), "CaiDat-SonicRec-Windows-v7.exe")
    kiem("Windows: tệp cài ghi số phiên bản thì tên bản mới là v<số>",
         dap.status_code == 200 and dap.json().get("ten_moi") == "v7"
         and dap.json().get("phien_ban") == "abc1234", dap.text[:120])
    cho_tat()
    MO_TRINH_CAI.clear()
    SO_LAN_TAT[0] = 0
    dap = cap_nhat(c, goi_exe("abc1234", so="7.2"), "CaiDat-SonicRec-Windows-v7.2.exe")
    kiem("Windows: tệp cài bản nhỏ thì tên bản mới có cả số sau dấu chấm (v7.2)",
         dap.status_code == 200 and dap.json().get("ten_moi") == "v7.2", dap.text[:120])
    cho_tat()
    bbh.LA_WINDOWS = os.name == "nt"

# Gói thật dựng bằng dong_goi.py. Tệp này chỉ có trong kho mã (trình cài không chép
# nó sang máy người dùng), nên máy đã cài thì bỏ qua phần này.
if (THU_MUC / "dong_goi.py").is_file():
    import dong_goi
    tep_mac, tep_win = dong_goi.dong_goi(TAM)
    with zipfile.ZipFile(tep_mac) as z:
        goi_that = {t.filename[len(APP_CAI):]: z.read(t) for t in z.infolist()}
        quyen = {t.filename[len(APP_CAI):]: (t.external_attr >> 16) & 0o777 for t in z.infolist()}
    kiem("gói Mac chỉ có ứng dụng Cài đặt SonicRec.app, tệp chạy có quyền chạy",
         all(t.startswith("Contents/") for t in goi_that) and quyen[bbh.TEP_CHAY_MAC] == 0o755
         and goi_that[bbh.TEP_CHAY_MAC] == (THU_MUC / "trinh_cai" / "cai_dat_mac.sh").read_bytes(),
         str(sorted(goi_that))[:200])
    import plistlib  # noqa: E402
    ds = plistlib.loads(goi_that["Contents/Info.plist"])
    kiem("gói Mac: Info.plist đúng tên, tệp chạy, biểu tượng, dấu tên",
         ds["CFBundleExecutable"] == "cai-dat" and ds["CFBundleName"] == "Cài đặt SonicRec"
         and ds["CFBundleDisplayName"] == "Cài đặt SonicRec"
         and ds["NSHumanReadableCopyright"] == "© 2026 Nguyễn Nam Hải"
         and "Contents/Resources/bieu-tuong.icns" in goi_that, str(ds))
    kiem("gói Mac thật: trình cài hiện tên bản (gói dựng thử mang thêm dấu mã, như v1-1cae91c), "
         "và mã trong gói mang đúng số thứ tự phát hành",
         goi_that["Contents/Resources/phien-ban"] == f"{bbh.TEN_BAN}-{bbh.PHIEN_BAN}".encode("ascii")
         and bbh.so_ban_cua(lambda t: goi_that[bbh.DUONG_GOI_MAC + t]) == bbh.SO_BAN)
    kiem("gói Mac không mang logo hay phông riêng của Trường, có phông Be Vietnam Pro kèm giấy phép",
         not [t for t in goi_that if re.search(r"logo-tlu|ThangLong|Manrope", t)]
         and bbh.DUONG_GOI_MAC + "tai_nguyen/phong/BeVietnamPro-OFL.txt" in goi_that
         and bbh.DUONG_GOI_MAC + "tai_nguyen/phong/BeVietnamPro-700-vietnamese.woff2" in goi_that)
    # Ảnh dải bên trái của trình cài Windows (BMP 24 bit): vùng trên đã từng có logo Thăng Long
    # phải trơn một màu nền. Đọc thẳng byte, không cần thư viện ảnh
    bmp = (THU_MUC / "trinh_cai" / "ben-trai.bmp").read_bytes()
    bmp_dau, bmp_rong, bmp_cao, bmp_bit = (struct.unpack("<I", bmp[10:14])[0], *struct.unpack("<ii", bmp[18:26]),
                                           struct.unpack("<H", bmp[28:30])[0])
    bmp_hang = ((bmp_rong * bmp_bit + 31) // 32) * 4

    def bmp_diem(x, y_tren):  # (x, y) tính từ góc trên trái; BMP lưu hàng dưới cùng trước
        i = bmp_dau + (bmp_cao - 1 - y_tren) * bmp_hang + x * 3
        return bmp[i:i + 3]
    nen_bmp = bmp_diem(2, 2)
    kiem("ảnh dải bên trái của trình cài Windows: BMP 24 bit, vùng trên (từng có logo Thăng Long) chỉ còn màu nền",
         bmp[:2] == b"BM" and bmp_bit == 24 and bmp_cao > 0
         and all(bmp_diem(x, y) == nen_bmp for y in range(15, 80) for x in range(bmp_rong)),
         f"{bmp_rong}x{bmp_cao} {bmp_bit} bit")
    hinh = THU_MUC / "tai_nguyen" / "hinh"
    png = (hinh / "bieu-tuong.png").read_bytes()
    ico = (hinh / "bieu-tuong.ico").read_bytes()
    icns = (hinh / "bieu-tuong.icns").read_bytes()
    khoi_icns, vi_tri = [], 8
    while vi_tri < len(icns):
        loai_khoi, dai_khoi = icns[vi_tri:vi_tri + 4], struct.unpack(">I", icns[vi_tri + 4:vi_tri + 8])[0]
        khoi_icns.append((loai_khoi, struct.unpack(">II", icns[vi_tri + 8 + 16:vi_tri + 8 + 24])))
        vi_tri += dai_khoi
    kiem("biểu tượng ứng dụng: PNG 1024x1024 có kênh trong suốt; ICO đủ 7 cỡ từ 16 tới 256; ICNS của Mac đủ 8 khối "
         "PNG (128, 256, 512, 1024, 32, 64 và hai khối gấp đôi) và độ dài khối khớp tổng",
         png[:8] == b"\x89PNG\r\n\x1a\n" and struct.unpack(">II", png[16:24]) == (1024, 1024) and png[25] == 6
         and ico[:4] == b"\x00\x00\x01\x00" and struct.unpack("<H", ico[4:6])[0] == 7
         and icns[:4] == b"icns" and struct.unpack(">I", icns[4:8])[0] == len(icns) and vi_tri == len(icns)
         and sorted(d for _, d in khoi_icns) == sorted([(128, 128), (256, 256), (512, 512), (1024, 1024), (32, 32),
                                                        (64, 64), (256, 256), (512, 512)]), str(khoi_icns))
    dau_bmp = (THU_MUC / "trinh_cai" / "dau-trang.bmp").read_bytes()
    kiem("ảnh đầu trang của trình cài Windows: BMP 24 bit không nén, 150x57",
         dau_bmp[:2] == b"BM" and struct.unpack("<ii", dau_bmp[18:26]) == (150, 57)
         and struct.unpack("<H", dau_bmp[28:30])[0] == 24 and struct.unpack("<I", dau_bmp[30:34])[0] == 0)
    if (THU_MUC / "dung_bieu_tuong.py").is_file():
        try:
            import fontTools  # noqa: F401
        except ImportError:
            print("  (máy không có fonttools: bỏ qua phép so logo với bản dựng)")
        else:
            import dung_bieu_tuong as dbt  # noqa: E402
            mau_goc = dbt.doc_mau()
            kiem("logo ở dải trên khớp đúng bản dựng từ bảng màu ở :root (lệch thì chạy lại dung_bieu_tuong.py "
                 "và dán dấu hiệu SVG mới); bảng màu có đủ biến cho tệp dựng",
                 dbt.svg_dau_muc(mau_goc) in (THU_MUC / "giao_dien.html").read_text(encoding="utf-8")
                 and mau_goc["dai-tren"] == "#0abab5" and mau_goc["chinh"] == "#0c4a54")
    # Cài một lần là xong (PM 28/9/2026): không Homebrew, Python dựng sẵn, trình mở dựng sẵn
    kiem("gói Mac mang bản Python cần tải kèm mã kiểm tra, các gói ghim bản và trình mở dựng sẵn "
         "(trình mở có quyền chạy)",
         all(goi_that.get(bbh.DUONG_GOI_MAC + t) == (THU_MUC / "trinh_cai" / t).read_bytes()
             for t in dong_goi.TEP_MAC_TRINH_CAI)
         and quyen.get(bbh.DUONG_GOI_MAC + "trinh-mo-mac") == 0o755, str(dong_goi.TEP_MAC_TRINH_CAI))
    env_py = dict(d.split("=", 1) for d in (THU_MUC / "trinh_cai" / "python-mac.env")
                  .read_text(encoding="utf-8").splitlines() if d and not d.startswith("#"))
    nhan = env_py.get("PY_GOC", "").rsplit("/", 1)[-1]
    kiem("python-mac.env: Python dựng sẵn ghim đúng một bản cho chip Apple và Intel, có mã sha256",
         env_py.get("PY_GOC", "").startswith(
             "https://github.com/astral-sh/python-build-standalone/releases/download/")
         and all(re.fullmatch(rf"cpython-{re.escape(env_py.get('PY_NHANH', '?'))}\.\d+\+{nhan}-{kt}"
                              r"-apple-darwin-install_only\.tar\.gz", env_py.get(f"PY_TEP_{k}", ""))
                 and re.fullmatch(r"[0-9a-f]{64}", env_py.get(f"PY_MA_{k}", ""))
                 for k, kt in (("ARM", "aarch64"), ("X86", "x86_64"))), str(env_py))
    ghim = [d for d in (THU_MUC / "trinh_cai" / "yeu-cau-mac.txt").read_text(encoding="utf-8")
            .splitlines() if d and not d.startswith("#")]
    ban_ghim = dict(d.split("==", 1) for d in ghim if "==" in d)
    kiem("yeu-cau-mac.txt: mọi gói ghim đúng một bản, đủ các gói ứng dụng cần (có imageio-ffmpeg "
         "cho phần ghi âm, notebooklm-py từ 0.8.3)",
         bool(ghim) and all(re.fullmatch(r"[a-z0-9._-]+==[0-9][0-9A-Za-z.+-]*", d) for d in ghim)
         and {"fastapi", "uvicorn", "python-multipart", "httpx", "python-docx", "pywebview",
              "notebooklm-py", "segno", "imageio-ffmpeg", "playwright"} <= set(ban_ghim)
         and tuple(int(x) for x in ban_ghim.get("notebooklm-py", "0").split(".")[:3]) >= (0, 8, 3),
         str(ghim)[:200])
    cai_mac = (THU_MUC / "trinh_cai" / "cai_dat_mac.sh").read_text(encoding="utf-8")
    lenh_cai = [d for d in cai_mac.splitlines() if d.strip() and not d.lstrip().startswith("#")]
    kiem("trình cài Mac không gọi Homebrew, không hỏi mật khẩu, không đòi công cụ dòng lệnh của Apple",
         not [d for d in lenh_cai if re.search(r"\bbrew\b|homebrew|sudo|xcode-select|hoi-mat-khau",
                                               d, re.IGNORECASE)],
         str([d for d in lenh_cai if re.search(r"brew|sudo|xcode", d, re.IGNORECASE)])[:200])
    kiem("trình cài Mac so mã sha256 của Python tải về, cài gói theo danh sách ghim, lấy ffmpeg đi kèm",
         '. "$GOI/python-mac.env"' in cai_mac and '[ "$MA_TAI" = "$PY_MA" ]' in cai_mac
         and '-r "$GOI/yeu-cau-mac.txt"' in cai_mac and "imageio_ffmpeg" in cai_mac
         and 'export PATH="$DICH/ffmpeg:$PATH"' in cai_mac)
    san_kho = THU_MUC / "trinh_cai" / "trinh-mo-mac"
    kiem("trình mở dựng sẵn trong kho dựng từ đúng mã trình mở hiện tại (đổi MA_C thì dựng lại "
         "bằng luồng bien-ban-hop-mac.yml)",
         san_kho.is_file() and san_kho.read_bytes()[:4] == b"\xca\xfe\xba\xbe"
         and f"BBH-MA-NGUON={tao_ung_dung.dau_ma_nguon()}".encode() in san_kho.read_bytes())
    with TestClient(bbh.app, base_url=GOC, client=("127.0.0.1", 50000)) as c:
        dap = cap_nhat(c, tep_mac.read_bytes(), tep_mac.name)
        kiem("gói Mac thật dựng từ chính mã này: đúng dạng gói, mang đúng phiên bản đang chạy",
             dap.status_code == 409 and bbh.PHIEN_BAN in dap.json()["detail"]
             and bbh.TEN_BAN in dap.json()["detail"]
             and tep_mac.name == f"CaiDat-SonicRec-Mac-{bbh.TEN_BAN}-{bbh.PHIEN_BAN}.zip", dap.text[:120])
        MO_TRINH_CAI.clear()
        goi_that[bbh.DUONG_GOI_MAC + "giao_dien.html"] = b"<html>ban khac</html>"
        dap = cap_nhat(c, goi_zip(goi_that))
        ma_moi = bbh.THU_MUC_CAP_NHAT / APP_CAI / bbh.DUONG_GOI_MAC
        kiem("gói Mac thật bản khác: giải nén đủ tệp trình cài cần",
             dap.status_code == 200 and all((ma_moi / t).is_file() for t in (
                 "bien_ban_hop.py", "ung_dung.py", "tao_ung_dung.py", "kiem_thu.py",
                 "Bat Bien Ban Hop.command", "thong_tin_cuoc_hop.json",
                 "tai_nguyen/hinh/bieu-tuong.icns", *dong_goi.TEP_MAC_TRINH_CAI)), dap.text[:120])
        cho_tat()
        if tep_win:
            bbh.LA_WINDOWS = True
            dap = cap_nhat(c, tep_win.read_bytes(), tep_win.name)
            bbh.LA_WINDOWS = os.name == "nt"
            kiem("gói Windows thật: tệp .exe mang đúng phiên bản đang chạy",
                 dap.status_code == 409 and bbh.PHIEN_BAN in dap.json()["detail"]
                 and tep_win.name == f"CaiDat-SonicRec-Windows-{bbh.TEN_BAN}-{bbh.PHIEN_BAN}.exe",
                 dap.text[:120])
            kiem("gói Windows thật: thông tin tệp ghi số thứ tự phát hành đúng với mã nguồn",
                 bbh.so_ban_trong_exe(tep_win.read_bytes()) == bbh.SO_BAN)
            # Đưa bản này lên kho bản mới (bản sao trên máy của kho GitHub): kho đang có bản
            # abc1234, trước nó là 1111111; danh sách cũ lỡ có cả bản đang chạy. SO_BAN là v1
            # thì bản trên kho là kiểu cũ chưa đánh số; không thì là bản liền trước của nó
            kho = TAM / "kho-ban-moi"
            (kho / "ban-cai").mkdir(parents=True)
            (kho / "ban-cai" / "CaiDat-BienBanHop-Mac-abc1234.zip").write_bytes(b"cu")
            (kho / "ban-cai" / "CaiDat-BienBanHop-Windows-abc1234.exe").write_bytes(b"cu")
            (kho / "ban-cai" / "CaiDat-SonicRec-Mac-1111111.zip").write_bytes(b"cu")
            cu_tren_kho = {"phien_ban": "abc1234", "cac_ban_truoc": ["1111111", bbh.PHIEN_BAN]}
            if ban_lien_truoc(bbh.SO_BAN):
                cu_tren_kho["so_ban"] = ban_lien_truoc(bbh.SO_BAN)
            (kho / "ban-moi.json").write_text(json.dumps(cu_tren_kho), encoding="utf-8")
            m = dong_goi.xuat_ban(kho, "Sửa lỗi nhỏ", ngay="28/9/2026")
            ten_kho = sorted(t.name for t in (kho / "ban-cai").iterdir())
            kiem("xuất bản: kho chỉ còn hai tệp cài của bản này, tệp cài cũ bị xoá (cả tên cũ "
                 "CaiDat-BienBanHop lẫn tên SonicRec của bản trước)",
                 ten_kho == sorted(bbh.TEN_TEP_CAI[he].format(bbh.SO_BAN) for he in ("mac", "windows")),
                 str(ten_kho))
            kiem("xuất bản: ban-moi.json qua phép kiểm của ứng dụng, mã và cỡ khớp đúng tệp trên kho",
                 bbh.doc_ban_moi((kho / "ban-moi.json").read_bytes()) == m and all(
                     hashlib.sha256((kho / "ban-cai" / m[he]["tep"]).read_bytes()).hexdigest()
                     == m[he]["sha256"] and (kho / "ban-cai" / m[he]["tep"]).stat().st_size == m[he]["co"]
                     for he in ("mac", "windows")), str(m)[:200])
            kiem("xuất bản: danh sách bản trước thêm bản cũ, bỏ chính bản này",
                 m["phien_ban"] == bbh.PHIEN_BAN and m["cac_ban_truoc"] == ["1111111", "abc1234"],
                 str(m["cac_ban_truoc"]))
            with zipfile.ZipFile(kho / "ban-cai" / m["mac"]["tep"]) as z:
                ten_trong_zip = z.read(APP_CAI + "Contents/Resources/phien-ban")
            kiem("xuất bản: tên bản là v<SO_BAN> và tệp trên kho mang tên trơn, không kèm dấu mã "
                 "như gói dựng thử; gói Windows ghi cả dấu mã lẫn số thứ tự",
                 m["so_ban"] == bbh.SO_BAN
                 and [m[he]["tep"] for he in ("mac", "windows")] ==
                 [f"CaiDat-SonicRec-Mac-{bbh.TEN_BAN}.zip", f"CaiDat-SonicRec-Windows-{bbh.TEN_BAN}.exe"]
                 and ten_trong_zip == bbh.TEN_BAN.encode("ascii")
                 and bbh.so_ban_trong_exe((kho / "ban-cai" / m["windows"]["tep"]).read_bytes()) == bbh.SO_BAN,
                 str(m)[:200])
            chu_readme = (kho / "README.md").read_text(encoding="utf-8")
            kiem("xuất bản: README có đường tải hai tệp cài trên kho, ghi tên bản mới nhất",
                 all(bbh.KHO_MAC_DINH + "ban-cai/" + m[he]["tep"] in chu_readme for he in ("mac", "windows"))
                 and f"**{bbh.TEN_BAN}**" in chu_readme)
            try:
                dong_goi.xuat_ban(kho, "lần hai")
                lan_hai = ""
            except SystemExit as loi:
                lan_hai = str(loi)
            kiem("xuất bản lại đúng bản đã có trên kho thì dừng, không ghi đè",
                 "đã có trên kho" in lan_hai
                 and bbh.doc_ban_moi((kho / "ban-moi.json").read_bytes()) == m, lan_hai)
            # Bản mới phải là bản kế tiếp của bản trên kho (sau v1 là v1.1 hoặc v2): cùng số hay
            # lùi đều dừng. Nhảy cóc kiểm ở phép thử la_ban_ke_tiep phía trên
            for ten_kho2, so_tren_kho in (("cùng số", bbh.SO_BAN), ("lùi", SO_LON_TIEP)):
                kho2 = TAM / f"kho-sai-so-{so_tren_kho}"
                kho2.mkdir()
                (kho2 / "ban-moi.json").write_text(json.dumps(
                    {"phien_ban": "abc1234", "so_ban": so_tren_kho, "cac_ban_truoc": []}), encoding="utf-8")
                try:
                    dong_goi.xuat_ban(kho2, "sai số")
                    sai_so = ""
                except SystemExit as loi:
                    sai_so = str(loi)
                duoc = " hoặc ".join("v" + b for b in bbh.ban_ke_tiep(so_tren_kho))
                kiem(f"xuất bản khi kho đang giữ v{so_tren_kho} ({ten_kho2}): dừng, nói bản này chỉ có "
                     f"thể là {duoc}, không ghi gì vào kho",
                     f"chỉ có thể là {duoc}" in sai_so and not (kho2 / "ban-cai").exists()
                     and not (kho2 / "README.md").exists(), sai_so)
        else:
            print("  (máy không có makensis: bỏ qua gói Windows thật)")

# Tự báo bản mới qua kho GitHub công khai (PM chốt 27/9/2026: dùng kho GitHub, hỏi trước
# khi cài). Kho giả là một máy chủ HTTP nhỏ chạy ngay trên máy này: không gọi mạng thật.
with TestClient(bbh.app, base_url=GOC, client=("127.0.0.1", 50000)) as c:
    tt = c.get("/may/trang-thai").json()
kiem("bộ kiểm không xem kho bản mới thật: KHO_BAN_MOI rỗng thì không bật việc xem",
     bbh.KHO_BAN_MOI == "" and bbh.XEM_BAN_MOI["task"] is None and "ban_moi" in tt
     and tt["ban_moi"] is None, str(tt.get("ban_moi")))


class KhoGia(http.server.BaseHTTPRequestHandler):
    """TEP: đường dẫn -> dữ liệu, ("chuyen", đường mới) để thử kho chuyển hướng (GitHub
    chuyển hướng khi kho đổi tên), hoặc danh sách mẩu gửi rỉ rả 0,3 giây một mẩu. GOI ghi
    lại các đường đã được gọi."""
    TEP: dict = {}
    GOI: list = []

    def do_GET(self):
        KhoGia.GOI.append(self.path)
        v = KhoGia.TEP.get(self.path)
        if isinstance(v, tuple):
            self.send_response(302)
            self.send_header("Location", v[1])
            self.end_headers()
            return
        if isinstance(v, list):
            self.send_response(200)
            self.send_header("Content-Length", str(sum(len(x) for x in v)))
            self.end_headers()
            try:
                for x in v:
                    self.wfile.write(x)
                    self.wfile.flush()
                    time.sleep(0.3)
            except OSError:  # máy đã thôi tải giữa chừng
                pass
            return
        du_lieu = b"Not Found" if v is None else v
        self.send_response(404 if v is None else 200)
        self.send_header("Content-Length", str(len(du_lieu)))
        self.end_headers()
        self.wfile.write(du_lieu)

    def log_message(self, *a):
        pass


may_kho = http.server.ThreadingHTTPServer(("127.0.0.1", 0), KhoGia)
threading.Thread(target=may_kho.serve_forever, daemon=True).start()
KHO_GIA = f"http://127.0.0.1:{may_kho.server_address[1]}/"
# Kho giả nằm trên máy: không đi qua proxy nào của máy (máy trường có thể đặt proxy)
PROXY_CU = {k: os.environ.get(k) for k in ("NO_PROXY", "no_proxy")}
os.environ["NO_PROXY"] = os.environ["no_proxy"] = "*"

# Bản trên kho là bản lớn kế tiếp của bản đang chạy (v1 thì v2): số phiên bản cao hơn, mã khác
SO_KHO = SO_LON_TIEP
SO_KHO_SAI = bbh.ban_ke_tiep(SO_KHO)[1]  # một số hợp lệ khác số thật của gói trên kho
TEP_KHO = goi_mau({"giao_dien.html": "<html>bản tải từ kho</html>".encode("utf-8"),
                   "bien_ban_hop.py": ma_ban_so(SO_KHO)})
BAN_KHO = bbh.dau_phien_ban(lambda t: TEP_KHO[bbh.DUONG_GOI_MAC + t])
ZIP_KHO, EXE_KHO = goi_zip(TEP_KHO), goi_exe(BAN_KHO, so=SO_KHO)


def ban_moi_json(phien_ban: str | None = None, truoc: list | None = None,
                 so: str | None = None) -> dict:
    """ban-moi.json như dong_goi.py --xuat-ban viết, chỉ tới ZIP_KHO và EXE_KHO. so: số phiên
    bản ("2", "1.1"...) ghi trong ban-moi.json (tên tệp cài theo số này); bỏ trống là SO_KHO,
    số thật của gói."""
    ban = phien_ban or BAN_KHO
    so = SO_KHO if so is None else so
    return {"phien_ban": ban, "so_ban": so, "ngay": "28/9/2026", "ghi_chu": "Sửa lỗi <b>nhỏ</b>",
            "cac_ban_truoc": [bbh.PHIEN_BAN] if truoc is None else truoc,
            **{he: {"tep": bbh.TEN_TEP_CAI[he].format(so),
                    "sha256": hashlib.sha256(du_lieu).hexdigest(), "co": len(du_lieu)}
               for he, du_lieu in (("mac", ZIP_KHO), ("windows", EXE_KHO))}}


def dat_kho(m) -> None:
    """Kho giả có ban-moi.json (m là bảng, hoặc dữ liệu thô) và hai tệp cài nó chỉ tới;
    m là None thì kho trống."""
    KhoGia.TEP.clear()
    KhoGia.GOI.clear()
    if isinstance(m, dict):
        KhoGia.TEP["/ban-moi.json"] = json.dumps(m).encode("utf-8")
        KhoGia.TEP["/ban-cai/" + m["mac"]["tep"]] = ZIP_KHO
        KhoGia.TEP["/ban-cai/" + m["windows"]["tep"]] = EXE_KHO
    elif m is not None:
        KhoGia.TEP["/ban-moi.json"] = m


M_DUNG = ban_moi_json()
kiem("ban-moi.json đúng dạng thì đọc được",
     bbh.doc_ban_moi(json.dumps(M_DUNG).encode("utf-8")) == M_DUNG)
SAI_DANG = {
    "không phải JSON": b"<html>404</html>",
    "không phải bảng": [1, 2],
    "phiên bản sai dạng": {**M_DUNG, "phien_ban": "abc 123"},
    "thiếu số thứ tự phát hành (ban-moi.json kiểu cũ, trước 30/9/2026)": {
        k: v for k, v in M_DUNG.items() if k != "so_ban"},
    "ban-moi.json kiểu cũ: tên tệp cài theo dấu mã, không theo số": {
        **{k: v for k, v in M_DUNG.items() if k != "so_ban"},
        "mac": {**M_DUNG["mac"], "tep": f"CaiDat-SonicRec-Mac-{BAN_KHO}.zip"},
        "windows": {**M_DUNG["windows"], "tep": f"CaiDat-SonicRec-Windows-{BAN_KHO}.exe"}},
    # Các dòng dưới đặt tên tệp khớp đúng giá trị số (v2, v2.0, vTrue...) để chỉ phép kiểm
    # KIỂU và DẠNG của số quyết định nhận hay từ chối, không nhờ phép so tên tệp
    **{f"số phiên bản {ten}": {**M_DUNG, "so_ban": gia_tri, **{
        he: {**M_DUNG[he], "tep": bbh.TEN_TEP_CAI[he].format(gia_tri)} for he in ("mac", "windows")}}
       for ten, gia_tri in {
        "là số nguyên (kiểu cũ)": int(SO_KHO.split(".")[0]), "là số thực": float(SO_KHO),
        "là true": True, "là null": None, "bản nhỏ .0": SO_KHO + ".0", "số 0 đứng đầu": "0" + SO_KHO,
        "bằng 0": "0", "ba cấp": SO_KHO + ".1.1", "thừa chữ v": "v" + SO_KHO, "rỗng": "",
        "bản lớn quá 3 chữ số": "1000", "bản nhỏ quá 2 chữ số": SO_KHO + ".100",
        "có khoảng trắng": SO_KHO + " ", "có dấu phẩy": SO_KHO.replace(".", ",") + ",1"}.items()},
    "tên tệp ghi số khác so_ban": {**M_DUNG, "so_ban": SO_KHO_SAI},
    "thiếu tệp Windows": {k: v for k, v in M_DUNG.items() if k != "windows"},
    "tên tệp trỏ ra ngoài kho": {**M_DUNG, "mac": {**M_DUNG["mac"], "tep": "../../" + M_DUNG["mac"]["tep"]}},
    "tên tệp khác bản ghi trong ban-moi.json": {**M_DUNG, "mac": {**M_DUNG["mac"],
                                                "tep": "CaiDat-SonicRec-Mac-v99.zip"}},
    "tệp mang tên cũ, trước khi đổi tên SonicRec": {**M_DUNG, "mac": {**M_DUNG["mac"], "tep": M_DUNG["mac"][
        "tep"].replace("SonicRec", "BienBanHop")}},
    "tệp Mac lại là .exe": {**M_DUNG, "mac": {**M_DUNG["mac"], "tep": M_DUNG["windows"]["tep"]}},
    "mã sha256 sai dạng": {**M_DUNG, "windows": {**M_DUNG["windows"], "sha256": "abc"}},
    "cỡ bằng 0": {**M_DUNG, "windows": {**M_DUNG["windows"], "co": 0}},
    "cỡ vượt giới hạn gói": {**M_DUNG, "windows": {**M_DUNG["windows"], "co": bbh.GIOI_HAN_GOI + 1}},
    "cỡ ghi bằng chữ": {**M_DUNG, "windows": {**M_DUNG["windows"], "co": str(len(EXE_KHO))}},
    "danh sách bản trước không phải danh sách": {**M_DUNG, "cac_ban_truoc": bbh.PHIEN_BAN},
}
lot = [ten for ten, m in SAI_DANG.items()
       if bbh.doc_ban_moi(m if isinstance(m, bytes) else json.dumps(m).encode("utf-8")) is not None]
kiem("ban-moi.json sai dạng ở bất kỳ chỗ nào thì coi như không có bản mới", not lot, str(lot))
kiem("mời cập nhật khi bản đang chạy là bản đã phát hành trước bản mới, cả bản lớn lẫn bản nhỏ",
     bbh.co_nen_bao(M_DUNG) and bbh.co_nen_bao(ban_moi_json(so=SO_NHO_TIEP)))
kiem("không mời khi kho báo đúng bản đang chạy (cùng mã, cùng số)",
     not bbh.co_nen_bao(ban_moi_json(phien_ban=bbh.PHIEN_BAN, so=bbh.SO_BAN)))
kiem("không mời khi kho báo đúng mã đang chạy, dù ban-moi.json ghi số cao hơn",
     not bbh.co_nen_bao(ban_moi_json(phien_ban=bbh.PHIEN_BAN)))
kiem("không mời khi số thứ tự trên kho không cao hơn bản đang chạy (bản mã khác nhưng cùng số là "
     "bản dựng thử, không phải bản phát hành mới)",
     not bbh.co_nen_bao(ban_moi_json(so=bbh.SO_BAN)))
kiem("không mời bản thử chưa phát hành (bản đang chạy không có trong danh sách bản trước)",
     not bbh.co_nen_bao(ban_moi_json(truoc=["abc1234"])))
kiem("không có ban-moi.json thì không mời", not bbh.co_nen_bao(None))
# So sánh phiên bản khi máy đang chạy một bản nhỏ (giả làm máy chạy v2.1): chỉ mời bản cao hơn
SO_BAN_THAT = bbh.SO_BAN
bbh.SO_BAN = "2.1"
try:
    moi_khong = {so: bbh.co_nen_bao(ban_moi_json(so=so)) for so in
                 ("1", "1.9", "2", "2.1", "2.2", "2.10", "3", "3.1", "10")}
finally:
    bbh.SO_BAN = SO_BAN_THAT
kiem("máy chạy v2.1: mời v2.2, v2.10, v3, v3.1, v10; không mời v1, v1.9, v2, v2.1 (so từng phần bằng số)",
     moi_khong == {"1": False, "1.9": False, "2": False, "2.1": False, "2.2": True, "2.10": True,
                   "3": True, "3.1": True, "10": True}, str(moi_khong))

dat_kho(M_DUNG)
KhoGia.TEP["/doi-ten/ban-moi.json"] = ("chuyen", "/ban-moi.json")
kiem("tải tệp từ kho, đi theo chuyển hướng",
     asyncio.run(bbh.tai_ve(KHO_GIA + "doi-ten/ban-moi.json", 64 * 1024, 5))
     == KhoGia.TEP["/ban-moi.json"])
for ten, url, gioi_han, loai in (
        ("tệp lớn hơn cỡ đã báo thì thôi tải ngay", "ban-cai/" + M_DUNG["mac"]["tep"], 100, bbh.LoiRo),
        ("tệp không có trên kho thì báo lỗi, không lấy trang lỗi làm dữ liệu", "khong-co.json", 1000,
         bbh.httpx.HTTPStatusError)):
    try:
        asyncio.run(bbh.tai_ve(KHO_GIA + url, gioi_han, 5))
        loi = None
    except Exception as e:  # noqa: BLE001
        loi = e
    kiem(ten, isinstance(loi, loai), repr(loi)[:120])
KhoGia.TEP["/ri-ra"] = [b"x" * 10] * 10  # mỗi mẩu tới kịp hạn chờ, cả tệp mất 3 giây
bat_dau = time.monotonic()
try:
    asyncio.run(bbh.tai_ve(KHO_GIA + "ri-ra", 1000, 1))
    loi = None
except Exception as e:  # noqa: BLE001
    loi = e
kiem("mạng rỉ rả quá hạn giờ của cả lần tải thì thôi, không chờ mãi",
     isinstance(loi, (TimeoutError, asyncio.TimeoutError)) and time.monotonic() - bat_dau < 2.5,
     f"{loi!r} sau {time.monotonic() - bat_dau:.1f} giây")

# Mở giao diện: máy xem kho MỘT lần rồi 6 giờ xem lại; giao diện hỏi tình trạng máy mỗi 2
# giây cũng không làm máy xem kho thêm
bbh.KHO_BAN_MOI = KHO_GIA
dat_kho(M_DUNG)
with TestClient(bbh.app, base_url=GOC, client=("127.0.0.1", 50000)) as c:
    c.get("/may/trang-thai")
    het = time.monotonic() + 5
    while not bbh.BAN_MOI and time.monotonic() < het:
        time.sleep(0.05)
    for _ in range(3):
        tt = c.get("/may/trang-thai").json()
    kiem("mở giao diện thì xem kho một lần; có bản mới thì tình trạng máy báo kèm ngày, ghi chú",
         tt.get("ban_moi") == {"phien_ban": BAN_KHO, "so_ban": SO_KHO, "ten": f"v{SO_KHO}",
                               "ngay": "28/9/2026", "ghi_chu": "Sửa lỗi <b>nhỏ</b>"}
         and KhoGia.GOI == ["/ban-moi.json"], f"{tt.get('ban_moi')} {KhoGia.GOI}")
    dat_kho(ban_moi_json(phien_ban=bbh.PHIEN_BAN))
    c.portal.call(bbh.xem_ban_moi)
    kiem("kho báo máy đang chạy bản mới nhất thì thôi báo",
         c.get("/may/trang-thai").json()["ban_moi"] is None)
    dat_kho(M_DUNG)
    c.portal.call(bbh.xem_ban_moi)
    dat_kho(None)
    c.portal.call(bbh.xem_ban_moi)
    kiem("mất mạng hay kho hỏng thì thôi báo, không lỗi",
         c.get("/may/trang-thai").json()["ban_moi"] is None and KhoGia.GOI == ["/ban-moi.json"])
    c.portal.call(bbh.XEM_BAN_MOI["task"].cancel)
bbh.XEM_BAN_MOI["task"] = None


def cap_nhat_mang(c, tieu_de=NUT):
    return c.post("/may/cap-nhat-tu-mang", headers=tieu_de)


# Nút Cập nhật ở dòng báo bản mới. Gói zip là cách cập nhật của máy Mac: giả làm máy Mac cả
# khi bộ kiểm chạy trên Windows thật (xem chú thích ở đầu mục H)
bbh.LA_WINDOWS = False
MO_TRINH_CAI.clear()
SO_LAN_TAT[0] = 0
with TestClient(bbh.app, base_url=GOC, client=("127.0.0.1", 50000)) as c:
    dat_kho(M_DUNG)
    kiem("cập nhật qua mạng thiếu tiêu đề giao diện thì bị chặn, không gọi kho",
         cap_nhat_mang(c, {}).status_code == 403 and not KhoGia.GOI)
    bbh.KHO_BAN_MOI = ""
    dap = cap_nhat_mang(c)
    bbh.KHO_BAN_MOI = KHO_GIA
    kiem("máy không xem bản mới qua mạng: báo rõ, không gọi kho",
         dap.status_code == 409 and not KhoGia.GOI, dap.text[:120])
    bbh.MAY_GHI.tt = "ghi"
    dap = cap_nhat_mang(c)
    bbh.MAY_GHI.tt = None
    kiem("đang ghi âm: không tải, không cài",
         dap.status_code == 409 and "Đang ghi âm" in dap.json()["detail"] and not KhoGia.GOI)
    for ten, m, ma, chu in (
            ("kho không có ban-moi.json", None, 503, "Chưa xem được"),
            ("ban-moi.json sai dạng", b"<html>", 503, "Chưa xem được"),
            ("kho báo đúng bản đang chạy", ban_moi_json(phien_ban=bbh.PHIEN_BAN), 409, "mới nhất"),
            ("kho ghi số thứ tự không cao hơn bản đang chạy", ban_moi_json(so=bbh.SO_BAN), 409, "mới nhất"),
            ("máy chạy bản thử chưa phát hành", ban_moi_json(truoc=["abc1234"]), 409, "mới nhất")):
        dat_kho(m)
        dap = cap_nhat_mang(c)
        kiem(f"{ten}: không tải tệp cài, báo rõ",
             dap.status_code == ma and chu in dap.json()["detail"]
             and not [g for g in KhoGia.GOI if g.startswith("/ban-cai/")], dap.text[:120])
    TEP_MAC_KHO = "/ban-cai/" + M_DUNG["mac"]["tep"]
    for ten, du_lieu, ma, chu in (
            ("tệp cài không có trên kho", None, 503, "Chưa tải được bản mới"),
            ("tệp cài lớn hơn cỡ ghi trong ban-moi.json", ZIP_KHO + b"x", 503, "lớn hơn cỡ"),
            ("tệp cài tải về thiếu", ZIP_KHO[:-10], 400, "không khớp mã kiểm tra"),
            ("tệp cài bị đổi (cùng cỡ, khác mã)", ZIP_KHO[:-1] + bytes([ZIP_KHO[-1] ^ 1]), 400,
             "không khớp mã kiểm tra")):
        dat_kho(M_DUNG)
        if du_lieu is None:
            del KhoGia.TEP[TEP_MAC_KHO]
        else:
            KhoGia.TEP[TEP_MAC_KHO] = du_lieu
        dap = cap_nhat_mang(c)
        kiem(f"{ten}: không cài, báo rõ", dap.status_code == ma and chu in dap.json()["detail"],
             dap.text[:150])
    dat_kho(ban_moi_json(phien_ban="1234567"))
    dap = cap_nhat_mang(c)
    kiem("tệp cài mang bản khác bản ban-moi.json báo: không cài",
         dap.status_code == 400 and f"là bản {BAN_KHO}, không phải bản 1234567" in dap.json()["detail"],
         dap.text[:150])
    # Số thứ tự trong gói phải đúng số ban-moi.json báo, không thì cài xong máy lại thấy "có
    # bản mới" mãi (Mac đọc dòng SO_BAN trong mã, Windows đọc thông tin tệp)
    dat_kho(ban_moi_json(so=SO_KHO_SAI))
    dap = cap_nhat_mang(c)
    kiem("Mac: gói mang số v<n> mà ban-moi.json báo số khác: không cài",
         dap.status_code == 400 and f"là bản v{SO_KHO}, không phải bản v{SO_KHO_SAI}" in dap.json()["detail"],
         dap.text[:150])
    bbh.LA_WINDOWS = True
    dap = cap_nhat_mang(c)
    bbh.LA_WINDOWS = False
    kiem("Windows: tệp cài mang số v<n> mà ban-moi.json báo số khác: không cài",
         dap.status_code == 400 and f"là bản v{SO_KHO}, không phải bản v{SO_KHO_SAI}" in dap.json()["detail"],
         dap.text[:150])
    exe_chua_so = goi_exe(BAN_KHO)  # tệp cài kiểu cũ, thông tin tệp không ghi số
    m_chua_so = ban_moi_json()
    m_chua_so["windows"] = {**m_chua_so["windows"], "sha256": hashlib.sha256(exe_chua_so).hexdigest(),
                            "co": len(exe_chua_so)}
    dat_kho(m_chua_so)
    KhoGia.TEP["/ban-cai/" + m_chua_so["windows"]["tep"]] = exe_chua_so
    bbh.LA_WINDOWS = True
    dap = cap_nhat_mang(c)
    bbh.LA_WINDOWS = False
    kiem("Windows: tệp cài không ghi số thứ tự mà ban-moi.json báo v<n>: không cài, nói không rõ số",
         dap.status_code == 400 and "không rõ số" in dap.json()["detail"], dap.text[:150])
    kiem("các lần từ chối không mở trình cài, không tắt ứng dụng",
         not MO_TRINH_CAI and SO_LAN_TAT[0] == 0, str(MO_TRINH_CAI))

    # Máy Mac: tải đúng tệp zip (kho chuyển hướng tới chỗ khác cũng được), cài như nút
    # Cập nhật bản mới
    dat_kho(M_DUNG)
    KhoGia.TEP[TEP_MAC_KHO] = ("chuyen", "/cho-khac/" + M_DUNG["mac"]["tep"])
    KhoGia.TEP["/cho-khac/" + M_DUNG["mac"]["tep"]] = ZIP_KHO
    dap = cap_nhat_mang(c)
    k = dap.json() if dap.status_code == 200 else {}
    ma_moi = bbh.THU_MUC_CAP_NHAT / APP_CAI / bbh.DUONG_GOI_MAC
    kiem("Mac: tải tệp zip của máy Mac, kiểm mã, mở trình cài của bản đó một lần",
         dap.status_code == 200 and k.get("phien_ban") == BAN_KHO and k.get("cu") == bbh.PHIEN_BAN
         and k.get("ten_moi") == f"v{SO_KHO}" and k.get("ten_cu") == bbh.TEN_BAN
         and MO_TRINH_CAI == [bbh.THU_MUC_CAP_NHAT / APP_CAI]
         and (ma_moi / "giao_dien.html").read_text(encoding="utf-8") == "<html>bản tải từ kho</html>"
         and KhoGia.GOI == ["/ban-moi.json", TEP_MAC_KHO, "/cho-khac/" + M_DUNG["mac"]["tep"]],
         f"{dap.text[:120]} {KhoGia.GOI}")
    kiem("Mac: mở trình cài xong thì ứng dụng tự tắt", cho_tat() == 1)

    MO_TRINH_CAI.clear()
    SO_LAN_TAT[0] = 0
    bbh.LA_WINDOWS = True
    dat_kho(M_DUNG)
    dap = cap_nhat_mang(c)
    bbh.LA_WINDOWS = False
    # Tệp tạm trong máy đặt tên theo dấu mã (duy nhất cho mỗi bản mã), không theo tên v<số>
    tep_exe = bbh.THU_MUC_CAP_NHAT / f"CaiDat-SonicRec-Windows-{BAN_KHO}.exe"
    kiem("Windows: tải tệp .exe của máy Windows, lưu nguyên vẹn, mở một lần",
         dap.status_code == 200 and dap.json().get("phien_ban") == BAN_KHO
         and dap.json().get("ten_moi") == f"v{SO_KHO}"
         and tep_exe.read_bytes() == EXE_KHO and MO_TRINH_CAI == [tep_exe]
         and KhoGia.GOI == ["/ban-moi.json", "/ban-cai/" + M_DUNG["windows"]["tep"]],
         f"{dap.text[:120]} {KhoGia.GOI}")
    kiem("Windows: mở trình cài xong thì ứng dụng tự tắt", cho_tat() == 1)
bbh.KHO_BAN_MOI = ""
bbh.BAN_MOI.clear()
bbh.LA_WINDOWS = os.name == "nt"
may_kho.shutdown()
for k, v in PROXY_CU.items():
    if v is None:
        os.environ.pop(k, None)
    else:
        os.environ[k] = v

# Hàm mở trình cài thật: Mac mở ứng dụng cài đặt với --cap-nhat, Windows chạy .exe với
# /CAPNHAT (bỏ lời chào và bước chọn thư mục, cài xong tự mở lại ứng dụng)
goi_run = []
that_run_h, that_which_h, that_win_h = bbh.subprocess.run, bbh.shutil.which, bbh.LA_WINDOWS
bbh.subprocess.run = lambda lenh, **k: goi_run.append(lenh)
bbh.shutil.which = lambda ten: "/usr/bin/open" if ten == "open" else None
bbh.LA_WINDOWS = False
app_mac = TAM / "goi" / "Cài đặt SonicRec.app"
CHAY_TRINH_CAI_THAT(app_mac)
kiem("Mac: mở ứng dụng cài đặt ở chế độ cập nhật, cửa sổ mới",
     goi_run == [["open", "-n", str(app_mac), "--args", "--cap-nhat"]], str(goi_run))
goi_run.clear()
goi_sf = []
co_sf = hasattr(bbh.os, "startfile")
that_sf = getattr(bbh.os, "startfile", None)
bbh.os.startfile = lambda tep, **k: goi_sf.append((tep, k))
bbh.LA_WINDOWS = True
tep_win_gia = TAM / "goi" / "CaiDat-SonicRec-Windows-abc1234.exe"
CHAY_TRINH_CAI_THAT(tep_win_gia)
if co_sf:
    bbh.os.startfile = that_sf
else:
    del bbh.os.startfile
bbh.subprocess.run, bbh.shutil.which, bbh.LA_WINDOWS = that_run_h, that_which_h, that_win_h
kiem("Windows: chạy tệp cài với /CAPNHAT, không gọi lệnh của Mac",
     goi_sf == [(str(tep_win_gia), {"arguments": "/CAPNHAT"})] and not goi_run, str(goi_sf))
bbh.chay_trinh_cai = CHAY_TRINH_CAI_THAT
bbh.KHI_TAT = lambda: None


# ----------------------------------------------------------------------------
print("\nI. Trợ lý trong buổi họp (bản 3): gửi từng đoạn lên NotebookLM trong lúc ghi")
# ----------------------------------------------------------------------------

class NlmNhieuNguon(NlmGia):
    """NotebookLM giả cho trợ lý: mỗi lần tải lên là một nguồn riêng (d1, d2...),
    nhớ tên từng nguồn, trả chữ riêng cho từng nguồn. tu_choi: số thứ tự các lần tải
    lên mà Google không nhận (nguồn hiện màu đỏ mãi)."""

    def __init__(self, tu_choi=(), **k):
        super().__init__(**k)
        self.ten, self.tu_choi, self.do = {}, set(tu_choi), set()
        self.ten_chu = {}  # nguồn chữ: mã -> tên (Thông tin buổi họp, bản chép lời)
        self.cau, self.so_tay = [], []  # các câu đã hỏi (kèm mã cuộc trò chuyện), ghi chú
        self.notes = SimpleNamespace(create=self._ghi_chu, update=self._sua_ghi_chu)
        self.sources.rename = self._doi_ten
        self.research = SimpleNamespace(discover=self._kham_pha, start=self._bat_dau_tim,
                                        wait_for_completion=self._cho_tim)

    async def _kham_pha(self, so_id, cau, mode="default"):
        await self._buoc("tim_web", cau)
        return SimpleNamespace(status="completed", summary="Tổng quan về khoá học MOS [1].",
                               sources=(SimpleNamespace(url="https://vi.wikipedia.org/wiki/MOS",
                                                        title="MOS là gì", hint="Giới thiệu MOS"),
                                        SimpleNamespace(url="javascript:alert(1)", title="Lạ",
                                                        hint="")))

    async def _bat_dau_tim(self, so_id, cau, source="web", mode="fast"):
        await self._buoc("tim_drive", cau, source, mode)
        return SimpleNamespace(task_id="tim1")

    async def _cho_tim(self, so_id, task_id=None, timeout=1800, **_):
        await self._buoc("cho_tim", task_id)
        return SimpleNamespace(status="completed", summary="", sources=(SimpleNamespace(
            url="https://docs.google.com/document/d/abc", title="Kế hoạch MOS 2026", hint=""),))

    async def _hoi(self, so_id, cau_hoi, source_ids=None, conversation_id=None):
        await self._buoc("hoi", tuple(source_ids or ()))
        self.cau.append((cau_hoi, conversation_id))
        dap = (TRA_LOI_GOOGLE if "BIÊN BẢN" in cau_hoi else THE_DOAN if "TÓM TẮT" in cau_hoi
               else THE_TONG_KET if "QUYẾT ĐỊNH" in cau_hoi else TRA_LOI_TU_HOI)
        return SimpleNamespace(answer=dap, conversation_id="c1" if "TÓM TẮT" in cau_hoi else "c2")

    async def _ghi_chu(self, so_id, tieu_de, noi_dung):
        await self._buoc("ghi_chu", tieu_de)
        self.so_tay.append(noi_dung)
        return SimpleNamespace(id="ghi1")

    async def _sua_ghi_chu(self, so_id, ma, noi_dung, tieu_de):
        await self._buoc("sua_ghi_chu", ma)
        self.so_tay.append(noi_dung)

    async def _them_tep(self, so_id, tep, loai=None, title=None, **_):
        await self._buoc("them_tep", Path(tep).suffix, loai, title)
        ma = f"d{len(self.ten) + 1}"
        self.ten[ma] = title or Path(tep).name
        self.tep = getattr(self, "tep", []) + [Path(tep).name]  # tên tệp tải lên
        if len(self.ten) in self.tu_choi:
            self.do.add(ma)
        return SimpleNamespace(id=ma, title=self.ten[ma])  # thư viện trả tên đã đặt được

    async def _them_chu(self, so_id, ten, chu, **_):
        await self._buoc("them_chu", chu)
        ma = "tin" if ten == bbh.TEN_THONG_TIN else "t1"
        self.ten_chu[ma] = ten
        return SimpleNamespace(id=ma)

    async def _doi_ten(self, so_id, nguon_id, ten):
        await self._buoc("doi_ten", nguon_id, ten)
        self.ten[nguon_id] = ten

    async def _cho(self, so_id, nguon_id):
        await self._buoc("cho", nguon_id)
        return SimpleNamespace(is_ready=nguon_id not in self.do, is_error=nguon_id in self.do)

    async def _chu(self, so_id, nguon_id):
        await self._buoc("chu", nguon_id)
        chu = f"Chữ của {self.ten.get(nguon_id, nguon_id)}, nội dung cuộc họp."
        return SimpleNamespace(content=chu, rendered_content=chu)


class NlmHongMotLan(NlmNhieuNguon):
    """Mạng chớp: hỏng đúng một lần ở mỗi bước trong mot_lan, sau đó bình thường. gio ghi lúc gọi
    từng bước, để đo khoảng cách giữa lần hỏng và lần thử lại."""

    def __init__(self, mot_lan=(), loi=ConnectionError, **k):
        super().__init__(**k)
        self.mot_lan, self.gio, self.loi = set(mot_lan), [], loi

    async def _buoc(self, ten, *doi_so):
        self.gio.append((time.monotonic(), ten))
        if ten in self.mot_lan:
            self.mot_lan.discard(ten)
            self.goi.append((ten,) + doi_so)
            raise self.loi(f"{ten}: mạng chớp giả lập")
        await super()._buoc(ten, *doi_so)


class NlmKetNoiChop(NlmNhieuNguon):
    """Mạng chớp lúc mở kết nối: so_lan lần vào sổ đầu đều hỏng, sau đó bình thường."""

    def __init__(self, so_lan=1, **k):
        super().__init__(**k)
        self.con, self.so_lan_vao = so_lan, 0

    async def __aenter__(self):
        self.so_lan_vao += 1
        if self.con > 0:
            self.con -= 1
            raise bbh.httpx.ConnectError("mạng chớp giả lập")
        return self


class NlmHongTaiLieu(NlmNhieuNguon):
    """Chỉ việc tải tài liệu lên hỏng (các đoạn ghi âm vẫn lên bình thường) khi hong_tl còn bật."""

    def __init__(self, hong_tl=True, **k):
        super().__init__(**k)
        self.hong_tl = hong_tl

    async def _them_tep(self, so_id, tep, loai=None, title=None, **_):
        if self.hong_tl and not (title or "").startswith("Đoạn"):
            await self._buoc("them_tep_hong", title)
            raise ConnectionError("tải tài liệu hỏng giả lập")
        return await super()._them_tep(so_id, tep, loai, title=title)


THE_DOAN = """## TÓM TẮT
- Khoá MOS có 32 học viên [1].
- Đề nghị thêm một buổi thực hành vào tuần thứ ba [2, 3].
**CÂU HỎI GỢI Ý**
- [Làm rõ] Ai phụ trách buổi thực hành?
- [Gợi mở] Có nên mời giảng viên doanh nghiệp không?
- [Cần chốt] Hạn nộp hồ sơ là ngày nào?
VIỆC CẦN CHỐT:
- Buổi thực hành chưa có người phụ trách
CHƯƠNG TRÌNH
- 1. Kiểm điểm công việc tuần trước: đã bàn
- 2. Kế hoạch tuần này: chưa bàn
VIỆC TUẦN TRƯỚC
- Không có
LIÊN QUAN
- Đoạn 1 đã nhắc hạn nộp hồ sơ 30/9 (Đoạn 1)
CỤM TỪ TÌM
khoá học MOS thực hành
"""
THE_TONG_KET = """QUYẾT ĐỊNH
- Thêm một buổi thực hành cho khoá MOS
VIỆC ĐÃ GIAO
- Chuẩn bị buổi thực hành: Lê Văn C, hạn 02/10
CÒN MỞ
- Người phụ trách hồ sơ [chưa rõ]
"""
TRA_LOI_TU_HOI = "Đầu buổi có nói khoá MOS có 32 học viên [1]."


def goi_hoi_cuoi(g):
    """Lần hỏi NotebookLM cuối cùng (sau đó có thể còn bước lưu ghi chú vào sổ)."""
    return [x for x in g.goi if x[0] == "hoi"][-1]


def doan_xong(ma: str) -> list:
    return [d for d in bbh.VIEC[ma]["tro_ly"]["doan"] if d["tt"] == "xong"]


# Bộ đếm lượt hỏi trong ngày
bbh.TEP_LUOT.unlink(missing_ok=True)
kiem("chưa hỏi lần nào thì còn đủ 50 lượt trong ngày", bbh.luot_con_lai() == 50)
bbh.tinh_mot_luot()
bbh.tinh_mot_luot()
kiem("mỗi lần hỏi NotebookLM trừ một lượt", bbh.luot_con_lai() == 48)
bbh.TEP_LUOT.write_text('{"ngay": "2026-01-01", "da_dung": 49}', encoding="utf-8")
kiem("sang ngày mới thì đếm lại từ đầu", bbh.luot_con_lai() == 50)


class RateLimitError(RuntimeError):
    """Cùng tên lỗi hết lượt của thư viện notebooklm-py."""


kiem("nhận ra lỗi hết lượt của NotebookLM, không nhầm với lỗi khác",
     bbh.la_het_luot(RateLimitError("x")) and bbh.la_het_luot(RuntimeError("Quota exceeded"))
     and not bbh.la_het_luot(RuntimeError("mất mạng")))

if not bbh.shutil.which("ffmpeg"):
    print("  (bỏ qua phần trợ lý trong lúc ghi vì máy chưa có ffmpeg)")
else:
    # Cắt phần vừa ghi theo khung ADTS
    tep_mau = TAM / "mau-cat.aac"
    bbh.subprocess.run(["ffmpeg", "-v", "error", "-f", "lavfi", "-i", "sine=frequency=440:duration=20",
                        "-ac", "1", "-ar", "16000", "-c:a", "aac", "-b:a", "48k", "-f", "adts",
                        str(tep_mau)], check=True, timeout=60)
    goc = tep_mau.read_bytes()
    _, _, giay_goc = ghi_am.tach_khung_adts(goc, het=True)
    con_tro, ghep, tong = 0, bytearray(), 0.0
    for moc_cat in list(range(97, len(goc), 7919)) + [len(goc)]:
        khung, qua, giay = ghi_am.tach_khung_adts(goc[con_tro:moc_cat])
        ghep += khung
        con_tro += qua
        tong += giay
    kiem("cắt phần vừa ghi ở vị trí bất kỳ, kể cả giữa khung: ghép lại trùng khít bản gốc",
         bytes(ghep) == goc and abs(tong - giay_goc) < 0.01, f"{tong:.2f}/{giay_goc:.2f} giây")
    kiem("số giây tính theo số khung khớp độ dài thật", abs(giay_goc - 20) < 0.2, f"{giay_goc:.2f}")
    cut = goc[:len(goc) - 101]
    kiem("khung cuối đang ghi dở thì chờ, chưa cắt", ghi_am.tach_khung_adts(cut)[1] < len(cut))
    kiem("khung bị cắt cụt (ffmpeg bị giết) rồi đoạn sau nối liền: bỏ khung cụt, giữ nguyên đoạn sau",
         ghi_am.tach_khung_adts(cut + goc, het=True)[0]
         == ghi_am.tach_khung_adts(cut, het=True)[0] + goc)
    tm_cat = TAM / "cat-qua-doan"
    tm_cat.mkdir()
    for i in (1, 2):
        (tm_cat / f"doan-0{i}.aac").write_bytes(goc)
    cac = sorted(tm_cat.glob("doan-*.aac"))
    kiem("đọc liền qua các tệp đoạn (tạm dừng rồi ghi tiếp) đúng vị trí",
         ghi_am.doc_tu_vi_tri(cac, len(goc) + 10) == goc[10:]
         and ghi_am.doc_tu_vi_tri(cac, 5) == goc[5:] + goc)
    kiem("sau khi nối lúc dừng, cắt tiếp trên tệp đã nối dùng chung con trỏ",
         ghi_am.cat_tu_tep(ghi_am.noi_doan(tm_cat), len(goc))[0] == goc)

    # Máy tắt ngang giữa lúc ghi: phần đã ghi phải nằm sẵn trên ổ đĩa
    os.environ["GHI_AM_NGUON"] = "-re -f lavfi -i sine=frequency=440:sample_rate=48000"
    may = ghi_am.MayGhi()
    tm_giet = TAM / "tat-ngang"
    tm_giet.mkdir()
    may.bat_dau("tatngang", tm_giet, (0, "Nguồn thử"))
    time.sleep(3.5)
    kiem("đang ghi thì tệp trên ổ đĩa đầy dần, trợ lý cắt được",
         ghi_am.tach_khung_adts(ghi_am.doc_tu_vi_tri([tm_giet / "doan-01.aac"], 0))[2] >= 2.5)
    may.tien_trinh.kill()
    time.sleep(0.5)
    con = ghi_am.tach_khung_adts((tm_giet / "doan-01.aac").read_bytes(), het=True)[2]
    kiem("ffmpeg bị tắt ngang sau 3,5 giây ghi: phần đã ghi vẫn còn trên ổ đĩa",
         con >= 2.5, f"còn {con:.1f} giây")
    may.dung()

    that = {k: getattr(bbh, k) for k in ("GIAY_MOI_PHUT", "DOAN_NGAN_NHAT", "DOAN_NGAN_NHAT_NUT",
                                         "NHIP_VONG", "TRAN_NGUON", "TRAN_LUOT")}
    han_that = dict(bbh.HAN_NLM)
    # Trần lượt hỏi thật là 50 mỗi ngày; ở đây nâng lên để các phép thử không làm cạn lượt
    # của nhau (còn ít lượt thì máy tự giãn nhịp). Mục J kiểm riêng các ngưỡng lượt hỏi.
    bbh.TRAN_LUOT = 1000
    bbh.TEP_LUOT.unlink(missing_ok=True)
    bbh.GIAY_MOI_PHUT = 0.6  # nhịp 5 "phút" thành 3 giây
    bbh.DOAN_NGAN_NHAT = bbh.DOAN_NGAN_NHAT_NUT = 1.0
    bbh.NHIP_VONG = 0.1
    bbh.HAN_NLM.update(nhip=0.05, doan=3, loi_keo_dai=0.3)
    DA_DANG_NHAP[0] = True
    SONG = "-re -f lavfi -i sine=frequency=440:sample_rate=48000"
    with TestClient(bbh.app, base_url=GOC, client=("127.0.0.1", 50000)) as c:
        kiem("không nhận nhịp gửi lạ",
             c.put("/may/thong-tin", json={"nhip_tro_ly": "7"}, headers=NUT).status_code == 400)
        c.put("/may/thong-tin", json={"cach_go_chu": "notebooklm", "nhip_tro_ly": "5"}, headers=NUT)
        kiem("lưu được nhịp gửi, đọc lại thấy đúng",
             c.get("/may/thong-tin").json()["truong"]["nhip_tro_ly"] == "5")

        # 1. Chạy trọn: tự gửi theo nhịp, bấm Tóm tắt ngay, Dừng thì chỉ còn đoạn cuối
        os.environ["GHI_AM_NGUON"] = SONG
        NLM[0] = g = NlmNhieuNguon()
        ma = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        v = bbh.VIEC[ma]
        kiem("bấm ghi ở cuộc họp gửi lên NotebookLM thì trợ lý chạy",
             c.get("/may/tro-ly").json().get("bat") is True)
        kiem("chưa tới nhịp thì chưa gọi Google lần nào", not g.goi, str(ten_goi(g)))
        cho_den(lambda: len(doan_xong(ma)) >= 2, 20)
        ds = v["tro_ly"]["doan"]
        tl = c.get("/may/tro-ly").json()
        kiem("tới nhịp thì đưa Thông tin buổi họp lên trước, rồi tự gửi từng đoạn lên và lấy chữ về",
             len(doan_xong(ma)) >= 2
             and ten_goi(g)[:5] == ["tao", "them_chu", "them_tep", "cho", "chu"],
             str(ten_goi(g))[:120])
        chu_tin = next((x[1] for x in g.goi if x[0] == "them_chu"), "")
        kiem("nguồn Thông tin buổi họp có đủ các mục đã khai báo, đưa lên một lần",
             g.ten_chu.get("tin") == "Thông tin buổi họp" and "THÔNG TIN BUỔI HỌP" in chu_tin
             and "Tên cuộc họp: Họp giao ban tuần Trung tâm" in chu_tin
             and "Chủ trì: Nguyễn Nam Hải" in chu_tin and "Trần Thị B" in chu_tin
             and ten_goi(g).count("them_chu") == 1 and v["tro_ly"]["thong_tin"]["tt"] == "xong",
             chu_tin[:200])
        kiem("gửi đoạn không làm ngừng ghi âm", c.get("/may/ghi/trang-thai").json()["tt"] == "ghi")
        kiem("mỗi đoạn có tên riêng trong sổ: số thứ tự, mốc trong bản ghi, giờ đồng hồ",
             re.fullmatch(r"Đoạn 1 \(00:00-\d\d:\d\d, \d\d:\d\d-\d\d:\d\d\)", ds[0]["ten"]) is not None
             and ds[1]["ten"].startswith("Đoạn 2 (") and g.ten.get("d1") == ds[0]["ten"]
             and next(x for x in g.goi if x[0] == "them_tep")[3] == ds[0]["ten"]  # đặt tên ngay lúc tải
             and "doi_ten" not in ten_goi(g)  # dịch vụ nhận tên thì khỏi đổi lại
             and ds[0]["ten"].split(", ")[1].rstrip(")").split("-")[1]
             == ds[1]["ten"].split(", ")[1].split("-")[0],
             f"{ds[0]['ten']} | {ds[1]['ten']} | trong sổ: {g.ten.get('d1')}")
        kiem("tên tệp tải lên của mỗi đoạn cũng khác nhau, có số thứ tự và mốc (trước đây đều là "
             "ghi-am.m4a)",
             len(set(g.tep)) == len(g.tep) >= 2
             and all(re.fullmatch(r"Doan-\d\d_\d\dm\d\ds-\d\dm\d\ds_\d\dh\d\d-\d\dh\d\d\.m4a", t)
                     for t in g.tep) and g.tep[0].startswith("Doan-01_00m00s-"), str(g.tep[:2]))
        kiem("các đoạn nối liền nhau, không hở không chồng",
             all(abs(a["den"] - b["tu"]) < 1e-6 for a, b in zip(ds, ds[1:])))
        kiem("màn Đang ghi biết đã chép lời tới đâu",
             tl["so_doan"] >= 2 and tl["go_chu_toi"] > 0 and "Đã chép lời tới" in tl["trang_thai"],
             str(tl)[:150])
        kiem("nút Tóm tắt ngay thiếu tiêu đề giao diện thì bị chặn",
             c.post("/may/tro-ly/tom-tat-ngay").status_code == 403)
        c.put("/may/thong-tin", json={"nhip_tro_ly": "0"}, headers=NUT)  # chỉ khi bấm nút
        time.sleep(1.5)
        so_truoc = len(doan_xong(ma))
        kiem("chọn Chỉ khi bấm nút thì không tự gửi nữa",
             not cho_den(lambda: len(doan_xong(ma)) > so_truoc, 4))
        c.post("/may/tro-ly/tom-tat-ngay", headers=NUT)
        kiem("bấm Tóm tắt ngay thì gửi luôn phần vừa ghi",
             cho_den(lambda: len(doan_xong(ma)) > so_truoc, 6))
        time.sleep(1.5)
        so_gui = ten_goi(g).count("them_tep")
        c.post("/may/ghi/dung", headers=NUT)
        kiem("dừng: gửi nốt đoạn cuối rồi soạn từ chữ các đoạn, tới Xong",
             cho_xong(ma, 15) == "Xong", str(v.get("loi")))
        tai = [x for x in g.goi if x[0] == "them_tep"]
        kiem("không tải cả bản ghi lên lần nữa: mọi lần tải đều là từng đoạn",
             all((x[3] or "").startswith("Đoạn ") for x in tai) and len(tai) == so_gui + 1,
             str([x[3] for x in tai]))
        kiem("bản chép lời cả buổi ghép từ chữ các đoạn, có mốc thời gian",
             v["ban_go_chu"].startswith("[00:00] Chữ của Đoạn 1")
             and v["ban_go_chu"].count("Chữ của Đoạn") == len(tai), v["ban_go_chu"][:80])
        kiem("soạn biên bản chỉ trên nguồn chữ ghép của cuộc họp",
             goi_hoi_cuoi(g) == ("hoi", ("t1",)) and ("them_chu", v["ban_go_chu"]) in g.goi,
             str(g.goi[-3:])[:150])
        kiem("tệp Word dựng như thường",
             bool(v.get("tep_word")) and (Path(v["thu_muc"]) / v["tep_word"]).is_file())
        kiem("nhật ký nói đã gửi bao nhiêu đoạn trong lúc họp",
             any("Trong lúc họp đã gửi" in x[1] for x in v["nhat_ky"])
             and any("Đã có chữ cả buổi" in x[1] for x in v["nhat_ky"]))
        luu = bbh.json.loads((Path(v["thu_muc"]) / "viec.json").read_text(encoding="utf-8"))
        kiem("lưu các đoạn xuống ổ đĩa, không lưu cờ tạm",
             len(luu["tro_ly"]["doan"]) == len(tai) and "dang_gui" not in luu["tro_ly"]
             and "yeu_cau" not in luu["tro_ly"])
        kiem("đếm đủ mọi lượt hỏi NotebookLM: thẻ gợi ý mỗi đoạn và lúc soạn biên bản",
             bbh.TRAN_LUOT - bbh.luot_con_lai() == ten_goi(g).count("hoi") >= 3,
             f"{bbh.TRAN_LUOT - bbh.luot_con_lai()} lượt; {ten_goi(g).count('hoi')} lần hỏi")
        c.put("/may/thong-tin", json={"nhip_tro_ly": "5"}, headers=NUT)

        # 2. Cuộc họp Không gửi lên mạng: trợ lý không chạy, không gọi Google lần nào
        c.put("/may/thong-tin", json={"cach_go_chu": "whisper"}, headers=NUT)
        NLM[0] = g = NlmNhieuNguon()
        ma = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        tl = c.get("/may/tro-ly").json()
        time.sleep(4)
        kiem("cuộc họp Không gửi lên mạng: nút Tóm tắt ngay bị từ chối",
             c.post("/may/tro-ly/tom-tat-ngay", headers=NUT).status_code == 409)
        c.post("/may/ghi/dung", headers=NUT)
        kiem("cuộc họp Không gửi lên mạng: trợ lý không chạy, không một lời gọi nào lên Google",
             tl.get("bat") is False and "Không gửi lên mạng" in tl.get("trang_thai", "")
             and cho_xong(ma) == "Xong" and not g.goi, str(ten_goi(g)))
        c.put("/may/thong-tin", json={"cach_go_chu": "notebooklm"}, headers=NUT)

        # 3. Có người phản đối giữa buổi: PM chọn giữ các đoạn đã gửi, thôi gửi phần sau
        NLM[0] = g = NlmNhieuNguon()
        ma = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        v = bbh.VIEC[ma]
        cho_den(lambda: len(doan_xong(ma)) >= 1, 15)
        c.put("/may/thong-tin", json={"cach_go_chu": "whisper"}, headers=NUT)
        so_tai = ten_goi(g).count("them_tep")
        time.sleep(4)
        c.put("/may/thong-tin", json={"cach_go_chu": "notebooklm"}, headers=NUT)
        time.sleep(4)
        kiem("chuyển sang Không gửi lên mạng giữa buổi: thôi gửi ngay, chuyển lại cũng không gửi tiếp",
             so_tai >= 1 and ten_goi(g).count("them_tep") == so_tai
             and c.get("/may/tro-ly").json()["bat"] is False, str(ten_goi(g)))
        c.post("/may/ghi/dung", headers=NUT)
        kiem("lúc Dừng không tải thêm gì: không đoạn cuối, không cả bản ghi",
             cho_xong(ma, 15) == "Xong" and ten_goi(g).count("them_tep") == so_tai,
             f"{ten_goi(g)}; {v.get('loi')}")
        kiem("giữ các đoạn đã gửi: NotebookLM soạn nháp phần đầu từ chữ các đoạn đó",
             v["ban_go_chu"].startswith("[00:00] Chữ của Đoạn 1")
             and ("them_chu", v["ban_go_chu"]) in g.goi and ten_goi(g)[-1] == "hoi",
             v["ban_go_chu"][:80])
        kiem("biên bản ghi rõ phần sau do thư ký nghe lại bản ghi, có dấu cần xem lại",
             "[Từ " in (v["ket_qua"] or "") and "thư ký nghe lại bản ghi" in v["ket_qua"])
        chu_word = "\n".join(p.text for p in Document(Path(v["thu_muc"]) / v["tep_word"]).paragraphs)
        kiem("dòng ghi chú đó có trong tệp Word", "thư ký nghe lại bản ghi" in chu_word)
        kiem("cảnh báo nói rõ chuyển giữa buổi, chỉ soạn nháp phần đã gửi",
             "giữa buổi" in (v.get("canh_bao") or "") and "phần đã gửi" in v["canh_bao"],
             str(v.get("canh_bao"))[:150])
        kiem("nhật ký có mốc lúc chuyển", any("giữa buổi (lúc" in x[1] for x in v["nhat_ky"]))

        # Chuyển đúng lúc trợ lý đang giữa một lượt (đã cắt đoạn, đang kết nối): thôi luôn
        class NlmChoKetNoi(NlmNhieuNguon):
            def __init__(self):
                super().__init__()
                self.dang_ket_noi, self.cho = threading.Event(), threading.Event()

            async def __aenter__(self):
                self.dang_ket_noi.set()
                await asyncio.to_thread(self.cho.wait, 10)
                return self

        NLM[0] = g = NlmChoKetNoi()
        ma = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        g.dang_ket_noi.wait(15)
        c.put("/may/thong-tin", json={"cach_go_chu": "whisper"}, headers=NUT)
        g.cho.set()
        time.sleep(1.5)
        c.post("/may/ghi/dung", headers=NUT)
        kiem("chuyển đúng lúc trợ lý đang giữa một lượt gửi: lượt đó thôi, không tải đoạn nào lên",
             cho_xong(ma) == "Xong" and "them_tep" not in ten_goi(g), str(ten_goi(g)))
        c.put("/may/thong-tin", json={"cach_go_chu": "notebooklm"}, headers=NUT)

        # Chưa đăng nhập NotebookLM: trợ lý chờ, không gửi gì; đăng nhập xong thì chạy
        DA_DANG_NHAP[0] = False
        NLM[0] = g = NlmNhieuNguon()
        ma = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        time.sleep(4)
        tl = c.get("/may/tro-ly").json()
        kiem("chưa đăng nhập NotebookLM thì trợ lý không gửi gì, nói rõ vì sao",
             not g.goi and "Chưa đăng nhập" in tl["trang_thai"], tl["trang_thai"])
        DA_DANG_NHAP[0] = True
        kiem("đăng nhập xong giữa buổi thì trợ lý bắt đầu gửi",
             cho_den(lambda: len(doan_xong(ma)) >= 1, 12))
        c.post("/may/ghi/dung", headers=NUT)
        cho_xong(ma, 15)

        # 4. Google không nhận một đoạn: bỏ đoạn đó, phần âm thanh đó đi cùng lần sau
        NLM[0] = g = NlmNhieuNguon(tu_choi={1})
        ma = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        v = bbh.VIEC[ma]
        cho_den(lambda: len(doan_xong(ma)) >= 1, 20)
        ds = v["tro_ly"]["doan"]
        kiem("Google không nhận một đoạn: bỏ đoạn đó khỏi sổ, phần âm thanh đó gửi lại cùng lần sau",
             ("xoa_nguon", "d1") in g.goi and ds and ds[0]["nguon"] == "d2" and ds[0]["tu"] == 0
             and ds[0]["ten"].startswith("Đoạn 1 ("), str([(d["ten"], d["nguon"]) for d in ds]))
        c.post("/may/ghi/dung", headers=NUT)
        cho_xong(ma, 15)

        # 5. Hỏng 3 lần liền: trợ lý tạm nghỉ, ghi âm vẫn chạy. Đã nghỉ mà mỗi nhịp vẫn thử một lần,
        # hết hỏng là tự chạy tiếp (PM chọn 30/9/2026; trước đó nghỉ hẳn tới khi bấm Tóm tắt ngay)
        NLM[0] = g = NlmNhieuNguon(hong={"them_tep"})
        ma = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        v = bbh.VIEC[ma]
        cho_den(lambda: v["tro_ly"]["tam_nghi"], 20)
        n = ten_goi(g).count("them_tep")
        kiem("hỏng 3 lần liền thì trợ lý tạm nghỉ, báo rõ (mỗi nhịp thử một lần), ghi âm vẫn chạy",
             "tạm nghỉ" in v["tro_ly"]["tam_nghi"] and "mỗi nhịp" in v["tro_ly"]["tam_nghi"] and n == 3
             and c.get("/may/ghi/trang-thai").json()["tt"] == "ghi", f"{n} lần; {v['tro_ly']}"[:200])
        kiem("nhật ký cuộc họp ghi ba lần hỏng đầu kèm lý do, không lặp cả buổi",
             sum("Trợ lý gửi hỏng lần" in x[1] for x in v["nhat_ky"]) == 3
             and any("lần 1 (" in x[1] for x in v["nhat_ky"]) and any("lần 3 (" in x[1] for x in v["nhat_ky"]),
             str(v["nhat_ky"])[:200])
        # Bấm Tóm tắt ngay khi đang nghỉ vẫn thử NGAY: lần tự thử kế tiếp cách lần hỏng vừa rồi đúng
        # một nhịp (3 giây), nên thấy lần thử trong 2,5 giây là do nút bấm
        c.post("/may/tro-ly/tom-tat-ngay", headers=NUT)
        kiem("đang nghỉ mà bấm Tóm tắt ngay thì thử ngay, không chờ tới nhịp",
             cho_den(lambda: ten_goi(g).count("them_tep") > n, 2.5))
        n = ten_goi(g).count("them_tep")
        cho_den(lambda: ten_goi(g).count("them_tep") > n, 8)
        kiem("đã nghỉ vẫn tự thử lại, mỗi nhịp một lần, không cần bấm nút; ghi âm vẫn chạy",
             ten_goi(g).count("them_tep") > n and c.get("/may/ghi/trang-thai").json()["tt"] == "ghi",
             f"{n} rồi {ten_goi(g).count('them_tep')} lần")
        g.hong.clear()
        kiem("hết hỏng thì trợ lý tự chạy lại, không cần bấm: gửi từ đầu phần chưa gửi, hết báo nghỉ, "
             "nhật ký ghi đã gửi lại được",
             cho_den(lambda: doan_xong(ma) and not v["tro_ly"]["tam_nghi"], 12)
             and doan_xong(ma)[0]["tu"] == 0 and any("gửi lại được sau" in x[1] for x in v["nhat_ky"]),
             str(v["tro_ly"].get("tam_nghi")))
        c.post("/may/ghi/dung", headers=NUT)
        kiem("hỏng giữa buổi không ảnh hưởng biên bản cuối", cho_xong(ma, 15) == "Xong")

        # 5b. Mạng chớp, tự gửi hỏng đúng một lần: thử lại sau 1 phút, không chờ tròn nhịp 5 phút
        # (PM chọn 30/9/2026). Thu 1 phút thành 1 giây, nhịp 5 giây, để tách bạch hai cách
        bbh.GIAY_MOI_PHUT = 1.0
        NLM[0] = g = NlmHongMotLan(mot_lan={"them_tep"})
        ma = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        v = bbh.VIEC[ma]
        cho_den(lambda: v["tro_ly"]["loi_lien"] == 1, 20)
        tl = c.get("/may/tro-ly").json()
        con_lai = tl["lan_sau"] - c.get("/may/ghi/trang-thai").json()["giay"]
        kiem("vừa gửi hỏng: màn hình báo lần sau là lần thử lại sau khoảng 1 phút, không phải tròn nhịp; "
             "chữ báo nói rõ phần đó gửi cùng lần sau, không đưa nút bấm vào (chủ trì xem dòng này trên điện thoại)",
             0 < con_lai <= 1.5 and "Phần đó sẽ gửi cùng lần sau" in tl["trang_thai"]
             and "Tóm tắt ngay" not in tl["trang_thai"]
             and "Mất kết nối mạng" in tl["trang_thai"], f"{con_lai:.1f} giây; {tl['trang_thai']}")
        # loi_lien về 0 khi cả lượt xong, kể cả hỏi thẻ, chứ không phải ngay lúc đoạn có chữ
        cho_den(lambda: len(doan_xong(ma)) >= 1 and v["tro_ly"]["loi_lien"] == 0, 20)
        tep = [t for t, ten in g.gio if ten == "them_tep"]
        kiem("tự gửi hỏng một lần: máy thử lại sau khoảng 1 phút chứ không chờ tròn một nhịp; gửi lại được "
             "thì hết báo hỏng, đoạn gửi từ đầu phần chưa gửi",
             len(tep) >= 2 and 0.4 < tep[1] - tep[0] < 3.5 and doan_xong(ma)[0]["tu"] == 0
             and v["tro_ly"]["loi_lien"] == 0 and not v["tro_ly"]["tam_nghi"],
             f"cách nhau {tep[1] - tep[0]:.1f} giây, nhịp {5 * bbh.GIAY_MOI_PHUT:.0f} giây"
             if len(tep) >= 2 else str(tep))
        kiem("nhật ký cuộc họp ghi lần hỏng và lần gửi lại được",
             any("Trợ lý gửi hỏng lần 1" in x[1] for x in v["nhat_ky"])
             and any("gửi lại được sau 1 lần" in x[1] for x in v["nhat_ky"]), str(v["nhat_ky"])[:200])
        c.post("/may/ghi/dung", headers=NUT)
        cho_xong(ma, 15)
        bbh.GIAY_MOI_PHUT = 0.6

        # 5c. Chọn Chỉ khi bấm nút: bấm mà hỏng thì máy không tự thử lại, không hẹn giờ, chờ bấm tiếp
        c.put("/may/thong-tin", json={"nhip_tro_ly": "0"}, headers=NUT)
        NLM[0] = g = NlmHongMotLan(mot_lan={"them_tep"})
        ma = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        v = bbh.VIEC[ma]
        time.sleep(2.5)  # đủ dài để phần vừa ghi qua mức tối thiểu của nút, kể cả khi ffmpeg khởi động chậm
        c.post("/may/tro-ly/tom-tat-ngay", headers=NUT)
        cho_den(lambda: v["tro_ly"]["loi_lien"] == 1, 10)
        time.sleep(3)  # gấp mấy lần hẹn thử lại 1 và 2 phút (0,6 và 1,2 giây)
        tl = c.get("/may/tro-ly").json()
        kiem("chọn Chỉ khi bấm nút: bấm mà hỏng thì máy không tự thử lại, cũng không hẹn giờ",
             ten_goi(g).count("them_tep") == 1 and v["tro_ly"].get("thu_lai") is None
             and tl["lan_sau"] is None and "Lần gửi vừa rồi hỏng" in tl["trang_thai"],
             f"{ten_goi(g).count('them_tep')} lần; {tl['trang_thai']}")
        c.post("/may/tro-ly/tom-tat-ngay", headers=NUT)
        kiem("chọn Chỉ khi bấm nút: bấm lại thì gửi được, hết báo hỏng",
             cho_den(lambda: len(doan_xong(ma)) >= 1 and v["tro_ly"]["loi_lien"] == 0, 8))
        c.post("/may/ghi/dung", headers=NUT)
        cho_xong(ma, 15)
        c.put("/may/thong-tin", json={"nhip_tro_ly": "5"}, headers=NUT)

        # 5e. Google báo hết lượt hay hạn chế lúc tự gửi: chờ tròn nhịp, khỏi hỏi dồn bằng lần thử sớm
        bbh.GIAY_MOI_PHUT = 1.0
        NLM[0] = g = NlmHongMotLan(mot_lan={"them_tep"}, loi=RateLimitError)
        ma = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        v = bbh.VIEC[ma]
        cho_den(lambda: len(doan_xong(ma)) >= 1, 25)
        tep = [t for t, ten in g.gio if ten == "them_tep"]
        kiem("Google báo hết lượt lúc tự gửi: máy chờ tròn một nhịp mới thử lại, không thử sớm sau 1 phút",
             len(tep) >= 2 and tep[1] - tep[0] > 3.5 and "hết lượt" in " ".join(x[1] for x in v["nhat_ky"]),
             f"cách nhau {tep[1] - tep[0]:.1f} giây, nhịp {5 * bbh.GIAY_MOI_PHUT:.0f} giây"
             if len(tep) >= 2 else str(tep))
        c.post("/may/ghi/dung", headers=NUT)
        cho_xong(ma, 15)
        bbh.GIAY_MOI_PHUT = 0.6

        # 5f. Đã tạm nghỉ vì hỏng liền, gặp lúc phần mới im lặng (chưa có gì để gửi): vẫn hẹn nhịp sau,
        # hết im lặng là tự gửi; không thì nghỉ mãi tới khi bấm nút
        NLM[0] = g = NlmNhieuNguon(hong={"them_tep"})
        ma = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        v = bbh.VIEC[ma]
        cho_den(lambda: v["tro_ly"]["tam_nghi"], 20)
        im_lang_that = bbh.im_lang

        async def im_lang_gia(aac):
            return True

        bbh.im_lang = im_lang_gia
        g.hong.clear()
        time.sleep(4.5)  # hơn một nhịp (3 giây): lần tự thử gặp im lặng, chưa gửi gì
        kiem("đang nghỉ mà phần mới im lặng: chưa gửi gì, vẫn báo nghỉ",
             not doan_xong(ma) and bool(v["tro_ly"]["tam_nghi"]))
        bbh.im_lang = im_lang_that
        kiem("hết im lặng thì máy vẫn tự thử lại theo nhịp và gửi được, không cần bấm nút",
             cho_den(lambda: doan_xong(ma) and not v["tro_ly"]["tam_nghi"], 12))
        c.post("/may/ghi/dung", headers=NUT)
        cho_xong(ma, 15)

        # 5d. Lịch thử lại (hàm thuần, không đợi giờ): lần hỏng 1 sau 1 phút, lần 2 sau 2 phút, từ lần 3
        # mỗi nhịp một lần; hết lượt hay bị hạn chế thì chờ tròn nhịp; Chỉ khi bấm nút thì không hẹn
        nhip_t, tm = 5 * bbh.GIAY_MOI_PHUT, bbh.GIAY_MOI_PHUT
        hen = bbh.hen_thu_lai
        kiem("lịch thử lại sau khi tự gửi hỏng: 1 phút, 2 phút, rồi mỗi nhịp một lần",
             abs(hen({"loi_lien": 1}, 100, nhip_t) - (100 + 1 * tm)) < 1e-9
             and abs(hen({"loi_lien": 2}, 100, nhip_t) - (100 + 2 * tm)) < 1e-9
             and abs(hen({"loi_lien": 3}, 100, nhip_t) - (100 + nhip_t)) < 1e-9
             and abs(hen({"loi_lien": 9}, 100, nhip_t) - (100 + nhip_t)) < 1e-9)
        kiem("lịch thử lại: nhịp ngắn hơn hẹn thì lấy nhịp; Google báo hết lượt thì chờ tròn nhịp, khỏi hỏi "
             "dồn; Chỉ khi bấm nút thì không hẹn",
             abs(hen({"loi_lien": 2}, 100, 0.5 * tm) - (100 + 0.5 * tm)) < 1e-9
             and abs(hen({"loi_lien": 1}, 100, nhip_t, nhanh=False) - (100 + nhip_t)) < 1e-9
             and hen({"loi_lien": 1}, 100, 0) is None)
        kiem("hằng số lịch thử lại khớp nhau: mỗi lần hẹn có một số phút, tài liệu nền cũng vậy",
             len(bbh.CACH_THU_LAI) == bbh.LOI_LIEN_TOI_DA - 1
             and len(bbh.CACH_THU_LAI_NEN) == bbh.LAN_TOI_DA_NEN - 1)

        # 6. Đoạn cuối Google không nhận: lùi về cách cũ, tải cả bản ghi lên
        c.put("/may/thong-tin", json={"nhip_tro_ly": "0"}, headers=NUT)
        NLM[0] = g = NlmNhieuNguon()
        ma = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        v = bbh.VIEC[ma]
        time.sleep(2)
        c.post("/may/tro-ly/tom-tat-ngay", headers=NUT)
        cho_den(lambda: len(doan_xong(ma)) >= 1, 8)
        time.sleep(1.5)
        g.tu_choi.add(len(g.ten) + 1)
        c.post("/may/ghi/dung", headers=NUT)
        kiem("đoạn cuối Google không nhận: lùi về cách cũ, tải cả bản ghi lên, vẫn Xong",
             cho_xong(ma, 20) == "Xong" and any(x[0] == "them_tep" and x[3] is None for x in g.goi)
             and goi_hoi_cuoi(g) == ("hoi", (f"d{len(g.ten)}",))
             and any("như cách cũ" in x[1] for x in v["nhat_ky"]), f"{ten_goi(g)}; {v.get('loi')}")
        c.put("/may/thong-tin", json={"nhip_tro_ly": "5"}, headers=NUT)

        # 7. Phần vừa ghi gần như im lặng: không gửi, không gọi Google
        os.environ["GHI_AM_NGUON"] = "-re -f lavfi -i anullsrc=r=48000:cl=mono"
        NLM[0] = g = NlmNhieuNguon()
        ma = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        time.sleep(4.5)
        tl = c.get("/may/tro-ly").json()
        c.post("/may/ghi/dung", headers=NUT)
        kiem("phần vừa ghi gần như im lặng thì trợ lý không gửi, không gọi Google",
             not g.goi and "không có tiếng" in tl["trang_thai"], tl["trang_thai"])
        kiem("im lặng cả buổi thì Dừng vẫn báo như cũ, không gửi gì",
             cho_xong(ma) == "Lỗi" and not g.goi)
        os.environ["GHI_AM_NGUON"] = SONG

        # 7b. Có tiếng mà Google không nghe ra lời (ghi nhầm micro sau Ghi tiếp, 27/9/2026):
        # thẻ báo rõ kèm cách xử lý, không hỏi NotebookLM cho thẻ trống
        class NlmKhongRaLoi(NlmNhieuNguon):
            async def _chu(self, so_id, nguon_id):
                await self._buoc("chu", nguon_id)
                return SimpleNamespace(content="", rendered_content="ừ ừ")

        NLM[0] = g = NlmKhongRaLoi()
        ma = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        v = bbh.VIEC[ma]
        cho_den(lambda: any(t["loai"] == "loi" for t in v["tro_ly"]["the"]), 15)
        the_loi = [t for t in v["tro_ly"]["the"] if t["loai"] == "loi"]
        kiem("đoạn không nghe ra lời: thẻ báo rõ kèm cách xử lý, không hỏi NotebookLM cho tốn lượt",
             bool(the_loi) and the_loi[0]["chu"].startswith("Đoạn 1 (")
             and "không nghe ra lời nói" in the_loi[0]["chu"] and "Ghi tiếp" in the_loi[0]["goi_y"]
             and "hoi" not in ten_goi(g), f"{the_loi[:1]}; {ten_goi(g)}")
        kiem("nhật ký cuộc họp ghi đoạn nào không nghe ra lời",
             any("không nghe ra lời nói" in x[1] for x in v["nhat_ky"]))
        c.post("/may/ghi/dung", headers=NUT)
        cho_xong(ma, 15)

        # 7c. Dịch vụ trả "Không có" cho đoạn mới khi cuộc trò chuyện đã dài (thẻ trống giữa
        # buổi, 27/9/2026), hay chép lại câu trả lời cũ (buổi giao ban 28/9/2026). Từ 28/9 mỗi
        # thẻ hỏi không kèm mã cuộc trò chuyện: không còn cần hỏi lại, không tốn thêm lượt
        class NlmQuenDoanMoi(NlmNhieuNguon):
            async def _chu(self, so_id, nguon_id):
                await self._buoc("chu", nguon_id)
                chu = "Chị Lan báo cáo tuyển sinh khoá MOS có ba mươi hai học viên. " * 5
                return SimpleNamespace(content=chu, rendered_content=chu)

            async def _hoi(self, so_id, cau_hoi, source_ids=None, conversation_id=None):
                dap = await super()._hoi(so_id, cau_hoi, source_ids, conversation_id)
                if conversation_id and "TÓM TẮT" in cau_hoi:
                    dap.answer = ("TÓM TẮT\n- Không có\nCÂU HỎI GỢI Ý\n- Không có\n"
                                  "VIỆC CẦN CHỐT\n- Buổi thực hành chưa có người phụ trách\n")
                return dap

        NLM[0] = g = NlmQuenDoanMoi()
        ma = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        v = bbh.VIEC[ma]
        cho_den(lambda: len([t for t in v["tro_ly"]["the"] if t["loai"] == "doan"]) >= 2, 20)
        the_doan = [t for t in v["tro_ly"]["the"] if t["loai"] == "doan"]
        ma_tc = [x[1] for x in g.cau if "TÓM TẮT" in x[0]]  # mã cuộc trò chuyện mỗi lần hỏi thẻ
        kiem("mỗi thẻ hỏi không kèm mã cuộc trò chuyện: đoạn có lời thì thẻ có tóm tắt, mỗi thẻ "
             "đúng một lượt hỏi",
             len(the_doan) >= 2 and all(t.get("tom_tat") for t in the_doan[:2])
             and ma_tc[:2] == [None, None] and len(ma_tc) == len(the_doan),
             f"{ma_tc}; {[t.get('tom_tat') for t in the_doan]}")
        c.post("/may/ghi/dung", headers=NUT)
        cho_xong(ma, 15)

        # 8. Sổ gần đủ 50 nguồn: trợ lý thôi gửi, biên bản cuối vẫn làm được
        bbh.TRAN_NGUON = 3
        NLM[0] = g = NlmNhieuNguon()
        ma = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        v = bbh.VIEC[ma]
        cho_den(lambda: "mức tối đa" in v["tro_ly"]["tam_nghi"], 15)
        kiem("sổ gần đủ 50 nguồn thì trợ lý thôi gửi, chừa chỗ cho biên bản cuối",
             ten_goi(g).count("them_tep") == 1 and "mức tối đa" in v["tro_ly"]["tam_nghi"],
             str(ten_goi(g)))
        c.post("/may/ghi/dung", headers=NUT)
        kiem("vẫn soạn được biên bản cuối", cho_xong(ma, 15) == "Xong")
        bbh.TRAN_NGUON = that["TRAN_NGUON"]

        # 9. NotebookLM báo hết lượt lúc soạn: nói rõ là hết lượt
        class NlmHetLuot(NlmGia):
            async def _hoi(self, so_id, cau_hoi, source_ids=None, **_):
                raise RateLimitError("rate limited")

        NLM[0] = NlmHetLuot()
        gui(c)
        v = viec_cuoi()
        kiem("NotebookLM báo hết lượt lúc soạn: nói rõ hết lượt, soạn tại máy từ bản chép lời",
             v["trang_thai"] == "Xong" and "hết lượt" in (v.get("canh_bao") or ""),
             str(v.get("canh_bao"))[:120])

        # 10. Máy sập giữa buổi khi trợ lý đã gửi vài đoạn: Làm lại chỉ gửi phần còn lại
        tm = bbh.THU_MUC_LUU / "2026-09-28_0900_sapgiua2"
        tm.mkdir()
        bbh.subprocess.run(["ffmpeg", "-v", "error", "-f", "lavfi", "-i", "sine=duration=8",
                            "-ac", "1", "-ar", "16000", "-c:a", "aac", "-b:a", "48k", "-f", "adts",
                            str(tm / "doan-01.aac")], check=True, timeout=60)
        du = (tm / "doan-01.aac").read_bytes()
        _, qua, giay = ghi_am.tach_khung_adts(du[:len(du) // 2])
        ty = bbh.moi_tro_ly()
        ty.update(con_tro=qua, giay_da_cat=giay, doan=[{
            "ten": "Đoạn 1", "tu": 0, "den": giay, "nguon": "cu1", "tt": "xong",
            "chu": "Chữ đoạn trước khi máy sập.", "con_tro_dau": 0}])
        bbh._ghi_an_toan(tm / "viec.json", bbh.json.dumps({
            "ma": "sapgiua2", "trang_thai": "Đang ghi âm", "tt": v["tt"], "tep_ghi_am": None,
            "nhan_luc": "2026-09-28T09:00:00", "bat_dau": "2026-09-28T09:00:00",
            "cach_da_bao": "notebooklm", "so_nlm": {"id": "so1", "ten": "x"}, "tro_ly": ty}))
        bbh.VIEC.clear()
        bbh.THU_TU.clear()
        bbh.nap_lai_lich_su()
        NLM[0] = g = NlmNhieuNguon()
        c.post("/may/viec/sapgiua2/lam-lai", headers=NUT)
        vs = bbh.VIEC["sapgiua2"]
        kiem("máy sập giữa buổi khi đã gửi vài đoạn: Làm lại chỉ gửi phần còn lại rồi soạn từ chữ",
             cho_xong("sapgiua2") == "Xong" and ten_goi(g).count("them_tep") == 1
             and vs["ban_go_chu"].startswith("[00:00] Chữ đoạn trước khi máy sập.")
             and "Chữ của Đoạn 2" in vs["ban_go_chu"], f"{ten_goi(g)}; {vs['ban_go_chu'][:90]}")

        # --------------------------------------------------------------------
        print("\nJ. Trợ lý: thẻ gợi ý, Tổng kết, Hỏi, Ghi nhanh, Ghi ngữ cảnh, Ghi chú của thư ký")
        # --------------------------------------------------------------------
        the = bbh.doc_the(THE_DOAN)
        kiem("đọc thẻ: tách đúng từng mục, bỏ số trích dẫn, bỏ dòng Không có",
             the.get("tom_tat") == ["Khoá MOS có 32 học viên.",
                                    "Đề nghị thêm một buổi thực hành vào tuần thứ ba."]
             and the.get("cau_hoi", [None])[0] == ["Làm rõ", "Ai phụ trách buổi thực hành?"]
             and the.get("can_chot") == ["Buổi thực hành chưa có người phụ trách"]
             and the.get("chuong_trinh", ["", ""])[1] == "2. Kế hoạch tuần này: chưa bàn"
             and the.get("viec_cu") == [] and the.get("cum_tu") == "khoá học MOS thực hành",
             str(the)[:200])
        kiem("đọc thẻ: câu trả lời sai khuôn thì giữ nguyên văn để vẫn hiện được",
             bbh.doc_the("NotebookLM trả lời tự do [1].") == {"tho": "NotebookLM trả lời tự do."})
        kiem("câu hỏi gợi ý không có nhãn thì vẫn giữ nguyên", bbh.tach_nhan("Ai làm?") == ["", "Ai làm?"])
        cau = bbh.cau_hoi_doan(dict(v["tt"], chuong_trinh="1. A\n2. B", viec_tuan_truoc="- Việc X"),
                               {"ten": "Đoạn 2 (05:00-10:00)"})
        kiem("câu hỏi mỗi đoạn nêu đúng đoạn cần tóm tắt, kèm chương trình, việc tuần trước, quy tắc",
             'Nguồn cần tóm tắt là "Đoạn 2 (05:00-10:00)"' in cau and "1. A\n2. B" in cau
             and "- Việc X" in cau and "[Làm rõ]" in cau and "không đoán tên người nói" in cau.lower()
             and "CHỈ có trong nguồn cần tóm tắt" in cau and "DIỄN BIẾN" not in cau)
        cau = bbh.cau_hoi_doan(v["tt"], {"ten": "Đoạn 3 (10:00-15:00)"}, {"ten": "Đoạn 2 (05:00-10:00)"},
                               True, False, "- Đoạn 1: Chị Lan báo cáo tuyển sinh")
        kiem("câu hỏi nói rõ đoạn liền trước chỉ để nối mạch, có Thông tin buổi họp và diễn biến "
             "từ đầu buổi",
             '"Đoạn 2 (05:00-10:00)" là phần ngay trước đó, chỉ để nối mạch' in cau
             and '"Thông tin buổi họp"' in cau and "DIỄN BIẾN TỪ ĐẦU BUỔI" in cau
             and "- Đoạn 1: Chị Lan báo cáo tuyển sinh" in cau and "tài liệu nền" not in cau, cau[:300])
        kiem("chưa điền chương trình thì câu hỏi không có mục chương trình",
             "CHƯƠNG TRÌNH" not in bbh.cau_hoi_doan(dict(v["tt"], chuong_trinh="", viec_tuan_truoc=""),
                                                    {"ten": "Đoạn 1"}))
        # Diễn biến từ đầu buổi: tóm từ các thẻ trước, kèm danh sách của thẻ gần nhất
        ty_mau = {"the": [{"loai": "ngu_canh", "chu": "Cô Hà đang phát biểu"}]
                  + [{"loai": "doan", "ten": f"Đoạn {i}", "tom_tat": [f"Ý chính số {i}. " + "x" * 300]}
                     for i in range(1, 31)]}
        ty_mau["the"][-1].update(can_chot=["Buổi thực hành chưa có người phụ trách"],
                                 chuong_trinh=["1. Kiểm điểm: đã bàn"])
        db = bbh.dien_bien(ty_mau)
        dong_db = {d.split(": ")[0]: d for d in db.split("\n") if d.startswith("- Đoạn ")}
        kiem("diễn biến từ đầu buổi: mỗi thẻ trước một dòng, thẻ cũ cắt ngắn hơn thẻ gần đây, có việc "
             "cần chốt và chương trình của thẻ gần nhất, không lẫn dòng ngữ cảnh",
             len(dong_db) >= 20 and "Ý chính số 30" in db and bbh.so_byte(db) <= bbh.TOI_DA_DIEN_BIEN
             and "Việc cần chốt đã ghi nhận:\n- Buổi thực hành chưa có người phụ trách" in db
             and "1. Kiểm điểm: đã bàn" in db and "Cô Hà đang phát biểu" not in db
             and len(dong_db.get("- Đoạn 30", "")) > len(dong_db.get("- Đoạn 10", "x" * 999)),
             db[:200])
        ty_mau["the"] = ty_mau["the"] * 8  # 240 thẻ: quá trần thì bỏ bớt các đoạn đầu
        db = bbh.dien_bien(ty_mau)
        kiem("diễn biến quá dài thì bỏ bớt các đoạn đầu, giữ các đoạn gần đây và các danh sách",
             bbh.so_byte(db) <= bbh.TOI_DA_DIEN_BIEN and db.startswith("- (bỏ bớt các đoạn đầu)")
             and "Việc cần chốt đã ghi nhận" in db, str(bbh.so_byte(db)))
        kiem("chưa có thẻ nào thì không có diễn biến", bbh.dien_bien({"the": []}) == "")
        # Đoạn liền trước chỉ chọn làm nguồn khi đã có chữ; nguồn của thẻ theo đúng thứ tự
        d1, d2, d3 = ({"ten": f"Đoạn {i}", "nguon": f"n{i}", "tt": "xong"} for i in (1, 2, 3))
        ty_mau = {"doan": [d1, d2, d3], "nen": [{"tt": "xong", "nguon": "tl1"}, {"tt": "loi"}],
                  "thong_tin": {"tt": "xong", "nguon": "tin"}}
        dang = dict(d2, tt="dang")
        kiem("đoạn liền trước: chỉ lấy khi đã có chữ; đoạn đầu không có đoạn trước; nguồn của thẻ "
             "là Thông tin buổi họp, tài liệu đã đọc được, đoạn liền trước rồi đoạn mới",
             bbh.doan_truoc(ty_mau, d3) is d2 and bbh.doan_truoc(ty_mau, d1) is None
             and bbh.doan_truoc({"doan": [d1, dang, d3]}, d3) is None
             and bbh.doan_truoc({"doan": [d1, dict(d2, nguon=None), d3]}, d3) is None
             and bbh.nguon_the(ty_mau, d3, d2) == ["tin", "tl1", "n2", "n3"]
             and bbh.nguon_the({"doan": [d1]}, d1, None) == ["n1"])

        # Một buổi có trợ lý: ghi nhanh, ghi ngữ cảnh, ghi chú của thư ký, thẻ sau mỗi
        # đoạn, Hỏi, Tổng kết. PM chốt 27/9/2026: ô Ghi chú của thư ký LUÔN gửi làm ngữ
        # cảnh ở cuộc họp gửi lên mạng (trước đó chỉ lưu trên máy).
        GHI_CHU = "Người nói đầu buổi là chị Lan, phòng Đào tạo"
        NGU_CANH = "Người nói ở phút 3 là anh Tuấn, kế toán"
        c.put("/may/thong-tin", json={"cach_go_chu": "notebooklm", "nhip_tro_ly": "5",
                                      "chuong_trinh": "1. Kiểm điểm công việc tuần trước\n"
                                                      "2. Kế hoạch tuần này"}, headers=NUT)
        NLM[0] = g = NlmNhieuNguon()
        ma = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        v = bbh.VIEC[ma]
        kiem("hỏi NotebookLM khi chưa có đoạn nào thì báo chờ lần gửi đầu",
             c.post("/may/tro-ly/hoi", json={"cau_hoi": "Có gì?"}, headers=NUT).status_code == 409)
        kiem("ghi nhanh thiếu tiêu đề giao diện thì bị chặn",
             c.post("/may/tro-ly/ghi-nhanh", json={"chu": "x"}).status_code == 403)
        c.post("/may/tro-ly/ghi-nhanh", json={"chu": "Anh Nam chốt phương án 2, hạn 30/9"}, headers=NUT)
        c.post("/may/tro-ly/ghi-nhanh", json={"chu": "Dòng ghi nhầm"}, headers=NUT)
        c.delete("/may/tro-ly/ghi-nhanh/1", headers=NUT)
        kiem("ghi nhanh: thêm được, xoá được, mỗi dòng có mốc thời gian trong bản ghi",
             [x["chu"] for x in v["tro_ly"]["ghi_nhanh"]] == ["Anh Nam chốt phương án 2, hạn 30/9"]
             and isinstance(v["tro_ly"]["ghi_nhanh"][0]["luc"], float))
        kiem("ghi chú của thư ký thiếu tiêu đề giao diện thì bị chặn",
             c.put(f"/may/viec/{ma}/ghi-chu-rieng", json={"chu": "x"}).status_code == 403)
        c.put(f"/may/viec/{ma}/ghi-chu-rieng", json={"chu": GHI_CHU}, headers=NUT)
        kiem("nút Ghi ngữ cảnh thiếu tiêu đề giao diện thì bị chặn",
             c.post("/may/tro-ly/ngu-canh", json={"chu": "x"}).status_code == 403)
        kiem("Ghi ngữ cảnh để trống thì không nhận",
             c.post("/may/tro-ly/ngu-canh", json={"chu": "  "}, headers=NUT).status_code == 400)
        c.post("/may/tro-ly/ngu-canh", json={"chu": NGU_CANH}, headers=NUT)
        c.post("/may/tro-ly/ngu-canh", json={"chu": "Dòng ngữ cảnh ghi nhầm"}, headers=NUT)
        nc = [t for t in v["tro_ly"]["the"] if t["loai"] == "ngu_canh"]
        kiem("xoá dòng ngữ cảnh không có thì báo không có",
             c.delete("/may/tro-ly/ngu-canh/khongco", headers=NUT).status_code == 404)
        kiem("xoá dòng ngữ cảnh thiếu tiêu đề giao diện thì bị chặn",
             c.delete(f"/may/tro-ly/ngu-canh/{nc[-1]['id']}").status_code == 403)
        c.delete(f"/may/tro-ly/ngu-canh/{nc[-1]['id']}", headers=NUT)
        nc = [t for t in v["tro_ly"]["the"] if t["loai"] == "ngu_canh"]
        kiem("Ghi ngữ cảnh: mỗi dòng thành một thẻ có mốc thời gian, xoá được từng dòng",
             [t["chu"] for t in nc] == [NGU_CANH] and isinstance(nc[0]["giay"], float)
             and len(nc[0]["id"]) == 10, str(nc))
        cho_den(lambda: len([t for t in v["tro_ly"]["the"] if t["loai"] == "doan"]) >= 3, 30)
        tl = c.get("/may/tro-ly").json()
        the_doan = [t for t in tl["the"] if t["loai"] == "doan"]
        kiem("sau mỗi đoạn có một thẻ gợi ý: tóm tắt, câu hỏi gợi ý gắn nhãn, liên quan",
             len(the_doan) >= 2 and the_doan[0]["ten"].startswith("Đoạn 1")
             and "32 học viên" in the_doan[0]["tom_tat"][0] and the_doan[0]["cau_hoi"][1][0] == "Gợi mở"
             and the_doan[0]["lien_quan"], str(the_doan[:1])[:200])
        kiem("khối ghim lấy việc cần chốt và chương trình từ thẻ mới nhất",
             tl["ghim"].get("can_chot") == ["Buổi thực hành chưa có người phụ trách"]
             and len(tl["ghim"].get("chuong_trinh") or []) == 2, str(tl["ghim"]))
        hoi_the = [x for x in g.goi if x[0] == "hoi"]
        cau_the = [x for x in g.cau if "TÓM TẮT" in x[0]]
        # Chương trình nằm trong nguồn Thông tin buổi họp: câu hỏi trỏ tới đó, không chép lại
        # (câu hỏi dài quá thì Google không nhận, buổi học tối 28/9/2026)
        kiem("câu hỏi làm thẻ trỏ tới chương trình trong nguồn Thông tin buổi họp (nguồn đó có chương "
             "trình), không chép lại; thẻ đầu hỏi trên Thông tin buổi họp và đoạn đầu",
             'mục đó của nguồn "Thông tin buổi họp"' in g.cau[0][0]
             and "1. Kiểm điểm công việc tuần trước" not in g.cau[0][0]
             and any(x[0] == "them_chu" and "1. Kiểm điểm công việc tuần trước" in x[1] for x in g.goi)
             and hoi_the[0] == ("hoi", ("tin", "d1")), str(hoi_the[:3]))
        kiem("mỗi thẻ hỏi không kèm mã cuộc trò chuyện, không nối tiếp thẻ trước",
             len(cau_the) >= 3 and all(x[1] is None for x in cau_the), str([x[1] for x in cau_the]))
        kiem("thẻ sau chỉ chọn Thông tin buổi họp, đoạn liền trước và đoạn mới; không chọn đoạn cũ "
             "hơn (Đoạn 25 chép lại Đoạn 10, 28/9/2026)",
             hoi_the[1] == ("hoi", ("tin", "d1", "d2")) and hoi_the[2] == ("hoi", ("tin", "d2", "d3")),
             str(hoi_the[:3]))
        kiem("thẻ sau biết mạch các đoạn trước qua khối diễn biến, kèm việc cần chốt đã ghi nhận",
             "DIỄN BIẾN TỪ ĐẦU BUỔI" not in cau_the[0][0]
             and "DIỄN BIẾN TỪ ĐẦU BUỔI" in cau_the[2][0] and "- Đoạn 1 (" in cau_the[2][0]
             and "- Đoạn 2 (" in cau_the[2][0] and "Khoá MOS có 32 học viên" in cau_the[2][0]
             and "Việc cần chốt đã ghi nhận" in cau_the[2][0]
             and '"Đoạn 2 (' in cau_the[2][0].split("chỉ để nối mạch")[0], cau_the[2][0][:300])
        kiem("câu hỏi làm thẻ gửi kèm ghi chú của thư ký và dòng Ghi ngữ cảnh",
             any(GHI_CHU in x[0] and NGU_CANH in x[0] for x in g.cau if "TÓM TẮT" in x[0]))
        c.post("/may/tro-ly/hoi", json={"cau_hoi": "Đầu buổi nói khoá MOS có bao nhiêu học viên?"},
               headers=NUT)
        cho_den(lambda: any(t["loai"] == "hoi" and not t.get("dang") for t in v["tro_ly"]["the"]), 8)
        the_hoi = [t for t in v["tro_ly"]["the"] if t["loai"] == "hoi"]
        kiem("ô Hỏi NotebookLM: câu trả lời hiện thành thẻ, bỏ số trích dẫn",
             bool(the_hoi) and the_hoi[0].get("tra_loi") == "Đầu buổi có nói khoá MOS có 32 học viên.",
             str(the_hoi)[:150])
        cau_o_hoi = [x for x in g.cau if "bao nhiêu học viên" in x[0]][0]
        kiem("ô Hỏi dùng cuộc trò chuyện riêng, không làm lệch khuôn của thẻ",
             cau_o_hoi[1] is None)
        kiem("ô Hỏi gửi kèm ghi chú của thư ký, dòng Ghi ngữ cảnh và ghi nhanh",
             GHI_CHU in cau_o_hoi[0] and NGU_CANH in cau_o_hoi[0]
             and "Anh Nam chốt phương án 2" in cau_o_hoi[0])
        c.post("/may/tro-ly/hoi", json={"cau_hoi": "Ai phụ trách khoá MOS?"}, headers=NUT)
        cho_den(lambda: sum(1 for t in v["tro_ly"]["the"]
                            if t["loai"] == "hoi" and not t.get("dang")) >= 2, 8)
        cau_hoi_2 = [x for x in g.cau if "Ai phụ trách khoá MOS" in x[0]]
        kiem("câu hỏi thứ hai ở ô Hỏi nối tiếp cuộc trò chuyện riêng của ô Hỏi, để hỏi tiếp "
             "được câu trước",
             bool(cau_hoi_2) and cau_hoi_2[0][1] == "c2" and v["tro_ly"]["hoi_thoai_rieng"] == "c2",
             str(cau_hoi_2[:1])[-80:])
        c.post("/may/tro-ly/tong-ket", headers=NUT)
        cho_den(lambda: any(t["loai"] == "tong_ket" for t in v["tro_ly"]["the"]), 10)
        tk = [t for t in v["tro_ly"]["the"] if t["loai"] == "tong_ket"]
        kiem("bấm Tổng kết: thẻ tổng kết có quyết định, việc đã giao, còn mở",
             bool(tk) and tk[0].get("quyet_dinh") == ["Thêm một buổi thực hành cho khoá MOS"]
             and tk[0].get("viec_giao") and tk[0].get("con_mo"), str(tk)[:150])
        time.sleep(1.5)
        c.post("/may/ghi/dung", headers=NUT)
        kiem("dừng: tới Xong như thường", cho_xong(ma, 15) == "Xong", str(v.get("loi")))
        cau_bb = [x[0] for x in g.cau if "BIÊN BẢN" in x[0]][-1]
        kiem("dòng ghi nhanh đi vào câu lệnh soạn biên bản, kèm mốc và lời dặn ưu tiên",
             "Anh Nam chốt phương án 2, hạn 30/9" in cau_bb and "ưu tiên các ghi chú này" in cau_bb
             and "Dòng ghi nhầm" not in cau_bb)
        kiem("ghi chú của thư ký và dòng Ghi ngữ cảnh đi vào câu lệnh soạn biên bản, "
             "dòng đã xoá thì không",
             GHI_CHU in cau_bb and NGU_CANH in cau_bb and "Dòng ngữ cảnh ghi nhầm" not in cau_bb)
        kiem("câu Tổng kết cũng gửi kèm ghi chú của thư ký",
             any(GHI_CHU in x[0] for x in g.cau if "QUYẾT ĐỊNH" in x[0] and "BIÊN BẢN" not in x[0]))
        tm = Path(v["thu_muc"])
        chu_tl = ((tm / "tro-ly.txt").read_text(encoding="utf-8")
                  if (tm / "tro-ly.txt").is_file() else "")
        kiem("tro-ly.txt có các thẻ, câu hỏi, tổng kết, dòng ngữ cảnh và dòng ghi nhanh",
             "32 học viên" in chu_tl and "Thêm một buổi thực hành" in chu_tl
             and "bao nhiêu học viên" in chu_tl and "Anh Nam chốt" in chu_tl
             and f"Ngữ cảnh thư ký ghi: {NGU_CANH}" in chu_tl)
        kiem("tro-ly.txt: thẻ Hỏi in câu hỏi một dòng rồi tới câu trả lời, không tách từng chữ",
             "khoá MOS có bao nhiêu học viên?\nTrả lời: Đầu buổi có nói" in chu_tl, chu_tl[-400:])
        kiem("ghi chép trong buổi họp lưu thành ghi chú trong sổ NotebookLM",
             ("ghi_chu", "Ghi chú trong buổi họp") in g.goi and bool(g.so_tay)
             and "32 học viên" in g.so_tay[-1] and "Anh Nam chốt" in g.so_tay[-1])
        kiem("ghi chú của thư ký lưu trên máy ở tệp riêng, xem lại cuộc họp thấy được",
             (tm / "ghi-chu-thu-ky.txt").read_text(encoding="utf-8") == GHI_CHU
             and c.get(f"/may/viec/{ma}").json().get("ghi_chu_rieng") == GHI_CHU)
        c.put(f"/may/viec/{ma}/ghi-chu-rieng", json={"chu": GHI_CHU + " (sửa sau họp)"},
              headers=NUT)
        kiem("sửa được ghi chú của thư ký sau khi họp xong",
             (tm / "ghi-chu-thu-ky.txt").read_text(encoding="utf-8").endswith("(sửa sau họp)"))
        c.put(f"/may/viec/{ma}/ghi-chu-rieng", json={"chu": ""}, headers=NUT)
        kiem("xoá hết ghi chú của thư ký thì xoá luôn tệp",
             not (tm / "ghi-chu-thu-ky.txt").exists())
        # Cuộc họp ghi trước 27/9/2026 còn tên tệp cũ: nạp lại thì đổi sang tên mới
        (tm / "ghi-chu-rieng.txt").write_text(GHI_CHU, encoding="utf-8")
        (tm / "ban-go-chu.txt").write_text((tm / "ban-chep-loi.txt").read_text(encoding="utf-8"),
                                           encoding="utf-8")
        (tm / "ban-chep-loi.txt").unlink()
        bbh.VIEC.clear()
        bbh.THU_TU.clear()
        bbh.nap_lai_lich_su()
        kiem("tắt mở lại ứng dụng: ghi chú của thư ký, các thẻ và dòng ghi nhanh vẫn còn",
             bbh.VIEC[ma].get("ghi_chu_rieng") == GHI_CHU and bbh.VIEC[ma]["tro_ly"]["the"]
             and bbh.VIEC[ma]["tro_ly"]["ghi_nhanh"])
        kiem("cuộc họp cũ còn tên tệp cũ: vẫn mở được, tệp đổi sang tên mới",
             (tm / "ghi-chu-thu-ky.txt").is_file() and not (tm / "ghi-chu-rieng.txt").exists()
             and (tm / "ban-chep-loi.txt").is_file() and not (tm / "ban-go-chu.txt").exists()
             and bool(bbh.VIEC[ma].get("ban_go_chu")))

        # Lượt hỏi trong ngày: còn ít thì giãn nhịp, gần hết thì thôi tóm tắt
        bbh.TRAN_LUOT = 50
        hom_nay = f"{datetime.now():%Y-%m-%d}"
        bbh.TEP_LUOT.write_text(bbh.json.dumps({"ngay": hom_nay, "da_dung": 40}), encoding="utf-8")
        kiem("còn dưới 15 lượt hỏi trong ngày thì nhịp giãn ra ít nhất 10 phút",
             bbh.nhip_thuc() == 10 * bbh.GIAY_MOI_PHUT)
        bbh.TEP_LUOT.write_text(bbh.json.dumps({"ngay": hom_nay, "da_dung": 47}), encoding="utf-8")
        NLM[0] = g = NlmNhieuNguon()
        ma = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        v = bbh.VIEC[ma]
        time.sleep(2)
        c.post("/may/tro-ly/tom-tat-ngay", headers=NUT)
        cho_den(lambda: len(doan_xong(ma)) >= 1, 10)
        time.sleep(0.5)
        kiem("còn 3 lượt thì vẫn gửi đoạn nhưng thôi tóm tắt, nói rõ để giữ lượt cho biên bản cuối",
             len(doan_xong(ma)) >= 1 and "hoi" not in ten_goi(g) and not v["tro_ly"]["the"]
             and "giữ lượt cho biên bản cuối" in v["tro_ly"]["trang_thai"], v["tro_ly"]["trang_thai"])
        kiem("khi đó ô Hỏi NotebookLM cũng từ chối, nói rõ vì sao",
             c.post("/may/tro-ly/hoi", json={"cau_hoi": "x"}, headers=NUT).status_code == 409)
        c.post("/may/ghi/dung", headers=NUT)
        kiem("biên bản cuối vẫn dùng được lượt đã giữ",
             cho_xong(ma, 15) == "Xong" and goi_hoi_cuoi(g) == ("hoi", ("t1",)))
        bbh.TRAN_LUOT = 1000
        bbh.TEP_LUOT.unlink(missing_ok=True)

        # NotebookLM báo hết lượt đúng lúc làm thẻ: đoạn vẫn giữ, các đoạn sau thôi hỏi
        class NlmHetLuotThe(NlmNhieuNguon):
            async def _hoi(self, so_id, cau_hoi, source_ids=None, conversation_id=None):
                if "TÓM TẮT" in cau_hoi:
                    await self._buoc("hoi_the")
                    raise RateLimitError("quota exceeded")
                return await super()._hoi(so_id, cau_hoi, source_ids, conversation_id)

        NLM[0] = g = NlmHetLuotThe()
        ma = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        v = bbh.VIEC[ma]
        cho_den(lambda: len(doan_xong(ma)) >= 2, 20)
        kiem("NotebookLM báo hết lượt khi làm thẻ: đoạn vẫn giữ, thẻ báo hết lượt, đoạn sau thôi hỏi",
             len(doan_xong(ma)) >= 2 and ten_goi(g).count("hoi_the") == 1 and v["tro_ly"]["het_luot"]
             and any("hết lượt" in t.get("chu", "") for t in v["tro_ly"]["the"]),
             f"{ten_goi(g)}; {v['tro_ly']['the']}"[:200])
        c.post("/may/ghi/dung", headers=NUT)
        cho_xong(ma, 15)

        # Cuộc họp Không gửi lên mạng: ghi nhanh, dòng Ghi ngữ cảnh và ô Ghi chú của thư ký
        # vào khung biên bản trên máy, không gửi đi đâu (PM đồng ý 27/9/2026)
        c.put("/may/thong-tin", json={"cach_go_chu": "whisper"}, headers=NUT)
        NLM[0] = g = NlmNhieuNguon()
        ma = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        v = bbh.VIEC[ma]
        c.post("/may/tro-ly/ghi-nhanh", json={"chu": "Chị Lan báo cáo tuyển sinh"}, headers=NUT)
        c.post("/may/tro-ly/ngu-canh", json={"chu": "Anh Tuấn nói về học phí"}, headers=NUT)
        c.put(f"/may/viec/{ma}/ghi-chu-rieng", json={"chu": "Khách mời là đại diện doanh nghiệp"},
              headers=NUT)
        kiem("cuộc họp Không gửi lên mạng: ô Hỏi không chạy",
             c.post("/may/tro-ly/hoi", json={"cau_hoi": "Có gì?"}, headers=NUT).status_code == 409)
        time.sleep(1)
        c.post("/may/ghi/dung", headers=NUT)
        kiem("cuộc họp Không gửi lên mạng: ghi nhanh, dòng ngữ cảnh, ghi chú của thư ký vào khung "
             "biên bản, không gửi đi đâu",
             cho_xong(ma) == "Xong" and "Chị Lan báo cáo tuyển sinh" in (v["ket_qua"] or "")
             and "Anh Tuấn nói về học phí" in v["ket_qua"]
             and "Khách mời là đại diện doanh nghiệp" in v["ket_qua"]
             and "Ghi chú của thư ký trong lúc họp" in v["ket_qua"] and not g.goi, str(ten_goi(g)))
        c.put("/may/thong-tin", json={"cach_go_chu": "notebooklm"}, headers=NUT)

        # Chuyển giữa buổi: chỉ gửi kèm các dòng ghi nhanh thuộc phần đã gửi
        NLM[0] = g = NlmNhieuNguon()
        ma = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        v = bbh.VIEC[ma]
        c.post("/may/tro-ly/ghi-nhanh", json={"chu": "Ghi chú phần đầu"}, headers=NUT)
        cho_den(lambda: len(doan_xong(ma)) >= 1, 15)
        c.put("/may/thong-tin", json={"cach_go_chu": "whisper"}, headers=NUT)
        c.post("/may/tro-ly/ghi-nhanh", json={"chu": "Ghi chú sau khi chuyển"}, headers=NUT)
        c.post("/may/tro-ly/ngu-canh", json={"chu": "Ngữ cảnh sau khi chuyển"}, headers=NUT)
        c.put(f"/may/viec/{ma}/ghi-chu-rieng", json={"chu": "Ô ghi chú viết sau khi chuyển"},
              headers=NUT)
        time.sleep(1)
        c.post("/may/ghi/dung", headers=NUT)
        cho_xong(ma, 15)
        cau_bb = [x[0] for x in g.cau if "BIÊN BẢN" in x[0]]
        kiem("chuyển giữa buổi: chỉ gửi kèm ghi nhanh của phần đã gửi, không lưu ghi chú vào sổ",
             bool(cau_bb) and "Ghi chú phần đầu" in cau_bb[-1]
             and "Ghi chú sau khi chuyển" not in repr(g.cau) + repr(g.goi)
             and "ghi_chu" not in ten_goi(g), str(ten_goi(g)))
        kiem("chuyển giữa buổi: dòng ngữ cảnh và ô Ghi chú của thư ký viết sau lúc chuyển "
             "không gửi đi đâu",
             "Ngữ cảnh sau khi chuyển" not in repr(g.cau) + repr(g.goi)
             and "Ô ghi chú viết" not in repr(g.cau) + repr(g.goi))
        NLM[0] = g = NlmNhieuNguon()
        asyncio.run(bbh.ghi_so_tay(v))
        kiem("lưới an toàn: cuộc họp đã chuyển sang Không gửi lên mạng thì dù bị gọi cũng không "
             "lưu ghi chú vào sổ", not g.goi, str(ten_goi(g)))
        c.put("/may/thong-tin", json={"cach_go_chu": "notebooklm"}, headers=NUT)

        # --------------------------------------------------------------------
        print("\nJ2. Sửa sau buổi giao ban 28/9/2026: mốc ghi chú theo âm thanh thật, tên từng "
              "đoạn, khai báo buổi họp")
        # --------------------------------------------------------------------
        # Đếm giây âm thanh thật trong các tệp đoạn, đọc tiếp từ lần đếm trước
        may = ghi_am.MayGhi()
        tm_do = TAM / "do-am-thanh"
        tm_do.mkdir()
        (tm_do / "doan-01.aac").write_bytes(goc[:len(goc) // 2 + 37])  # dừng giữa một khung
        may.thu_muc = tm_do
        g1 = may.giay_am_thanh()
        (tm_do / "doan-01.aac").write_bytes(goc)
        (tm_do / "doan-02.aac").write_bytes(goc)  # tạm dừng rồi ghi tiếp
        g2 = may.giay_am_thanh()
        kiem("đếm giây âm thanh thật trong các tệp đoạn, đọc tiếp phần mới, khung đang ghi dở chưa tính",
             0 < g1 < giay_goc and abs(g2 - 2 * giay_goc) < 0.01, f"{g1:.2f}; {g2:.2f}/{2 * giay_goc:.2f}")
        may.thu_muc = None
        kiem("không ghi thì không có giây âm thanh", may.giay_am_thanh() == 0.0)
        kiem("hệ số đổi mốc: cuộc họp mới là 1; cuộc họp cũ lấy âm thanh chia đồng hồ; số lạ thì 1",
             bbh.ti_le_moc({"tro_ly": {"moc_am": True}, "am_thanh_giay": 500, "thoi_luong_giay": 600}) == 1
             and abs(bbh.ti_le_moc({"tro_ly": {}, "am_thanh_giay": 525, "thoi_luong_giay": 600})
                     - 0.875) < 1e-9
             and bbh.ti_le_moc({"tro_ly": {}, "am_thanh_giay": 100, "thoi_luong_giay": 600}) == 1
             and bbh.ti_le_moc({"tro_ly": {}}) == 1 and bbh.moi_tro_ly()["moc_am"] is True)

        # Máy rớt tiếng: đồng hồ ghi đi trước âm thanh. Mốc ghi chú phải theo âm thanh thật,
        # cùng thang với mốc các đoạn (thẻ đã dời người nói tới 10 phút, 28/9/2026)
        c.put("/may/thong-tin", json={"cach_go_chu": "notebooklm", "nhip_tro_ly": "0"}, headers=NUT)
        NLM[0] = g = NlmNhieuNguon()
        ma = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        v = bbh.VIEC[ma]
        time.sleep(2)
        with bbh.MAY_GHI.khoa:
            bbh.MAY_GHI.giay_truoc += 600  # như đã rớt 10 phút tiếng
        c.post("/may/tro-ly/ghi-nhanh", json={"chu": "Chị Lan bắt đầu báo cáo"}, headers=NUT)
        c.post("/may/tro-ly/ngu-canh", json={"chu": "Cô Hà đang phát biểu"}, headers=NUT)
        gn = v["tro_ly"]["ghi_nhanh"][-1]["luc"]
        nc = [t for t in v["tro_ly"]["the"] if t["loai"] == "ngu_canh"][-1]["giay"]
        dh = c.get("/may/ghi/trang-thai").json()["giay"]
        kiem("máy rớt tiếng (đồng hồ đi trước âm thanh 10 phút): ghi nhanh và dòng ngữ cảnh mang mốc "
             "theo âm thanh thật, không theo đồng hồ",
             dh > 600 and 0.5 < gn < 10 and 0.5 < nc < 10, f"đồng hồ {dh}; ghi nhanh {gn}; ngữ cảnh {nc}")
        time.sleep(1)
        c.post("/may/tro-ly/tom-tat-ngay", headers=NUT)
        cho_den(lambda: any(t["loai"] == "doan" for t in v["tro_ly"]["the"]), 10)
        cau = next((x[0] for x in g.cau if "TÓM TẮT" in x[0]), "")
        kiem("câu hỏi làm thẻ gửi mốc ghi chú cùng thang với mốc đoạn, không trễ ra sau đoạn",
             re.search(r"- \[00:0\d\] Cô Hà đang phát biểu", cau) is not None, cau[-300:])
        c.put("/may/thong-tin", json={"cach_go_chu": "whisper"}, headers=NUT)
        kiem("mốc lúc chuyển sang Không gửi lên mạng cũng theo âm thanh thật",
             v["tro_ly"]["chuyen_luc"] is not None and v["tro_ly"]["chuyen_luc"] < 60,
             str(v["tro_ly"]["chuyen_luc"]))
        c.post("/may/ghi/dung", headers=NUT)
        cho_xong(ma, 15)
        kiem("lúc Dừng lưu độ dài âm thanh thật cạnh độ dài đồng hồ, nhật ký báo hụt",
             0 < (v.get("am_thanh_giay") or 0) < 60 and v["thoi_luong_giay"] > 600
             and any("hụt" in x[1] for x in v["nhat_ky"]),
             f"{v.get('am_thanh_giay')}; {v.get('thoi_luong_giay')}")
        c.put("/may/thong-tin", json={"cach_go_chu": "notebooklm", "nhip_tro_ly": "0"}, headers=NUT)

        # Thư viện tải lên được nhưng chưa đặt được tên riêng: nguồn mang tên tệp
        class NlmKhongDatTen(NlmNhieuNguon):
            async def _them_tep(self, so_id, tep, loai=None, title=None, **_):
                d = await super()._them_tep(so_id, tep, loai, title=title)
                self.ten[d.id] = Path(tep).name
                return SimpleNamespace(id=d.id, title=Path(tep).name)

        NLM[0] = g = NlmKhongDatTen()
        ma = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        time.sleep(1.5)
        c.post("/may/tro-ly/tom-tat-ngay", headers=NUT)
        cho_den(lambda: len(doan_xong(ma)) >= 1, 10)
        d1 = (bbh.VIEC[ma]["tro_ly"]["doan"] or [{}])[0]
        kiem("dịch vụ chưa nhận tên riêng lúc tải lên: nguồn sẵn sàng thì máy đổi tên lại đúng tên đoạn",
             any(x[0] == "doi_ten" and x[2] == d1.get("ten") for x in g.goi)
             and g.ten.get(d1.get("nguon")) == d1.get("ten") and d1.get("ten_so") == d1.get("ten"),
             str([x for x in g.goi if x[0] == "doi_ten"]))
        c.post("/may/ghi/dung", headers=NUT)
        cho_xong(ma, 15)

        # Đổi tên cũng hỏng: thôi, đoạn vẫn dùng được (tên tệp cũng có số thứ tự và mốc)
        class NlmDoiTenHong(NlmKhongDatTen):
            async def _doi_ten(self, so_id, nguon_id, ten):
                await self._buoc("doi_ten_hong", nguon_id)
                raise RuntimeError("đổi tên hỏng giả lập")

        NLM[0] = g = NlmDoiTenHong()
        ma = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        time.sleep(1.5)
        c.post("/may/tro-ly/tom-tat-ngay", headers=NUT)
        cho_den(lambda: len(doan_xong(ma)) >= 1, 10)
        d1 = (bbh.VIEC[ma]["tro_ly"]["doan"] or [{}])[0]
        kiem("đổi tên cũng hỏng thì thôi: đoạn vẫn lấy chữ về, giữ tên tệp, không bỏ đoạn gửi lại",
             "doi_ten_hong" in ten_goi(g) and d1.get("tt") == "xong" and bool(d1.get("chu"))
             and str(d1.get("ten_so")).startswith("Doan-01_") and "xoa_nguon" not in ten_goi(g),
             str(d1)[:200])
        c.post("/may/ghi/dung", headers=NUT)
        cho_xong(ma, 15)

        # Giờ đồng hồ trong tên đoạn: đoạn sau bắt đầu đúng giờ đoạn trước kết thúc; bỏ đoạn
        # hỏng thì lùi cả giờ. "25:00" không bao giờ là giờ thật nên phép thử không phụ thuộc
        # lúc chạy (các đoạn trong phép thử khác cắt cách nhau vài giây, cùng một phút).
        class NlmGhiTen:
            def __init__(self):
                self.chu = []
                self.sources = SimpleNamespace(add_file=self._them, delete=self._xoa,
                                               add_text=self._them_chu)

            async def _them(self, so_id, tep, loai=None, title=None, **_):
                return SimpleNamespace(id="g1", title=title)

            async def _xoa(self, so_id, nguon_id):
                pass

            async def _them_chu(self, so_id, ten, chu, **_):
                self.chu.append(ten)
                return SimpleNamespace(id="tin")

        (TAM / "gio-doan").mkdir()  # ngoài thư mục lưu: không thành một cuộc họp trong danh sách
        vg = {"ma": "giodoan", "thu_muc": str(TAM / "gio-doan"), "tro_ly": bbh.moi_tro_ly()}
        vg["tro_ly"]["gio_cat"] = "25:00"
        dg = asyncio.run(bbh.tai_doan(NlmGhiTen(), vg, {"id": "s"}, TAM / "x.m4a", 300.0, 999))
        gio_sau = vg["tro_ly"]["gio_cat"]
        asyncio.run(bbh.bo_doan(NlmGhiTen(), vg, {"id": "s"}, dg))
        kiem("đoạn mới bắt đầu từ giờ đoạn trước kết thúc, rồi dời giờ tới lúc cắt; bỏ đoạn hỏng thì "
             "lùi cả giờ, đoạn gửi lại mang đúng giờ bắt đầu cũ",
             dg["gio_tu"] == "25:00" and dg["ten"].startswith("Đoạn 1 (00:00-05:00, 25:00-")
             and gio_sau == dg["gio_den"] != "25:00" and vg["tro_ly"]["gio_cat"] == "25:00"
             and vg["tro_ly"]["giay_da_cat"] == 0 and not vg["tro_ly"]["doan"],
             f"{dg.get('ten')}; {gio_sau}; {vg['tro_ly'].get('gio_cat')}")
        # Lưới an toàn thứ hai: cuộc họp Không gửi lên mạng thì dua_thong_tin không gửi gì,
        # kể cả khi nơi gọi quên xét (nơi gọi hiện đều đã xét trước)
        gk = NlmGhiTen()
        vk = {"ma": "khonggui", "thu_muc": str(TAM / "gio-doan"), "tro_ly": bbh.moi_tro_ly(),
              "tt": {"ten_cuoc_hop": "Họp kín"}, "cach_da_bao": "whisper"}
        asyncio.run(bbh.dua_thong_tin(gk, vk, {"id": "s"}))
        khong_gui = (list(gk.chu), vk["tro_ly"]["thong_tin"])  # kiểm ngay, trước lần gọi sau
        vk["cach_da_bao"] = "notebooklm"
        asyncio.run(bbh.dua_thong_tin(gk, vk, {"id": "s"}))
        asyncio.run(bbh.dua_thong_tin(gk, vk, {"id": "s"}))
        kiem("cuộc họp Không gửi lên mạng: Thông tin buổi họp không gửi đi dù được gọi; cuộc họp "
             "gửi lên mạng thì gửi đúng một lần",
             khong_gui == ([], None) and gk.chu == [bbh.TEN_THONG_TIN]
             and vk["tro_ly"]["thong_tin"] == {"tt": "xong", "nguon": "tin"},
             f"{khong_gui}; {gk.chu}")

        # Không đưa được Thông tin buổi họp lên: thử lại ở lượt sau, tối đa 3 lần; thẻ vẫn chạy
        class NlmTinHong(NlmNhieuNguon):
            async def _them_chu(self, so_id, ten, chu, **_):
                if ten == bbh.TEN_THONG_TIN:
                    await self._buoc("them_chu_hong")
                    raise RuntimeError("mất mạng")
                return await super()._them_chu(so_id, ten, chu)

        c.put("/may/thong-tin", json={"nhip_tro_ly": "5"}, headers=NUT)
        NLM[0] = g = NlmTinHong()
        ma = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        v = bbh.VIEC[ma]
        cho_den(lambda: len([t for t in v["tro_ly"]["the"] if t["loai"] == "doan"]) >= 4, 30)
        kiem("không đưa được Thông tin buổi họp lên: thử lại tối đa 3 lần, các đoạn và thẻ vẫn chạy",
             ten_goi(g).count("them_chu_hong") == 3 and (v["tro_ly"]["thong_tin"] or {}).get("tt") == "loi"
             and len(doan_xong(ma)) >= 4 and all("tin" not in x[1] for x in g.goi if x[0] == "hoi"),
             f"{ten_goi(g).count('them_chu_hong')}; {v['tro_ly']['thong_tin']}")
        c.post("/may/ghi/dung", headers=NUT)
        cho_xong(ma, 15)

        # Ô Nội dung chính của hộp Khai báo buổi họp
        c.put("/may/thong-tin", json={"noi_dung": "Rà soát chương trình đào tạo có doanh nghiệp"},
              headers=NUT)
        tt_kb = bbh.tt_mac_dinh()
        kiem("khai báo Nội dung chính: lưu được, cuộc họp mới chụp lại cùng các mục khác",
             c.get("/may/thong-tin").json()["truong"].get("noi_dung")
             == "Rà soát chương trình đào tạo có doanh nghiệp"
             and tt_kb.get("noi_dung") == "Rà soát chương trình đào tạo có doanh nghiệp")
        kiem("Nội dung chính đi vào nguồn Thông tin buổi họp và câu lệnh soạn biên bản; không khai "
             "báo (hay cuộc họp cũ) thì không có dòng đó",
             "Nội dung chính: Rà soát" in bbh.chu_thong_tin(tt_kb)
             and "Nội dung chính (thư ký khai báo" in bbh.cau_lenh_soan(tt_kb)
             and "Nội dung chính" not in bbh.cau_lenh_soan(dict(tt_kb, noi_dung=""))
             and "Nội dung chính" not in bbh.cau_lenh_soan(
                 {k: x for k, x in tt_kb.items() if k != "noi_dung"}))
        c.put("/may/thong-tin", json={"noi_dung": "", "nhip_tro_ly": "5"}, headers=NUT)
        # Nội dung chính là của riêng buổi đó, như tệp liên quan: bắt đầu ghi thì bỏ khỏi mặc định
        c.put("/may/thong-tin", json={"noi_dung": "Chốt kế hoạch tuyển sinh quý 4",
                                      "cach_go_chu": "whisper"}, headers=NUT)
        ma_nd = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        mac_dinh_sau = c.get("/may/thong-tin").json()["truong"]
        kiem("bắt đầu ghi: cuộc họp giữ Nội dung chính đã khai báo; mặc định cho buổi sau bỏ ô đó "
             "(buổi sau không điền sẵn trọng tâm cũ), các ô khác vẫn giữ",
             bbh.VIEC[ma_nd]["tt"].get("noi_dung") == "Chốt kế hoạch tuyển sinh quý 4"
             and mac_dinh_sau.get("noi_dung") == ""
             and mac_dinh_sau["ten_cuoc_hop"] == bbh.VIEC[ma_nd]["tt"]["ten_cuoc_hop"] != "",
             str(mac_dinh_sau)[:160])
        time.sleep(2)
        c.post("/may/ghi/dung", headers=NUT)
        cho_xong(ma_nd, 15)
        c.put("/may/thong-tin", json={"cach_go_chu": "notebooklm"}, headers=NUT)
        gd = (THU_MUC / "giao_dien.html").read_text(encoding="utf-8")
        kb_ghi = gd.split('$("kb-ghi").onclick', 1)[-1].split("\n});", 1)[0]
        kiem("giao diện: bấm Bắt đầu ghi âm thì mở hộp Khai báo buổi họp, đủ các ô (kể cả Nội dung "
             "chính và tệp liên quan); hộp lưu thông tin rồi mới bắt đầu ghi",
             '$("nut-ghi").onclick = moKhaiBao;' in gd
             and all(f'id="kb-{k}"' in gd for k in ("ten_cuoc_hop", "thoi_gian", "dia_diem", "chu_tri",
                                                    "thu_ky", "tham_du", "chuong_trinh", "noi_dung",
                                                    "viec_tuan_truoc", "chon-tl"))
             and 0 <= kb_ghi.find('goi("/may/thong-tin", "PUT", moi)')
             < kb_ghi.find('goi("/may/ghi/bat-dau")'), kb_ghi[:200])

        # Loại họp và mẫu biên bản (PM duyệt tối 28/9/2026)
        ds_goc = c.get("/may/loai-hop").json()["ds"]
        kiem("chưa lưu loại họp nào: có sẵn hai mẫu gốc, Họp giao ban đứng đầu, rồi Buổi học nội bộ",
             [x["ten"] for x in ds_goc] == ["Họp giao ban", "Buổi học nội bộ"], str(ds_goc)[:120])
        tt_gb = dict(tt_kb, loai_hop="", viec_tuan_truoc="")
        cau_gb = bbh.cau_lenh_soan(tt_gb)
        kiem("họp giao ban giữ đúng mẫu cũ: tiêu đề, 4 mục, Phân công là bảng 3 cột và là phần "
             "quan trọng nhất",
             "Soạn BIÊN BẢN HỌP GIAO BAN" in cau_gb and "- Loại họp: Họp giao ban" in cau_gb
             and "1. THÀNH PHẦN THAM DỰ\n2. NỘI DUNG: tách theo từng vấn đề" in cau_gb
             and ("3. KẾT LUẬN CỦA CHỦ TRÌ\n4. PHÂN CÔNG: bảng 3 cột gồm Việc, Người phụ trách, "
                  "Hạn hoàn thành. Đây là phần quan trọng nhất") in cau_gb, cau_gb[-900:])
        cau_gb_tt = bbh.cau_lenh_soan(dict(tt_gb, viec_tuan_truoc="Gửi báo cáo quý"))
        kiem("có việc tuần trước: chèn mục kiểm điểm ngay sau Thành phần, các mục sau lùi số",
             "2. KIỂM ĐIỂM VIỆC TUẦN TRƯỚC" in cau_gb_tt and "5. PHÂN CÔNG" in cau_gb_tt
             and "Việc đã phân công tuần trước:\nGửi báo cáo quý" in cau_gb_tt)
        tt_hoc = dict(tt_gb, loai_hop="Buổi học nội bộ")
        cau_hoc = bbh.cau_lenh_soan(tt_hoc)
        kiem("buổi học nội bộ: đúng tiêu đề và 5 mục PM duyệt, bảng việc cần làm 3 cột, không có "
             "mục Phân công hay chữ họp giao ban",
             "Soạn BIÊN BẢN BUỔI HỌC NỘI BỘ" in cau_hoc
             and "2. NỘI DUNG CHUYÊN ĐỀ: ý chính người trình bày nói" in cau_hoc
             and "3. THẢO LUẬN, HỎI ĐÁP: câu hỏi và câu trả lời" in cau_hoc
             and "4. KẾT LUẬN, ĐIỀU RÚT RA\n" in cau_hoc
             and "5. VIỆC CẦN LÀM SAU BUỔI HỌC: bảng 3 cột gồm Việc, Người phụ trách, Hạn." in cau_hoc
             and "PHÂN CÔNG" not in cau_hoc and "GIAO BAN" not in cau_hoc, cau_hoc[-900:])
        kiem("tên loại ghi hoa thường, thừa dấu cách vẫn nhận; loại đã xoá, đổi tên hay cuộc họp cũ "
             "chưa có loại thì dùng loại đầu danh sách",
             bbh.loai_hop_cua(dict(tt_gb, loai_hop="  buổi HỌC  nội bộ "))["ten"] == "Buổi học nội bộ"
             and bbh.loai_hop_cua(dict(tt_gb, loai_hop="Họp đã xoá"))["ten"] == "Họp giao ban"
             and bbh.loai_hop_cua({})["ten"] == "Họp giao ban")
        khoi_hoc = tao_word.tach_than_bai(bbh.khung_bien_ban("[00:00] xin chào", tt_hoc),
                                          tt_hoc["ten_cuoc_hop"])
        muc_hoc = [k[1] for k in khoi_hoc if k[0] == "muc"]
        vi_tri = [i for i, k in enumerate(khoi_hoc) if k == ("doan", "[00:00] xin chào")]
        kiem("khung biên bản trên máy theo mẫu buổi học: đủ mục đúng thứ tự, chữ chép lời nằm ở mục "
             "chữ đầu tiên, bảng việc cần làm có hàng trống để điền",
             muc_hoc == ["CHƯƠNG TRÌNH", "NỘI DUNG CHUYÊN ĐỀ", "THẢO LUẬN, HỎI ĐÁP",
                         "KẾT LUẬN, ĐIỀU RÚT RA", "VIỆC CẦN LÀM SAU BUỔI HỌC"]
             and vi_tri and khoi_hoc.index(("muc", "NỘI DUNG CHUYÊN ĐỀ")) < vi_tri[0]
             < khoi_hoc.index(("muc", "THẢO LUẬN, HỎI ĐÁP"))
             and [k[1] for k in khoi_hoc if k[0] == "bang"] == [[["Việc", "Người phụ trách", "Hạn"],
                                                                 ["", "", ""]]], str(khoi_hoc)[:300])
        sai = [c.put("/may/loai-hop", json={"ds": d}, headers=NUT).status_code for d in (
            [], [{"ten": "", "muc": "A"}], [{"ten": "Họp A", "muc": " \n "}],
            [{"ten": "Họp A", "muc": "A"}, {"ten": "họp  a", "muc": "B"}],
            [{"ten": "Họp A", "muc": "VIỆC bảng gồm A | B"}],
            [{"ten": "Họp A", "muc": "A", "dan": 5}],
            [{"ten": f"Loại {i}", "muc": "A"} for i in range(bbh.TOI_DA_LOAI_HOP + 1)])]
        khong_rao = c.put("/may/loai-hop", json={"ds": ds_goc}).status_code
        kiem("lưu loại họp: từ chối danh sách rỗng, tên trống, không có mục, trùng tên (khác hoa "
             "thường, thừa dấu cách), mục bảng thiếu dấu hai chấm, sai kiểu, quá số loại tối đa; không "
             "qua hàng rào của giao diện thì bị chặn; danh sách cũ giữ nguyên",
             sai == [400] * 7 and khong_rao == 403 and c.get("/may/loai-hop").json()["ds"] == ds_goc,
             f"{sai} {khong_rao}")
        moi_ds = ds_goc + [{"ten": "Họp hội đồng thi", "tieu_de": "biên bản họp hội đồng thi",
                            "muc": ("1. THÀNH PHẦN THAM DỰ\n2) Kết quả thi: theo từng lớp\n"
                                    "- DANH SÁCH ĐỖ: bảng gồm Họ tên | Lớp | Điểm"),
                            "dan": "Giữ nguyên điểm số"}]
        r_lh = c.put("/may/loai-hop", json={"ds": moi_ds}, headers=NUT)
        luu_lh = c.get("/may/loai-hop").json()["ds"]
        r_chon = c.put("/may/thong-tin", json={"loai_hop": "Họp hội đồng thi"}, headers=NUT)
        tt_ht = bbh.tt_mac_dinh()
        cau_ht = bbh.cau_lenh_soan(dict(tt_ht, viec_tuan_truoc=""))
        kiem("thêm loại họp mới: lưu được, tiêu đề tự viết hoa, số thứ tự và gạch đầu dòng tự gõ bị "
             "bỏ, tên mục viết hoa; chọn ở hộp Khai báo thì cuộc họp mới dùng đúng mẫu, có lời dặn "
             "riêng, nguồn Thông tin buổi họp ghi loại họp",
             r_lh.status_code == 200 and r_chon.status_code == 200 and len(luu_lh) == 3
             and luu_lh[2]["tieu_de"] == "BIÊN BẢN HỌP HỘI ĐỒNG THI"
             and tt_ht["loai_hop"] == "Họp hội đồng thi" and "Soạn BIÊN BẢN HỌP HỘI ĐỒNG THI" in cau_ht
             and ("2. KẾT QUẢ THI: theo từng lớp\n3. DANH SÁCH ĐỖ: bảng 3 cột gồm Họ tên, Lớp, "
                  "Điểm.") in cau_ht
             and "Lời dặn riêng cho loại họp này: Giữ nguyên điểm số" in cau_ht
             and "Loại họp: Họp hội đồng thi" in bbh.chu_thong_tin(tt_ht), cau_ht[-700:])
        kiem("chọn loại họp không có trong danh sách thì bị từ chối",
             c.put("/may/thong-tin", json={"loai_hop": "Họp không có"}, headers=NUT).status_code == 400)
        # Cả đường đi thật: chọn Buổi học nội bộ, ghi, Dừng, câu soạn biên bản cuối theo mẫu đó
        c.put("/may/thong-tin", json={"loai_hop": "Buổi học nội bộ"}, headers=NUT)
        NLM[0] = g = NlmNhieuNguon()
        ma_lh = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        time.sleep(2)
        c.post("/may/ghi/dung", headers=NUT)
        xong_lh = cho_xong(ma_lh, 15)
        cau_cuoi = [x[0] for x in g.cau if "Soạn BIÊN BẢN" in x[0]]
        kiem("cuộc họp chọn Buổi học nội bộ: câu soạn biên bản cuối theo mẫu buổi học",
             xong_lh == "Xong" and bool(cau_cuoi) and "Soạn BIÊN BẢN BUỔI HỌC NỘI BỘ" in cau_cuoi[-1]
             and bbh.VIEC[ma_lh]["tt"]["loai_hop"] == "Buổi học nội bộ",
             f"{xong_lh}; {[x[0][:60] for x in g.cau][-2:]}")
        c.put("/may/loai-hop", json={"ds": ds_goc}, headers=NUT)
        c.put("/may/thong-tin", json={"loai_hop": "Họp giao ban"}, headers=NUT)
        kiem("giao diện: hộp Khai báo có ô chọn Loại họp lấy từ danh sách loại họp; thẻ Cài đặt có "
             "khung sửa mẫu, lưu cả danh sách",
             'id="kb-loai_hop"' in gd and '"loai_hop", "ten_cuoc_hop"' in gd
             and 'LOAI_HOP = (await lay("/may/loai-hop")).ds' in gd
             and all(f'id="lh-{k}"' in gd for k in ("chon", "them", "xoa", "ten", "tieu_de", "muc",
                                                    "dan", "luu"))
             and 'await goi("/may/loai-hop", "PUT", {ds: LH});' in gd)

        # Cuộc họp ghi trước 28/9/2026 (mốc ghi chú theo đồng hồ): Làm lại thì đo âm thanh thật
        # rồi quy đổi mốc ghi chú về cùng thang với bản chép lời
        tm = bbh.THU_MUC_LUU / "2026-09-28_0907_giaoban1"
        tm.mkdir()
        (tm / "ghi-am.aac").write_bytes(goc)  # 20 giây âm thanh
        ty = bbh.moi_tro_ly()
        ty.pop("moc_am")
        ty["ghi_nhanh"] = [{"luc": 16.0, "chu": "Cô Hà đang phát biểu"}]  # mốc theo đồng hồ
        bbh._ghi_an_toan(tm / "viec.json", bbh.json.dumps({
            "ma": "giaoban1", "trang_thai": "Lỗi", "tt": tt_kb, "tep_ghi_am": "ghi-am.aac",
            "nhan_luc": "2026-09-28T09:07:00", "bat_dau": "2026-09-28T09:07:00",
            "thoi_luong_giay": 25, "cach_da_bao": "notebooklm", "tro_ly": ty}))
        bbh.VIEC.clear()
        bbh.THU_TU.clear()
        bbh.nap_lai_lich_su()
        NLM[0] = g = NlmNhieuNguon()
        c.post("/may/viec/giaoban1/lam-lai", headers=NUT)
        vb = bbh.VIEC["giaoban1"]
        xong_gb = cho_xong("giaoban1")
        cau_bb = next((x[0] for x in reversed(g.cau) if "BIÊN BẢN" in x[0]), "")
        kiem("cuộc họp cũ bấm Làm lại: đo âm thanh thật (20 giây trên 25 giây đồng hồ), mốc ghi chú "
             "16 giây đồng hồ thành 12 giây trong bản ghi",
             xong_gb == "Xong" and abs((vb.get("am_thanh_giay") or 0) - 20) < 0.5
             and "[00:12] Cô Hà đang phát biểu" in cau_bb, f"{vb.get('am_thanh_giay')}; {cau_bb[-160:]}")

        # --------------------------------------------------------------------
        print("\nJ3. Câu hỏi dài quá: buổi học tối 28/9/2026 hỏng thẻ từ đoạn 4")
        # --------------------------------------------------------------------
        class ChatError(RuntimeError):
            """Cùng tên lỗi của thư viện notebooklm-py khi Google không nhận câu hỏi."""

        # Nguyên văn câu báo của thư viện (mục #1472): dài quá, khung lỗi, bị hạn chế lượt
        TU_CHOI = ("Chat request was rejected by the server (status 3). This usually means the "
                   "request was malformed or too large — most often an over-long question past "
                   "the server-side size limit; shorten it and try again.")
        KHUNG_LOI = ("Chat request failed: the server returned an error frame (code 3). This usually "
                     "means the request was rejected or the conversation could not be served; try "
                     "again.")
        HAN_CHE = "Chat request was rate limited or rejected by the API. Wait a few seconds and try again."
        DAI_QUA = "Dịch vụ xử lý không nhận câu hỏi, thường vì câu hỏi gửi lên dài quá"
        kiem("nhận ra lỗi Google không nhận câu hỏi vì dài quá (cả dạng khung lỗi), không nhầm với "
             "hết lượt hay mất mạng; câu báo nói rõ nguyên nhân, không còn chỉ là Có lỗi khi xử lý",
             bbh.la_qua_dai(ChatError(TU_CHOI)) and bbh.la_qua_dai(ChatError(KHUNG_LOI))
             and not bbh.la_qua_dai(ChatError(HAN_CHE)) and bbh.la_het_luot(ChatError(HAN_CHE))
             and not bbh.la_qua_dai(RuntimeError("mất mạng"))
             and bbh.ly_do_loi(ChatError(TU_CHOI)) == DAI_QUA
             and "hết lượt" in bbh.ly_do_loi(ChatError(HAN_CHE)))

        # Dựng lại buổi Học Marketing 2 theo ảnh PM gửi tối 28/9/2026
        Y = ("[Chưa rõ ai nói] cho biết việc sở hữu NFT và tài sản số (như vị trí đất ảo để truyền "
             "thông, con tàu đắt tiền, bức tranh) giúp thực hiện giao dịch mua bán dễ dàng.")
        CHOT = ["Triển khai cá nhân hóa trải nghiệm khách hàng và tối ưu hóa hành trình khách hàng dựa "
                "trên dữ liệu lớn (chưa rõ người phụ trách, chưa rõ hạn).",
                "Triển khai ứng dụng dữ liệu phi cấu trúc (social listening) để cải tiến sản phẩm "
                "(chưa rõ người phụ trách, chưa rõ hạn).",
                "Tối ưu hóa điểm chạm và điều chỉnh luồng thanh toán trên hệ thống (chưa rõ người "
                "phụ trách, chưa rõ hạn)."]
        TT_HOC = {"loai_hop": "Buổi học nội bộ", "ten_cuoc_hop": "Học Marketing 2",
                  "thoi_gian": "19 giờ 06 phút ngày 28 tháng 9 năm 2026", "dia_diem": "Trực tuyến",
                  "chu_tri": "Nguyễn Thị Mỹ Linh", "thu_ky": "Nguyễn Nam Hải",
                  "tham_du": "Nguyễn Thị Mỹ Linh\nNguyễn Nam Hải", "chuong_trinh": "",
                  "noi_dung": "Buổi học Marketing cho nghiên cứu sinh", "viec_tuan_truoc": ""}
        (TAM / "dai-qua").mkdir()  # ngoài thư mục lưu: không thành một cuộc họp trong danh sách

        def viec_dai(so_the, tt=TT_HOC, so_ghi=0, ghi_chu=""):
            """Cuộc họp gửi lên mạng đã có so_the thẻ, một dòng Ghi ngữ cảnh, so_ghi dòng ghi
            nhanh (30 giây một dòng) và ô ghi chú; so_the + 1 đoạn đã có chữ, Thông tin buổi họp
            đã lên sổ. Đoạn cuối là đoạn đang chờ làm thẻ."""
            ty = bbh.moi_tro_ly()
            ten = [f"Đoạn {i} ({i * 5 - 5:02d}:00-{i * 5:02d}:00)" for i in range(1, so_the + 2)]
            ty["the"] = [{"loai": "doan", "ten": ten[i], "tom_tat": [Y] * 4, "can_chot": CHOT}
                         for i in range(so_the)]
            ty["the"].append({"loai": "ngu_canh", "chu": "Người giảng là cô Nguyễn Thị Mỹ Linh",
                              "giay": 480.0})
            ty["ghi_nhanh"] = [{"luc": 30.0 * i, "chu": f"Ghi nhanh số {i}: anh Tuấn nhắc hạn nộp hồ "
                                                         "sơ ngày 30/9"} for i in range(1, so_ghi + 1)]
            ty["doan"] = [{"ten": ten[i], "tu": 300.0 * i, "den": 300.0 * i + 300, "nguon": f"n{i + 1}",
                           "tt": "xong"} for i in range(so_the + 1)]
            ty.update(thong_tin={"tt": "xong", "nguon": "tin"}, giay_da_cat=300.0 * (so_the + 1))
            return {"ma": "daiqua", "thu_muc": str(TAM / "dai-qua"), "tt": dict(tt), "tro_ly": ty,
                    "ghi_chu_rieng": ghi_chu, "cach_da_bao": "notebooklm", "so_nlm": {"id": "so1"},
                    "nhat_ky": []}

        def cau_the(vx, i):
            d = vx["tro_ly"]["doan"][i]
            return bbh.cau_hoi_the(vx, d, bbh.doan_truoc(vx["tro_ly"], d))

        cau5 = [cau_the(viec_dai(n, ghi_chu="Đây là buổi học Marketing của tôi, cho Nghiên cứu sinh. "
                                            "Tôi là NCS"), n) for n in range(5)]
        kiem("dựng lại buổi Học Marketing 2: câu hỏi thẻ đoạn 1 tới 5 đều dưới trần; đoạn 5 vẫn có "
             "diễn biến các đoạn gần nhất, việc cần chốt, ghi chú và dòng Ghi ngữ cảnh",
             all(bbh.so_byte(x) <= bbh.TRAN_CAU_HOI for x in cau5)
             and "- Đoạn 4 (15:00-20:00): " in cau5[4] and "- Đoạn 3 (10:00-15:00): " in cau5[4]
             and "Việc cần chốt đã ghi nhận:" in cau5[4] and "Tôi là NCS" in cau5[4]
             and "Người giảng là cô Nguyễn Thị Mỹ Linh" in cau5[4], str([bbh.so_byte(x) for x in cau5]))

        GHI_CHU_DAI = "Chị Lan là trưởng phòng Đào tạo. " * 60
        TT_GB = dict(TT_HOC, loai_hop="Họp giao ban",
                     chuong_trinh="1. Kiểm điểm việc tuần trước\n2. Tuyển sinh tháng 10",
                     viec_tuan_truoc="- Gửi kế hoạch tuyển sinh cho Phòng Đào tạo")
        vd = viec_dai(12, tt=TT_GB, so_ghi=40, ghi_chu=GHI_CHU_DAI)
        d13 = vd["tro_ly"]["doan"][12]
        d12 = bbh.doan_truoc(vd["tro_ly"], d13)
        cu = bbh.cau_hoi_doan(vd["tt"], d13, d12, True, False, bbh.dien_bien(vd["tro_ly"]),
                              bbh.khoi_ngu_canh(vd))  # ghép như trước bản sửa: gửi hết, không tính trần
        moi = bbh.cau_hoi_the(vd, d13, d12)
        kiem("họp dài, nhiều ghi chú: ghép như cũ thì vượt xa trần; câu hỏi thẻ mới dưới trần, giữ "
             "đoạn gần nhất, ghi nhanh mới nhất và đầu ô ghi chú; bỏ bớt các đoạn đầu, ghi nhanh cũ",
             bbh.so_byte(cu) > 2 * bbh.TRAN_CAU_HOI and bbh.so_byte(moi) <= bbh.TRAN_CAU_HOI
             and "- Đoạn 12 (55:00-60:00): " in moi and "- (bỏ bớt các đoạn đầu)" in moi
             and "- Đoạn 1 (00:00-05:00): " not in moi and "Ghi nhanh số 40:" in moi
             and "Ghi nhanh số 1:" not in moi and "Chị Lan là trưởng phòng" in moi,
             f"{bbh.so_byte(cu)} -> {bbh.so_byte(moi)}")
        kiem("đã có nguồn Thông tin buổi họp thì chương trình và việc tuần trước trỏ tới nguồn đó, "
             "không chép lại; chưa có nguồn thì chép vào câu hỏi nhưng cắt ngắn",
             "Gửi kế hoạch tuyển sinh" not in moi and "Tuyển sinh tháng 10" not in moi
             and moi.count('trong mục đó của nguồn "Thông tin buổi họp"') == 2
             and bbh.so_byte(bbh.cau_hoi_doan(dict(TT_GB, chuong_trinh="Mục dài. " * 400), d13)) < 4000)
        gon = bbh.cau_hoi_the(vd, d13, d12, gon=True)
        kiem("bản gọn để hỏi lại: không có diễn biến, ngắn hơn hẳn",
             "DIỄN BIẾN TỪ ĐẦU BUỔI" not in gon and bbh.so_byte(gon) < bbh.so_byte(moi) - 1000,
             f"{bbh.so_byte(gon)} / {bbh.so_byte(moi)}")
        db = bbh.dien_bien(vd["tro_ly"], toi_da=700)
        kiem("khối diễn biến theo số byte cho phép: giữ đoạn gần nhất, bớt cuối danh sách trước khi "
             "bỏ đoạn gần nhất; không đủ chỗ cho gì thì bỏ hẳn",
             bbh.so_byte(db) <= 700 and "- Đoạn 12 (55:00-60:00): " in db and "- Đoạn 11 (" not in db
             and "Việc cần chốt đã ghi nhận:" in db and CHOT[0][:40] in db and CHOT[2][:40] not in db
             and bbh.dien_bien(vd["tro_ly"], toi_da=40) == "", db)
        vn = viec_dai(0, so_ghi=2, ghi_chu="Chị Lan là trưởng phòng Đào tạo")
        vg = viec_dai(0, ghi_chu=GHI_CHU_DAI)
        nc = bbh.khoi_ngu_canh(vg, toi_da=1200)
        kiem("khối ghi chú: vừa trần thì gửi nguyên; ít dòng ghi nhanh thì ô ghi chú dài dùng hết chỗ "
             "còn lại (quá nửa), cắt cuối có dấu ba chấm; trần nhỏ hơn cả dòng đầu thì bỏ hẳn",
             bbh.khoi_ngu_canh(vn, toi_da=1200) == bbh.khoi_ngu_canh(vn) != ""
             and 1100 < bbh.so_byte(nc) <= 1200 and nc.endswith("...")
             and "Người giảng là cô Nguyễn Thị Mỹ Linh" in nc
             and bbh.khoi_ngu_canh(vg, toi_da=100) == "", str(bbh.so_byte(nc)))

        # Google không nhận câu dưới trần: trần thật thấp hơn máy tưởng
        class NlmTranThap(NlmNhieuNguon):
            def __init__(self, tran=4000, **k):
                super().__init__(**k)
                self.tran = tran

            async def _hoi(self, so_id, cau_hoi, source_ids=None, conversation_id=None):
                if bbh.so_byte(cau_hoi) > self.tran:
                    await self._buoc("tu_choi", bbh.so_byte(cau_hoi))
                    raise ChatError(TU_CHOI)
                return await super()._hoi(so_id, cau_hoi, source_ids, conversation_id)

        vd = viec_dai(12, so_ghi=40, ghi_chu=GHI_CHU_DAI)
        g = NlmTranThap()
        asyncio.run(bbh.hoi_the(g, vd, vd["tro_ly"]["doan"][12]))
        tu_choi = [x[1] for x in g.goi if x[0] == "tu_choi"]
        the_moi = vd["tro_ly"]["the"][-1]
        kiem("Google không nhận câu hỏi thẻ dù đã dưới trần: hỏi lại một lần bằng bản gọn (không có "
             "diễn biến), thẻ vẫn có tóm tắt; trần của cuộc họp hạ xuống dưới câu bị từ chối; nhật "
             "ký ghi lại",
             len(tu_choi) == 1 and 4000 < tu_choi[0] <= bbh.TRAN_CAU_HOI and len(g.cau) == 1
             and "DIỄN BIẾN" not in g.cau[0][0] and the_moi["loai"] == "doan"
             and bool(the_moi.get("tom_tat")) and vd["tro_ly"].get("tran") == tu_choi[0] - 500
             and any("không được nhận, hỏi lại bản gọn" in x[1] for x in vd["nhat_ky"]),
             f"{tu_choi}; {[bbh.so_byte(x[0]) for x in g.cau]}; {vd['tro_ly'].get('tran')}")
        vd["tro_ly"]["doan"].append({"ten": "Đoạn 14 (65:00-70:00)", "tu": 3900.0, "den": 4200.0,
                                     "nguon": "n14", "tt": "xong"})
        g = NlmTranThap()
        asyncio.run(bbh.hoi_the(g, vd, vd["tro_ly"]["doan"][13]))
        kiem("thẻ sau của cuộc họp đó hỏi theo trần đã hạ: một lần là được, không bị từ chối nữa",
             "tu_choi" not in ten_goi(g) and len(g.cau) == 1
             and bbh.so_byte(g.cau[0][0]) <= vd["tro_ly"]["tran"]
             and vd["tro_ly"]["the"][-1]["loai"] == "doan", str([bbh.so_byte(x[0]) for x in g.cau]))

        class NlmLuonTuChoi(NlmNhieuNguon):
            async def _hoi(self, so_id, cau_hoi, source_ids=None, conversation_id=None):
                await self._buoc("tu_choi", bbh.so_byte(cau_hoi))
                raise ChatError(TU_CHOI)

        vd = viec_dai(12, so_ghi=40)
        g = NlmLuonTuChoi()
        asyncio.run(bbh.hoi_the(g, vd, vd["tro_ly"]["doan"][12]))
        the_loi = vd["tro_ly"]["the"][-1]
        kiem("Google không nhận cả bản gọn: thẻ báo rõ câu hỏi dài quá, đúng hai lần hỏi, trần hạ "
             "xuống mức thấp nhất",
             ten_goi(g).count("tu_choi") == 2 and the_loi["loai"] == "loi"
             and the_loi["chu"] == f"Chưa tóm tắt được đoạn 13 (60:00-65:00) ({DAI_QUA})."
             and vd["tro_ly"].get("tran") == bbh.TRAN_THAP_NHAT, str(the_loi))

        class NlmMatMang(NlmNhieuNguon):
            async def _hoi(self, so_id, cau_hoi, source_ids=None, conversation_id=None):
                await self._buoc("mat_mang")
                raise bbh.httpx.ConnectError("mất mạng")

        vd = viec_dai(3)
        g = NlmMatMang()
        asyncio.run(bbh.hoi_the(g, vd, vd["tro_ly"]["doan"][3]))
        kiem("lỗi khác (mất mạng): không hỏi lại, không hạ trần, thẻ báo đúng lỗi mạng",
             ten_goi(g).count("mat_mang") == 1 and "tran" not in vd["tro_ly"]
             and "Mất kết nối mạng" in vd["tro_ly"]["the"][-1].get("chu", ""),
             str(vd["tro_ly"]["the"][-1]))

        vd = viec_dai(12, so_ghi=80, ghi_chu=GHI_CHU_DAI)
        g = NlmNhieuNguon()
        asyncio.run(bbh.hoi_the(g, vd, None))
        cau_tk = g.cau[-1][0] if g.cau else ""
        kiem("Tổng kết: câu hỏi kèm ghi chú vẫn dưới trần, giữ ghi nhanh mới nhất, ra thẻ tổng kết",
             bbh.so_byte(cau_tk) <= bbh.TRAN_CAU_HOI and "Ghi nhanh số 80:" in cau_tk
             and "Ghi nhanh số 1:" not in cau_tk and vd["tro_ly"]["the"][-1]["loai"] == "tong_ket",
             str(bbh.so_byte(cau_tk)))
        NLM[0] = g = NlmNhieuNguon()
        th = {"loai": "hoi", "cau_hoi": "Đầu buổi nói khoá MOS có bao nhiêu học viên?", "dang": True}
        asyncio.run(bbh.tra_loi_o_hoi(vd, th))
        cau_oh = g.cau[-1][0] if g.cau else ""
        kiem("ô Hỏi: câu hỏi kèm ghi chú vẫn dưới trần, giữ câu của thư ký và ghi nhanh mới nhất",
             bool(th.get("tra_loi")) and bbh.so_byte(cau_oh) <= bbh.TRAN_CAU_HOI
             and cau_oh.startswith("Đầu buổi nói khoá MOS") and "Ghi nhanh số 80:" in cau_oh,
             str(bbh.so_byte(cau_oh)))
        NLM[0] = NlmLuonTuChoi()
        th = {"loai": "hoi", "cau_hoi": "Ai phụ trách?", "dang": True}
        asyncio.run(bbh.tra_loi_o_hoi(vd, th))
        kiem("ô Hỏi bị từ chối vì dài: báo rõ trên thẻ, hạ trần để hỏi lại thì ngắn hơn",
             th.get("loi") == f"Chưa hỏi được ({DAI_QUA})"
             and vd["tro_ly"].get("tran", bbh.TRAN_CAU_HOI) < bbh.TRAN_CAU_HOI, str(th))

        # Biên bản cuối: ghi chú của thư ký gửi kèm câu lệnh soạn cũng theo trần
        vn = viec_dai(0, so_ghi=3, ghi_chu="Chị Lan là trưởng phòng Đào tạo")
        them_ngan = bbh.ngu_canh_bien_ban(vn, TT_HOC)
        vd = viec_dai(0, so_ghi=200, ghi_chu=GHI_CHU_DAI * 2)
        cau_dai = bbh.cau_lenh_soan(TT_HOC, them=bbh.ngu_canh_bien_ban(vd, TT_HOC))
        luu_y = "Lưu ý: bản chép lời chỉ có phần đầu cuộc họp, tới 50:00."
        them_ly = bbh.ngu_canh_bien_ban(viec_dai(0, so_ghi=200), TT_HOC, truoc=3000.0, luu_y=luu_y)
        kiem("biên bản cuối: ghi chú ngắn gửi nguyên, không cảnh báo; ghi chú dài quá thì câu lệnh "
             "soạn vẫn dưới trần, giữ ghi nhanh mới nhất, nhắc thư ký đối chiếu ghi chú đầu buổi; "
             "lời dặn chuyển giữa buổi luôn giữ",
             them_ngan == bbh.khoi_ngu_canh(vn) and not vn.get("canh_bao")
             and bbh.so_byte(cau_dai) <= bbh.TRAN_CAU_HOI and "Ghi nhanh số 200:" in cau_dai
             and "Ghi nhanh số 1:" not in cau_dai
             and "đối chiếu lại biên bản với các ghi chú đầu buổi" in (vd.get("canh_bao") or "")
             and them_ly.startswith(luu_y) and "Ghi nhanh số 99:" in them_ly
             and "Ghi nhanh số 100:" not in them_ly
             and bbh.so_byte(bbh.cau_lenh_soan(TT_HOC, them=them_ly)) <= bbh.TRAN_CAU_HOI,
             f"{bbh.so_byte(cau_dai)}; {vd.get('canh_bao')}")

        class NlmTuChoiGhiChu(NlmNhieuNguon):
            """Không nhận câu lệnh soạn biên bản có kèm ghi chú (dài quá); không kèm thì nhận."""

            async def _hoi(self, so_id, cau_hoi, source_ids=None, conversation_id=None):
                if "Soạn BIÊN BẢN" in cau_hoi and "Ghi chú của thư ký (mốc" in cau_hoi:
                    await self._buoc("tu_choi", bbh.so_byte(cau_hoi))
                    raise ChatError(TU_CHOI)
                return await super()._hoi(so_id, cau_hoi, source_ids, conversation_id)

        c.put("/may/thong-tin", json={"cach_go_chu": "notebooklm", "nhip_tro_ly": "0"}, headers=NUT)
        NLM[0] = g = NlmTuChoiGhiChu()
        ma = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        v = bbh.VIEC[ma]
        c.put(f"/may/viec/{ma}/ghi-chu-rieng", json={"chu": "Chị Lan là trưởng phòng Đào tạo"},
              headers=NUT)
        time.sleep(2)
        c.post("/may/ghi/dung", headers=NUT)
        xong_bb = cho_xong(ma, 15)
        cau_bb = [x[0] for x in g.cau if "Soạn BIÊN BẢN" in x[0]]
        kiem("Google không nhận câu lệnh soạn biên bản cuối vì dài: soạn lại một lần không kèm ghi "
             "chú của thư ký, vẫn ra biên bản, cảnh báo thư ký đối chiếu; Làm lại thì ghi chú ngắn hơn",
             xong_bb == "Xong" and ten_goi(g).count("tu_choi") == 1 and len(cau_bb) == 1
             and "Chị Lan là trưởng phòng" not in cau_bb[0] and bool(v.get("ket_qua"))
             and "soạn lại không kèm ghi chú của thư ký" in (v.get("canh_bao") or "")
             and v["tro_ly"].get("tran") == bbh.TRAN_THAP_NHAT,
             f"{xong_bb}; {ten_goi(g)}; {v.get('canh_bao')}")
        c.put("/may/thong-tin", json={"nhip_tro_ly": "5"}, headers=NUT)

        # --------------------------------------------------------------------
        print("\nK. Nguồn thêm: biên bản buổi trước, tài liệu cho trợ lý, tìm trên mạng và Drive")
        # --------------------------------------------------------------------
        bbh.bien_ban_da_chon = BIEN_BAN_DA_CHON_THAT

        def tl(ten, noi_dung=b"Noi dung tai lieu"):
            return {"tep": (ten, noi_dung)}

        kiem("thả tài liệu thiếu tiêu đề giao diện thì bị chặn",
             c.post("/may/tai-lieu", files=tl("a.pdf")).status_code == 403)
        kiem("chỉ nhận tài liệu (PDF, Word, PowerPoint, chữ), không nhận tệp khác",
             c.post("/may/tai-lieu", files=tl("x.exe"), headers=NUT).status_code == 400
             and c.post("/may/tai-lieu", files=tl("ghi.m4a"), headers=NUT).status_code == 400)
        kiem("không nhận tệp rỗng",
             c.post("/may/tai-lieu", files=tl("rong.txt", b""), headers=NUT).status_code == 400)
        r = c.post("/may/tai-lieu", headers=NUT, files=tl(
            "../../" + unicodedata.normalize("NFD", "Kế hoạch tuyển sinh.PDF")))
        kiem("tên tệp bỏ phần đường dẫn, đưa về chữ dựng sẵn, đuôi viết thường",
             r.status_code == 200 and [t["ten"] for t in r.json()["ds"]] == ["Kế hoạch tuyển sinh.pdf"],
             r.text[:200])
        for i in range(4):
            c.post("/may/tai-lieu", files=tl(f"tai-lieu-{i}.txt", f"Tài liệu số {i}".encode()),
                   headers=NUT)
        kiem("tối đa 5 tài liệu",
             c.post("/may/tai-lieu", files=tl("thua.txt"), headers=NUT).status_code == 409)
        kiem("xoá tài liệu: tên có đường dẫn thì không xoá gì",
             c.delete("/may/tai-lieu/..%2F..%2Fthong_tin_cuoc_hop.json", headers=NUT).status_code == 404
             and len(bbh.ds_tai_lieu_cho()) == 5)
        c.delete("/may/tai-lieu/tai-lieu-3.txt", headers=NUT)
        kiem("xoá được một tài liệu", [t["ten"] for t in c.get("/may/tai-lieu").json()["ds"]]
             == ["Kế hoạch tuyển sinh.pdf", "tai-lieu-0.txt", "tai-lieu-1.txt", "tai-lieu-2.txt"])
        bbh.TOI_DA_BYTE_TAI_LIEU = 10
        kiem("tệp lớn quá thì từ chối, không để lại tệp dở",
             c.post("/may/tai-lieu", files=tl("lon.txt", b"x" * 11), headers=NUT).status_code == 413
             and not list(bbh.thu_muc_tai_lieu_cho().glob("*.tam")))
        bbh.TOI_DA_BYTE_TAI_LIEU = 50 * 1024 * 1024

        # Biên bản buổi trước: danh sách, chọn sẵn theo tên, đọc tệp Word thư ký đã sửa
        ds = c.get("/may/bien-ban-truoc").json()["ds"]
        khong_gui = [m for m, x in bbh.VIEC.items()
                     if x["trang_thai"] == "Xong" and x.get("cach_da_bao") == "whisper"]
        kiem("danh sách biên bản buổi trước: chỉ cuộc họp đã xong và gửi lên NotebookLM từ đầu tới "
             "cuối, mới nhất lên đầu",
             len(ds) >= 2 and khong_gui and not set(khong_gui) & {x["ma"] for x in ds}
             and all(bbh.VIEC[x["ma"]]["cach_da_bao"] == "notebooklm"
                     and bbh.VIEC[x["ma"]]["trang_thai"] == "Xong" for x in ds)
             and [x["ma"] for x in ds] == [m for m in reversed(bbh.THU_TU)
                                            if m in {x["ma"] for x in ds}],
             f"{len(ds)} biên bản, {len(khong_gui)} cuộc họp không gửi")
        ten = ds[0]["ten"]
        c.put("/may/thong-tin", json={"ten_cuoc_hop": ten}, headers=NUT)
        kiem("chưa chọn thì máy chọn sẵn biên bản gần nhất trùng hẳn tên cuộc họp",
             c.get("/may/bien-ban-truoc").json()["chon"] == ds[0]["ma"])
        c.put("/may/thong-tin", json={"ten_cuoc_hop": ten + " tháng 10"}, headers=NUT)
        kiem("tên cuộc họp khác (dù gần giống) thì không chọn sẵn",
             c.get("/may/bien-ban-truoc").json()["chon"] == "")
        c.put("/may/thong-tin", json={"ten_cuoc_hop": ten}, headers=NUT)
        c.put("/may/bien-ban-truoc", json={"ma": ""}, headers=NUT)
        kiem("chọn Không dùng thì máy không tự chọn nữa, kể cả khi có cuộc họp trùng tên",
             c.get("/may/bien-ban-truoc").json()["chon"] == "")
        c.put("/may/bien-ban-truoc", json={"ma": ds[1]["ma"]}, headers=NUT)
        kiem("chọn một biên bản cũ hơn thì giữ đúng lựa chọn đó",
             c.get("/may/bien-ban-truoc").json()["chon"] == ds[1]["ma"])
        kiem("chọn thiếu tiêu đề giao diện thì bị chặn",
             c.put("/may/bien-ban-truoc", json={"ma": ds[0]["ma"]}).status_code == 403)
        kiem("không chọn được biên bản lạ, hay biên bản của cuộc họp Không gửi lên mạng",
             c.put("/may/bien-ban-truoc", json={"ma": "khongco"}, headers=NUT).status_code == 404
             and all(c.put("/may/bien-ban-truoc", json={"ma": m}, headers=NUT).status_code == 404
                     for m in khong_gui))
        v1 = bbh.VIEC[ds[0]["ma"]]
        chu, bang = bbh.chu_bien_ban_xong(v1)
        kiem("đọc tệp Word máy dựng: có chữ biên bản và bảng Phân công",
             "32 học viên" in chu
             and bbh.viec_tu_bang(bang) == ["- Hoàn thiện hồ sơ khoá MOS (Chị Lan, hạn 30/9)"],
             str(bang))
        # Thư ký sửa tệp Word: đổi người phụ trách, thêm một việc, thêm một đoạn
        tep_word = Path(v1["thu_muc"]) / v1["tep_word"]
        d = Document(tep_word)
        b = next(t for t in d.tables if "phụ trách" in t.rows[0].cells[1].text.lower())
        b.rows[1].cells[1].text = "Anh Nam"
        hang = b.add_row()
        hang.cells[0].text = "Gửi thư mời hội đồng"
        d.add_paragraph("Thư ký bổ sung: chốt lịch thi ngày 15/10.")
        d.save(tep_word)
        chu, bang = bbh.chu_bien_ban_xong(v1)
        kiem("thư ký sửa tệp Word: máy đọc đúng bản đã sửa, bỏ hàng việc trống",
             "chốt lịch thi ngày 15/10" in chu and bbh.viec_tu_bang(bang)
             == ["- Hoàn thiện hồ sơ khoá MOS (Anh Nam, hạn 30/9)", "- Gửi thư mời hội đồng"],
             str(bbh.viec_tu_bang(bang)))
        kiem("bảng có thêm cột STT vẫn tách đúng cột việc",
             bbh.viec_tu_bang([["STT", "Nội dung công việc", "Người phụ trách", "Thời hạn"],
                               ["1", "Chuẩn bị buổi thực hành", "Lê Văn C", "02/10/2026"],
                               ["2", "", "x", ""]])
             == ["- Chuẩn bị buổi thực hành (Lê Văn C, hạn 02/10/2026)"])
        kiem("không có tệp Word thì lấy bảng Phân công từ bản nháp",
             bbh.viec_tu_bang(bbh.chu_bien_ban_xong(dict(v1, tep_word=None))[1])
             == ["- Hoàn thiện hồ sơ khoá MOS (Chị Lan, hạn 30/9)"])

        # Tự điền ô Việc tuần trước
        c.put("/may/bien-ban-truoc", json={"ma": ds[0]["ma"], "dien_viec": True, "tu_dong": True},
              headers=NUT)
        kiem("giao diện tự điền theo biên bản máy chọn sẵn thì không ghi thành lựa chọn của thư ký",
             bbh.thong_tin_mac_dinh().get("bien_ban_truoc") == ds[1]["ma"],
             str(bbh.thong_tin_mac_dinh().get("bien_ban_truoc")))
        r = c.put("/may/bien-ban-truoc", json={"ma": ds[0]["ma"], "dien_viec": True},
                  headers=NUT).json()
        tt = bbh.thong_tin_mac_dinh()
        kiem("chọn biên bản buổi trước thì tự điền ô Việc tuần trước từ bảng Phân công",
             r.get("so_viec") == 2 and tt["viec_tuan_truoc"]
             == "- Hoàn thiện hồ sơ khoá MOS (Anh Nam, hạn 30/9)\n- Gửi thư mời hội đồng"
             and c.get("/may/bien-ban-truoc").json()["tu"] == ds[0]["ma"], str(r))
        c.put("/may/thong-tin", json={"viec_tuan_truoc": tt["viec_tuan_truoc"],
                                      "dia_diem": "Phòng họp tầng 2"}, headers=NUT)
        kiem("bấm Lưu ở Cài đặt mà không đổi ô Việc tuần trước thì máy vẫn nhớ là máy điền",
             c.get("/may/bien-ban-truoc").json()["tu"] == ds[0]["ma"])
        c.put("/may/bien-ban-truoc", json={"ma": "", "dien_viec": True}, headers=NUT)
        kiem("chọn Không dùng thì xoá các việc máy đã điền",
             bbh.thong_tin_mac_dinh()["viec_tuan_truoc"] == "")
        c.put("/may/bien-ban-truoc", json={"ma": ds[0]["ma"], "dien_viec": True}, headers=NUT)
        c.put("/may/thong-tin", json={"viec_tuan_truoc": "- Việc thư ký tự gõ"}, headers=NUT)
        kiem("thư ký tự sửa ô Việc tuần trước thì máy thôi coi là nội dung máy điền",
             c.get("/may/bien-ban-truoc").json()["tu"] == "")
        c.put("/may/bien-ban-truoc", json={"ma": "", "dien_viec": True}, headers=NUT)
        kiem("ô Việc tuần trước thư ký tự gõ thì chọn Không dùng cũng không xoá",
             bbh.thong_tin_mac_dinh()["viec_tuan_truoc"] == "- Việc thư ký tự gõ")
        c.put("/may/thong-tin", json={"viec_tuan_truoc": ""}, headers=NUT)
        c.put("/may/bien-ban-truoc", json={"ma": ds[0]["ma"]}, headers=NUT)

        # Bấm ghi: đưa biên bản buổi trước và tài liệu lên sổ ngay đầu buổi
        NLM[0] = g = NlmNhieuNguon()
        ma = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        v = bbh.VIEC[ma]
        tm = Path(v["thu_muc"])
        nen = v["tro_ly"].get("nen") or []
        kiem("bấm ghi: tài liệu chờ chuyển vào thư mục cuộc họp, chữ biên bản buổi trước (bản thư "
             "ký đã sửa) chép ra tệp",
             not bbh.ds_tai_lieu_cho() and (tm / "tai-lieu" / "Kế hoạch tuyển sinh.pdf").is_file()
             and "chốt lịch thi ngày 15/10" in (tm / "tai-lieu" / "bien-ban-buoi-truoc.txt").read_text(
                 encoding="utf-8") and len(nen) == 5
             and nen[0]["ten"].startswith("Biên bản buổi trước: "), str(nen)[:200])
        kiem("lựa chọn biên bản buổi trước đã dùng cho cuộc họp này thì bỏ, cuộc họp sau chọn lại",
             bbh.thong_tin_mac_dinh().get("bien_ban_truoc") == "")
        cho_den(lambda: nen and all(n["tt"] != "cho" for n in nen), 10)
        tai = [x for x in g.goi if x[0] == "them_tep"]
        kiem("đầu buổi đưa Thông tin buổi họp, biên bản buổi trước và 4 tài liệu lên sổ, trước lần "
             "gửi đoạn đầu, đúng loại tệp",
             [n["tt"] for n in nen] == ["xong"] * 5
             and ten_goi(g)[:3] == ["tao", "them_chu", "them_tep"]
             and [x[3] for x in tai[:5]] == [n["ten"] for n in nen]
             and tai[0][1] == ".txt" and tai[1][1:3] == (".pdf", "application/pdf"), str(tai[:5])[:300])
        cho_den(lambda: any(t["loai"] == "doan" for t in v["tro_ly"]["the"]), 20)
        hoi_dau = next((x for x in g.goi if x[0] == "hoi"), None)
        cau_the = [x[0] for x in g.cau if "TÓM TẮT" in x[0]]
        kiem("thẻ gợi ý hỏi trên cả tài liệu nền, câu hỏi nói rõ các nguồn còn lại là tài liệu nền",
             hoi_dau is not None and {"d1", "d2", "d3", "d4", "d5", "d6"} <= set(hoi_dau[1])
             and bool(cau_the) and "tài liệu nền" in cau_the[0], str(hoi_dau))
        kiem("trạng thái trợ lý có danh sách tài liệu nền",
             [n["tt"] for n in c.get("/may/tro-ly").json()["nen"]] == ["xong"] * 5)

        # Tìm trên mạng, tìm trong Drive, mở link
        so = next(i for i, t in enumerate(v["tro_ly"]["the"]) if t["loai"] == "doan")

        def tim(than, dau=NUT):
            return c.post("/may/tro-ly/tim", json=than, headers=dau).status_code

        kiem("tìm: yêu cầu sai hay thiếu tiêu đề giao diện thì từ chối",
             tim({"so": 99, "cum_tu": "x", "noi": "web"}) == 400
             and tim({"so": so, "cum_tu": "x", "noi": "bing"}) == 400
             and tim({"so": True, "cum_tu": "x", "noi": "web"}) == 400
             and tim({"so": so, "cum_tu": " ", "noi": "web"}) == 400
             and tim({"so": so, "cum_tu": "x", "noi": "web"}, {}) == 403)
        tim({"so": so, "cum_tu": "khoá học MOS", "noi": "web"})
        cho_den(lambda: not v["tro_ly"]["the"][so]["tim"]["dang"], 5)
        kq = v["tro_ly"]["the"][so]["tim"]
        kiem("tìm trên mạng: có đoạn tổng quan (bỏ số trích dẫn) và link, bỏ link không phải trang "
             "web, không đưa gì vào sổ",
             kq.get("tong_quan") == "Tổng quan về khoá học MOS." and not kq.get("loi")
             and [k["url"] for k in kq.get("ket_qua", [])] == ["https://vi.wikipedia.org/wiki/MOS"]
             and ("tim_web", "khoá học MOS") in g.goi, str(kq)[:200])
        tim({"so": so, "cum_tu": "kế hoạch MOS", "noi": "drive"})
        cho_den(lambda: not v["tro_ly"]["the"][so]["tim"]["dang"], 5)
        kq = v["tro_ly"]["the"][so]["tim"]
        kiem("tìm trong Drive: tìm nhanh rồi chờ tới khi xong, trả link tài liệu trong Drive",
             ("tim_drive", "kế hoạch MOS", "drive", "fast") in g.goi and ("cho_tim", "tim1") in g.goi
             and [k["url"] for k in kq.get("ket_qua", [])] == ["https://docs.google.com/document/d/abc"],
             str(kq)[:200])
        mo = []
        mo_that, bbh.mo_bang_he_thong = bbh.mo_bang_he_thong, mo.append
        kiem("mở link: chỉ mở link có trong kết quả tìm, bằng trình duyệt của máy",
             c.post("/may/mo-lien-ket", json={"url": "https://docs.google.com/document/d/abc"},
                    headers=NUT).status_code == 200
             and c.post("/may/mo-lien-ket", json={"url": "https://lua-dao.example/x"},
                        headers=NUT).status_code == 404
             and c.post("/may/mo-lien-ket",
                        json={"url": "https://docs.google.com/document/d/abc"}).status_code == 403
             and mo == ["https://docs.google.com/document/d/abc"], str(mo))
        bbh.mo_bang_he_thong = mo_that
        g.research = None
        tim({"so": so, "cum_tu": "khoá học MOS", "noi": "web"})
        cho_den(lambda: not v["tro_ly"]["the"][so]["tim"]["dang"], 5)
        kiem("máy còn thư viện NotebookLM cũ thì báo chạy lại trình cài",
             "chạy lại trình cài" in (v["tro_ly"]["the"][so]["tim"].get("loi") or ""),
             str(v["tro_ly"]["the"][so]["tim"]))

        # Thả tài liệu NGAY TRONG buổi họp (PM yêu cầu 27/9/2026): vào thư mục cuộc họp, trợ lý
        # đưa lên sổ ở lượt kế tiếp, các thẻ sau hỏi trên cả tài liệu đó
        kiem("thả tài liệu trong lúc họp: thiếu tiêu đề giao diện bị chặn, sai loại tệp bị từ chối",
             c.post("/may/tro-ly/tai-lieu", files=tl("a.txt")).status_code == 403
             and c.post("/may/tro-ly/tai-lieu", files=tl("x.exe"), headers=NUT).status_code == 400)
        r = c.post("/may/tro-ly/tai-lieu", files=tl("Danh sách bài báo.txt", "Bài báo số 3".encode()),
                   headers=NUT)
        cho_den(lambda: v["tro_ly"]["nen"][-1]["tt"] != "cho", 10)
        so_the = len(g.cau)
        c.post("/may/tro-ly/tom-tat-ngay", headers=NUT)
        cho_den(lambda: len(g.cau) > so_the, 10)
        kiem("thả tài liệu trong lúc họp: lưu vào thư mục cuộc họp, trợ lý đưa lên sổ, thẻ sau hỏi "
             "trên cả tài liệu đó",
             r.status_code == 200 and (tm / "tai-lieu" / "Danh sách bài báo.txt").is_file()
             and v["tro_ly"]["nen"][-1]["tt"] == "xong" and ("them_tep", ".txt", "text/plain",
                                                           "Danh sách bài báo.txt") in g.goi
             and v["tro_ly"]["nen"][-1]["nguon"] in goi_hoi_cuoi(g)[1]
             and any("Tài liệu thêm trong lúc họp" in x[1] for x in v["nhat_ky"]),
             f"{r.text[:80]}; {v['tro_ly']['nen'][-1]}")
        kiem("tối đa 5 tài liệu mỗi cuộc họp, tính cả tài liệu thả vào trước buổi họp",
             c.post("/may/tro-ly/tai-lieu", files=tl("thua.txt"), headers=NUT).status_code == 409
             and not (tm / "tai-lieu" / "thua.txt").exists())
        c.post("/may/ghi/dung", headers=NUT)
        xong = cho_xong(ma, 15) == "Xong"
        chon = goi_hoi_cuoi(g)[1]
        tl_len = [n["nguon"] for n in v["tro_ly"]["nen"]
                  if n.get("loai") == "tai_lieu" and n.get("tt") == "xong"]
        bb_truoc = [n.get("nguon") for n in v["tro_ly"]["nen"] if n.get("loai") == "bien_ban_truoc"]
        cau_soan = g.cau[-1][0]
        kiem("dừng: biên bản cuối chỉ đọc bản chép lời cả buổi (PM chốt 28/9/2026, thay 27/9): "
             "không chọn tài liệu cho trợ lý, không chọn biên bản buổi trước, câu lệnh không "
             "nhắc tới tài liệu",
             xong and tuple(chon) == ("t1",) and len(tl_len) >= 2 and bb_truoc
             and "Danh sách bài báo.txt" not in cau_soan and "tài liệu cuộc họp nhắc tới" not in cau_soan
             and "nguồn được chọn" in cau_soan,
             f"{chon}; {tl_len}; {bb_truoc}")

        # Sổ của cuộc họp đã bị xoá trên NotebookLM, Làm lại tạo sổ mới: tài liệu của sổ cũ
        # không có trong sổ mới nên không được chọn (chọn là dịch vụ báo lỗi)
        class NlmSoMoi(NlmNhieuNguon):
            async def _tao(self, tieu_de):
                await self._buoc("tao", tieu_de)
                return SimpleNamespace(id="so2", title=tieu_de)
        v["trang_thai"] = "Lỗi"
        NLM[0] = g = NlmSoMoi(so_da_xoa={"so1"})
        c.post(f"/may/viec/{ma}/lam-lai", headers=NUT)
        kiem("Làm lại khi sổ cũ đã bị xoá: sổ mới chỉ có bản chép lời, không chọn tài liệu của sổ cũ",
             cho_xong(ma, 15) == "Xong" and "tao" in ten_goi(g) and goi_hoi_cuoi(g)[1] == ("t1",)
             and "Các nguồn còn lại là tài liệu" not in g.cau[-1][0], str(ten_goi(g)))

        # Cuộc họp Không gửi lên mạng: tài liệu để dành, không gửi gì
        c.post("/may/tai-lieu", files=tl("de-danh.txt"), headers=NUT)
        c.put("/may/thong-tin", json={"cach_go_chu": "whisper"}, headers=NUT)
        NLM[0] = g = NlmNhieuNguon()
        ma = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        time.sleep(1)
        ma_tl = c.post("/may/tro-ly/tai-lieu", files=tl("trong-hop.txt"), headers=NUT).status_code
        c.post("/may/ghi/dung", headers=NUT)
        cho_xong(ma)
        kiem("cuộc họp Không gửi lên mạng: không đụng tới tài liệu (để dành cho cuộc họp sau), "
             "không nhận tài liệu thả trong lúc họp, không gọi Google",
             [t["ten"] for t in bbh.ds_tai_lieu_cho()] == ["de-danh.txt"] and not g.goi and ma_tl == 409
             and not (Path(bbh.VIEC[ma]["thu_muc"]) / "tai-lieu").exists(), f"{ma_tl}; {ten_goi(g)}")
        c.put("/may/thong-tin", json={"cach_go_chu": "notebooklm"}, headers=NUT)

        # Google không đọc được một tài liệu: bỏ qua tệp đó, phần còn lại như thường. Trần 50
        # nguồn mỗi sổ tính cả tài liệu nền và Thông tin buổi họp (hạ trần xuống 6 để thử
        # nhanh: 2 tài liệu, Thông tin buổi họp, 1 đoạn)
        bbh.TRAN_NGUON = 6
        NLM[0] = g = NlmNhieuNguon(tu_choi=(1,))
        ma = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        v = bbh.VIEC[ma]
        cho_den(lambda: v["tro_ly"].get("nen") and all(n["tt"] != "cho" for n in v["tro_ly"]["nen"]),
                10)
        cho_den(lambda: len(doan_xong(ma)) >= 1, 15)
        nen = v["tro_ly"].get("nen") or []
        kiem("Google không nhận một tài liệu lần đầu: máy xoá nguồn đỏ, tự gửi lại được, tệp khác và các "
             "đoạn vẫn như thường (trước 30/9/2026 hỏng một lần là bỏ hẳn tài liệu)",
             [n["tt"] for n in nen] == ["xong", "xong"] and nen[0].get("lan") == 1
             and nen[1].get("lan", 0) == 0 and ("xoa_nguon", "d1") in g.goi and nen[0]["nguon"] != "d1"
             and len(doan_xong(ma)) >= 1, str(nen))
        cho_den(lambda: "mức tối đa" in v["tro_ly"]["tam_nghi"], 10)
        kiem("trần nguồn của sổ tính cả tài liệu nền và Thông tin buổi họp",
             len(v["tro_ly"]["doan"]) == 1 and v["tro_ly"]["thong_tin"]["tt"] == "xong"
             and "mức tối đa" in v["tro_ly"]["tam_nghi"], f"{len(v['tro_ly']['doan'])} đoạn")
        bbh.TRAN_NGUON = that["TRAN_NGUON"]
        c.post("/may/ghi/dung", headers=NUT)
        cho_xong(ma, 15)

        # PM báo 30/9/2026: tài liệu hiện "chưa gửi được" mà bấm Tóm tắt ngay thì trợ lý chạy được. Lý do:
        # mạng chớp đúng lúc mới bấm ghi thì tài liệu bị bỏ hẳn, không thử lại (dua_nen). Nay tự gửi lại.
        # 1. Kết nối chớp một lần lúc mới bấm ghi: hẹn gửi lại, cả hai tài liệu lên được, thẻ dùng luôn
        for i in range(2):
            c.post("/may/tai-lieu", files=tl(f"chop-{i}.txt"), headers=NUT)
        c.put("/may/bien-ban-truoc", json={"ma": ""}, headers=NUT)
        NLM[0] = g = NlmKetNoiChop(so_lan=1)
        ma = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        v = bbh.VIEC[ma]
        cho_den(lambda: v["tro_ly"].get("nen") and all(n["tt"] == "xong" for n in v["tro_ly"]["nen"]), 10)
        nen = v["tro_ly"].get("nen") or []
        kiem("mạng chớp lúc mới bấm ghi: tài liệu không bị bỏ, máy hẹn rồi gửi lại được cả hai; nhật ký ghi "
             "lần hỏng đầu kèm lý do và hẹn thử lại",
             [n["tt"] for n in nen] == ["xong", "xong"] and all(n.get("lan") == 1 for n in nen)
             and g.so_lan_vao >= 2 and ten_goi(g).count("them_tep") == 2
             and any("Chưa gửi được tài liệu chop-0.txt (Mất kết nối mạng" in x[1] and "sẽ thử lại" in x[1]
                     for x in v["nhat_ky"]), f"{[(n['tt'], n.get('lan')) for n in nen]}; {g.so_lan_vao} lần vào")
        # câu hỏi thẻ tới sau lúc đoạn có chữ: chờ tới khi có, không thì goi_hoi_cuoi báo không có lần hỏi nào
        cho_den(lambda: len(doan_xong(ma)) >= 1 and "hoi" in ten_goi(g), 15)
        kiem("tài liệu gửi lại được thì thẻ gợi ý dùng luôn cả hai tài liệu đó",
             all(n["nguon"] in goi_hoi_cuoi(g)[1] for n in nen), str(goi_hoi_cuoi(g)))
        c.post("/may/ghi/dung", headers=NUT)
        cho_xong(ma, 15)

        # 1b. Tài liệu đã lên sổ mà lúc chờ Google đọc thì mạng chớp: lần thử lại chỉ chờ tiếp, không tải trùng
        class NlmChoChop(NlmNhieuNguon):
            def __init__(self, **k):
                super().__init__(**k)
                self.da_chop = False

            async def _cho(self, so_id, nguon_id):
                if nguon_id == "d1" and not self.da_chop:  # nguồn tải lên đầu tiên là tài liệu
                    self.da_chop = True
                    await self._buoc("cho_chop", nguon_id)
                    raise ConnectionError("mạng chớp lúc chờ giả lập")
                return await super()._cho(so_id, nguon_id)

        c.post("/may/tai-lieu", files=tl("cho-chop.txt"), headers=NUT)
        c.put("/may/bien-ban-truoc", json={"ma": ""}, headers=NUT)
        NLM[0] = g = NlmChoChop()
        ma = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        v = bbh.VIEC[ma]
        cho_den(lambda: v["tro_ly"].get("nen") and v["tro_ly"]["nen"][0]["tt"] == "xong", 10)
        n0 = v["tro_ly"]["nen"][0]
        kiem("tài liệu đã lên sổ mà lúc chờ Google đọc thì mạng chớp: lần thử lại chỉ chờ tiếp, không tải "
             "trùng lên sổ, không xoá nguồn",
             n0["tt"] == "xong" and n0["lan"] == 1 and n0["nguon"] == "d1"
             and ten_goi(g).count("them_tep") == 1 and "xoa_nguon" not in ten_goi(g), str(n0))
        c.post("/may/ghi/dung", headers=NUT)
        cho_xong(ma, 15)

        # 2. Tài liệu hỏng cả ba lần: mới báo chưa gửi được (kèm lý do), rồi thôi; các đoạn ghi âm vẫn
        # chạy. Bấm Tóm tắt ngay thì thử lại đúng MỘT lần (không lặp mãi); hết hỏng thì gửi lên được
        c.post("/may/tai-lieu", files=tl("hong-mai.txt"), headers=NUT)
        c.put("/may/bien-ban-truoc", json={"ma": ""}, headers=NUT)
        NLM[0] = g = NlmHongTaiLieu(hong_tl=True)
        ma = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        v = bbh.VIEC[ma]
        cho_den(lambda: v["tro_ly"].get("nen") and v["tro_ly"]["nen"][0]["tt"] == "loi", 10)
        cho_den(lambda: "chưa gửi được" in v["tro_ly"]["trang_thai"], 5)  # dòng trạng thái đặt sau cùng
        n0 = v["tro_ly"]["nen"][0]
        kiem("tài liệu hỏng cả ba lần: mới báo chưa gửi được kèm lý do; đúng ba lần tải, không hơn; nhật ký "
             "nói bấm Tóm tắt ngay để gửi lại",
             n0["tt"] == "loi" and n0["lan"] == bbh.LAN_TOI_DA_NEN and "Mất kết nối mạng" in n0["loi"]
             and ten_goi(g).count("them_tep_hong") == 3
             and any("Bấm Tóm tắt ngay để gửi lại" in x[1] for x in v["nhat_ky"])
             and "Có tài liệu chưa gửi được" in v["tro_ly"]["trang_thai"]
             and "Tóm tắt ngay" not in v["tro_ly"]["trang_thai"], str(n0))
        cho_den(lambda: len(doan_xong(ma)) >= 1, 15)
        so_hong = ten_goi(g).count("them_tep_hong")
        time.sleep(1.5)
        kiem("hết ba lần thì máy thôi tự gửi lại tài liệu; các đoạn ghi âm vẫn lên bình thường",
             ten_goi(g).count("them_tep_hong") == so_hong and len(doan_xong(ma)) >= 1
             and v["tro_ly"]["nen"][0]["tt"] == "loi")
        c.post("/may/tro-ly/tom-tat-ngay", headers=NUT)
        cho_den(lambda: ten_goi(g).count("them_tep_hong") > so_hong, 8)
        time.sleep(1.5)  # gấp mấy chục vòng của trợ lý (0,1 giây một vòng): lặp mãi thì đếm tăng mãi
        kiem("bấm Tóm tắt ngay: tài liệu còn hỏng được thử lại đúng một lần, không lặp mãi",
             ten_goi(g).count("them_tep_hong") == so_hong + 1 and v["tro_ly"]["nen"][0]["tt"] == "loi",
             f"{so_hong} rồi {ten_goi(g).count('them_tep_hong')} lần")
        g.hong_tl = False
        c.post("/may/tro-ly/tom-tat-ngay", headers=NUT)
        kiem("hết hỏng rồi bấm Tóm tắt ngay: tài liệu lên được, hết báo hỏng",
             cho_den(lambda: v["tro_ly"]["nen"][0]["tt"] == "xong", 8) and v["tro_ly"]["nen"][0]["nguon"])
        c.post("/may/ghi/dung", headers=NUT)
        kiem("tài liệu hỏng giữa buổi không ảnh hưởng biên bản cuối", cho_xong(ma, 15) == "Xong")

        # 3. Bấm Tóm tắt ngay chỉ đụng tài liệu còn hỏng hay đang chờ hẹn; tài liệu đã gửi xong thì để yên
        nen_thu = [{"tt": "xong", "nguon": "d1", "lan": 1}, {"tt": "loi", "lan": 3},
                   {"tt": "cho", "sau": time.time() + 3600, "lan": 1}, {"tt": "cho"}]
        bbh.gui_lai_nen({"nen": nen_thu})
        kiem("bấm Tóm tắt ngay: tài liệu hỏng và tài liệu đang chờ hẹn được thử lại đúng một lần nữa; tài "
             "liệu đã gửi xong và tài liệu mới chưa thử thì để yên",
             nen_thu[0] == {"tt": "xong", "nguon": "d1", "lan": 1}
             and nen_thu[1] == {"tt": "cho", "sau": 0, "lan": bbh.LAN_TOI_DA_NEN - 1}
             and nen_thu[2] == {"tt": "cho", "sau": 0, "lan": bbh.LAN_TOI_DA_NEN - 1}
             and nen_thu[3] == {"tt": "cho"} and len(bbh.nen_den_luot({"nen": nen_thu})) == 3)

        # Chuyển sang Không gửi lên mạng giữa lúc đang đưa tài liệu lên: thôi đưa tệp sau
        class NlmCham(NlmNhieuNguon):
            async def _them_tep(self, so_id, tep, loai=None, title=None, **_):
                self.goi.append(("bat_dau_tai", title))  # ghi ngay lúc bắt đầu tải
                await asyncio.sleep(0.6)
                return await super()._them_tep(so_id, tep, loai, title=title)

        for i in range(2):
            c.post("/may/tai-lieu", files=tl(f"cham-{i}.txt"), headers=NUT)
        c.put("/may/bien-ban-truoc", json={"ma": ""}, headers=NUT)
        NLM[0] = g = NlmCham()
        ma = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        v = bbh.VIEC[ma]
        cho_den(lambda: "bat_dau_tai" in ten_goi(g), 5)
        c.put("/may/thong-tin", json={"cach_go_chu": "whisper"}, headers=NUT)
        time.sleep(2)
        kiem("chuyển sang Không gửi lên mạng giữa lúc đưa tài liệu lên: tệp đang tải dở thì cho "
             "xong, thôi đưa các tệp còn lại",
             ten_goi(g).count("bat_dau_tai") == 1 and ten_goi(g).count("them_tep") == 1
             and [n["tt"] for n in v["tro_ly"]["nen"]][1:] == ["cho"], str(ten_goi(g)))
        c.post("/may/ghi/dung", headers=NUT)
        cho_xong(ma, 15)
        c.put("/may/thong-tin", json={"cach_go_chu": "notebooklm"}, headers=NUT)

        # Danh sách việc tuần trước dài (PM chốt 30/9/2026): biên bản cuối chọn thêm nguồn Thông tin
        # buổi họp, nơi đã có danh sách, thay vì chép cả danh sách vào câu lệnh (chép thì hết chỗ cho
        # ghi chú của thư ký). Danh sách ngắn vẫn chép thẳng như cũ. "Dài" do máy tự tính theo trần
        # độ dài câu hỏi của Google (tran_cau_hoi)
        def ds_viec(n):
            return "\n".join(f"- Việc số {i}: chuẩn bị hồ sơ khoá học, người làm và hạn nộp đã thống nhất"
                             for i in range(1, n + 1))

        def tt_viec(n):
            return dict(TT_HOC, viec_tuan_truoc=ds_viec(n))

        n_ranh = next(n for n in range(1, 200) if bbh.viec_cu_qua_dai({}, tt_viec(n)))
        kiem("danh sách việc tuần trước: rỗng hay ngắn thì không coi là dài, dài quá thì coi là dài; ngưỡng "
             "tính theo trần độ dài câu hỏi của cuộc họp nên hạ trần thì ngưỡng dịch theo",
             not bbh.viec_cu_qua_dai({}, tt_viec(0)) and not bbh.viec_cu_qua_dai({}, tt_viec(1))
             and 9 <= n_ranh <= 13 and not bbh.viec_cu_qua_dai({}, tt_viec(n_ranh - 1))
             and bbh.viec_cu_qua_dai({"tro_ly": {"tran": bbh.TRAN_THAP_NHAT}}, tt_viec(n_ranh - 1)), str(n_ranh))
        cau_chep, cau_tro = bbh.cau_lenh_soan(tt_viec(40)), bbh.cau_lenh_soan(tt_viec(40), o_nguon=True)
        kiem("câu lệnh soạn: danh sách dài chuyển sang nguồn thì câu lệnh chỉ trỏ tới đó (ngắn hơn hẳn, vẫn có "
             "mục kiểm điểm); mặc định vẫn chép nguyên danh sách; không có danh sách thì không có khối này",
             "Việc số 20:" in cau_chep and "Việc số 20:" not in cau_tro
             and 'nguồn "Thông tin buổi họp", mục Việc tuần trước' in cau_tro
             and bbh.so_byte(cau_chep) - bbh.so_byte(cau_tro) > 3000 and bbh.MUC_KIEM_DIEM in cau_chep
             and "lấy đúng danh sách việc ở dưới" not in cau_tro
             and 'lấy đúng danh sách việc trong nguồn "Thông tin buổi họp"' in cau_tro
             and 'trừ nguồn "Thông tin buổi họp"' in cau_tro and "không phải lời nói trong cuộc họp" in cau_tro
             and "không phải lời nói trong cuộc họp" not in cau_chep
             and "Nội dung cuộc họp nằm trong nguồn được chọn của sổ này" in cau_chep
             and "Việc đã phân công tuần trước" not in bbh.cau_lenh_soan(tt_viec(0))
             and "Việc đã phân công tuần trước" not in bbh.cau_lenh_soan(tt_viec(0), o_nguon=True))
        vx = viec_dai(0, tt=tt_viec(40), so_ghi=6, ghi_chu="Chị Lan là trưởng phòng Đào tạo")
        nc_moi = bbh.ngu_canh_bien_ban(vx, vx["tt"])
        viec_cu_that, bbh.viec_cu_qua_dai = bbh.viec_cu_qua_dai, lambda viec, tt: False
        nc_cu = bbh.ngu_canh_bien_ban(vx, vx["tt"])
        bbh.viec_cu_qua_dai = viec_cu_that
        kiem("ghi chú của thư ký gửi kèm tính chỗ theo câu lệnh đã trỏ nguồn: danh sách 40 việc mà ghi chú vẫn "
             "còn chỗ; nếu chép cả danh sách vào câu lệnh thì hết chỗ, ghi chú bị bỏ",
             "Ghi nhanh số" in nc_moi and "Chị Lan là trưởng phòng" in nc_moi and nc_cu == "",
             f"{bbh.so_byte(nc_moi)} / {bbh.so_byte(nc_cu)}")

        # Đưa nguồn Thông tin buổi họp lên lúc soạn biên bản cuối, hoặc dùng nguồn đã có
        vx = viec_dai(0, tt=tt_viec(40))
        vx["tro_ly"]["thong_tin"] = None
        g = NlmNhieuNguon()
        ds_nguon = asyncio.run(bbh.nguon_viec_cu(g, vx, {"id": "so1"}, False))
        dua = [x for x in g.goi if x[0] == "them_chu"]
        kiem("chưa có nguồn Thông tin buổi họp trên sổ (họp ngắn chưa gửi đoạn nào): đưa lên lúc soạn, mang đủ "
             "danh sách việc tuần trước, rồi trả mã nguồn để chọn kèm",
             ds_nguon == ["tin"] and len(dua) == 1 and dua[0][1].startswith("THÔNG TIN BUỔI HỌP")
             and "Việc số 40:" in dua[0][1] and vx["tro_ly"]["thong_tin"]["tt"] == "xong", str(g.goi)[:200])
        vx = viec_dai(0, tt=tt_viec(40))
        vx["tro_ly"]["thong_tin"] = {"tt": "xong", "nguon": "cu"}
        g = NlmNhieuNguon()
        ds_cu = asyncio.run(bbh.nguon_viec_cu(g, vx, {"id": "so1"}, False))
        g2 = NlmNhieuNguon()
        ds_moi = asyncio.run(bbh.nguon_viec_cu(g2, vx, {"id": "so2"}, True))
        kiem("đã có nguồn trên sổ thì dùng luôn (chỉ xem nó còn không), không đưa lên lại; sổ vừa tạo mới thì "
             "nguồn của sổ cũ không còn, đưa lên lại",
             ds_cu == ["cu"] and ("cho", "cu") in g.goi and not [x for x in g.goi if x[0] == "them_chu"]
             and ds_moi == ["tin"] and sum(1 for x in g2.goi if x[0] == "them_chu") == 1, f"{ds_cu}; {ds_moi}")
        vx = viec_dai(0, tt=tt_viec(40))
        vx["tro_ly"]["thong_tin"] = {"tt": "xong", "nguon": "cu"}
        g3 = NlmNhieuNguon()
        g3.do.add("cu")  # nguồn ghi là xong mà trên sổ đã hỏng hay bị xoá
        ds_xoa = asyncio.run(bbh.nguon_viec_cu(g3, vx, {"id": "so1"}, False))
        vx["tro_ly"]["thong_tin"] = {"tt": "xong", "nguon": "cu"}
        g4 = NlmNhieuNguon(hong=("cho",))
        ds_khong_xem = asyncio.run(bbh.nguon_viec_cu(g4, vx, {"id": "so1"}, False))
        kiem("nguồn đã ghi là xong mà trên sổ không còn dùng được (bị xoá hay hỏng) thì đưa lên lại; không xem "
             "được (mạng chập chờn) thì cứ dùng nguồn đã ghi, không đưa lên lại",
             ds_xoa == ["tin"] and sum(1 for x in g3.goi if x[0] == "them_chu") == 1
             and ds_khong_xem == ["cu"] and not [x for x in g4.goi if x[0] == "them_chu"], f"{ds_xoa}; {ds_khong_xem}")
        vx = viec_dai(0, tt=tt_viec(40))
        vx["tro_ly"]["thong_tin"] = None
        vx["cach_da_bao"] = "whisper"  # đã chuyển sang Không gửi lên mạng giữa buổi
        g_chuyen = NlmNhieuNguon()
        ds_chuyen = asyncio.run(bbh.nguon_viec_cu(g_chuyen, vx, {"id": "so1"}, False))
        kiem("cuộc họp đã chuyển sang Không gửi lên mạng giữa buổi: không đưa thêm gì lên mạng lúc soạn biên bản "
             "cuối, trả rỗng để chép thẳng danh sách vào câu lệnh",
             ds_chuyen == [] and not [x for x in g_chuyen.goi if x[0] in ("them_chu", "them_tep")]
             and vx["tro_ly"]["thong_tin"] is None, str(g_chuyen.goi))
        vx = viec_dai(0, tt=tt_viec(40))
        vx["tro_ly"]["thong_tin"] = None
        g = NlmNhieuNguon(hong=("them_chu",))
        ds_hong = asyncio.run(bbh.nguon_viec_cu(g, vx, {"id": "so1"}, False))
        vx_cu = {"tt": tt_viec(40), "cach_da_bao": "notebooklm", "nhat_ky": []}  # cuộc họp cũ, không có tro_ly
        g_cu = NlmNhieuNguon()
        ds_khong = asyncio.run(bbh.nguon_viec_cu(g_cu, vx_cu, {"id": "so1"}, False))
        kiem("không đưa được nguồn lên (Google từ chối) hay cuộc họp cũ không có dữ liệu trợ lý: trả rỗng, không "
             "làm hỏng việc soạn",
             ds_hong == [] and vx["tro_ly"]["thong_tin"]["tt"] == "loi" and ds_khong == [] and not g_cu.goi,
             str(vx["tro_ly"]["thong_tin"]))

        # Cả luồng: 40 việc tuần trước, có ghi nhanh. Dừng thì biên bản cuối chọn kèm Thông tin buổi họp
        c.put("/may/thong-tin", json={"viec_tuan_truoc": ds_viec(40), "nhip_tro_ly": "0"}, headers=NUT)
        NLM[0] = g = NlmNhieuNguon()
        ma = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        v = bbh.VIEC[ma]
        c.post("/may/tro-ly/ghi-nhanh", json={"chu": "Chị Lan là trưởng phòng Đào tạo"}, headers=NUT)
        time.sleep(2)
        c.post("/may/tro-ly/tom-tat-ngay", headers=NUT)
        cho_den(lambda: len(doan_xong(ma)) >= 1, 10)
        c.post("/may/ghi/dung", headers=NUT)
        xong = cho_xong(ma, 20) == "Xong"
        cau_soan = g.cau[-1][0]
        kiem("danh sách việc tuần trước dài: biên bản cuối chọn thêm nguồn Thông tin buổi họp, câu lệnh chỉ trỏ tới "
             "đó (không chép 40 việc), ghi chú của thư ký vẫn còn chỗ, nhật ký ghi lại",
             xong and tuple(goi_hoi_cuoi(g)[1]) == ("t1", "tin") and "Việc số 20:" not in cau_soan
             and 'nguồn "Thông tin buổi họp"' in cau_soan and "Chị Lan là trưởng phòng Đào tạo" in cau_soan
             and any("đọc thêm nguồn Thông tin buổi họp" in x[1] for x in v["nhat_ky"])
             and not v.get("canh_bao"), f"{goi_hoi_cuoi(g)}; {v.get('loi')}")

        # Sổ cũ đã bị xoá, Làm lại tạo sổ mới: nguồn Thông tin buổi họp của sổ cũ không còn, đưa lên lại
        v["trang_thai"] = "Lỗi"
        NLM[0] = g = NlmSoMoi(so_da_xoa={"so1"})
        c.post(f"/may/viec/{ma}/lam-lai", headers=NUT)
        kiem("Làm lại khi sổ cũ đã bị xoá: đưa nguồn Thông tin buổi họp lên sổ mới đúng một lần rồi chọn kèm",
             cho_xong(ma, 20) == "Xong" and tuple(goi_hoi_cuoi(g)[1]) == ("t1", "tin")
             and sum(1 for x in g.goi if x[0] == "them_chu" and x[1].startswith("THÔNG TIN BUỔI HỌP")) == 1,
             str(ten_goi(g)))

        # Google không nhận câu lệnh lần đầu: soạn lại không kèm ghi chú, vẫn chọn kèm nguồn và vẫn trỏ nguồn
        class NlmTuChoiLanDau(NlmNhieuNguon):
            da_tu_choi = False

            async def _hoi(self, so_id, cau_hoi, source_ids=None, conversation_id=None):
                if "BIÊN BẢN" in cau_hoi and not self.da_tu_choi:
                    self.da_tu_choi = True
                    await self._buoc("tu_choi", tuple(source_ids or ()))
                    raise ChatError(TU_CHOI)
                return await super()._hoi(so_id, cau_hoi, source_ids, conversation_id)

        NLM[0] = g = NlmTuChoiLanDau()
        ma = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        v = bbh.VIEC[ma]
        c.post("/may/tro-ly/ghi-nhanh", json={"chu": "Chị Lan là trưởng phòng Đào tạo"}, headers=NUT)
        time.sleep(2)
        c.post("/may/tro-ly/tom-tat-ngay", headers=NUT)
        cho_den(lambda: len(doan_xong(ma)) >= 1, 10)
        c.post("/may/ghi/dung", headers=NUT)
        xong = cho_xong(ma, 20) == "Xong"
        hoi_soan = [x for x in g.goi if x[0] in ("hoi", "tu_choi") and len(x) > 1]
        kiem("Google không nhận câu lệnh soạn lần đầu: soạn lại một lần, hai lần đều chọn kèm nguồn Thông tin buổi "
             "họp và đều trỏ nguồn thay vì chép danh sách",
             xong and g.da_tu_choi and ("tu_choi", ("t1", "tin")) in g.goi
             and tuple(goi_hoi_cuoi(g)[1]) == ("t1", "tin") and "Việc số 20:" not in g.cau[-1][0]
             and 'nguồn "Thông tin buổi họp"' in g.cau[-1][0], str(hoi_soan)[:200])

        # Danh sách ngắn: chép thẳng vào câu lệnh như trước nay, chỉ chọn bản chép lời
        c.put("/may/thong-tin", json={"viec_tuan_truoc": ds_viec(3)}, headers=NUT)
        NLM[0] = g = NlmNhieuNguon()
        ma = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        v = bbh.VIEC[ma]
        time.sleep(2)
        c.post("/may/tro-ly/tom-tat-ngay", headers=NUT)
        cho_den(lambda: len(doan_xong(ma)) >= 1, 10)
        c.post("/may/ghi/dung", headers=NUT)
        xong = cho_xong(ma, 20) == "Xong"
        kiem("danh sách việc tuần trước ngắn: biên bản cuối chỉ chọn bản chép lời, chép thẳng danh sách vào "
             "câu lệnh như cũ, không nhắc gì tới nguồn Thông tin buổi họp",
             xong and tuple(goi_hoi_cuoi(g)[1]) == ("t1",) and "Việc số 3:" in g.cau[-1][0]
             and "trừ nguồn" not in g.cau[-1][0] and not v.get("canh_bao")
             and not any("đọc thêm nguồn Thông tin buổi họp" in x[1] for x in v["nhat_ky"]),
             f"{goi_hoi_cuoi(g)}; {v.get('canh_bao')}")
        c.put("/may/thong-tin", json={"viec_tuan_truoc": ds_viec(40)}, headers=NUT)

        # Không đưa được nguồn lên: chép thẳng danh sách vào câu lệnh như cũ và nhắc thư ký đối chiếu
        class NlmKhongDuaKhaiBao(NlmNhieuNguon):
            async def _them_chu(self, so_id, ten, chu, **_):
                if ten == bbh.TEN_THONG_TIN:
                    await self._buoc("them_chu_hong", ten)
                    raise RuntimeError("không đưa được")
                return await super()._them_chu(so_id, ten, chu, **_)

        NLM[0] = g = NlmKhongDuaKhaiBao()
        ma = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        v = bbh.VIEC[ma]
        time.sleep(2)
        c.post("/may/tro-ly/tom-tat-ngay", headers=NUT)
        cho_den(lambda: len(doan_xong(ma)) >= 1, 10)
        c.post("/may/ghi/dung", headers=NUT)
        xong = cho_xong(ma, 20) == "Xong"
        kiem("danh sách dài mà không đưa được nguồn Thông tin buổi họp lên: vẫn soạn được, chép thẳng danh sách "
             "vào câu lệnh như cũ, chỉ chọn bản chép lời, nhắc thư ký đối chiếu mục kiểm điểm",
             xong and tuple(goi_hoi_cuoi(g)[1]) == ("t1",) and "Việc số 20:" in g.cau[-1][0]
             and "Danh sách việc tuần trước dài" in v.get("canh_bao", ""), f"{goi_hoi_cuoi(g)}; {v.get('canh_bao')}")
        c.put("/may/thong-tin", json={"viec_tuan_truoc": "", "nhip_tro_ly": "5"}, headers=NUT)

        # --------------------------------------------------------------------
        print("\nL. Chủ trì xem khung Trợ lý trên điện thoại")
        # --------------------------------------------------------------------
        import httpx

        def mo(u):
            try:
                return httpx.get(u, timeout=5).status_code
            except httpx.HTTPError:
                return None

        ip_that = bbh.ip_mang_noi_bo
        try:
            ip = ip_that()
            kiem("tìm được địa chỉ của máy trong mạng nội bộ, không phải địa chỉ nội máy",
                 not ip.startswith("127."), ip)
        except OSError:
            ip = None
            kiem("máy không có mạng thì hàm tìm địa chỉ báo lỗi", True)
        bbh.ip_mang_noi_bo = lambda: "127.0.0.1"  # máy chủ phụ nghe mọi địa chỉ, thử qua 127.0.0.1
        c.put("/may/bien-ban-truoc", json={"ma": ""}, headers=NUT)
        NLM[0] = g = NlmNhieuNguon()
        ma = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        v = bbh.VIEC[ma]
        c.post("/may/tro-ly/ghi-nhanh", json={"chu": "Ghi nhanh không lên điện thoại"}, headers=NUT)
        c.put(f"/may/viec/{ma}/ghi-chu-rieng", json={"chu": "Ghi chú thư ký không lên điện thoại"},
              headers=NUT)
        c.post("/may/tro-ly/ngu-canh", json={"chu": "Ngữ cảnh không lên điện thoại"}, headers=NUT)
        cho_den(lambda: any(t["loai"] == "doan" for t in v["tro_ly"]["the"]), 20)
        kiem("bật xem trên điện thoại thiếu tiêu đề giao diện thì bị chặn",
             c.post("/may/tro-ly/xem-dien-thoai", json={"bat": True}).status_code == 403)
        r = c.post("/may/tro-ly/xem-dien-thoai", json={"bat": True}, headers=NUT)
        xem = (r.json() if r.status_code == 200 else {}).get("xem") or {}
        url = xem.get("url", "")
        kiem("bật xem: địa chỉ ở cổng riêng, có mã ngẫu nhiên, kèm mã QR",
             re.fullmatch(r"http://127\.0\.0\.1:\d+/[\w-]{16}/", url) is not None
             and "<svg" in xem.get("qr", "") and not url.startswith(GOC), r.text[:200])
        trang = httpx.get(url, timeout=5) if url else None
        du = httpx.get(url + "du-lieu", timeout=5).json() if url else {}
        kiem("điện thoại mở được trang xem và dữ liệu của khung Trợ lý",
             trang is not None and trang.status_code == 200 and "Trợ lý cuộc họp" in trang.text
             and bool(du.get("the")) and du.get("dang_ghi") is True, str(du)[:200])
        chu_du = bbh.json.dumps(du, ensure_ascii=False)
        kiem("dữ liệu trên điện thoại không có ghi chú của thư ký, ghi nhanh, dòng ngữ cảnh, "
             "cụm từ tìm hay tài liệu",
             "Ghi chú thư ký không lên" not in chu_du and "Ghi nhanh không lên điện thoại" not in chu_du
             and "Ngữ cảnh không lên" not in chu_du and "ngu_canh" not in chu_du
             and all("cum_tu" not in t for t in du.get("the", [])) and set(du) == {
                 "ten", "dang_ghi", "trang_thai", "ghim", "the"}, chu_du[:200])
        goc_xem = url.rsplit("/", 2)[0]
        if ip:
            kiem("máy chủ phụ chỉ nghe đúng địa chỉ đã chọn, không nghe mọi địa chỉ của máy",
                 mo(url.replace("127.0.0.1", ip) + "du-lieu") is None, ip)
        kiem("máy chủ phụ: sai mã, hay đường nào khác ngoài trang xem, đều là không có trang này",
             all(mo(goc_xem + d) == 404 for d in (
                 "/sai-ma-xxxxxxxxxxxx/", "/sai-ma-xxxxxxxxxxxx/du-lieu", "/", "/may/trang-thai",
                 f"/may/viec/{ma}", "/may/tro-ly", "/docs", "/%C3%A9/")), goc_xem)
        kiem("máy chủ phụ không nhận lệnh gửi lên (không có nút lệnh nào)",
             httpx.post(goc_xem + "/may/ghi/dung", headers=NUT, timeout=5).status_code in (404, 405)
             and c.get("/may/ghi/trang-thai").json()["tt"] == "ghi")
        c.post("/may/tro-ly/xem-dien-thoai", json={"bat": True}, headers=NUT)
        url2 = (c.get("/may/tro-ly").json().get("xem") or {}).get("url", "")
        kiem("bật lại thì đổi mã (không chỉ đổi cổng); địa chỉ cũ không vào được nữa",
             url2 and url2.rsplit("/", 2)[-2] != url.rsplit("/", 2)[-2]
             and mo(url2 + "du-lieu") == 200 and mo(url + "du-lieu") != 200)
        c.post("/may/tro-ly/xem-dien-thoai", json={"bat": False}, headers=NUT)
        kiem("thư ký bấm tắt thì điện thoại thôi xem được",
             mo(url2 + "du-lieu") != 200 and c.get("/may/tro-ly").json().get("xem") is None)
        c.post("/may/tro-ly/xem-dien-thoai", json={"bat": True}, headers=NUT)
        url3 = (c.get("/may/tro-ly").json().get("xem") or {}).get("url", "")
        c.post("/may/ghi/dung", headers=NUT)
        kiem("bấm Dừng thì tự tắt trang xem trên điện thoại",
             url3 and mo(url3 + "du-lieu") != 200 and bbh.XEM["may"] is None)
        cho_xong(ma, 15)
        kiem("hết ghi âm thì không bật được nữa",
             c.post("/may/tro-ly/xem-dien-thoai", json={"bat": True}, headers=NUT).status_code == 409)

        def khong_mang():
            raise OSError("không có mạng")

        bbh.ip_mang_noi_bo = khong_mang
        NLM[0] = g = NlmNhieuNguon()
        ma = c.post("/may/ghi/bat-dau", headers=NUT).json()["ma"]
        r = c.post("/may/tro-ly/xem-dien-thoai", json={"bat": True}, headers=NUT)
        kiem("máy chưa nối Wi-Fi thì báo rõ, không bật", r.status_code == 409
             and "Wi-Fi" in r.json().get("detail", "") and bbh.XEM["may"] is None, r.text[:150])
        c.post("/may/ghi/dung", headers=NUT)
        cho_xong(ma, 15)
        bbh.ip_mang_noi_bo = ip_that

    os.environ.pop("GHI_AM_NGUON", None)
    for k, gt in that.items():
        setattr(bbh, k, gt)
    bbh.HAN_NLM.clear()
    bbh.HAN_NLM.update(han_that)


# ----------------------------------------------------------------------------
print("\nM. Bản 4: chỉ hiện trạng thái chung chung, dấu tên, thư mục lưu chọn được")
# ----------------------------------------------------------------------------
# PM yêu cầu 27/9/2026: phần mềm không hiện là đang làm trong NotebookLM, chỉ hiện
# trạng thái chung chung. Lời hứa với người họp thì vẫn phải nói rõ bản ghi đi đâu.
import ast  # noqa: E402


def chuoi_hien_ra(ten_tep: str) -> list[tuple[int, str]]:
    """Các chuỗi trong mã có thể hiện ra màn hình: bỏ docstring và chữ in vào nhật ký
    máy (print), vì nhật ký là chỗ người phụ trách kỹ thuật tra lỗi."""
    cay = ast.parse((THU_MUC / ten_tep).read_text(encoding="utf-8"))
    bo = set()
    for n in ast.walk(cay):
        if (isinstance(n, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
                and n.body and isinstance(n.body[0], ast.Expr)
                and isinstance(n.body[0].value, ast.Constant)):
            bo.add(id(n.body[0].value))
        if isinstance(n, ast.Call) and getattr(n.func, "id", "") == "print":
            bo.update(id(m) for m in ast.walk(n))
    return [(n.lineno, n.value) for n in ast.walk(cay)
            if isinstance(n, ast.Constant) and isinstance(n.value, str) and id(n) not in bo]


for ten_tep in ("bien_ban_hop.py", "ghi_am.py", "tao_word.py", "tao_ung_dung.py", "ung_dung.py"):
    lot = [d for d, s in chuoi_hien_ra(ten_tep) if "NotebookLM" in s]
    kiem(f"{ten_tep}: không câu nào hiện ra màn hình nêu tên NotebookLM", not lot, str(lot))
# Chữ Google chỉ được nói ở chỗ đăng nhập (bắt buộc đăng nhập Google, PM giữ 27/9/2026)
# và tên trình duyệt Google Chrome; mọi dòng trạng thái khác nói chung chung
lot = [(d, s[:60]) for d, s in chuoi_hien_ra("bien_ban_hop.py")
       if "Google" in s and not any(k in s for k in ("đăng nhập Google", "Google Chrome"))]
kiem("máy chủ chỉ nói Google ở chỗ đăng nhập, trạng thái thì chung chung", not lot, str(lot))
for ten_tep in ("giao_dien.html", "xem_dien_thoai.html"):
    kiem(f"{ten_tep}: không còn chữ NotebookLM",
         "NotebookLM" not in (THU_MUC / ten_tep).read_text(encoding="utf-8"))
GD = (THU_MUC / "giao_dien.html").read_text(encoding="utf-8")
lot = [d.strip()[:60] for d in GD.splitlines() if "Google" in d and not any(
    k in d for k in ("đăng nhập Google", "Đăng nhập Google", "dịch vụ trực tuyến của Google",
                     "tài khoản Google"))]
kiem("giao diện chỉ nói Google ở câu thông báo, lựa chọn trong Cài đặt và chỗ đăng nhập",
     not lot, str(lot))
cau_gui = next((d for d in GD.splitlines() if d.startswith("const CAU_NOTEBOOKLM")), "")
cau_giu = next((d for d in GD.splitlines() if d.startswith("const CAU_TAI_MAY")), "")
kiem("câu chủ trì đọc đầu buổi vẫn nói rõ bản ghi gửi lên dịch vụ của Google, lưu ở đâu",
     "dịch vụ trực tuyến của Google" in cau_gui and "trong lúc họp" in cau_gui
     and "được lưu trong tài khoản" in cau_gui and "không đồng ý" in cau_gui, cau_gui[:120])
kiem("câu thông báo của cuộc họp không gửi lên mạng vẫn như cũ",
     "không gửi lên mạng" in cau_giu and "Google" not in cau_giu)
kiem("lựa chọn gửi lên mạng trong Cài đặt nói rõ là dịch vụ của Google",
     re.search(r"<b>Gửi lên mạng</b><br><span class=\"nho\">Bản ghi gửi lên dịch vụ "
               r"trực tuyến của Google", GD) is not None)
kiem("có dấu © 2026 Nguyễn Nam Hải ở dải dưới cùng, ngoài vùng cuộn nội dung",
     '<footer class="chan" id="dau-ten">© 2026 Nguyễn Nam Hải<span id="ban-chan"></span></footer>' in GD
     and GD.index("</main>") < GD.index('id="dau-ten"') < GD.index("<script>")
     and re.search(r"\.chan \{[^}]*flex: none", GD) is not None)
# Số phiên bản cạnh dấu tên (PM yêu cầu 27/9/2026) lấy từ máy chủ lúc chạy: ghi cứng vào
# giao_dien.html thì sai ngay, vì chính tệp đó nằm trong phần tính dấu phiên bản
kiem("góc dưới bên trái: sau tên PM là tên ứng dụng SonicRec kèm tên bản đang chạy (v1, v2...; PM "
     "yêu cầu 28/9/2026, đặt tên theo số 30/9/2026) và tên đơn vị được cấp mã, lấy từ tình trạng máy",
     re.search(r'\$\("ban-chan"\)\.textContent = \(TT\.ten_ban \|\| TT\.phien_ban \? " · SonicRec " \+ '
               r'\(TT\.ten_ban \|\| "v" \+ TT\.phien_ban\) : ""\) \+\s*'
               r'\(TT\.kich_hoat && TT\.kich_hoat\.cho \? " · Cấp cho " \+ TT\.kich_hoat\.cho : ""\)', GD)
     is not None and "giao_dien.html" in bbh.TEP_PHIEN_BAN)
kiem("giao diện gọi bản bằng tên v1, v2... ở mọi chỗ người dùng thấy: dòng Phiên bản trong Cài đặt "
     "(kèm mã), dải báo bản mới, hộp xác nhận cập nhật, màn đang cập nhật",
     "<b>${h(TT.ten_ban || TT.phien_ban)}</b>" in GD and "(mã ${h(TT.phien_ban)})" in GD
     and "Có bản mới <b>${h(m.ten)}</b>" in GD and '"Cập nhật lên bản " + m.ten + "?"' in GD
     and "boQuaBan = TT.ban_moi ? TT.ban_moi.ten" in GD
     and "từ bản ${h(k.ten_cu || k.cu)} lên bản ${h(k.ten_moi || k.phien_ban)}" in GD
     and "<b>v${h(m.phien_ban)}</b>" not in GD and '"Cập nhật lên bản v" + m.phien_ban' not in GD)

# Lỗi: câu của máy hiện nguyên văn; lỗi của thư viện hay của mạng chỉ nói chung chung
# theo loại, nguyên văn ghi vào nhật ký máy


class RateLimitGia(Exception):
    pass


so_nhat_ky = io.StringIO()
with contextlib.redirect_stdout(so_nhat_ky):
    kq_loi = {
        "ro": bbh.ly_do_loi(bbh.LoiRo("Chưa đăng nhập Google.")),
        "thu_vien": bbh.ly_do_loi(RuntimeError("NotebookLM RPC error 7: notebooklm.google.com")),
        "mang": bbh.ly_do_loi(bbh.httpx.ConnectError("nối không được")),
        "han": bbh.ly_do_loi(TimeoutError()),
        "luot": bbh.ly_do_loi(RateLimitGia("quota exceeded")),
        "dang_nhap": bbh.ly_do_loi(RuntimeError("Authentication expired, please login")),
        "quyen": bbh.ly_do_loi(PermissionError(13, "Permission denied")),
    }
kiem("lỗi máy tự đặt hiện nguyên văn", kq_loi["ro"] == "Chưa đăng nhập Google.")
kiem("lỗi của thư viện chỉ nói chung chung, không nêu tên dịch vụ hay nguyên văn tiếng Anh",
     all(x not in kq_loi["thu_vien"] for x in ("NotebookLM", "notebooklm", "RPC", "RuntimeError"))
     and "Có lỗi khi xử lý" in kq_loi["thu_vien"], kq_loi["thu_vien"])
kiem("nguyên văn lỗi của thư viện vẫn ghi vào nhật ký máy để tra",
     "NotebookLM RPC error 7" in so_nhat_ky.getvalue())
kiem("mất mạng, quá hạn, hết lượt, hết phiên đăng nhập, thiếu quyền ghi: mỗi loại một câu rõ",
     "Mất kết nối mạng" in kq_loi["mang"] and "không trả lời kịp" in kq_loi["han"]
     and "hết lượt" in kq_loi["luot"] and "Đăng nhập lại" in kq_loi["dang_nhap"]
     and "không cho ghi tệp" in kq_loi["quyen"], str(kq_loi))
# Quét lại mọi cuộc họp các phần trên đã chạy (có cả những lần thư viện giả báo hỏng):
# không chỗ nào người dùng thấy còn tên dịch vụ hay nguyên văn lỗi của thư viện
lot = []
for v in bbh.VIEC.values():
    ty = v.get("tro_ly") or {}
    cho_xem = [v.get("trang_thai"), v.get("loi"), v.get("canh_bao"), ty.get("trang_thai"),
               ty.get("tam_nghi")] + [x[1] for x in v.get("nhat_ky") or []]
    cho_xem += [t.get(k) for t in ty.get("the") or [] for k in ("loi", "chu")]
    cho_xem += [n.get("loi") for n in ty.get("nen") or []]
    lot += [s for s in cho_xem if isinstance(s, str) and any(
        k in s for k in ("NotebookLM", "hỏng giả lập", "RuntimeError", "RateLimit"))]
kiem(f"quét {len(bbh.VIEC)} cuộc họp đã chạy: không trạng thái, lỗi, cảnh báo, nhật ký hay thẻ "
     "nào nêu tên dịch vụ hay nguyên văn lỗi thư viện", len(bbh.VIEC) > 20 and not lot, str(lot[:3]))

# Thư mục lưu: trình cài ghi vào cau-hinh-may.json, ứng dụng đọc lúc bật
that_tep_ch = bbh.TEP_CAU_HINH_MAY
bbh.TEP_CAU_HINH_MAY = TAM / "cau-hinh-may.json"
bbh.TEP_CAU_HINH_MAY.write_text('{"thu_muc_luu": "/Users/a/Bien ban hop"}', encoding="utf-8")
kiem("đọc thư mục lưu trình cài đã chọn",
     bbh.thu_muc_luu_da_chon() == Path("/Users/a/Bien ban hop"))
bbh.TEP_CAU_HINH_MAY.write_text("{hỏng", encoding="utf-8")
kiem("tệp cấu hình hỏng thì dùng thư mục mặc định", bbh.thu_muc_luu_da_chon() is None)
bbh.TEP_CAU_HINH_MAY.write_text('{"thu_muc_luu": "  "}', encoding="utf-8")
kiem("chưa chọn thư mục thì dùng thư mục mặc định", bbh.thu_muc_luu_da_chon() is None)
bbh.TEP_CAU_HINH_MAY.unlink()
kiem("không có tệp cấu hình thì dùng thư mục mặc định", bbh.thu_muc_luu_da_chon() is None)
bbh.TEP_CAU_HINH_MAY = that_tep_ch


# ----------------------------------------------------------------------------
print("\nN. Khoá kích hoạt: mã riêng cho từng máy, người phát hành ký (PM chốt 28/9/2026)")
# ----------------------------------------------------------------------------
import base64  # noqa: E402

# Chữ ký Ed25519 viết thẳng bằng Python: phải đúng ba bộ mẫu của RFC 8032 mục 7.1
MAU_RFC = [
    ("9d61b19deffd5a60ba844af492ec2cc44449c5697b326919703bac031cae7f60",
     "d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a", "",
     "e5564300c360ac729086e2cc806e828a84877f1eb8e5d974d873e065224901555fb8821590a33bacc61e3970"
     "1cf9b46bd25bf5f0595bbe24655141438e7a100b"),
    ("4ccd089b28ff96da9db6c346ec114e0f5b8a319f35aba624da8cf6ed4fb8a6fb",
     "3d4017c3e843895a92b70aa74d1b7ebc9c982ccf2ec4968cc0cd55f12af4660c", "72",
     "92a009a9f0d4cab8720e820b5f642540a2b27b5416503f8fb3762223ebdb69da085ac1e43e15996e458f3613"
     "d0f11d8c387b2eaeb4302aeeb00d291612bb0c00"),
    ("c5aa8df43f9f837bedb7442f31dcb7b166d38535076f094b85ce3a2e0b4458f7",
     "fc51cd8e6218a1a38da47ed00230f0580816ed13ba3303ac5deb911548908025", "af82",
     "6291d657deec24024827e69c3abe01a30ce548a284743a445e3680d7db5ac3ac18ff9b538d16f290ae67f760"
     "984dc6594a7c15e9716ed28dc027beceea1ec40a"),
]
dung_rfc = []
for an, cong, tin, ck in MAU_RFC:
    an, cong, tin, ck = (bytes.fromhex(x) for x in (an, cong, tin, ck))
    dung_rfc.append(kich_hoat.khoa_cong_khai_tu(an) == cong and kich_hoat.ky(an, tin) == ck
                    and kich_hoat.dung_chu_ky(cong, tin, ck))
kiem("chữ ký Ed25519 đúng ba bộ mẫu của RFC 8032 (mã công khai, chữ ký, phép kiểm)",
     all(dung_rfc), str(dung_rfc))
an, cong = bytes(range(32)), kich_hoat.khoa_cong_khai_tu(bytes(range(32)))
ck = kich_hoat.ky(an, b"Trung tam A")
s_them_l = (int.from_bytes(ck[32:], "little") + kich_hoat._L).to_bytes(32, "little")
kiem("sửa một chữ của nội dung, một bit của chữ ký, hay cộng L vào chữ ký đều bị từ chối",
     kich_hoat.dung_chu_ky(cong, b"Trung tam A", ck)
     and not kich_hoat.dung_chu_ky(cong, b"Trung tam B", ck)
     and not kich_hoat.dung_chu_ky(cong, b"Trung tam A", ck[:5] + bytes([ck[5] ^ 4]) + ck[6:])
     and not kich_hoat.dung_chu_ky(cong, b"Trung tam A", ck[:32] + s_them_l))

# Mã máy: đọc mã phần cứng thật (Mac: ioreg, Windows: sổ đăng ký, Linux: machine-id)
tho = kich_hoat.ma_may_tho()
kich_hoat._MA_MAY.clear()
may_that = kich_hoat.ma_may()
kiem("đọc được mã phần cứng của máy này không cần quyền quản trị; mã máy dạng XXXX-XXXX-XXXX, "
     "đọc lại vẫn vậy", len(tho) >= 8 and not (kich_hoat.THU_MUC_GOC / ".ma-may").exists()
     and bool(re.fullmatch(r"[0-9A-HJKMNP-TV-Z]{4}(-[0-9A-HJKMNP-TV-Z]{4}){2}", may_that))
     and kich_hoat.ma_may() == may_that, may_that)
kiem("mã máy người dùng gửi qua tin nhắn: chữ thường, dấu cách, chữ I, L, O gõ nhầm vẫn nhận; "
     "sai độ dài hay ký tự lạ thì không",
     kich_hoat.chuan_ma_may(" mzkx edwe prcj ") == "MZKX-EDWE-PRCJ"
     and kich_hoat.chuan_ma_may("1LO0-AAAA-BBBB") == "1100-AAAA-BBBB"
     and kich_hoat.chuan_ma_may("MZKX-EDWE-PRC") is None and kich_hoat.chuan_ma_may("MZKX-EDWE-PRC#") is None)

# Từ đây bật khoá bằng cặp chìa khoá thử, máy giả có mã AAAA-BBBB-CCCC
AN_THU = bytes(range(1, 33))
kich_hoat.KHOA_CONG_KHAI = (kich_hoat.chu_cong_khai(AN_THU),)
kich_hoat._MA_MAY[:] = ["AAAA-BBBB-CCCC"]
HOM_NAY = date.today()
ma_dung = kich_hoat.tao_ma(AN_THU, "AAAA-BBBB-CCCC", "Trung tâm Đào tạo A", HOM_NAY + timedelta(days=30), 1)
nd, _ = kich_hoat.doc_ma(ma_dung)
kiem("mã kích hoạt đọc ra đúng máy, đơn vị (có dấu), hạn dùng",
     bool(nd) and nd["may"] == "AAAA-BBBB-CCCC" and nd["cho"] == "Trung tâm Đào tạo A"
     and nd["han"] == HOM_NAY + timedelta(days=30), str(nd))
tin_nhan = (f"Mã kích hoạt SonicRec cho Trung tâm Đào tạo A, dùng đến hết ngày ...:\n"
            f"{ma_dung[:70]}\n{ma_dung[70:150]} {ma_dung[150:]}\nCảm ơn anh")
kiem("dán cả tin nhắn, mã bị xuống dòng hay có dấu cách giữa chừng vẫn đọc được",
     (kich_hoat.doc_ma(tin_nhan)[0] or {}).get("cho") == "Trung tâm Đào tạo A")


def _mo(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def _dong(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).decode().rstrip("=")


phan = ma_dung.split(".")
nd_sua = json.loads(_mo(phan[1]))
nd_sua["han"] = "2099-12-31"
ma_sua_han = "BBH1." + _dong(json.dumps(nd_sua, ensure_ascii=False).encode()) + "." + phan[2]
nd_sua = json.loads(_mo(phan[1]))
nd_sua["may"] = "ZZZZ-ZZZZ-ZZZZ"
ma_sua_may = "BBH1." + _dong(json.dumps(nd_sua, ensure_ascii=False).encode()) + "." + phan[2]
ma_khoa_khac = kich_hoat.tao_ma(bytes(32), "AAAA-BBBB-CCCC", "Tự làm", HOM_NAY + timedelta(days=999), 1)
kiem("tự sửa hạn dùng hay mã máy trong mã, hoặc tự ký bằng chìa khoá khác: đều bị từ chối",
     all(kich_hoat.doc_ma(m)[0] is None for m in (ma_sua_han, ma_sua_may, ma_khoa_khac)))
kiem("chữ lung tung hay mã bị cụt: báo rõ, không lỗi",
     all(kich_hoat.doc_ma(m)[0] is None and kich_hoat.doc_ma(m)[1] for m in ("", "abc", ma_dung[:-3])))


def tt_kh(cu: bool = False, ngay: date | None = None) -> dict:
    return kich_hoat.trang_thai(lambda: cu, ngay or HOM_NAY)


kich_hoat.TEP_KICH_HOAT.unlink(missing_ok=True)
t1 = tt_kh(cu=False)
t2 = tt_kh(cu=True)
kiem("máy mới cài chưa có mã: chặn ngay ở lần mở đầu, không có 30 ngày; cuộc họp ghi sau "
     "cũng không mở thêm 30 ngày", t1["tinh_trang"] == t2["tinh_trang"] == "chua_kich_hoat"
     and not t1["duoc_dung"] and not t2["duoc_dung"], f"{t1['tinh_trang']} {t2['tinh_trang']}")
kich_hoat.TEP_KICH_HOAT.unlink(missing_ok=True)
t1 = tt_kh(cu=True)
t2 = tt_kh(cu=False, ngay=HOM_NAY + timedelta(days=30))
t3 = tt_kh(cu=True, ngay=HOM_NAY + timedelta(days=31))
kiem("máy đã có cuộc họp trước khi có khoá: dùng tiếp đúng 30 ngày rồi mới chặn",
     t1["tinh_trang"] == "dung_tiep" and t1["duoc_dung"] and t1["con_ngay"] == 30
     and t2["duoc_dung"] and t2["con_ngay"] == 0
     and t3["tinh_trang"] == "het_dung_tiep" and not t3["duoc_dung"],
     f"{t1['con_ngay']} {t2['con_ngay']} {t3['tinh_trang']}")
that_ngay_khoa = kich_hoat.NGAY_BAT_KHOA
kich_hoat.NGAY_BAT_KHOA = HOM_NAY - timedelta(days=50)
kich_hoat.TEP_KICH_HOAT.unlink(missing_ok=True)
t1 = tt_kh(cu=True)
kich_hoat.NGAY_BAT_KHOA = that_ngay_khoa
kiem("xoá tệp kích hoạt để lấy lại 30 ngày: không bao giờ quá 60 ngày sau ngày có khoá",
     t1["con_ngay"] == 10, str(t1["con_ngay"]))

kich_hoat.TEP_KICH_HOAT.unlink(missing_ok=True)
nd, ly_do = kich_hoat.nhap_ma(tin_nhan)
t1 = tt_kh()
t2 = tt_kh(ngay=HOM_NAY + timedelta(days=25))
t3 = tt_kh(ngay=HOM_NAY + timedelta(days=30))
t4 = tt_kh(ngay=HOM_NAY + timedelta(days=31))
kiem("nhập đúng mã: dùng được tới hết ngày hết hạn, nhắc từ 7 ngày cuối, qua ngày đó thì chặn",
     bool(nd) and t1["tinh_trang"] == "da_kich_hoat" and t1["duoc_dung"]
     and t1["cho"] == "Trung tâm Đào tạo A" and t1["han"] == f"{HOM_NAY + timedelta(days=30):%d/%m/%Y}"
     and t2["tinh_trang"] == "sap_het_han" and t2["duoc_dung"] and t3["duoc_dung"]
     and t4["tinh_trang"] == "het_han" and not t4["duoc_dung"],
     f"{ly_do} {t1['tinh_trang']} {t2['tinh_trang']} {t4['tinh_trang']}")
nd, ly_do = kich_hoat.nhap_ma(kich_hoat.tao_ma(AN_THU, "ZZZZ-ZZZZ-ZZZZ", "B", HOM_NAY + timedelta(days=9), 2))
kiem("mã cấp cho máy khác: từ chối, nói rõ mã máy đúng phải gửi",
     nd is None and "ZZZZ-ZZZZ-ZZZZ" in ly_do and "AAAA-BBBB-CCCC" in ly_do, ly_do)
nd, ly_do = kich_hoat.nhap_ma(kich_hoat.tao_ma(AN_THU, "AAAA-BBBB-CCCC", "C", HOM_NAY - timedelta(days=1), 3))
kiem("mã đã hết hạn lúc nhập: từ chối, mã cũ đang dùng giữ nguyên",
     nd is None and "hết hạn" in ly_do and tt_kh()["cho"] == "Trung tâm Đào tạo A", ly_do)
kich_hoat._MA_MAY[:] = ["DDDD-EEEE-FFFF"]
t1 = tt_kh(cu=True)
kich_hoat._MA_MAY[:] = ["AAAA-BBBB-CCCC"]
kiem("chép nguyên thư mục cài (cả cuộc họp cũ) sang máy khác: mã cũ không dùng được ở máy đó, "
     "cũng không được 30 ngày dùng tiếp", not t1["duoc_dung"] and "máy khác" in t1["ly_do"], str(t1))
luu_that = kich_hoat.TEP_KICH_HOAT.read_text(encoding="utf-8")
sua_tay = []
for chu in ('{"ma": 5}', '{"ma": 5, "dung_tiep_tu": 7}', '{"dung_tiep_tu": [1]}', "[]", "{hỏng"):
    kich_hoat.TEP_KICH_HOAT.write_text(chu, encoding="utf-8")
    try:
        sua_tay.append(tt_kh(cu=True)["tinh_trang"])
    except Exception as loi:  # noqa: BLE001
        sua_tay.append(f"đổ: {type(loi).__name__}")
kich_hoat.TEP_KICH_HOAT.write_text(luu_that, encoding="utf-8")
kiem("tệp kích hoạt bị sửa tay hay hỏng: máy không đổ (vẫn mở được để xem), mã sai thì chặn",
     not any(x.startswith("đổ") for x in sua_tay) and sua_tay[:2] == ["chua_kich_hoat"] * 2, str(sua_tay))

# Máy người phát hành: chìa khoá riêng, cấp mã, danh sách đã cấp
kiem("máy không có chìa khoá riêng: không phải máy phát hành, không cấp mã được",
     not kich_hoat.may_phat_hanh()["co"])
try:
    kich_hoat.cap_ma("AAAA-BBBB-CCCC", "X", HOM_NAY)
    cap_duoc = True
except PermissionError:
    cap_duoc = False
kiem("không có chìa khoá thì hàm cấp mã từ chối", not cap_duoc)
that_thu_muc_ck = kich_hoat.THU_MUC_CHIA_KHOA
kich_hoat.THU_MUC_CHIA_KHOA = TAM / "cap-ma-khac"
ck_la = kich_hoat.tao_chia_khoa()
try:
    kich_hoat.tao_chia_khoa()
    de_duoc = True
except FileExistsError:
    de_duoc = False
ph_la = kich_hoat.may_phat_hanh()
kiem("tạo chìa khoá mới: không bao giờ ghi đè chìa khoá đã có; chìa khoá chưa gắn vào bản cài "
     "thì chưa cấp được, và hiện mã công khai của nó",
     not de_duoc and ph_la["co"] and not ph_la["khop"] and ph_la["cong_khai"] == ck_la)
if os.name != "nt":
    kiem("tệp chìa khoá riêng chỉ chủ máy đọc được",
         (kich_hoat.THU_MUC_CHIA_KHOA / kich_hoat.TEN_CHIA_KHOA).stat().st_mode & 0o777 == 0o600
         and kich_hoat.THU_MUC_CHIA_KHOA.stat().st_mode & 0o777 == 0o700)
kich_hoat.THU_MUC_CHIA_KHOA = that_thu_muc_ck
ck_nap = kich_hoat.nap_ban_sao("dán nhầm dấu cách RIENG-" + _dong(AN_THU) + "  ")
ph = kich_hoat.may_phat_hanh()
kiem("nạp bản sao chìa khoá: ra đúng chìa khoá gắn trong bản cài; máy phát hành không cần mã",
     ck_nap == kich_hoat.KHOA_CONG_KHAI[0] and ph["khop"] and tt_kh()["tinh_trang"] == "phat_hanh"
     and tt_kh()["duoc_dung"])
ma_cap = kich_hoat.cap_ma(" gggg hhhh jjjj ", "  Trường   B  ", HOM_NAY + timedelta(days=31))
nd, _ = kich_hoat.doc_ma(ma_cap)
ds = kich_hoat.ds_da_cap()
kiem("cấp mã: chuẩn hoá mã máy và tên, ghi vào danh sách đã cấp",
     bool(nd) and nd["may"] == "GGGG-HHHH-JJJJ" and nd["cho"] == "Trường B"
     and ds and ds[0]["ma"] == ma_cap and ds[0]["so"] == 1, str(ds[:1]))
loi_cap = []
for may, cho, han in (("GGGG-HHHH", "A", HOM_NAY), ("GGGG-HHHH-JJJJ", "  ", HOM_NAY),
                      ("GGGG-HHHH-JJJJ", "A", HOM_NAY - timedelta(days=1))):
    try:
        kich_hoat.cap_ma(may, cho, han)
    except ValueError as loi:
        loi_cap.append(str(loi))
kiem("cấp mã sai (mã máy thiếu ký tự, chưa điền tên, hạn đã qua): báo rõ, không ghi gì",
     len(loi_cap) == 3 and len(kich_hoat.ds_da_cap()) == 1, str(loi_cap))

# Máy chủ: chặn đúng ba việc, xem vẫn được, nhập mã thì mở; khớp với giao diện
tep_ck = kich_hoat.THU_MUC_CHIA_KHOA / kich_hoat.TEN_CHIA_KHOA
tep_ck.rename(TAM / "chia-khoa-cat-di.txt")  # thôi là máy phát hành
kich_hoat.TEP_KICH_HOAT.write_text('{"dung_tiep_tu": ""}', encoding="utf-8")
with TestClient(bbh.app, base_url=GOC, client=("127.0.0.1", 50000)) as c:
    tt_may = c.get("/may/trang-thai").json()["kich_hoat"]
    kiem("máy chủ báo giao diện: đã bật khoá, máy chưa kích hoạt, kèm mã máy",
         tt_may["bat"] and not tt_may["duoc_dung"] and tt_may["ma_may"] == "AAAA-BBBB-CCCC", str(tt_may))
    so_thu_muc = len(list(bbh.THU_MUC_LUU.iterdir()))
    d1 = c.post("/may/ghi/bat-dau", headers=NUT)
    d2 = c.post("/may/tai-len", headers=NUT, files={"ghi_am": ("hop.m4a", b"khong phai am thanh", "audio/mp4")})
    xong = next(m for m in bbh.THU_TU if bbh.VIEC[m]["trang_thai"] == "Xong")
    loi = next((m for m in bbh.THU_TU if bbh.VIEC[m]["trang_thai"] in ("Lỗi", "Bị gián đoạn")), xong)
    d3 = c.post(f"/may/viec/{loi}/lam-lai", headers=NUT)
    kiem("chưa kích hoạt: máy chủ từ chối bắt đầu ghi, nhận tệp ghi âm, Làm lại, nói rõ gửi mã máy "
         "nào; không tạo cuộc họp nào", all(d.status_code == 403 and "AAAA-BBBB-CCCC" in d.json()["detail"]
                                            for d in (d1, d2, d3))
         and not bbh.MAY_GHI.tt and len(list(bbh.THU_MUC_LUU.iterdir())) == so_thu_muc,
         f"{d1.status_code} {d2.status_code} {d3.status_code} {d1.json().get('detail', '')[:60]}")
    d4 = c.get(f"/may/viec/{xong}")
    d5 = c.post("/may/ghi/tam-dung", headers=NUT)
    kiem("chưa kích hoạt: vẫn xem được cuộc họp cũ; lệnh của cuộc họp đang ghi (Tạm dừng, Ghi tiếp, "
         "Dừng) không bị khoá", d4.status_code == 200 and d5.status_code != 403, f"{d4.status_code} {d5.status_code}")
    d6 = c.post("/may/kich-hoat", headers=NUT, json={"ma": "BBH1.sai.sai"})
    d7 = c.post("/may/kich-hoat", json={"ma": ma_dung})
    d8 = c.post("/may/kich-hoat", headers=NUT, json={"ma": tin_nhan})
    d9 = c.post(f"/may/viec/{xong}/lam-lai", headers=NUT)
    kiem("nhập mã sai thì báo lý do; thiếu tiêu đề giao diện thì bị chặn; nhập đúng thì mở khoá "
         "ngay (Làm lại qua được khoá, tới phép kiểm tiếp theo)",
         d6.status_code == 400 and d6.json()["detail"] and d7.status_code == 403
         and d8.status_code == 200 and d8.json()["duoc_dung"] and d8.json()["cho"] == "Trung tâm Đào tạo A"
         and d9.status_code == 409 and "đã xong" in d9.json()["detail"],
         f"{d6.status_code} {d7.status_code} {d8.status_code} {d9.status_code}")
    that_tep_kh = kich_hoat.TEP_KICH_HOAT
    kich_hoat.TEP_KICH_HOAT = TAM / "khong-co-thu-muc-nay" / "kich-hoat.json"
    try:
        d_ghi_hong = c.post("/may/kich-hoat", headers=NUT, json={"ma": tin_nhan})
        ghi_hong = (d_ghi_hong.status_code, str(d_ghi_hong.json().get("detail", "")))
    except Exception as loi:  # noqa: BLE001
        ghi_hong = (0, f"đổ: {type(loi).__name__}")
    finally:
        kich_hoat.TEP_KICH_HOAT = that_tep_kh
    kiem("không ghi được tệp kích hoạt (thư mục cài chỉ đọc): báo rõ lý do, không đổ",
         ghi_hong[0] == 500 and "Không ghi được tệp kích hoạt" in ghi_hong[1], str(ghi_hong)[:120])
    luu = json.loads(kich_hoat.TEP_KICH_HOAT.read_text(encoding="utf-8"))
    luu["ma"] = kich_hoat.tao_ma(AN_THU, "AAAA-BBBB-CCCC", "Trung tâm Đào tạo A", HOM_NAY - timedelta(days=2), 4)
    kich_hoat.TEP_KICH_HOAT.write_text(json.dumps(luu), encoding="utf-8")  # như đã qua ngày hết hạn
    tt_het = c.get("/may/trang-thai").json()["kich_hoat"]
    d10 = c.post("/may/ghi/bat-dau", headers=NUT)
    kiem("mã hết hạn: giao diện biết, máy chủ chặn ghi và nói rõ ngày hết hạn",
         tt_het["tinh_trang"] == "het_han" and not tt_het["duoc_dung"] and d10.status_code == 403
         and f"{HOM_NAY - timedelta(days=2):%d/%m/%Y}" in d10.json()["detail"], d10.text[:120])
    d11 = c.get("/may/cap-ma")
    tep_ck_cat = TAM / "chia-khoa-cat-di.txt"
    tep_ck_cat.rename(tep_ck)
    d12 = c.get("/may/cap-ma")
    d13 = c.post("/may/cap-ma", headers=NUT, json={"may": "kkkk-mmmm-nnnn", "cho": "Viện C",
                                                  "han": d12.json()["han_mac_dinh"]})
    d14 = c.post("/may/cap-ma", headers=NUT, json={"may": "sai", "cho": "Viện C", "han": "2099-01-01"})
    d15 = c.post("/may/cap-ma", json={"may": "kkkk-mmmm-nnnn", "cho": "Viện C", "han": "2099-01-01"})
    han_md = date.fromisoformat(d12.json()["han_mac_dinh"])
    kiem("mục Cấp mã: không có ở máy thường; ở máy phát hành thì cấp được, hạn mặc định một tháng, "
         "tin nhắn gửi đi có sẵn mã; mã máy sai bị từ chối; thiếu tiêu đề giao diện thì bị chặn",
         d11.status_code == 404 and d12.status_code == 200 and d12.json()["khop"]
         and han_md == bbh.mot_thang_sau(HOM_NAY) and 28 <= (han_md - HOM_NAY).days <= 31
         and d13.status_code == 200 and d13.json()["ma"] in d13.json()["tin_nhan"]
         and d13.json()["tin_nhan"].startswith("Mã kích hoạt SonicRec cho Viện C")
         and (kich_hoat.doc_ma(d13.json()["tin_nhan"])[0] or {}).get("may") == "KKKK-MMMM-NNNN"
         and d14.status_code == 400 and d15.status_code == 403,
         f"{d11.status_code} {d12.status_code} {d13.status_code} {d14.status_code} {d15.status_code}")
kiem("một tháng sau: cuối tháng dài sang tháng ngắn lấy ngày cuối tháng, qua năm đúng",
     bbh.mot_thang_sau(date(2027, 1, 31)) == date(2027, 2, 28)
     and bbh.mot_thang_sau(date(2028, 1, 31)) == date(2028, 2, 29)
     and bbh.mot_thang_sau(date(2026, 12, 15)) == date(2027, 1, 15))
giao_dien = (THU_MUC / "giao_dien.html").read_text(encoding="utf-8")
kiem("giao diện: nút ghi tắt khi máy chủ không cho dùng, thả tệp ghi âm thì mở màn kích hoạt; "
     "mã hết hạn giữa lúc đang ghi thì không che nút Dừng",
     '$("nut-ghi").disabled = !TT || !TT.ffmpeg || !choDung();' in giao_dien
     and "if (!choDung()) { khDaDong = false; moKichHoat(); return; }" in giao_dien
     and 'if (!k.duoc_dung && !khDaDong && $("kh-man").hidden && !TT.ghi.tt) moKichHoat();' in giao_dien)
kiem("mã công khai gắn trong bản cài đúng dạng (hoặc chưa bật khoá)",
     all(re.fullmatch(r"CONGKHAI-[A-Za-z0-9_-]{43}", x) and kich_hoat._mo_nen(_mo(x[9:])) for x in KHOA_THAT))
kiem("kich_hoat.py nằm trong dấu phiên bản: sửa khoá thì số phiên bản đổi",
     "kich_hoat.py" in bbh.TEP_PHIEN_BAN)
if (THU_MUC / "dong_goi.py").is_file():
    import dong_goi  # noqa: E402
    lenh = dong_goi.tep_tao_chia_khoa().decode("utf-8")
    kiem("tệp tạo chìa khoá cho người phát hành mang đúng mã kich_hoat.py hiện tại, và không nằm "
         "trong gói cài gửi người dùng",
         (THU_MUC / "kich_hoat.py").read_text(encoding="utf-8").rstrip("\n") in lenh
         and '"$PY" "$T/kich_hoat.py" tao-chia-khoa' in lenh and "kich_hoat.py" in dong_goi.TEP_UNG_DUNG
         and dong_goi.TEN_TEP_CHIA_KHOA not in dong_goi.cac_tep_goi(windows=False)
         and dong_goi.TEN_TEP_CHIA_KHOA not in dong_goi.cac_tep_goi(windows=True))
kich_hoat.KHOA_CONG_KHAI = ()
kich_hoat._MA_MAY.clear()


# ----------------------------------------------------------------------------
print("\nP. Nhiều tài khoản Google dự phòng (v1.3): hết lượt thì tự thử tài khoản kế")
# ----------------------------------------------------------------------------

class NlmTaiKhoan(NlmGia):
    """NotebookLM giả có tài khoản: chỉ thấy sổ do chính tài khoản này tạo (sổ của tài khoản
    khác thì get_or_none trả None, như thật). het_luot: mọi câu hỏi bị báo hết lượt."""

    def __init__(self, ma, het_luot=False, **k):
        super().__init__(**k)
        self.ma, self.het_luot, self.so_cua_toi, self.cau = ma, het_luot, set(), []
        self.notes = SimpleNamespace(create=self._ghi_chu, update=self._sua_ghi_chu)

    async def _tao(self, tieu_de):
        await self._buoc("tao", tieu_de)
        so_id = f"so-{self.ma}-{len(self.so_cua_toi) + 1}"
        self.so_cua_toi.add(so_id)
        return SimpleNamespace(id=so_id, title=tieu_de)

    async def _tim(self, so_id):
        await self._buoc("tim", so_id)
        return SimpleNamespace(id=so_id) if so_id in self.so_cua_toi else None

    async def _hoi(self, so_id, cau_hoi, source_ids=None, conversation_id=None):
        await self._buoc("hoi", tuple(source_ids or ()))
        self.cau.append(cau_hoi)
        if self.het_luot:
            raise RateLimitError("quota exceeded")
        return SimpleNamespace(answer=TRA_LOI_GOOGLE)

    async def _ghi_chu(self, so_id, tieu_de, noi_dung):
        await self._buoc("ghi_chu", so_id)
        return SimpleNamespace(id=f"ghi-{self.ma}")

    async def _sua_ghi_chu(self, so_id, ma, noi_dung, tieu_de):
        await self._buoc("sua_ghi_chu", so_id, ma)


def dat_tk(chinh_het=False, p1_het=False, p2_het=False, **k):
    """Dựng lại ba NotebookLM giả (chính, dự phòng 1, dự phòng 2) và xoá bộ đếm lượt."""
    NLM[0] = gc = NlmTaiKhoan("chinh", het_luot=chinh_het, **k)
    NLM_TK["du-phong-1"] = g1 = NlmTaiKhoan("du-phong-1", het_luot=p1_het)
    NLM_TK["du-phong-2"] = g2 = NlmTaiKhoan("du-phong-2", het_luot=p2_het)
    bbh.TEP_LUOT.unlink(missing_ok=True)
    KET_NOI_LOG.clear()
    return gc, g1, g2


def them_loi(ten, gmail):
    """Thêm tài khoản dự phòng; trả câu báo lỗi nếu bị từ chối, rỗng nếu thêm được."""
    try:
        bbh.them_tai_khoan_phu(ten, gmail)
    except bbh.LoiRo as loi:
        return str(loi)
    return ""


def da_dung(ma=None):
    return bbh.TRAN_LUOT - bbh.luot_con_lai(ma)


# --- Sổ tài khoản ---
bbh.TEP_TAI_KHOAN.unlink(missing_ok=True)
kiem("chưa có sổ tài khoản: chỉ có tài khoản chính, tên gọi mặc định",
     [(x["ma"], x["ten"]) for x in bbh.cac_tai_khoan()] == [("chinh", "Tài khoản chính")])
kiem("tên gọi trống, Gmail sai dạng: bị từ chối, nói rõ lý do, sổ không đổi",
     "tên gọi" in them_loi("  ", "a@gmail.com") and "Gmail" in them_loi("A", "khong-phai-gmail")
     and "Gmail" in them_loi("A", "a b@gmail.com") and "Gmail" in them_loi("A", "a@b")
     and "tên gọi" in them_loi("x" * 61, "a@gmail.com") and len(bbh.cac_tai_khoan()) == 1)
tk1 = bbh.them_tai_khoan_phu("  Gmail   phụ 1 ", "Phu.Mot@gmail.com")
kiem("thêm tài khoản dự phòng: mã du-phong-1, gọn khoảng trắng, đứng sau tài khoản chính",
     tk1 == {"ma": "du-phong-1", "ten": "Gmail phụ 1", "gmail": "Phu.Mot@gmail.com"}
     and [x["ma"] for x in bbh.cac_tai_khoan()] == ["chinh", "du-phong-1"], str(tk1))
kiem("Gmail đã có (không phân biệt hoa thường) thì không thêm lần nữa",
     "đã có" in them_loi("Trùng", "phu.mot@GMAIL.com") and len(bbh.cac_tai_khoan()) == 2)
tk2 = bbh.them_tai_khoan_phu("Gmail phụ 2", "phu.hai@gmail.com")
kiem("tài khoản thứ hai là du-phong-2; thứ tự dùng là thứ tự thêm vào",
     tk2["ma"] == "du-phong-2"
     and [x["ma"] for x in bbh.cac_tai_khoan()] == ["chinh", "du-phong-1", "du-phong-2"])
kiem("tối đa 2 tài khoản dự phòng: thêm cái thứ ba bị từ chối",
     "tối đa 2" in them_loi("Ba", "phu.ba@gmail.com") and len(bbh.cac_tai_khoan()) == 3)
kiem("sổ tài khoản lưu xuống ổ đĩa, đọc lại đúng thứ tự",
     [x["gmail"] for x in bbh.json.loads(bbh.TEP_TAI_KHOAN.read_text(encoding="utf-8"))["phu"]]
     == ["Phu.Mot@gmail.com", "phu.hai@gmail.com"])
loi_xoa = []
for ma_sai in ("chinh", "../etc", "du-phong-9", "du-phong-1/../x", "", "du-phong-10"):
    try:
        bbh.xoa_tai_khoan_phu(ma_sai)
    except bbh.LoiRo as loi:
        loi_xoa.append(str(loi))
kiem("xoá mã không phải tài khoản dự phòng đang có (kể cả tài khoản chính, đường dẫn lạ) bị từ chối",
     len(loi_xoa) == 6 and len(bbh.cac_tai_khoan()) == 3, str(loi_xoa))
bbh.xoa_tai_khoan_phu("du-phong-1")
tk1b = bbh.them_tai_khoan_phu("Gmail mới", "phu.moi@gmail.com")
kiem("xoá rồi thêm lại lấy số nhỏ nhất còn trống; tài khoản thêm trước vẫn đứng trước",
     tk1b["ma"] == "du-phong-1"
     and [x["ma"] for x in bbh.cac_tai_khoan()] == ["chinh", "du-phong-2", "du-phong-1"])
bbh.xoa_tai_khoan_phu("du-phong-1")
bbh.xoa_tai_khoan_phu("du-phong-2")
tk1 = bbh.them_tai_khoan_phu("Gmail phụ 1", "phu.mot@gmail.com")
tk2 = bbh.them_tai_khoan_phu("Gmail phụ 2", "phu.hai@gmail.com")
bbh.TEP_TAI_KHOAN.write_text("{hỏng", encoding="utf-8")
ds_hong = [x["ma"] for x in bbh.cac_tai_khoan()]
bbh.TEP_TAI_KHOAN.write_text('["không phải sổ"]', encoding="utf-8")
ds_sai_dang = [x["ma"] for x in bbh.cac_tai_khoan()]
bbh.TEP_TAI_KHOAN.write_text(bbh.json.dumps({"phu": [
    {"ma": "khac", "ten": "Mã lạ", "gmail": "a@gmail.com"}, "không phải bản ghi",
    {"ma": "du-phong-1", "ten": "Một", "gmail": "1@gmail.com"},
    {"ma": "du-phong-2", "ten": "Hai", "gmail": "2@gmail.com"},
    {"ma": "du-phong-3", "ten": "Ba", "gmail": "3@gmail.com"},
    {"ma": "du-phong-1", "ten": "Bản ghi thừa", "gmail": "4@gmail.com"}]}), encoding="utf-8")
ds_dai = [x["ma"] for x in bbh.cac_tai_khoan()]
kiem("sổ tài khoản hỏng hay sai dạng thì coi như chưa có tài khoản dự phòng; mã lạ bị bỏ; không quá 2",
     ds_hong == ["chinh"] and ds_sai_dang == ["chinh"] and ds_dai[0] == "chinh"
     and len(ds_dai) <= 3 and "khac" not in ds_dai and "du-phong-3" not in ds_dai, str(ds_dai))
bbh.TEP_TAI_KHOAN.write_text(bbh.json.dumps({"phu": [
    {"ma": "du-phong-1", "ten": "Một", "gmail": "1@gmail.com"},
    {"ma": "du-phong-1", "ten": "Bản trùng mã", "gmail": "2@gmail.com"}]}), encoding="utf-8")
kiem("sổ tài khoản sửa tay mà hai dòng trùng mã thì giữ dòng đầu, không soạn hai lần ở một tài khoản",
     [(x["ma"], x["ten"]) for x in bbh.cac_tai_khoan()] == [("chinh", "Tài khoản chính"), ("du-phong-1", "Một")])
bbh.TEP_TAI_KHOAN.unlink()
bbh.them_tai_khoan_phu("Gmail phụ 1", "phu.mot@gmail.com")
bbh.them_tai_khoan_phu("Gmail phụ 2", "phu.hai@gmail.com")

# --- Phiên đăng nhập thật: mỗi tài khoản một hồ sơ riêng ---
try:
    import notebooklm
    from notebooklm.paths import get_profile_dir, get_storage_path
    kiem("tài khoản dự phòng chưa đăng nhập thì báo chưa, hồ sơ mặc định không liên quan",
         DA_DANG_NHAP_THAT("du-phong-1") is False and DA_DANG_NHAP_THAT("du-phong-2") is False)
    get_profile_dir("du-phong-1").mkdir(parents=True, exist_ok=True)
    get_storage_path("du-phong-1").write_text("{}", encoding="utf-8")
    kiem("có phiên đăng nhập riêng của du-phong-1 thì biết đã đăng nhập; du-phong-2 vẫn chưa",
         DA_DANG_NHAP_THAT("du-phong-1") is True and DA_DANG_NHAP_THAT("du-phong-2") is False)
    goi_ket_noi = []
    from_storage_that = notebooklm.NotebookLMClient.from_storage
    notebooklm.NotebookLMClient.from_storage = classmethod(
        lambda cls, *a, **k: goi_ket_noi.append(k) or "khach")
    try:
        KET_NOI_THAT("du-phong-1")
        KET_NOI_THAT()
        KET_NOI_THAT("chinh")
    finally:
        notebooklm.NotebookLMClient.from_storage = from_storage_that
    kiem("kết nối tài khoản dự phòng dùng hồ sơ riêng của nó; tài khoản chính dùng hồ sơ mặc định như trước",
         goi_ket_noi == [{"profile": "du-phong-1"}, {}, {}], str(goi_ket_noi))
    get_profile_dir("default").mkdir(parents=True, exist_ok=True)
    (get_profile_dir("default") / "giu-lai.txt").write_text("x", encoding="utf-8")
    bbh.xoa_tai_khoan_phu("du-phong-1")
    kiem("xoá tài khoản dự phòng thì xoá luôn phiên đăng nhập của nó, không đụng hồ sơ khác",
         not get_profile_dir("du-phong-1").exists() and (get_profile_dir("default") / "giu-lai.txt").is_file()
         and [x["ma"] for x in bbh.cac_tai_khoan()] == ["chinh", "du-phong-2"])
except ImportError:
    print("  (bỏ qua các phép thử phiên đăng nhập thật vì máy chưa cài notebooklm-py)")
for x in bbh.cac_tai_khoan()[1:]:
    bbh.xoa_tai_khoan_phu(x["ma"])
bbh.them_tai_khoan_phu("Gmail phụ 1", "phu.mot@gmail.com")
bbh.them_tai_khoan_phu("Gmail phụ 2", "phu.hai@gmail.com")

# --- Đếm lượt riêng từng tài khoản ---
bbh.TEP_LUOT.unlink(missing_ok=True)
hom_nay_p = f"{datetime.now():%Y-%m-%d}"
bbh.tinh_mot_luot()
bbh.tinh_mot_luot()
bbh.tinh_mot_luot("du-phong-1")
kiem("mỗi tài khoản đếm lượt riêng: chính 2, dự phòng 1 là 1, dự phòng 2 chưa dùng",
     (da_dung(), da_dung("chinh"), da_dung("du-phong-1"), da_dung("du-phong-2")) == (2, 2, 1, 0))
kiem("chưa tài khoản nào bị Google báo hết lượt",
     not any(bbh.da_het_luot_hom_nay(x) for x in (None, "chinh", "du-phong-1", "du-phong-2")))
bbh.danh_dau_het_luot("du-phong-1")
kiem("Google báo hết lượt thì chỉ tài khoản đó bị đánh dấu, số lượt đã đếm không đổi",
     bbh.da_het_luot_hom_nay("du-phong-1") and not bbh.da_het_luot_hom_nay()
     and not bbh.da_het_luot_hom_nay("du-phong-2") and da_dung("du-phong-1") == 1)
bbh.danh_dau_het_luot("du-phong-1", het=False)
kiem("bỏ dấu hết lượt được (tài khoản hỏi lại được nghĩa là còn lượt)",
     not bbh.da_het_luot_hom_nay("du-phong-1") and da_dung("du-phong-1") == 1)
bbh.TEP_LUOT.write_text(bbh.json.dumps({"ngay": hom_nay_p, "da_dung": 7}), encoding="utf-8")
kiem("tệp đếm của bản cũ (chưa có phần tài khoản dự phòng) vẫn đọc được",
     da_dung() == 7 and da_dung("du-phong-1") == 0 and not bbh.da_het_luot_hom_nay())
bbh.TEP_LUOT.write_text(bbh.json.dumps({"ngay": "2026-01-01", "da_dung": 7, "tk": {"du-phong-1": 5},
                                       "het": ["chinh"]}), encoding="utf-8")
kiem("sang ngày mới thì đếm lại từ đầu, kể cả dấu hết lượt",
     da_dung() == 0 and da_dung("du-phong-1") == 0 and not bbh.da_het_luot_hom_nay())
bbh.TEP_LUOT.write_text(bbh.json.dumps({"ngay": hom_nay_p, "da_dung": 3, "tk": "sai", "het": 5}),
                        encoding="utf-8")
kiem("tệp đếm sai kiểu ở phần tài khoản thì bỏ phần đó, giữ số lượt tài khoản chính",
     da_dung() == 3 and da_dung("du-phong-1") == 0 and not bbh.da_het_luot_hom_nay())
bbh.TEP_LUOT.write_text("[1, 2", encoding="utf-8")
kiem("tệp đếm hỏng thì coi như chưa dùng lượt nào", da_dung() == 0)
bbh.TEP_LUOT.unlink()

kiem("địa chỉ mở sổ: tài khoản chính như cũ, tài khoản dự phòng thêm authuser (Gmail giữ dấu @)",
     bbh.dia_chi_so_nlm("abc") == "https://notebooklm.google.com/notebook/abc"
     and bbh.dia_chi_so_nlm("abc", "phu.mot@gmail.com")
     == "https://notebooklm.google.com/notebook/abc?authuser=phu.mot@gmail.com"
     and bbh.dia_chi_so_nlm("abc", "a+b&c=d@gmail.com").endswith("?authuser=a%2Bb%26c%3Dd@gmail.com")
     and bbh.dia_chi_so_nlm("abc", "") == "https://notebooklm.google.com/notebook/abc")
kiem("lệnh đăng nhập thật: tài khoản dự phòng có -p và mã hồ sơ đặt trước login; tài khoản chính không có -p",
     LENH_DANG_NHAP_THAT("du-phong-1")[2:6] == ["notebooklm", "-p", "du-phong-1", "login"]
     and "-p" not in LENH_DANG_NHAP_THAT() and "-p" not in LENH_DANG_NHAP_THAT("chinh")
     and LENH_DANG_NHAP_THAT("chinh") == LENH_DANG_NHAP_THAT())
src_p = (THU_MUC / "bien_ban_hop.py").read_text(encoding="utf-8")
noi_tk = [x.strip() for x in src_p.splitlines() if "ket_noi_nlm(" in x
          and not x.strip().startswith(("def ", "#", '"""')) and "ket_noi_nlm()" not in x]
kiem("mọi chỗ soạn biên bản cuối đều đi qua soan_nhieu_tai_khoan: dong_notebooklm chỉ được gọi từ chính nó",
     src_p.count("await dong_notebooklm(") == 1 and src_p.count("await soan_nhieu_tai_khoan(") == 2,
     f'{src_p.count("await dong_notebooklm(")} {src_p.count("await soan_nhieu_tai_khoan(")}')
kiem("chỉ ba chỗ nối bằng tài khoản dự phòng (soạn biên bản cuối, ghi chú trong sổ, kiểm tra kết nối); "
     "trợ lý trong buổi họp luôn dùng tài khoản chính",
     len(noi_tk) == 3 and any("ket_noi_nlm(ma_tk)" in x for x in noi_tk)
     and any('so.get("tai_khoan")' in x for x in noi_tk) and any("ket_noi_nlm(ma)" in x for x in noi_tk),
     str(noi_tk))

# --- Soạn biên bản cuối: hết lượt thì thử tài khoản kế ---
DA_DANG_NHAP[0] = True
DA_DANG_NHAP_TK.update({"du-phong-1": True, "du-phong-2": True})
mo_da_goi = []
MO_THAT = bbh.mo_bang_he_thong
bbh.mo_bang_he_thong = mo_da_goi.append

with TestClient(bbh.app, base_url=GOC, client=("127.0.0.1", 50000)) as c:
    # A. Còn lượt: chỉ dùng tài khoản chính
    gc, g1, g2 = dat_tk()
    gui(c)
    v = viec_cuoi()
    kiem("tài khoản chính còn lượt: soạn bằng tài khoản chính, không đụng tài khoản dự phòng, không báo thêm gì",
         v["trang_thai"] == "Xong" and ten_goi(gc) == ["tao", "them_tep", "cho", "chu", "hoi"]
         and not g1.goi and not g2.goi and KET_NOI_LOG == ["chinh"] and "tai_khoan" not in v["so_nlm"]
         and not v.get("canh_bao") and da_dung() == 1 and not bbh.da_het_luot_hom_nay(), str(ten_goi(gc)))
    ma_chinh = v["ma"]

    # B. Tài khoản chính hết lượt: tự thử tài khoản dự phòng thứ nhất
    gc, g1, g2 = dat_tk(chinh_het=True)
    so_nhat_ky = io.StringIO()
    with contextlib.redirect_stdout(so_nhat_ky):
        gui(c)
    v = viec_cuoi()
    so_moi = v["so_nlm"]
    kiem("tài khoản chính hết lượt hỏi: máy tự thử tài khoản dự phòng thứ nhất và soạn xong",
         v["trang_thai"] == "Xong" and "32 học viên" in (v["ket_qua"] or "")
         and ten_goi(gc).count("hoi") == 1 and ten_goi(g1) == ["tao", "them_chu", "hoi"]
         and not g2.goi and KET_NOI_LOG == ["chinh", "du-phong-1"],
         f"{ten_goi(gc)} {ten_goi(g1)} {KET_NOI_LOG}")
    kiem("dự phòng nhận bản chép lời đã có (không tải lại bản ghi) và bắt đầu sổ mới của chính nó",
         "them_tep" not in ten_goi(g1) and "tim" not in ten_goi(g1)
         and so_moi.get("id") == "so-du-phong-1-1" and so_moi.get("tai_khoan") == "du-phong-1"
         and so_moi.get("gmail") == "phu.mot@gmail.com", str(so_moi))
    kiem("biên bản báo rõ đã soạn bằng tài khoản dự phòng nào; nhật ký ghi cả lần chuyển lẫn lần soạn",
         'tài khoản dự phòng "Gmail phụ 1"' in (v.get("canh_bao") or "")
         and "soạn tại máy" not in v["canh_bao"] and "các đoạn tóm tắt" not in v["canh_bao"]
         and any("Tài khoản \"Tài khoản chính\" hết lượt hỏi hôm nay, thử tài khoản kế" in x[1]
                 for x in v["nhat_ky"])
         and any('Soạn biên bản bằng tài khoản dự phòng "Gmail phụ 1"' in x[1] for x in v["nhat_ky"]),
         str(v.get("canh_bao")))
    kiem("tài khoản dự phòng hỏi đúng câu lệnh mà tài khoản chính đã hỏi",
         bool(g1.cau) and g1.cau[0] == gc.cau[0])
    kiem("mỗi tài khoản đếm lượt riêng; chỉ tài khoản chính bị đánh dấu hết lượt",
         da_dung() == 1 and da_dung("du-phong-1") == 1 and da_dung("du-phong-2") == 0
         and bbh.da_het_luot_hom_nay() and not bbh.da_het_luot_hom_nay("du-phong-1"))
    kiem("tệp Word vẫn dựng từ biên bản của tài khoản dự phòng",
         bool(v.get("tep_word")) and (Path(v["thu_muc"]) / v["tep_word"]).is_file())
    ma_phu = v["ma"]
    kiem("màn Kết quả biết tên tài khoản giữ sổ; cuộc họp ở tài khoản chính thì không có",
         c.get(f"/may/viec/{ma_phu}").json()["ten_tai_khoan_so"] == "Gmail phụ 1"
         and c.get(f"/may/viec/{ma_chinh}").json()["ten_tai_khoan_so"] is None)
    mo_da_goi.clear()
    c.post(f"/may/viec/{ma_phu}/mo?cai=notebooklm", headers=NUT)
    c.post(f"/may/viec/{ma_chinh}/mo?cai=notebooklm", headers=NUT)
    kiem("Mở bản lưu trực tuyến mở đúng tài khoản: dự phòng thêm authuser, tài khoản chính như cũ",
         mo_da_goi == ["https://notebooklm.google.com/notebook/so-du-phong-1-1?authuser=phu.mot@gmail.com",
                       "https://notebooklm.google.com/notebook/so-chinh-1"], str(mo_da_goi))
    # Xoá tài khoản khỏi danh sách rồi mở: Gmail đã ghi cùng sổ nên vẫn mở đúng tài khoản
    ds_truoc = bbh.TEP_TAI_KHOAN.read_text(encoding="utf-8")
    bbh.TEP_TAI_KHOAN.write_text('{"phu": []}', encoding="utf-8")
    mo_da_goi.clear()
    c.post(f"/may/viec/{ma_phu}/mo?cai=notebooklm", headers=NUT)
    kiem("tài khoản đã bị xoá khỏi danh sách thì nút Mở bản lưu trực tuyến vẫn mở đúng tài khoản (Gmail ghi cùng sổ)",
         mo_da_goi == ["https://notebooklm.google.com/notebook/so-du-phong-1-1?authuser=phu.mot@gmail.com"]
         and c.get(f"/may/viec/{ma_phu}").json()["ten_tai_khoan_so"] == "Tài khoản dự phòng")
    bbh.TEP_TAI_KHOAN.write_text(ds_truoc, encoding="utf-8")

    # C. Cùng ngày, cuộc họp sau: tài khoản chính đã báo hết lượt thì bỏ qua luôn
    NLM[0] = gc = NlmTaiKhoan("chinh", het_luot=True)
    NLM_TK["du-phong-1"] = g1 = NlmTaiKhoan("du-phong-1")
    KET_NOI_LOG.clear()
    gui(c)
    v = viec_cuoi()
    kiem("tài khoản chính đã báo hết lượt hôm nay thì cuộc họp sau đi thẳng tài khoản dự phòng, không thử lại",
         v["trang_thai"] == "Xong" and not gc.goi and KET_NOI_LOG == ["du-phong-1"]
         and ten_goi(g1) == ["tao", "them_tep", "cho", "chu", "hoi"]
         and v["so_nlm"].get("tai_khoan") == "du-phong-1"
         and 'tài khoản dự phòng "Gmail phụ 1"' in (v.get("canh_bao") or ""), str(KET_NOI_LOG))

    # D. Cả ba tài khoản đều hết lượt
    gc, g1, g2 = dat_tk(chinh_het=True, p1_het=True, p2_het=True)
    with contextlib.redirect_stdout(so_nhat_ky):
        gui(c)
    v = viec_cuoi()
    kiem("cả ba tài khoản hết lượt: mỗi tài khoản chỉ bị hỏi một lần, báo rõ, biên bản soạn tại máy từ bản chép lời",
         v["trang_thai"] == "Xong" and all(ten_goi(x).count("hoi") == 1 for x in (gc, g1, g2))
         and "Đã thử 3 tài khoản, tất cả đều hết lượt hỏi hôm nay." in (v.get("canh_bao") or "")
         and "soạn tại máy từ bản chép lời đã có" in v["canh_bao"] and "32 học viên" in (v["ket_qua"] or "")
         and "chưa đăng nhập" not in v["canh_bao"], str(v.get("canh_bao"))[:200])
    kiem("cả ba đều bị đánh dấu hết lượt; nhật ký ghi hai lần thử tài khoản kế",
         all(bbh.da_het_luot_hom_nay(x) for x in ("chinh", "du-phong-1", "du-phong-2"))
         and sum("thử tài khoản kế" in x[1] for x in v["nhat_ky"]) == 2)

    # E. Mọi tài khoản đã bị đánh dấu hết lượt trong ngày mà nay hỏi lại được
    gc, g1, g2 = dat_tk()
    for ma_tk in ("chinh", "du-phong-1", "du-phong-2"):
        bbh.danh_dau_het_luot(ma_tk)
    gui(c)
    v = viec_cuoi()
    kiem("mọi tài khoản đều bị đánh dấu hết lượt trong ngày thì vẫn thử lại từ tài khoản chính "
         "(lượt của Google tính theo cửa sổ trượt); hỏi được thì bỏ dấu",
         v["trang_thai"] == "Xong" and "tai_khoan" not in v["so_nlm"] and not g1.goi and not g2.goi
         and KET_NOI_LOG == ["chinh"] and not bbh.da_het_luot_hom_nay()
         and bbh.da_het_luot_hom_nay("du-phong-1"), str(KET_NOI_LOG))

    # F. Tài khoản dự phòng thứ nhất chưa đăng nhập: bỏ qua
    gc, g1, g2 = dat_tk(chinh_het=True)
    DA_DANG_NHAP_TK["du-phong-1"] = False
    gui(c)
    v = viec_cuoi()
    DA_DANG_NHAP_TK["du-phong-1"] = True
    kiem("tài khoản dự phòng chưa đăng nhập thì bị bỏ qua, chuyển sang tài khoản kế",
         v["trang_thai"] == "Xong" and v["so_nlm"].get("tai_khoan") == "du-phong-2" and not g1.goi
         and "du-phong-1" not in KET_NOI_LOG and ten_goi(g2) == ["tao", "them_chu", "hoi"],
         str(KET_NOI_LOG))

    # F2. Cả hai tài khoản dự phòng đều chưa đăng nhập: hết lượt thì nhắc đăng nhập
    gc, g1, g2 = dat_tk(chinh_het=True)
    DA_DANG_NHAP_TK.update({"du-phong-1": False, "du-phong-2": False})
    with contextlib.redirect_stdout(so_nhat_ky):
        gui(c)
    v = viec_cuoi()
    DA_DANG_NHAP_TK.update({"du-phong-1": True, "du-phong-2": True})
    kiem("hết lượt mà các tài khoản dự phòng đều chưa đăng nhập: soạn tại máy, nhắc đăng nhập kèm tên từng tài khoản",
         v["trang_thai"] == "Xong" and not g1.goi and not g2.goi and KET_NOI_LOG == ["chinh"]
         and "chưa đăng nhập nên chưa dùng được: Gmail phụ 1, Gmail phụ 2" in (v.get("canh_bao") or "")
         and "Đã thử" not in v["canh_bao"], str(v.get("canh_bao"))[:200])

    # G. Lỗi khác hết lượt: không chuyển tài khoản
    gc, g1, g2 = dat_tk(hong={"hoi"})
    with contextlib.redirect_stdout(so_nhat_ky):
        gui(c)
    v = viec_cuoi()
    kiem("lỗi khác hết lượt (mạng, hỏng giữa chừng) thì KHÔNG chuyển tài khoản: báo như trước, soạn tại máy",
         v["trang_thai"] == "Xong" and not g1.goi and not g2.goi and KET_NOI_LOG == ["chinh"]
         and "soạn tại máy từ bản chép lời đã có" in (v.get("canh_bao") or "")
         and not any(bbh.da_het_luot_hom_nay(x) for x in ("chinh", "du-phong-1", "du-phong-2")),
         str(v.get("canh_bao"))[:150])

    # J. Sổ đổi sang tài khoản khác: ghi chú "Ghi chú trong buổi họp" tạo lại ở sổ mới
    vj = bbh.VIEC[ma_chinh]
    vj.setdefault("tro_ly", bbh.moi_tro_ly())  # cuộc họp tải tệp lên không có dữ liệu trợ lý
    vj["tro_ly"]["ghi_chu_so"] = "ghi-cu"
    vj["tro_ly"]["ghi_nhanh"] = [{"luc": 5, "chu": "Ghi nhanh thử"}]
    vj["tro_ly"]["doan"] = [{"tt": "xong"}]
    gc, g1, g2 = dat_tk(chinh_het=True)
    gc.so_cua_toi.add(vj["so_nlm"]["id"])
    with contextlib.redirect_stdout(so_nhat_ky):
        asyncio.run(bbh.soan_nhieu_tai_khoan(Path(vj["thu_muc"]) / vj["tep_ghi_am"], vj["tt"], vj))
    kiem("sổ đổi sang tài khoản dự phòng thì bỏ mã ghi chú cũ (nó nằm ở sổ cũ), để tạo lại ở sổ mới",
         vj["so_nlm"].get("tai_khoan") == "du-phong-1" and vj["tro_ly"]["ghi_chu_so"] is None
         and ten_goi(g1) == ["tao", "them_chu", "hoi"])
    kiem("có trợ lý trong buổi họp thì lời báo nói rõ các đoạn tóm tắt vẫn ở tài khoản trước",
         "các đoạn tóm tắt trong lúc họp vẫn nằm ở tài khoản trước" in (vj.get("canh_bao") or ""))
    KET_NOI_LOG.clear()
    asyncio.run(bbh.ghi_so_tay(vj))
    kiem("ghi chép trong buổi họp lưu vào sổ của đúng tài khoản đang giữ sổ, tạo ghi chú mới ở đó",
         KET_NOI_LOG == ["du-phong-1"] and ten_goi(g1)[-1] == "ghi_chu"
         and not any(x[0] in ("ghi_chu", "sua_ghi_chu") for x in gc.goi)
         and vj["tro_ly"]["ghi_chu_so"] == "ghi-du-phong-1", str(KET_NOI_LOG))
    asyncio.run(bbh.ghi_so_tay(vj))
    kiem("lần lưu kế: sửa ghi chú đã có ở sổ đó, không tạo thêm",
         ten_goi(g1)[-1] == "sua_ghi_chu" and ten_goi(g1).count("ghi_chu") == 1)
    vj["tro_ly"]["ghi_nhanh"], vj["tro_ly"]["doan"] = [], []

    # --- Lời gọi máy chủ ---
    for x in bbh.cac_tai_khoan()[1:]:
        bbh.xoa_tai_khoan_phu(x["ma"])
    DA_DANG_NHAP_TK.clear()
    n = c.get("/may/notebooklm").json()
    kiem("tình trạng: chưa thêm gì thì chỉ có tài khoản chính, tối đa 2 tài khoản dự phòng",
         [(x["ma"], x["phu"]) for x in n["tai_khoan"]] == [("chinh", False)] and n["toi_da_phu"] == 2
         and n["dang_mo_ma"] is None and "da_dang_nhap" in n, str(n)[:150])
    kiem("thêm tài khoản thiếu tiêu đề giao diện thì bị chặn",
         c.post("/may/notebooklm/tai-khoan", json={"ten": "A", "gmail": "a@gmail.com"}).status_code == 403)
    r1 = c.post("/may/notebooklm/tai-khoan", headers=NUT,
                json={"ten": "Gmail phụ 1", "gmail": "phu.mot@gmail.com"})
    kiem("thêm tài khoản dự phòng: được, trả mã và đưa vào danh sách",
         r1.status_code == 200 and r1.json()["tai_khoan"]["ma"] == "du-phong-1"
         and [x["ma"] for x in bbh.cac_tai_khoan()] == ["chinh", "du-phong-1"])
    r_sai = [c.post("/may/notebooklm/tai-khoan", headers=NUT, json=j) for j in (
        {"ten": "B", "gmail": "sai"}, {"ten": "", "gmail": "b@gmail.com"},
        {"ten": 5, "gmail": "b@gmail.com"}, ["x"], {"ten": "Trùng", "gmail": "PHU.MOT@gmail.com"})]
    kiem("thêm sai (tên trống, Gmail sai hoặc trùng, dữ liệu sai kiểu) đều bị từ chối, có lý do",
         all(x.status_code == 400 and x.json()["detail"] for x in r_sai) and len(bbh.cac_tai_khoan()) == 2,
         str([x.status_code for x in r_sai]))
    kiem("thêm mà không gửi dữ liệu: bị từ chối",
         c.post("/may/notebooklm/tai-khoan", headers=NUT).status_code == 400)
    c.post("/may/notebooklm/tai-khoan", headers=NUT, json={"ten": "Gmail phụ 2", "gmail": "phu.hai@gmail.com"})
    r3 = c.post("/may/notebooklm/tai-khoan", headers=NUT, json={"ten": "Ba", "gmail": "phu.ba@gmail.com"})
    kiem("thêm tài khoản thứ ba bị từ chối vì tối đa 2",
         r3.status_code == 400 and "tối đa 2" in r3.json()["detail"])
    DA_DANG_NHAP_TK.update({"du-phong-1": True, "du-phong-2": False})
    bbh.danh_dau_het_luot("du-phong-1")
    n = c.get("/may/notebooklm").json()
    kiem("tình trạng liệt kê tài khoản theo thứ tự thêm vào, kèm đã đăng nhập chưa và hết lượt chưa",
         [(x["ma"], x["ten"], x["gmail"], x["phu"], x["da_dang_nhap"], x["het_luot"]) for x in n["tai_khoan"]][1:]
         == [("du-phong-1", "Gmail phụ 1", "phu.mot@gmail.com", True, True, True),
             ("du-phong-2", "Gmail phụ 2", "phu.hai@gmail.com", True, False, False)], str(n["tai_khoan"]))
    bbh.danh_dau_het_luot("du-phong-1", het=False)

    # Đăng nhập từng tài khoản
    lenh_goi = []
    bbh.lenh_dang_nhap_nlm = lambda ma=None: (lenh_goi.append(ma), [
        sys.executable, "-c", "import time; time.sleep(1.2)"])[1]
    kiem("đăng nhập tài khoản không có trong danh sách: 404, không mở cửa sổ nào",
         c.post("/may/notebooklm/dang-nhap", headers=NUT, json={"ma": "du-phong-9"}).status_code == 404
         and not lenh_goi)
    kiem("đăng nhập tài khoản dự phòng: mở cửa sổ đăng nhập của đúng hồ sơ",
         c.post("/may/notebooklm/dang-nhap", headers=NUT, json={"ma": "du-phong-1"}).status_code == 200
         and lenh_goi == ["du-phong-1"])
    n = c.get("/may/notebooklm").json()
    kiem("đang mở cửa sổ đăng nhập của tài khoản dự phòng: tình trạng nói rõ tài khoản nào",
         n["dang_mo"] is True and n["dang_mo_ma"] == "du-phong-1")
    kiem("cửa sổ đăng nhập đang mở thì không mở cái thứ hai, dù cho tài khoản nào",
         c.post("/may/notebooklm/dang-nhap", headers=NUT).status_code == 409
         and c.post("/may/notebooklm/dang-nhap", headers=NUT, json={"ma": "du-phong-2"}).status_code == 409)
    d409 = c.delete("/may/notebooklm/tai-khoan/du-phong-1", headers=NUT)
    kiem("tài khoản đang mở cửa sổ đăng nhập thì chưa xoá được",
         d409.status_code == 409 and len(bbh.cac_tai_khoan()) == 3)
    cho_den(lambda: not c.get("/may/notebooklm").json()["dang_mo"])
    n = c.get("/may/notebooklm").json()
    kiem("đăng nhập xong thì hết chờ, không báo lỗi",
         n["dang_mo"] is False and n["dang_mo_ma"] is None and n["loi"] == "")
    bbh.lenh_dang_nhap_nlm = lambda ma=None: [sys.executable, "-c",
                                              "import sys; print('bi tu choi'); sys.exit(2)"]
    c.post("/may/notebooklm/dang-nhap", headers=NUT, json={"ma": "du-phong-1"})
    with contextlib.redirect_stdout(so_nhat_ky):
        cho_den(lambda: c.get("/may/notebooklm").json()["loi"] != "")
        n = c.get("/may/notebooklm").json()
    kiem("đăng nhập tài khoản dự phòng hỏng: lời báo nêu tên tài khoản và gắn đúng tài khoản",
         "Gmail phụ 1" in n["loi"] and "Đăng nhập chưa xong" in n["loi"] and n["loi_ma"] == "du-phong-1"
         and "bi tu choi" not in n["loi"], n["loi"])
    lenh_goi.clear()
    bbh.lenh_dang_nhap_nlm = lambda ma=None: (lenh_goi.append(ma), [
        sys.executable, "-c", "import time; time.sleep(1.2)"])[1]
    c.post("/may/notebooklm/dang-nhap", headers=NUT)
    kiem("bấm đăng nhập mà không nói tài khoản nào là tài khoản chính (như trước bản v1.3)",
         lenh_goi == ["chinh"] and c.get("/may/notebooklm").json()["dang_mo_ma"] == "chinh")
    cho_den(lambda: not c.get("/may/notebooklm").json()["dang_mo"])
    bbh.lenh_dang_nhap_nlm = LENH_DANG_NHAP_THAT

    # Kiểm tra kết nối từng tài khoản
    NLM[0] = NlmTaiKhoan("chinh")
    NLM_TK["du-phong-1"] = NlmTaiKhoan("du-phong-1")
    DA_DANG_NHAP_TK["du-phong-1"] = True
    KET_NOI_LOG.clear()
    k = c.post("/may/notebooklm/kiem-tra", headers=NUT, json={"ma": "du-phong-1"}).json()
    kiem("kiểm tra kết nối tài khoản dự phòng: nối đúng hồ sơ của nó", k == {"ok": True}
         and KET_NOI_LOG == ["du-phong-1"], str(k))
    KET_NOI_LOG.clear()
    k = c.post("/may/notebooklm/kiem-tra", headers=NUT).json()
    kiem("kiểm tra kết nối không nói tài khoản nào là tài khoản chính", k == {"ok": True}
         and KET_NOI_LOG == ["chinh"])
    k = c.post("/may/notebooklm/kiem-tra", headers=NUT, json={"ma": "du-phong-2"}).json()
    kiem("kiểm tra tài khoản dự phòng chưa đăng nhập: báo chưa đăng nhập",
         k["ok"] is False and "Chưa đăng nhập" in k["loi"])
    kiem("kiểm tra mã tài khoản lạ: 404",
         c.post("/may/notebooklm/kiem-tra", headers=NUT, json={"ma": "khac"}).status_code == 404)

    # Xoá tài khoản
    kiem("xoá tài khoản thiếu tiêu đề giao diện thì bị chặn",
         c.delete("/may/notebooklm/tai-khoan/du-phong-2").status_code == 403)
    kiem("xoá tài khoản chính hay mã lạ: 404",
         c.delete("/may/notebooklm/tai-khoan/chinh", headers=NUT).status_code == 404
         and c.delete("/may/notebooklm/tai-khoan/khong-co", headers=NUT).status_code == 404)
    kiem("xoá tài khoản dự phòng: được, danh sách ngắn lại",
         c.delete("/may/notebooklm/tai-khoan/du-phong-2", headers=NUT).status_code == 200
         and [x["ma"] for x in bbh.cac_tai_khoan()] == ["chinh", "du-phong-1"])

    # H. Không thêm tài khoản dự phòng nào: giống hệt trước bản v1.3
    bbh.xoa_tai_khoan_phu("du-phong-1")
    gc, g1, g2 = dat_tk(chinh_het=True)
    with contextlib.redirect_stdout(so_nhat_ky):
        gui(c)
    v = viec_cuoi()
    kiem("chưa thêm tài khoản dự phòng: hết lượt thì soạn tại máy như trước, không thêm lời báo nào về tài khoản",
         v["trang_thai"] == "Xong" and KET_NOI_LOG == ["chinh"] and not g1.goi and not g2.goi
         and "Đã thử" not in (v.get("canh_bao") or "") and "dự phòng" not in (v.get("canh_bao") or "")
         and "soạn tại máy từ bản chép lời đã có" in v["canh_bao"], str(v.get("canh_bao"))[:150])

bbh.mo_bang_he_thong = MO_THAT
bbh.lenh_dang_nhap_nlm = LENH_DANG_NHAP_THAT
NLM_TK.clear()
DA_DANG_NHAP_TK.clear()
DA_DANG_NHAP[0] = True
NLM[0] = NlmGia()
bbh.TEP_TAI_KHOAN.unlink(missing_ok=True)
bbh.TEP_LUOT.unlink(missing_ok=True)

giao_dien_p = (THU_MUC / "giao_dien.html").read_text(encoding="utf-8")
kiem("giao diện Cài đặt: khối tài khoản dự phòng có danh sách, ô thêm, ba nút theo từng tài khoản, gọi đúng lời gọi",
     all(x in giao_dien_p for x in (
         'id="tk-ds"', 'id="tk-form"', 'id="tk-ten"', 'id="tk-gmail"', '"/may/notebooklm/tai-khoan"',
         '"/may/notebooklm/tai-khoan/" + encodeURIComponent(d.tkXoa), "DELETE"',
         '{ma: d.tkDn}', '{ma: d.tkKt}', 'data-tk-dn', 'data-tk-kt', 'data-tk-xoa',
         'if (!await hoi("Xoá tài khoản dự phòng?"', '$("tk-form").hidden = phu.length >= toiDa;',
         "    veTaiKhoan(n);\n", "chinh.het_luot ? \" Hết lượt hỏi hôm nay.\" : \"\"")))
kiem("giao diện: nút Mở bản lưu trực tuyến ghi tên tài khoản khi sổ nằm ở tài khoản dự phòng",
     'v.ten_tai_khoan_so ? " (" + h(v.ten_tai_khoan_so) + ")" : ""' in giao_dien_p)
kiem("giao diện: tên và Gmail của tài khoản đi qua h() trước khi chèn vào trang",
     '<div class="tk-ten">${h(x.ten)}</div><div class="nho">${h(x.gmail)}</div>' in giao_dien_p
     and 'data-tk-ten="${h(x.ten)}"' in giao_dien_p)
tep_gi = THU_MUC / ".gitignore"  # bản đã cài trên máy người dùng không có tệp này: coi như đạt
kiem("tệp danh sách tài khoản (có Gmail) nằm trong .gitignore để không lên kho",
     not tep_gi.is_file() or "tai-khoan-google.json" in tep_gi.read_text(encoding="utf-8").splitlines())

# ----------------------------------------------------------------------------
print("\nQ. Cài nhanh (v1.4): kiểm nhanh, tải trình duyệt khi cần, kiểm tra toàn bộ, gói đầy đủ")
# ----------------------------------------------------------------------------
import shutil  # noqa: E402
import subprocess  # noqa: E402


def q_kiem_nhanh(gia_loi: str = "", han: int = 180, them_env: dict | None = None):
    """Chạy tu_kiem_nhanh.py trong tiến trình riêng, như trình cài chạy nó."""
    env = {**os.environ, "BBH_KIEM_NHANH_GIA_LOI": gia_loi, "PYTHONUTF8": "1", **(them_env or {})}
    bat_dau = time.monotonic()
    ra = subprocess.run([sys.executable, "-X", "utf8", str(THU_MUC / "tu_kiem_nhanh.py")],
                        capture_output=True, text=True, encoding="utf-8", errors="replace",
                        env=env, cwd=str(THU_MUC), timeout=han)
    return ra.returncode, ra.stdout, time.monotonic() - bat_dau


def q_ghi(chu: str, n: int = 240) -> str:
    """Chữ của bộ kiểm chạy thử, đưa vào ghi chú: đổi [TRUOT] và [DAT ] để dòng ghi chú không lẫn với phép trượt
    của chính bộ kiểm này (luồng thử và bộ cài lỗi cố ý đọc các dòng đó)."""
    return chu[-n:].replace("[TRUOT]", "(trượt)").replace("[DAT ]", "(đạt)")


def q_so_phep(chu: str):
    m = re.findall(r"^(\d+)/(\d+) phép đạt$", chu, re.MULTILINE)
    return (int(m[-1][0]), int(m[-1][1])) if m else None


# --- Kiểm nhanh ---
q_ma, q_chu, q_giay = q_kiem_nhanh()
q_kq = q_so_phep(q_chu)
kiem("kiểm nhanh chạy trên máy này như trình cài chạy nó: đạt hết, từ 15 phép trở lên, xong dưới 90 giây",
     q_ma == 0 and q_kq is not None and q_kq[0] == q_kq[1] >= 15 and q_giay < 90,
     f"{q_kq} {q_giay:.0f} giây {q_chu[-200:] if q_ma else ''}")
# Luồng GitHub thử cài khi chặn mạng bằng proxy hỏng: kiểm nhanh gọi máy chủ ngay trên máy này, không được đi qua proxy
q_proxy = {k: "http://127.0.0.1:9" for k in ("HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "http_proxy", "https_proxy", "all_proxy")}
q_ma_p, q_chu_p, _ = q_kiem_nhanh(them_env={**q_proxy, "NO_PROXY": "", "no_proxy": ""})
kiem("kiểm nhanh vẫn đạt khi máy đặt proxy hỏng (luồng thử chặn mạng): gọi máy chủ trên máy này không đi qua proxy",
     q_ma_p == 0 and q_so_phep(q_chu_p) is not None and q_so_phep(q_chu_p)[0] == q_so_phep(q_chu_p)[1], q_chu_p[-200:])
for q_loi, q_nhan in (("ffmpeg", "ffmpeg chạy được"), ("may-chu", "máy chủ bật được"),
                      ("word", "dựng được tệp Word"), ("ma", "mã ứng dụng nạp được"),
                      ("thu-muc", "thư mục lưu các cuộc họp ghi được"),
                      ("nap-segno", "thành phần segno nạp được")):
    q_ma2, q_chu2, _ = q_kiem_nhanh(q_loi)
    q_kq2 = q_so_phep(q_chu2)
    kiem(f"kiểm nhanh bắt được lỗi cố ý ({q_loi}): thoát mã 1, ghi rõ phép trượt, ít phép đạt hơn",
         q_ma2 == 1 and "TRƯỢT:" in q_chu2 and q_kq2 is not None and q_kq2[0] < q_kq2[1]
         and any(d.lstrip().startswith("[TRUOT]") and q_nhan in d for d in q_chu2.splitlines()),
         q_ghi(q_chu2))

# --- Tải trình duyệt khi cần (Mac chưa có Chrome) ---
q_that = (bbh.LA_MAC, bbh.co_chrome, bbh.co_chromium_cua_thu_vien, bbh.LA_WINDOWS)
q_chromium_that = bbh.co_chromium_cua_thu_vien
q_lenh_mo_that = bbh.lenh_mo_dang_nhap


def q_dat_may(mac: bool, chrome: bool, chromium: bool) -> None:
    # LA_WINDOWS luôn ép về False: trên máy Windows thật nó là True và lệnh đăng nhập khi đó luôn dùng Edge
    # (luồng GitHub Windows lượt đầu trượt hai phép ở đây vì quên điều này)
    bbh.LA_MAC, bbh.co_chrome, bbh.co_chromium_cua_thu_vien = mac, (lambda: chrome), (lambda: chromium)
    bbh.LA_WINDOWS = False


q_bang = {(True, False, False): True, (True, True, False): False, (True, False, True): False,
          (True, True, True): False, (False, False, False): False}
q_ket = {}
for q_khoa in q_bang:
    q_dat_may(*q_khoa)
    q_ket[q_khoa] = bbh.can_tai_trinh_duyet()
kiem("chỉ máy Mac chưa có Chrome và chưa có trình duyệt riêng của thư viện mới phải tải trình duyệt; "
     "Windows (Edge có sẵn) không bao giờ", q_ket == q_bang, str(q_ket))
q_pw = TAM / "pw-cache"
(q_pw / "chromium-1234").mkdir(parents=True)
(q_pw / "chromium_headless_shell-1234").mkdir()
q_moi_truong = os.environ.get("PLAYWRIGHT_BROWSERS_PATH")
os.environ["PLAYWRIGHT_BROWSERS_PATH"] = str(q_pw)
q_chua_xong = q_chromium_that()
(q_pw / "chromium-1234" / "INSTALLATION_COMPLETE").write_text("", encoding="utf-8")
q_xong = q_chromium_that()
if q_moi_truong is None:
    os.environ.pop("PLAYWRIGHT_BROWSERS_PATH")
else:
    os.environ["PLAYWRIGHT_BROWSERS_PATH"] = q_moi_truong
kiem("trình duyệt riêng của thư viện chỉ tính là đã có khi tải xong (có tệp INSTALLATION_COMPLETE)",
     q_chua_xong is False and q_xong is True)
q_dat_may(True, False, False)
q_lenh, q_tai = bbh.lenh_mo_dang_nhap("du-phong-1")
kiem("Mac chưa có Chrome: lệnh đăng nhập được bọc trong đoạn mã tải trình duyệt chạy bằng chính Python này, "
     "lệnh đăng nhập (kể cả tài khoản dự phòng) đi sau",
     q_tai is True and q_lenh[:4] == [sys.executable, "-X", "utf8", "-c"]
     and q_lenh[4] == bbh.MA_TAI_TRINH_DUYET and q_lenh[5:] == bbh.lenh_dang_nhap_nlm("du-phong-1")
     and "--browser" not in q_lenh[5:] and "-p" in q_lenh[5:], str(q_lenh[5:]))
q_dat_may(True, True, False)
q_lenh2, q_tai2 = bbh.lenh_mo_dang_nhap()
kiem("máy có Chrome: lệnh đăng nhập chạy thẳng dùng Chrome, không tải gì",
     q_tai2 is False and q_lenh2 == bbh.lenh_dang_nhap_nlm() and q_lenh2[-2:] == ["--browser", "chrome"],
     str(q_lenh2))
q_dat_may(False, False, False)
kiem("không phải Mac: lệnh đăng nhập chạy thẳng, không bao giờ bọc đoạn mã tải",
     bbh.lenh_mo_dang_nhap()[1] is False)
bbh.LA_MAC, bbh.co_chrome, bbh.co_chromium_cua_thu_vien, bbh.LA_WINDOWS = q_that
if os.name != "nt":
    q_gia = TAM / "gia-playwright"
    (q_gia / "playwright").mkdir(parents=True)
    (q_gia / "playwright" / "__init__.py").write_text("", encoding="utf-8")
    (q_gia / "playwright" / "__main__.py").write_text(
        "import os, sys, time\nprint('gia-cai', sys.argv[1:], flush=True)\n"
        "time.sleep(float(os.environ.get('GIA_PW_NGU', '0')))\n"
        "sys.exit(int(os.environ.get('GIA_PW_MA', '0')))\n", encoding="utf-8")

    def q_chay_doan_ma(ma_thoat: int, ngu: float = 0, doan_ma: str | None = None):
        env = {**os.environ, "PYTHONPATH": str(q_gia), "GIA_PW_MA": str(ma_thoat), "GIA_PW_NGU": str(ngu)}
        return subprocess.run([sys.executable, "-X", "utf8", "-c", doan_ma or bbh.MA_TAI_TRINH_DUYET,
                               sys.executable, "-c", "print('DA-MO-DANG-NHAP')"],
                              capture_output=True, text=True, encoding="utf-8", env=env, timeout=60)
    q_r0 = q_chay_doan_ma(0)
    kiem("đoạn mã tải trình duyệt: tải xong thì ghi dấu bắt đầu, dấu xong (mã 0), rồi chạy lệnh đăng nhập ngay "
         "trong cùng tiến trình",
         q_r0.returncode == 0 and "gia-cai ['install', 'chromium']" in q_r0.stdout
         and q_r0.stdout.index(bbh.DAU_TAI_TRINH_DUYET) < q_r0.stdout.index(bbh.DAU_XONG_TAI_TRINH_DUYET + " ma=0")
         < q_r0.stdout.index("DA-MO-DANG-NHAP"), q_r0.stdout[-200:] + q_r0.stderr[-200:])
    q_r7 = q_chay_doan_ma(7)
    kiem("tải trình duyệt hỏng (mã 7): ghi mã đó, vẫn chạy lệnh đăng nhập để báo lỗi rõ",
         f"{bbh.DAU_XONG_TAI_TRINH_DUYET} ma=7" in q_r7.stdout and "DA-MO-DANG-NHAP" in q_r7.stdout,
         q_r7.stdout[-200:])
    q_rh = q_chay_doan_ma(0, ngu=8, doan_ma=bbh.MA_TAI_TRINH_DUYET.replace(
        f"timeout={bbh.HAN_TAI_TRINH_DUYET_GIAY}", "timeout=1"))
    kiem("tải trình duyệt quá hạn thì thôi tải (mã -2), không đứng chờ mãi, rồi chạy lệnh đăng nhập",
         f"{bbh.DAU_XONG_TAI_TRINH_DUYET} ma=-2" in q_rh.stdout and "DA-MO-DANG-NHAP" in q_rh.stdout,
         q_rh.stdout[-200:])
else:
    print("  (Windows: bỏ qua ba phép chạy đoạn mã tải trình duyệt, chỉ Mac dùng đoạn mã đó)")
kiem("đoạn mã tải trình duyệt thay chính nó bằng lệnh đăng nhập (execv), để việc tắt cửa sổ đăng nhập "
     "tắt đúng tiến trình", "os.execv(sys.argv[1], sys.argv[1:])" in bbh.MA_TAI_TRINH_DUYET)

with TestClient(bbh.app, base_url=GOC, client=("127.0.0.1", 50000)) as c:
    def q_doi_het_dang_nhap():
        het = time.monotonic() + 15
        while bbh.DANG_NHAP_NLM["tien_trinh"].poll() is None and time.monotonic() < het:
            time.sleep(0.1)

    q_ma_giai_doan = ("import time\nprint('BBH-TAI-TRINH-DUYET', flush=True)\ntime.sleep(1.6)\n"
                      "print('BBH-XONG-TAI-TRINH-DUYET ma=0', flush=True)\ntime.sleep(2.5)\n")
    bbh.lenh_mo_dang_nhap = lambda ma=None: ([sys.executable, "-c", q_ma_giai_doan], True)
    c.post("/may/notebooklm/dang-nhap", headers=NUT)
    time.sleep(0.6)
    q_n1 = c.get("/may/notebooklm").json()
    time.sleep(1.6)
    q_n2 = c.get("/may/notebooklm").json()
    kiem("đang tải trình duyệt thì tình trạng báo tai_trinh_duyet; tải xong thì hết báo, cửa sổ đăng nhập vẫn mở",
         q_n1["dang_mo"] is True and q_n1["tai_trinh_duyet"] is True
         and q_n2["dang_mo"] is True and q_n2["tai_trinh_duyet"] is False, f"{q_n1} {q_n2}")
    q_doi_het_dang_nhap()
    q_that_han = bbh.HAN_DANG_NHAP_GIAY
    bbh.HAN_DANG_NHAP_GIAY = 0.5
    bbh.lenh_mo_dang_nhap = lambda ma=None: ([sys.executable, "-c", "import time; time.sleep(8)"], True)
    c.post("/may/notebooklm/dang-nhap", headers=NUT)
    time.sleep(1.2)
    q_n3 = c.get("/may/notebooklm").json()
    kiem("lần đăng nhập có tải trình duyệt được cộng thêm hạn tải: quá hạn đăng nhập thường (0,5 giây) vẫn chưa bị đóng",
         q_n3["dang_mo"] is True and q_n3["loi"] == "", str(q_n3))
    bbh.DANG_NHAP_NLM["tien_trinh"].kill()
    q_doi_het_dang_nhap()
    bbh.lenh_mo_dang_nhap = lambda ma=None: ([sys.executable, "-c", "import time; time.sleep(8)"], False)
    c.post("/may/notebooklm/dang-nhap", headers=NUT)
    time.sleep(1.2)
    q_n4 = c.get("/may/notebooklm").json()
    kiem("lần đăng nhập không tải trình duyệt vẫn đóng đúng hạn như trước",
         q_n4["dang_mo"] is False and "đã đóng cửa sổ đăng nhập" in q_n4["loi"], str(q_n4))
    bbh.HAN_DANG_NHAP_GIAY = q_that_han
    q_ma_hong = ("print('BBH-TAI-TRINH-DUYET', flush=True)\n"
                 "print('BBH-XONG-TAI-TRINH-DUYET ma=7', flush=True)\nimport sys\nsys.exit(1)\n")
    bbh.lenh_mo_dang_nhap = lambda ma=None: ([sys.executable, "-c", q_ma_hong], True)
    c.post("/may/notebooklm/dang-nhap", headers=NUT)
    q_doi_het_dang_nhap()
    with contextlib.redirect_stdout(io.StringIO()):
        q_n5 = c.get("/may/notebooklm").json()
    kiem("tải trình duyệt hỏng rồi đăng nhập hỏng: báo chưa tải được trình duyệt, nhắc kiểm tra mạng hoặc cài Chrome, "
         "không đổ lỗi cho việc đăng nhập",
         "Chưa tải được trình duyệt" in q_n5["loi"] and "Google Chrome" in q_n5["loi"]
         and "Đăng nhập chưa xong" not in q_n5["loi"], q_n5["loi"])
    bbh.lenh_mo_dang_nhap = q_lenh_mo_that
    bbh.DANG_NHAP_NLM.update(tai=False)

# --- Kiểm tra toàn bộ ở thẻ Cài đặt ---
q_that_kd = (bbh.lenh_kiem_day_du, bbh.TEP_KIEM_DAY_DU, bbh.HAN_KIEM_DAY_DU_GIAY, bbh.dang_ban)
bbh.TEP_KIEM_DAY_DU = TAM / "kiem-day-du.txt"
# Các mục trước để lại cuộc họp còn dở trong VIEC: không cho chúng làm nút này trả 409
bbh.dang_ban = lambda: False
with TestClient(bbh.app, base_url=GOC, client=("127.0.0.1", 50000)) as c:
    def q_kiem_day_du(doan_ma: str):
        bbh.KIEM_DAY_DU.update(tien_trinh=None, ket_qua=None)
        bbh.lenh_kiem_day_du = lambda: [sys.executable, "-X", "utf8", "-c", doan_ma]
        dap = c.post("/may/kiem-tra-day-du", headers=NUT)
        het = time.monotonic() + 20
        k = c.get("/may/kiem-tra-day-du").json()
        while k["dang_chay"] and time.monotonic() < het:
            time.sleep(0.1)
            k = c.get("/may/kiem-tra-day-du").json()
        return dap, k

    q_dap, q_k = q_kiem_day_du("print('  [DAT ] mot')\nprint('\\n3/3 phép đạt')")
    kiem("nút Kiểm tra toàn bộ: chạy bộ kiểm trong tiến trình riêng, đọc dòng N/M phép đạt, báo đạt",
         q_dap.status_code == 200 and q_k["dang_chay"] is False and q_k["co_kiem_thu"] is True
         and q_k["ket_qua"] == {"dat": True, "chu": "Đạt 3/3 phép kiểm."}, str(q_k))
    q_dap, q_k = q_kiem_day_du("import sys\nprint('\\n2/3 phép đạt')\nprint('TRƯỢT: phép xyz')\nsys.exit(1)")
    kiem("bộ kiểm đầy đủ trượt: báo đạt 2/3, nêu phép chưa đạt, nhắc gửi người phụ trách kỹ thuật",
         q_k["ket_qua"]["dat"] is False and "Đạt 2/3" in q_k["ket_qua"]["chu"]
         and "Chưa đạt: phép xyz" in q_k["ket_qua"]["chu"] and "người phụ trách kỹ thuật" in q_k["ket_qua"]["chu"],
         str(q_k))
    q_dap, q_k = q_kiem_day_du("print('khong co dong ket qua')")
    kiem("bộ kiểm đầy đủ không in dòng kết quả: báo chưa đọc được, không báo đạt",
         q_k["ket_qua"]["dat"] is False and "Chưa đọc được kết quả" in q_k["ket_qua"]["chu"], str(q_k))
    q_dap, q_k = q_kiem_day_du("import sys\nprint('\\n3/3 phép đạt')\nsys.exit(1)")
    kiem("dòng 3/3 nhưng tiến trình thoát mã 1: không báo đạt",
         q_k["ket_qua"]["dat"] is False, str(q_k))
    bbh.dang_ban = lambda: True
    kiem("đang ghi âm hay soạn biên bản thì không cho chạy bộ kiểm đầy đủ (409)",
         c.post("/may/kiem-tra-day-du", headers=NUT).status_code == 409)
    bbh.dang_ban = lambda: False
    kiem("nút Kiểm tra toàn bộ thiếu tiêu đề giao diện thì bị chặn",
         c.post("/may/kiem-tra-day-du").status_code == 403)
    with TestClient(bbh.app, base_url=GOC, client=("192.168.1.20", 50000)) as la:
        kiem("máy lạ trong wifi không chạy được bộ kiểm cũng không xem được kết quả",
             la.post("/may/kiem-tra-day-du", headers=NUT).status_code == 403
             and la.get("/may/kiem-tra-day-du").status_code == 403)
    bbh.KIEM_DAY_DU.update(tien_trinh=None, ket_qua=None)
    bbh.lenh_kiem_day_du = lambda: [sys.executable, "-c", "import time; time.sleep(30)"]
    c.post("/may/kiem-tra-day-du", headers=NUT)
    kiem("đang kiểm tra thì bấm lần nữa bị từ chối (409), không chạy hai bộ kiểm một lúc",
         c.post("/may/kiem-tra-day-du", headers=NUT).status_code == 409
         and c.get("/may/kiem-tra-day-du").json()["dang_chay"] is True)
    bbh.don_dep()
    q_het = time.monotonic() + 5
    while bbh.KIEM_DAY_DU["tien_trinh"].poll() is None and time.monotonic() < q_het:
        time.sleep(0.1)
    kiem("tắt ứng dụng (don_dep) thì tắt luôn bộ kiểm đang chạy", bbh.KIEM_DAY_DU["tien_trinh"].poll() is not None)
    bbh.HAN_KIEM_DAY_DU_GIAY = 0.3
    bbh.KIEM_DAY_DU.update(tien_trinh=None, ket_qua=None)
    c.post("/may/kiem-tra-day-du", headers=NUT)
    time.sleep(0.8)
    q_k = c.get("/may/kiem-tra-day-du").json()
    kiem("bộ kiểm chạy quá hạn (đồng hồ phía mình) thì bị tắt và báo rõ",
         q_k["dang_chay"] is False and "Quá 30 phút" in q_k["ket_qua"]["chu"]
         and bbh.KIEM_DAY_DU["tien_trinh"].poll() is not None, str(q_k))
(bbh.lenh_kiem_day_du, bbh.TEP_KIEM_DAY_DU, bbh.HAN_KIEM_DAY_DU_GIAY, bbh.dang_ban) = q_that_kd
bbh.KIEM_DAY_DU.update(tien_trinh=None, ket_qua=None)

giao_dien_q = (THU_MUC / "giao_dien.html").read_text(encoding="utf-8")
kiem("giao diện Cài đặt: khối Kiểm tra toàn bộ có nút, gọi đúng lời gọi và theo dõi tới khi xong; báo tải trình duyệt lần đầu",
     all(x in giao_dien_q for x in (
         'id="khung-kiem-day-du"', 'id="nut-kiem-day-du"', 'id="kiem-day-du-kq"',
         'lay("/may/kiem-tra-day-du")', 'goi("/may/kiem-tra-day-du")', "  napKiemDayDu();\n"))
     and giao_dien_q.count("n.tai_trinh_duyet ? TAI_TRINH_DUYET") == 2)

# --- Trình cài và gói (chỉ có trong kho mã) ---
if (THU_MUC / "dong_goi.py").is_file():
    import dong_goi
    import lzma
    import tarfile
    q_mac, q_win = dong_goi.cac_tep_goi(windows=False), dong_goi.cac_tep_goi(windows=True)
    kiem("gói nhỏ Mac và Windows đều mang tu_kiem_nhanh.py; gói Windows mang danh sách gói ghim bản, còn tệp "
         "chỉ để dựng (python-windows.env, yeu-cau.in) không vào gói",
         "tu_kiem_nhanh.py" in q_mac and "tu_kiem_nhanh.py" in q_win and "yeu-cau-windows.txt" in q_win
         and "yeu-cau-windows.txt" not in q_mac and "python-windows.env" not in q_win
         and "yeu-cau.in" not in q_win and "yeu-cau.in" not in q_mac)
    kiem("danh sách tệp tính dấu mã giữ NGUYÊN 9 tệp của bản v1.3 (thêm tệp thì máy chạy bản cũ tính dấu mã "
         "của gói mới khác ban-moi.json và nút Cập nhật báo tệp tải về sai bản); tu_kiem_nhanh.py không nằm đó",
         bbh.TEP_PHIEN_BAN == ("bien_ban_hop.py", "ghi_am.py", "tao_word.py", "giao_dien.html",
                               "xem_dien_thoai.html", "kiem_thu.py", "ung_dung.py", "tao_ung_dung.py",
                               "kich_hoat.py"), str(bbh.TEP_PHIEN_BAN))
    q_tc = THU_MUC / "trinh_cai"
    q_env_mac = dong_goi.doc_env(q_tc / "python-mac.env")
    q_env_win = dong_goi.doc_env(q_tc / "python-windows.env")
    q_nhan = q_env_win.get("PY_GOC", "").rsplit("/", 1)[-1]
    kiem("python-windows.env: cùng bản phát hành và cùng nhánh Python với python-mac.env, tệp Windows, có mã sha256",
         q_env_win.get("PY_GOC") == q_env_mac.get("PY_GOC") and q_env_win.get("PY_NHANH") == q_env_mac.get("PY_NHANH")
         and re.fullmatch(rf"cpython-{re.escape(q_env_win.get('PY_NHANH', '?'))}\.\d+\+{q_nhan}-x86_64-pc-windows-msvc"
                          r"-install_only\.tar\.gz", q_env_win.get("PY_TEP", ""))
         and re.fullmatch(r"[0-9a-f]{64}", q_env_win.get("PY_MA", "")), str(q_env_win))

    def q_ghim(ten: str) -> dict:
        return dict(d.split("==", 1) for d in (q_tc / ten).read_text(encoding="utf-8").splitlines()
                    if d and not d.startswith("#"))
    q_gm, q_gw = q_ghim("yeu-cau-mac.txt"), q_ghim("yeu-cau-windows.txt")
    q_can = {"fastapi", "uvicorn", "python-multipart", "httpx", "python-docx", "pywebview", "notebooklm-py",
             "segno", "imageio-ffmpeg", "playwright"}
    kiem("yeu-cau-windows.txt: ghim đúng một bản mỗi gói, đủ các gói ứng dụng cần (có imageio-ffmpeg mang ffmpeg, "
         "pythonnet cho cửa sổ riêng), không có gói của Mac, và các gói chung cùng bản với yeu-cau-mac.txt",
         q_can <= set(q_gw) and {"pythonnet", "clr-loader"} <= set(q_gw)
         and not [g for g in q_gw if g.startswith("pyobjc")]
         and all(q_gw[g] == q_gm[g] for g in set(q_gw) & set(q_gm)), str(sorted(set(q_gw) ^ set(q_gm)))[:200])
    q_in = (q_tc / "yeu-cau.in").read_text(encoding="utf-8")
    kiem("yeu-cau.in (danh sách gốc dựng hai tệp ghim) liệt kê đủ các gói ứng dụng, và cả tu_kiem_nhanh.py biết các gói đó",
         all(g in q_in for g in ("fastapi", "uvicorn", "python-multipart", "httpx", "python-docx", "pywebview",
                                 "notebooklm-py[browser]>=0.8.3", "segno", "imageio-ffmpeg"))
         and all(f'"{g}"' in (THU_MUC / "tu_kiem_nhanh.py").read_text(encoding="utf-8")
                 for g in ("fastapi", "uvicorn", "httpx", "python-docx", "python-multipart", "notebooklm-py",
                           "playwright", "segno", "imageio-ffmpeg")))

    # Nén và giải nén phần thành phần: cùng cách trình cài Mac giải nén (tarfile của Python vừa giải ra)
    q_cay = TAM / "cay-thu"
    (q_cay / "goi" / "bin").mkdir(parents=True)
    (q_cay / "goi" / "vac").mkdir()
    (q_cay / "goi" / "chay.sh").write_text("#!/bin/sh\n", encoding="utf-8")
    (q_cay / "goi" / "chay.sh").chmod(0o755)
    (q_cay / "goi" / "du-lieu.txt").write_text("nội dung có dấu", encoding="utf-8")
    (q_cay / "goi" / "du-lieu.txt").chmod(0o664)
    q_ten_dai = "x" * 130 + ".txt"
    (q_cay / "goi" / q_ten_dai).write_text("dài", encoding="utf-8")
    if os.name != "nt":
        os.symlink("du-lieu.txt", q_cay / "goi" / "lien-ket")
    q_xz1, q_xz2 = TAM / "cay-1.tar.xz", TAM / "cay-2.tar.xz"
    dong_goi.tao_tar_xz(q_cay / "goi", q_xz1)
    time.sleep(1.1)  # khác giờ dựng, để chắc tệp không mang giờ của máy
    for q_t in (q_cay / "goi").rglob("*"):
        os.utime(q_t, (time.time(), time.time()))
    dong_goi.tao_tar_xz(q_cay / "goi", q_xz2)
    q_giai = TAM / "cay-giai"
    with tarfile.open(q_xz1, "r:xz") as q_tar:
        q_tar.extractall(q_giai, filter="tar")
    kiem("nén phần thành phần: dựng hai lần ra cùng một tệp (không mang giờ hay tên máy dựng)",
         hashlib.sha256(q_xz1.read_bytes()).hexdigest() == hashlib.sha256(q_xz2.read_bytes()).hexdigest())
    q_ok_tar = ((q_giai / "du-lieu.txt").read_text(encoding="utf-8") == "nội dung có dấu"
                and (q_giai / q_ten_dai).read_text(encoding="utf-8") == "dài" and (q_giai / "vac").is_dir()
                and (q_giai / "bin").is_dir())
    if os.name != "nt":
        q_ok_tar = (q_ok_tar and (q_giai / "chay.sh").stat().st_mode & 0o777 == 0o755
                    and (q_giai / "du-lieu.txt").stat().st_mode & 0o777 == 0o644
                    and os.readlink(q_giai / "lien-ket") == "du-lieu.txt")
    kiem("giải nén bằng tarfile (filter=tar) như trình cài Mac: đủ tệp, tên dài, thư mục rỗng, giữ quyền chạy "
         "(0755) và liên kết; tệp thường về 0644", q_ok_tar)

    # Gọn Python cho Windows
    q_py = TAM / "py-win"
    for q_p in ("python.exe", "python312.pdb", "DLLs/_tkinter.pyd", "DLLs/tcl86t.dll", "DLLs/_testcapi.pyd",
                "DLLs/_ssl.pyd", "DLLs/_ssl.pdb", "tcl/tcl8.6/init.tcl", "include/Python.h", "libs/python312.lib",
                "Lib/test/test_x.py", "Lib/idlelib/a.py", "Lib/tkinter/__init__.py", "Lib/turtledemo/a.py",
                "Lib/venv/scripts/nt/python.exe", "Lib/venv/scripts/nt/python.pdb", "Lib/ensurepip/_bundled/pip.whl",
                "Lib/site-packages/pip/__init__.py", "Lib/os.py"):
        (q_py / q_p).parent.mkdir(parents=True, exist_ok=True)
        (q_py / q_p).write_bytes(b"x")
    dong_goi.gon_python_windows(q_py)
    q_con = {str(t.relative_to(q_py)).replace("\\", "/") for t in q_py.rglob("*") if t.is_file()}
    kiem("gọn Python cho Windows: bỏ tệp gỡ lỗi, tkinter, tcl, bộ kiểm thử, tệp dịch C; giữ python.exe, DLL cần, "
         "venv, ensurepip và pip (tạo môi trường riêng cần chúng)",
         q_con == {"python.exe", "DLLs/_ssl.pyd", "Lib/venv/scripts/nt/python.exe", "Lib/ensurepip/_bundled/pip.whl",
                   "Lib/site-packages/pip/__init__.py", "Lib/os.py"}, str(sorted(q_con)))

    # Dựng phần thành phần bằng uv: thử bằng uv giả, xem lệnh gọi và phần dọn
    q_uv_gia = TAM / "uv-gia.py"
    q_uv_gia.write_text(
        "import json, pathlib, sys\na = sys.argv[1:]\ndich = pathlib.Path(a[a.index('--target') + 1])\n"
        "(dich / 'fastapi' / '__pycache__').mkdir(parents=True)\n(dich / 'fastapi' / '__init__.py').write_text('')\n"
        "(dich / 'fastapi' / '__pycache__' / 'a.pyc').write_text('x')\n"
        "for t in ('bin', 'Scripts', 'PyObjCTest'):\n    (dich / t).mkdir()\n    (dich / t / 'x').write_text('x')\n"
        "pathlib.Path(sys.argv[0] + '.goi').write_text(json.dumps(a))\n", encoding="utf-8")
    q_lenh_uv_that = dong_goi.lenh_uv
    dong_goi.lenh_uv = lambda: [sys.executable, str(q_uv_gia)]
    for q_nen, q_nen_uv, q_yc in ((dong_goi.NEN_MAC_ARM, "aarch64-apple-darwin", "yeu-cau-mac.txt"),
                                  (dong_goi.NEN_WINDOWS, "x86_64-pc-windows-msvc", "yeu-cau-windows.txt")):
        q_sp = TAM / f"sp-{q_nen}"
        dong_goi.dung_thanh_phan(q_nen, q_sp)
        q_goi = json.loads(Path(str(q_uv_gia) + ".goi").read_text(encoding="utf-8"))
        kiem(f"dựng phần thành phần {q_nen}: uv được gọi cho ĐÚNG máy đích, chỉ cài các gói ghim (không kéo gói phụ), "
             "rồi dọn bin, Scripts, PyObjCTest và tệp đã dịch",
             q_goi[:2] == ["pip", "install"] and q_goi[q_goi.index("--python-platform") + 1] == q_nen_uv
             and q_goi[q_goi.index("--python-version") + 1] == q_env_mac["PY_NHANH"] and "--no-deps" in q_goi
             and q_goi[q_goi.index("-r") + 1].endswith(q_yc) and (q_sp / "fastapi" / "__init__.py").is_file()
             and not [t for t in ("bin", "Scripts", "PyObjCTest") if (q_sp / t).exists()]
             and not list(q_sp.rglob("__pycache__")), str(q_goi))
    dong_goi.lenh_uv = q_lenh_uv_that

    # Tải có kiểm mã sha256
    q_nguon = TAM / "nguon-tai"
    q_nguon.mkdir()
    (q_nguon / "cpython-x+1-thu.tar.gz").write_bytes(b"noi dung tai ve")
    q_url = (q_nguon / "cpython-x+1-thu.tar.gz").as_uri()
    q_ma_dung = hashlib.sha256(b"noi dung tai ve").hexdigest()
    q_cache = TAM / "cache-tai"
    q_tep_tai = dong_goi.tai_co_kiem(q_url.replace("+", "%2B"), q_ma_dung, q_cache)
    q_chay_that = dong_goi.subprocess.run
    dong_goi.subprocess.run = lambda *a, **k: (_ for _ in ()).throw(AssertionError("tải lại dù đã có trong cache"))
    q_tep_tai2 = dong_goi.tai_co_kiem(q_url.replace("+", "%2B"), q_ma_dung, q_cache)
    dong_goi.subprocess.run = q_chay_that
    kiem("tải phần nền: đúng mã sha256 thì lưu vào cache (tên có dấu +), lần sau dùng lại, không tải lại",
         q_tep_tai.read_bytes() == b"noi dung tai ve" and q_tep_tai2 == q_tep_tai and "cpython-x+1-thu" in q_tep_tai.name)
    q_cache2 = TAM / "cache-tai-sai"
    try:
        dong_goi.tai_co_kiem(q_url.replace("+", "%2B"), "0" * 64, q_cache2)
        q_loi_ma = ""
    except SystemExit as loi:
        q_loi_ma = str(loi)
    kiem("tải phần nền sai mã sha256: dừng, nói rõ hai mã, không để lại tệp nào trong cache",
         "Sai mã sha256" in q_loi_ma and "0" * 64 in q_loi_ma and not list(q_cache2.iterdir()), q_loi_ma[:160])
    try:
        dong_goi.tai_co_kiem((q_nguon / "khong-co.tar.gz").as_uri(), q_ma_dung, q_cache2)
        q_loi_url = ""
    except SystemExit as loi:
        q_loi_url = str(loi)
    kiem("tải phần nền không được (không có tệp): dừng và nói không tải được", "Không tải được" in q_loi_url, q_loi_url[:120])

    # Zip Mac với tệp lớn nén sẵn, và gói Mac đầy đủ ráp từ phần nền giả
    q_lon = TAM / "lon.bin"
    q_lon.write_bytes(os.urandom(300_000))
    q_zip = TAM / "thu-lon.zip"
    dong_goi.ghi_zip_mac(q_zip, {"Contents/MacOS/cai-dat": b"#!/bin/bash\n", "Contents/Resources/nen/lon.bin": q_lon})
    with zipfile.ZipFile(q_zip) as z:
        q_a, q_b = z.getinfo(dong_goi.TEN_APP + "/Contents/MacOS/cai-dat"), z.getinfo(dong_goi.TEN_APP + "/Contents/Resources/nen/lon.bin")
        kiem("ghi zip Mac: tệp lớn đã nén sẵn chép thẳng (STORED, nguyên vẹn, không mang quyền chạy), tệp chạy có quyền 0755",
             q_b.compress_type == zipfile.ZIP_STORED and z.read(q_b) == q_lon.read_bytes()
             and (q_b.external_attr >> 16) & 0o777 == 0o644 and (q_a.external_attr >> 16) & 0o777 == 0o755
             and q_a.compress_type == zipfile.ZIP_DEFLATED)
    q_dung_nen_mac_that = dong_goi.dung_nen_mac

    def q_nen_mac_gia(dich, cache=None):
        dich.mkdir(parents=True, exist_ok=True)
        (dich / "python.tar.gz").write_bytes(b"py-gia")
        (dich / "thanh-phan.tar.xz").write_bytes(b"tp-gia")
        return {"he": "mac-arm64", "thanh_phan": {"sha256": "a" * 64}}
    dong_goi.dung_nen_mac = q_nen_mac_gia
    q_ra = TAM / "ra-day-du"
    q_ra.mkdir()
    q_dd = dong_goi.goi_mac_day_du(q_ra, "vthu", cache=TAM / "cache-x")
    dong_goi.dung_nen_mac = q_dung_nen_mac_that
    with zipfile.ZipFile(q_dd) as z:
        q_tep_dd = {t.filename[len(APP_CAI):]: z.read(t) for t in z.infolist()}
        q_kq_dd = {t.filename[len(APP_CAI):]: t.compress_type for t in z.infolist()}
    q_nho = dong_goi.noi_dung_goi_mac("vthu")
    kiem("gói Mac đầy đủ: tên MacChipM-DayDu, có mọi tệp của gói nhỏ (cùng nội dung) kèm nen/nen.json, python.tar.gz "
         "và thanh-phan.tar.xz",
         q_dd.name == "CaiDat-SonicRec-MacChipM-DayDu-vthu.zip"
         and all(q_tep_dd.get(t) == nd for t, nd in q_nho.items())
         and q_tep_dd["Contents/Resources/nen/python.tar.gz"] == b"py-gia"
         and q_tep_dd["Contents/Resources/nen/thanh-phan.tar.xz"] == b"tp-gia"
         and json.loads(q_tep_dd["Contents/Resources/nen/nen.json"])["ban"] == "vthu"
         and q_kq_dd["Contents/Resources/nen/python.tar.gz"] == zipfile.ZIP_STORED, str(sorted(q_tep_dd))[:200])
    kiem("gói nhỏ Mac KHÔNG có thư mục nen (trình cài dựa vào nen.json để biết đó là gói đầy đủ)",
         not [t for t in q_nho if "/nen/" in t or t.endswith("/nen")])

    # Trình cài NSIS: gói nhỏ và gói đầy đủ đều dịch được; gói đầy đủ mang tên riêng
    if shutil.which("makensis"):
        q_nen_gia = TAM / "nen-nsis"
        (q_nen_gia / "python").mkdir(parents=True)
        (q_nen_gia / "python" / "python.exe").write_bytes(b"MZ-gia")
        (q_nen_gia / "site-packages").mkdir()
        (q_nen_gia / "site-packages" / "x.py").write_text("x = 1\n", encoding="utf-8")
        q_ra_w = TAM / "ra-nsis"
        q_ra_w.mkdir()
        q_exe_dd = dong_goi.goi_windows(q_ra_w, "vthu", nen=q_nen_gia)
        q_exe_nho = dong_goi.goi_windows(q_ra_w, "vthu")
        kiem("trình cài Windows: gói đầy đủ dịch được với phần nền và mang tên DayDu; gói nhỏ vẫn mang tên cũ; cả hai ghi "
             "đúng dấu mã và số phiên bản",
             q_exe_dd.name == "CaiDat-SonicRec-Windows-DayDu-vthu.exe" and q_exe_nho.name == "CaiDat-SonicRec-Windows-vthu.exe"
             and all(bbh.so_ban_trong_exe(t.read_bytes()) == bbh.SO_BAN and t.read_bytes()[:2] == b"MZ"
                     for t in (q_exe_dd, q_exe_nho))
             and q_exe_dd.stat().st_size > q_exe_nho.stat().st_size - 1)
    else:
        print("  (máy không có makensis: bỏ qua phép dịch trình cài Windows đầy đủ)")

    # Xuất bản kèm gói đầy đủ
    if shutil.which("makensis"):
        q_kho = TAM / "kho-day-du"
        (q_kho / "ban-cai").mkdir(parents=True)
        (q_kho / "ban-cai" / "CaiDat-SonicRec-MacChipM-DayDu-v0.zip").write_bytes(b"cu")
        q_cu_kho = {"phien_ban": "abc1234", "cac_ban_truoc": [bbh.PHIEN_BAN]}
        if ban_lien_truoc(bbh.SO_BAN):
            q_cu_kho["so_ban"] = ban_lien_truoc(bbh.SO_BAN)
        (q_kho / "ban-moi.json").write_text(json.dumps(q_cu_kho), encoding="utf-8")
        q_dd_that = dong_goi.dong_goi_day_du

        def q_dd_gia(ra, ban=None):
            (ra / f"CaiDat-SonicRec-MacChipM-DayDu-{ban}.zip").write_bytes(b"mac-day-du")
            (ra / f"CaiDat-SonicRec-Windows-DayDu-{ban}.exe").write_bytes(b"win-day-du")
            return ra / f"CaiDat-SonicRec-MacChipM-DayDu-{ban}.zip", ra / f"CaiDat-SonicRec-Windows-DayDu-{ban}.exe"
        dong_goi.dong_goi_day_du = q_dd_gia
        q_m = dong_goi.xuat_ban(q_kho, "Cài nhanh", ngay="30/9/2026", day_du=True)
        q_ten = sorted(t.name for t in (q_kho / "ban-cai").iterdir())
        q_doc = bbh.doc_ban_moi((q_kho / "ban-moi.json").read_bytes())
        q_readme = (q_kho / "README.md").read_text(encoding="utf-8")
        kiem("xuất bản kèm gói đầy đủ: kho có hai gói nhỏ và hai gói đầy đủ (gói đầy đủ cũ bị xoá), ban-moi.json có khoá "
             "day_du ghi tên, mã, cỡ đúng và VẪN qua phép kiểm của ứng dụng (bản đã cài bỏ qua khoá lạ)",
             q_ten == sorted([bbh.TEN_TEP_CAI["mac"].format(bbh.SO_BAN), bbh.TEN_TEP_CAI["windows"].format(bbh.SO_BAN),
                              f"CaiDat-SonicRec-MacChipM-DayDu-v{bbh.SO_BAN}.zip",
                              f"CaiDat-SonicRec-Windows-DayDu-v{bbh.SO_BAN}.exe"])
             and q_doc == q_m and set(q_m["day_du"]) == {"mac_chip_m", "windows"}
             and q_m["day_du"]["mac_chip_m"] == {"tep": f"CaiDat-SonicRec-MacChipM-DayDu-v{bbh.SO_BAN}.zip",
                                                 "sha256": hashlib.sha256(b"mac-day-du").hexdigest(), "co": 10}
             and q_m["day_du"]["windows"]["co"] == 10, str(q_ten))
        kiem("xuất bản kèm gói đầy đủ: README dẫn đường tải cả gói đầy đủ lẫn gói nhỏ, nói máy chip Intel dùng gói nhỏ",
             all(bbh.KHO_MAC_DINH + "ban-cai/" + q_m["day_du"][k]["tep"] in q_readme for k in q_m["day_du"])
             and all(bbh.KHO_MAC_DINH + "ban-cai/" + q_m[he]["tep"] in q_readme for he in ("mac", "windows"))
             and "chip Intel" in q_readme and "không cần mạng" in q_readme)
        # Quá 99 MB thì dừng, không ghi gì vào kho
        q_kho2 = TAM / "kho-qua-nang"
        q_kho2.mkdir()
        (q_kho2 / "ban-moi.json").write_text(json.dumps(q_cu_kho), encoding="utf-8")
        q_han_that = dong_goi.GIOI_HAN_KHO
        dong_goi.GIOI_HAN_KHO = 5
        try:
            dong_goi.xuat_ban(q_kho2, "quá nặng", day_du=True)
            q_loi_nang = ""
        except SystemExit as loi:
            q_loi_nang = str(loi)
        dong_goi.GIOI_HAN_KHO = q_han_that
        kiem("gói đầy đủ nặng quá giới hạn 99 MB của kho: xuất bản dừng, nói rõ tên và cỡ, không ghi gì vào kho",
             "quá giới hạn 99 MB" in q_loi_nang and not (q_kho2 / "ban-cai").exists()
             and not (q_kho2 / "README.md").exists() and json.loads((q_kho2 / "ban-moi.json").read_text(encoding="utf-8")) == q_cu_kho,
             q_loi_nang[:160])
        dong_goi.dong_goi_day_du = q_dd_that
    kiem("gói đầy đủ tự dựng không nặng quá giới hạn của kho: hằng số GIOI_HAN_KHO là 99 MB",
         dong_goi.GIOI_HAN_KHO == 99 * 1024 * 1024)

    # Chữ trong các trình cài: không còn tải trình duyệt lúc cài, có đường gói đầy đủ và kiểm nhanh
    q_sh = (q_tc / "cai_dat_mac.sh").read_text(encoding="utf-8")
    q_lenh_sh = "\n".join(d for d in q_sh.splitlines() if d.strip() and not d.lstrip().startswith("#"))
    kiem("trình cài Mac: gói đầy đủ (nen.json) không tải Python, kiểm lại mã sha256, giải nén thành phần bằng tarfile; "
         "không tải trình duyệt lúc cài, không nâng pip; chỉ kiểm nhanh (bộ đầy đủ khi BBH_KIEM_DAY_DU=1)",
         all(x in q_sh for x in ('NEN="$NOI/Resources/nen"', 'DAY_DU=1', 'TEP_PY="$NEN/python.tar.gz"',
                                 '"$NEN/thanh-phan.tar.xz"', 'filter="tar"', 'chip Apple (M1 trở lên)',
                                 'tu_kiem_nhanh.py', 'BBH_KIEM_DAY_DU', 'PIP_DISABLE_PIP_VERSION_CHECK=1'))
         and "playwright install" not in q_lenh_sh and "--upgrade pip" not in q_lenh_sh
         and 'kiem_thu.py 2>&1' not in q_lenh_sh)
    q_ps = (THU_MUC / "cai_dat_windows.ps1").read_bytes().decode("utf-8-sig")
    kiem("trình cài Windows: Python đi kèm đứng đầu, môi trường dựng lại trên nó (gói đầy đủ luôn dựng lại), cài theo "
         "yeu-cau-windows.txt, ffmpeg lấy từ imageio-ffmpeg trước khi tải, chỉ kiểm nhanh",
         all(x in q_ps for x in ('[string]$Nen = ""', 'Join-Path $Dich "python\\python.exe"', '$Nen -ne "1"',
                                 '"-r", $yc', 'yeu-cau-windows.txt', 'imageio_ffmpeg\\binaries', 'ffmpeg-win*.exe',
                                 'tu_kiem_nhanh.py', 'BBH_KIEM_DAY_DU'))
         and "python-3.12.10-amd64.exe" in q_ps and q_ps.count('"kiem_thu.py"') == 1)
    q_nsi = (q_tc / "trinh_cai_windows.nsi").read_text(encoding="utf-8")
    kiem("trình cài NSIS: gói đầy đủ (NEN) chép Python đi kèm trước bước python, chép thành phần vào .venv ngay sau bước "
         "moi-truong, truyền -Nen 1; gỡ cài đặt xoá cả python",
         all(x in q_nsi for x in ('!ifdef NEN', 'File /r "${NEN}\\python\\*"', 'SetOutPath "$INSTDIR\\.venv\\Lib\\site-packages"',
                                  'File /r "${NEN}\\site-packages\\*"', '!define THAM_SO_NEN " -Nen 1"',
                                  'RMDir /r "$INSTDIR\\python"', 'Kiểm tra nhanh ứng dụng',
                                  '-ThuMucLuu "$ThuMucLuu"${THAM_SO_NEN}'))
         and q_nsi.index('File /r "${NEN}\\python\\*"') < q_nsi.index('!insertmacro BuocChinh "python"')
         < q_nsi.index('!insertmacro BuocChinh "moi-truong"') < q_nsi.index('File /r "${NEN}\\site-packages\\*"')
         < q_nsi.index('!insertmacro Buoc "goi" "Kiểm tra các thành phần..."'))
    # Luồng GitHub: thử cả gói nhỏ lẫn gói đầy đủ trên máy thật, đầy đủ thì chặn mạng
    q_wf = THU_MUC.parents[2] / ".github" / "workflows"
    if (q_wf / "bien-ban-hop-mac.yml").is_file() and (q_wf / "bien-ban-hop-windows.yml").is_file():
        q_ymac = (q_wf / "bien-ban-hop-mac.yml").read_text(encoding="utf-8")
        q_ywin = (q_wf / "bien-ban-hop-windows.yml").read_text(encoding="utf-8")
        kiem("luồng GitHub Mac: hai việc (gói nhỏ, gói đầy đủ), gói đầy đủ cài khi chặn mạng, đo thời gian, giữ trần 99 MB, "
             "và chạy bộ kiểm đầy đủ ở bước riêng",
             all(x in q_ymac for x in ("cai-nho:", "cai-day-du:", "PIP_NO_INDEX=1", "HTTPS_PROXY=http://127.0.0.1:9",
                                       "goi_mac_day_du", "99 * 1048576", "THOI_GIAN_CAI", "kiem_thu.py",
                                       "Tự kiểm nhanh: [0-9]*/[0-9]* phép đạt")))
        kiem("luồng GitHub Windows: dựng gói đầy đủ trên Linux rồi chạy chính tệp .exe trên máy Windows thật ở chế độ /S, "
             "chặn mạng, đo thời gian, kiểm Python đi kèm; bộ kiểm đầy đủ chạy ở bước riêng",
             all(x in q_ywin for x in ("dung-goi-day-du:", "cai-day-du:", "goi_windows_day_du", "upload-artifact",
                                       "download-artifact", '"/S"', "PIP_NO_INDEX", "python\\python.exe", "kiem_thu.py",
                                       "99 * 1048576")))
    else:
        print("  (không có thư mục .github: bỏ qua phép kiểm hai luồng GitHub)")

# ----------------------------------------------------------------------------
# Trình cài chạy bộ kiểm này mỗi lần cập nhật: dọn thư mục tạm, đừng để rác lại
import shutil  # noqa: E402

shutil.rmtree(TAM, ignore_errors=True)
print(f"\n{len(DAT)}/{len(DAT) + len(TRUOT)} phép đạt")
if TRUOT:
    print("TRƯỢT: " + "; ".join(TRUOT))
sys.exit(1 if TRUOT else 0)
