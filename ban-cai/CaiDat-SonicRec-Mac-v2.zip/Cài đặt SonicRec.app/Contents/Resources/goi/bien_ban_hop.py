# SonicRec: tệp mốc để máy cài bản v1.6 trở xuống nhận ra gói cài này. Không phải mã ứng
# dụng (mã đã dịch nằm ở bien_ban_hop.pyc); trình cài không chép tệp này vào máy.
SO_BAN = "2"
MA_NGUON = "79d19efe250a28bd95ad2c7ce37a92e720424f65"
