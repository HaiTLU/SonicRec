#!/usr/bin/env python3
"""Dựng tệp Word biên bản họp theo mẫu chính thức của Văn phòng Trường.

Mọi con số (lề, cỡ chữ, giãn dòng, bảng đầu văn bản, ba đường kẻ) lấy đúng từ
01_Projects/Web_ChuanHoaVanBan/src/lib/docx/chuan-dhtl.ts: bộ số đã đo trực tiếp
từ XML của mẫu do Văn phòng Trường ban hành kèm Quy chế Văn thư - Lưu trữ ngày
08/7/2025. Cách vẽ đường kẻ, gạch đầu dòng và bảng cũng chép theo công cụ đó,
để hai công cụ ra văn bản giống hệt nhau.

Khung văn bản (đầu văn bản, tiêu đề, thời gian, thành phần, chữ ký) dựng từ
thông tin cuộc họp, KHÔNG lấy từ bản nháp của mô hình: mô hình viết khá tự do,
còn các dòng này sẽ được ký nên phải đúng từng chữ. Chỉ phần thân (nội dung,
kết luận, phân công) lấy từ bản nháp.

Chạy thử một mình:   .venv/bin/python tao_word.py bien-ban.txt ra.docx
"""

import math
import re
import sys
import unicodedata
from datetime import date
from pathlib import Path

from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt, RGBColor, Twips

# ----------------------------------------------------------------------------
# Số đo, chép từ chuan-dhtl.ts. Đơn vị twip: 1 cm = 566,93 twip.
# ----------------------------------------------------------------------------

def cm(x: float) -> int:
    return round(x * 566.93)


FONT = "Times New Roman"
DEN = RGBColor(0, 0, 0)  # quy tắc bắt buộc của kho: chữ chỉ màu đen

KHO_A4 = (11906, 16838)
LE = {"tren": cm(2), "phai": 851, "duoi": cm(2), "trai": cm(3)}  # 851 đo từ mẫu
BE_NGANG_CHU = cm(16.5)

# Bảng đầu văn bản: HAI ô 8,5cm và 10cm (4820 và 5670 twip đo từ mẫu). Lưới của
# mẫu có 4 cột 8 - 0,5 - 9,75 - 0,25cm nhưng hàng chứa chữ gộp mỗi ô hai cột; đọc
# nhầm thành 4 ô thì ô quốc hiệu chỉ còn 9,75cm. Bảng rộng hơn vùng chữ và thụt
# lề âm để tràn ra cả hai lề, nhờ vậy quốc hiệu nằm gọn một dòng mà không nén chữ.
COT_DAU = [4820, 5670]
BANG_DAU_BE_NGANG = 10490
# Lề trong ô của hai bảng bố cục (đầu văn bản và chữ ký), đo từ cả 5 mẫu.
LE_O_BO_CUC = 108
# Mẫu ghi tblInd -743 ở chế độ Word 2003, khi đó thụt lề tính tới MÉP CHỮ trong
# ô. Tệp này ở chế độ Word 2013 (CHE_DO_WORD), thụt lề tính tới MÉP BẢNG, nên
# phải trừ thêm lề trong ô thì chữ mới nằm đúng chỗ như mẫu.
BANG_DAU_THUT_LE = -743 - LE_O_BO_CUC
COT_CHAN = cm(7.94)
CHAN_THUT_LE = 0 - LE_O_BO_CUC  # mẫu để tblInd 0: chữ thẳng lề trái
CHE_DO_WORD = "15"  # Word 2013 trở lên, như công cụ Chuẩn hóa văn bản
LE_DAU_TRANG = 284  # 0,5cm từ mép giấy tới số trang, đo từ mẫu (pgMar w:header)

KE_DUOI_CO_QUAN = cm(2.78)
KE_DUOI_TIEU_NGU = cm(5.95)
KE_DUOI_TRICH_YEU = cm(4.5)

THUT_DAU_DONG = cm(1.25)
THUT_GACH = cm(0.5)
NGUONG_CHU_DAI = 30  # ô bảng dài hơn thì căn trái, còn lại căn giữa

CO_THAN = 14
CO_CO_QUAN = 13       # cơ quan chủ quản, cơ quan ban hành, số ký hiệu, quốc hiệu
CO_TIEU_NGU = 14      # tiêu ngữ, địa danh ngày tháng
CO_GHI_CHU_KY = 13

# (giãn dòng, cách trước pt, cách sau pt). Đo từ 5 mẫu của Văn phòng Trường:
# thân bài và khối tiêu đề 1,3 dòng (1,2 chỉ dành cho căn cứ và các Điều của
# quyết định, biên bản không có); ô bảng đầu và bảng chữ ký dòng đơn. Mọi đoạn
# cách 3pt trước và sau. python-docx ghi số thực thành lineRule="auto" như mẫu.
GIAN_THAN = (1.3, 3, 3)
GIAN_TIEU_DE = (1.3, 3, 3)
GIAN_O_BANG = (1.0, 3, 3)
GIAN_CHAT = (1.15, 0, 0)
GIAN_SAT = (1.0, 0, 0)

# Chỗ ký: cả 5 mẫu để 2 dòng trống cỡ 13pt giữa ghi chú và họ tên người ký.
SO_DONG_TRONG_KY = 2
CO_DONG_TRONG = 13

MAC_DINH = {
    "co_quan_chu_quan": "TRƯỜNG ĐẠI HỌC THĂNG LONG",
    # Xuống dòng sẵn cho cân hai dòng; để máy tự ngắt thì chữ "NGHỆ" rớt một mình
    "co_quan_ban_hanh": "TRUNG TÂM ĐÀO TẠO NGẮN HẠN\nVÀ CHUYỂN GIAO CÔNG NGHỆ",
    "ky_hieu": "BB-TTC",
    "dia_danh": "Hà Nội",
}
CHAM = "....."  # chỗ trống để thư ký tự điền


# ----------------------------------------------------------------------------
# Viên gạch nhỏ
# ----------------------------------------------------------------------------

# Word đòi các thẻ con đứng đúng thứ tự trong lược đồ OOXML. Sai thứ tự thì
# LibreOffice vẫn mở, nhưng Word có lúc báo "nội dung không đọc được".
# python-docx chỉ tự xếp những thẻ nó biết, nên thẻ nào tự gắn thì phải xếp lại.
THU_TU_TBLPR = ["tblStyle", "tblpPr", "tblOverlap", "bidiVisual", "tblStyleRowBandSize",
                "tblStyleColBandSize", "tblW", "jc", "tblCellSpacing", "tblInd",
                "tblBorders", "shd", "tblLayout", "tblCellMar", "tblLook"]
THU_TU_PPR = ["pStyle", "keepNext", "keepLines", "pageBreakBefore", "framePr",
              "widowControl", "numPr", "suppressLineNumbers", "pBdr", "shd", "tabs",
              "suppressAutoHyphens", "kinsoku", "wordWrap", "overflowPunct",
              "topLinePunct", "autoSpaceDE", "autoSpaceDN", "bidi", "adjustRightInd",
              "snapToGrid", "spacing", "ind", "contextualSpacing", "mirrorIndents",
              "suppressOverlap", "jc", "textDirection", "textAlignment",
              "textboxTightWrap", "outlineLvl", "divId", "cnfStyle", "rPr", "sectPr",
              "pPrChange"]


def _ten_the(e) -> str:
    return e.tag.split("}")[-1]


def sap_xep(cha, thu_tu: list[str]) -> None:
    """Xếp lại thẻ con theo lược đồ, giữ nguyên thứ tự giữa các thẻ cùng loại."""
    con = list(cha)
    con.sort(key=lambda e: thu_tu.index(_ten_the(e)) if _ten_the(e) in thu_tu
             else len(thu_tu))
    for e in con:
        cha.remove(e)
    for e in con:
        cha.append(e)

def chu(p, text: str, co: float = CO_THAN, dam: bool = False, nghieng: bool = False):
    if "\n" in text:  # xuống dòng trong cùng một đoạn
        cac_dong = text.split("\n")
        for dong in cac_dong[:-1]:
            chu(p, dong, co, dam, nghieng).add_break()
        return chu(p, cac_dong[-1], co, dam, nghieng)
    r = p.add_run(text)
    f = r.font
    f.name = FONT
    f.size = Pt(co)
    f.bold = True if dam else None
    f.italic = True if nghieng else None
    f.color.rgb = DEN
    # font.name chỉ đặt ascii và hAnsi; đặt nốt để Word máy nào cũng ra Times
    rfonts = r._element.get_or_add_rPr().get_or_add_rFonts()
    rfonts.set(qn("w:eastAsia"), FONT)
    rfonts.set(qn("w:cs"), FONT)
    return r


# Chữ đậm kiểu markdown **...**, và dấu ngoặc vuông cần xem lại như
# [chưa rõ ai nói]. Mốc giờ [00:12] của bản chép lời thì để chữ thường.
DAM = re.compile(r"\*\*[^*]+\*\*")
DANH_DAU = re.compile(r"\[(?!\d)[^\]]+\]")
MANH = re.compile(f"({DAM.pattern}|{DANH_DAU.pattern})")


# PM chốt 1/10/2026 (v1.7): chữ "[cần kiểm tra]" không in vào văn bản nữa. Chỗ cần kiểm tra thành
# bình luận bên lề, gắn vào chữ ngay trước nó, chứa đoạn bản chép lời làm bằng chứng (kèm mốc
# phút:giây). Mô hình ghi [cần kiểm tra: "<nguyên văn ngắn>"]; nội dung không có ngoặc kép là lời
# ghi chú của máy (ví dụ giờ tính từ tệp ghi âm). Trước khi trình ký: Xoá tất cả bình luận.
KIEM_TRA = re.compile(r"\[cần kiểm tra(?::\s*(.*?))?\]")
# [chưa rõ ai nói] thành ô chọn của Word: bấm vào hiện danh sách chủ trì, thư ký, người tham dự
CHUA_RO_AI = "[chưa rõ ai nói]"
MOC_CHEP_LOI = re.compile(r"^\[(\d{1,3}:\d{2}(?::\d{2})?)\]\s*")


class BoiCanh:
    """Những thứ chu_co_danh_dau cần để dựng bình luận và ô chọn người nói."""

    def __init__(self, doc=None, nguoi: list[str] | None = None, chep_loi: str = ""):
        self.doc, self.nguoi = doc, nguoi or []
        self.doan = [d.strip() for d in re.split(r"\n\s*\n", chep_loi or "") if d.strip()]


def _gon(s: str) -> str:
    return re.sub(r"\s+", " ", s).strip().lower()


def bang_chung(trich: str, doan: list[str], toi_da: int = 500) -> tuple[str, str]:
    """(mốc, đoạn chép lời) chứa câu trích. Không tìm thấy thì ("", "")."""
    can = _gon(trich)
    if not can:
        return "", ""
    for d in doan:
        m = MOC_CHEP_LOI.match(d)
        moc, than = (m[1], d[m.end():]) if m else ("", d)
        gon = _gon(than)
        i = gon.find(can)
        if i < 0:
            continue
        if len(gon) > toi_da:  # cắt quanh câu trích cho bình luận khỏi dài
            dau = max(0, i - (toi_da - len(can)) // 2)
            gon = ("..." if dau else "") + gon[dau:dau + toi_da] + ("..." if dau + toi_da < len(gon) else "")
            return moc, gon
        return moc, re.sub(r"\s+", " ", than).strip()
    return "", ""


def loi_binh_kiem_tra(noi: str | None, bc: "BoiCanh") -> str:
    noi = (noi or "").strip()
    trich = noi[1:-1].strip() if len(noi) >= 2 and noi[0] in "\"“" and noi[-1] in "\"”" else ""
    if not trich:
        return "Cần kiểm tra" + (f": {noi}." if noi else ", đối chiếu với bản chép lời.")
    moc, doan = bang_chung(trich, bc.doan)
    if doan:
        return f"Cần kiểm tra. Bản chép lời{', phút ' + moc if moc else ''}: \"{doan}\""
    return f"Cần kiểm tra. Máy dựa vào câu \"{trich}\" nhưng không tìm thấy nguyên văn trong bản chép lời."


def _o_chon_nguoi(r, nguoi: list[str]) -> None:
    """Bọc run r thành ô chọn (dropDownList) của Word: chữ hiện là [chưa rõ ai nói]."""
    sdt = OxmlElement("w:sdt")
    pr = OxmlElement("w:sdtPr")
    ten = OxmlElement("w:alias")
    ten.set(qn("w:val"), "Người phát biểu")
    pr.append(ten)
    ds = OxmlElement("w:dropDownList")
    for x in [CHUA_RO_AI, *nguoi]:
        muc = OxmlElement("w:listItem")
        muc.set(qn("w:displayText"), x)
        muc.set(qn("w:value"), x)
        ds.append(muc)
    pr.append(ds)
    sdt.append(pr)
    noi_dung = OxmlElement("w:sdtContent")
    sdt.append(noi_dung)
    r._r.addprevious(sdt)
    noi_dung.append(r._r)


def ds_nguoi(tt: dict) -> list[str]:
    """Chủ trì, thư ký và người tham dự (ô Tham dự tách theo dấu phẩy, chấm phẩy, xuống dòng)."""
    ra: list[str] = []
    for x in [tt.get("chu_tri") or "", tt.get("thu_ky") or "",
              *re.split(r"[,;\n]", tt.get("tham_du") or "")]:
        x = x.strip(" -.\t")
        if x and x not in ra and x != CHUA_RO_AI:
            ra.append(x)
    return ra


def chu_co_danh_dau(p, text: str, co: float = CO_THAN, bc: BoiCanh | None = None) -> None:
    truoc = None  # run chữ ngay trước, để gắn bình luận cần kiểm tra
    if bc is not None and bc.doc is not None:
        # Nhãn bị bỏ khỏi chữ: kéo nó sát chữ đứng trước để không sót hai dấu cách liền nhau
        text = re.sub(r"[ \t]+(" + KIEM_TRA.pattern + r")", r"\1", text)
    co_bl = bc is not None and bc.doc is not None
    cac_manh = [m for m in MANH.split(text) if m]
    for so, manh in enumerate(cac_manh):
        kt = KIEM_TRA.fullmatch(manh)
        if kt and co_bl:
            if truoc is None:
                truoc = chu(p, "", co=co)
            bc.doc.add_comment(truoc, text=loi_binh_kiem_tra(kt[1], bc), author="SonicRec", initials="SR")
            continue
        if DAM.fullmatch(manh):
            truoc = chu(p, manh[2:-2], co=co, dam=True)
        elif DANH_DAU.fullmatch(manh):
            # Không tô màu được (quy tắc chữ đen), nên đậm nghiêng cho dễ thấy
            truoc = chu(p, manh, co=co, dam=True, nghieng=True)
            if manh == CHUA_RO_AI and bc is not None and bc.nguoi:
                _o_chon_nguoi(truoc, bc.nguoi)
        else:
            # Chữ đứng ngay trước một chỗ cần kiểm tra: tách riêng chữ cuối (thường là con số) để
            # bình luận chỉ gắn vào đúng chữ đó, như phần xem trước gạch chân đúng chữ đó
            sau = cac_manh[so + 1] if so + 1 < len(cac_manh) else ""
            j = max(manh.rfind(" "), manh.rfind("\t")) if co_bl and KIEM_TRA.fullmatch(sau) else -1
            if 0 <= j < len(manh) - 1:
                chu(p, manh[:j + 1], co=co)
                manh = manh[j + 1:]
            truoc = chu(p, manh, co=co)


def dinh_dang(p, can=WD_ALIGN_PARAGRAPH.JUSTIFY, gian=GIAN_THAN, dau_dong=0,
              trai=0, phai=0, treo=0, giu_voi_sau=False):
    pf = p.paragraph_format
    pf.alignment = can
    dong, truoc, sau = gian
    pf.line_spacing = dong
    pf.space_before = Pt(truoc)
    pf.space_after = Pt(sau)
    if dau_dong:
        pf.first_line_indent = Twips(dau_dong)
    if treo:
        pf.first_line_indent = Twips(-treo)
    if trai:
        pf.left_indent = Twips(trai)
    if phai:
        pf.right_indent = Twips(phai)
    if giu_voi_sau:
        pf.keep_with_next = True
    return p


def doan_moi(noi):
    """Đoạn mới. Ô bảng mới tạo đã có sẵn một đoạn rỗng, dùng lại đoạn đó."""
    ps = getattr(noi, "paragraphs", [])
    if hasattr(noi, "_tc") and len(ps) == 1 and not ps[0].text and not ps[0].runs:
        if not getattr(noi, "_da_dung_doan_dau", False):
            noi._da_dung_doan_dau = True
            return ps[0]
    return noi.add_paragraph()


def duong_ke(noi, do_rong_o: int, do_dai: int):
    """Đường kẻ liền nét sát dưới dòng chữ: viền dưới của một đoạn rỗng cao 2pt,
    thụt đều hai bên cho ngắn lại và nằm giữa. Đúng cách của công cụ kia."""
    p = doan_moi(noi)
    # Làm tròn nửa lên như Math.round của công cụ kia; round() của Python làm
    # tròn 1040,5 xuống 1040 nên đường kẻ dưới tiêu ngữ lệch 1 twip
    thut = max(0, math.floor((do_rong_o - do_dai) / 2 + 0.5))
    pf = p.paragraph_format
    pf.alignment = WD_ALIGN_PARAGRAPH.CENTER
    pf.space_before = Pt(0)
    pf.space_after = Pt(0)
    pf.line_spacing = Pt(2)
    pf.line_spacing_rule = WD_LINE_SPACING.EXACTLY
    pf.left_indent = Twips(thut)
    pf.right_indent = Twips(thut)
    pbdr = OxmlElement("w:pBdr")
    duoi = OxmlElement("w:bottom")
    for k, v in (("w:val", "single"), ("w:sz", "6"), ("w:space", "0"), ("w:color", "000000")):
        duoi.set(qn(k), v)
    pbdr.append(duoi)
    pPr = p._p.get_or_add_pPr()
    pPr.append(pbdr)
    sap_xep(pPr, THU_TU_PPR)
    chu(p, "", co=2)
    return p


def dong_trong(noi, co: float = CO_DONG_TRONG, gian=GIAN_O_BANG):
    """Đoạn trống tạo khoảng cách, như các mẫu của Trường. Cỡ chữ đặt ở dấu đoạn
    (pPr/rPr): Word lấy chiều cao dòng trống từ dấu đoạn, run rỗng không tính."""
    p = dinh_dang(doan_moi(noi), can=WD_ALIGN_PARAGRAPH.CENTER, gian=gian)
    pPr = p._p.get_or_add_pPr()
    rPr = OxmlElement("w:rPr")
    for ten in ("w:sz", "w:szCs"):
        e = OxmlElement(ten)
        e.set(qn("w:val"), str(round(co * 2)))
        rPr.append(e)
    pPr.append(rPr)
    sap_xep(pPr, THU_TU_PPR)
    return p


def _vien(tbl, kieu: str, sz: int = 0) -> None:
    tblPr = tbl._tbl.tblPr
    cu = tblPr.find(qn("w:tblBorders"))
    if cu is not None:
        tblPr.remove(cu)
    vien = OxmlElement("w:tblBorders")
    for canh in ("top", "left", "bottom", "right", "insideH", "insideV"):
        e = OxmlElement(f"w:{canh}")
        e.set(qn("w:val"), kieu)
        if kieu != "nil":
            e.set(qn("w:sz"), str(sz))
            e.set(qn("w:space"), "0")
            e.set(qn("w:color"), "000000")
        vien.append(e)
    tblPr.append(vien)
    sap_xep(tblPr, THU_TU_TBLPR)


def bang(doc, cot: list[int], so_hang: int = 1, be_ngang: int | None = None,
         thut_le: int | None = None):
    """Bảng bề ngang cố định. Đặt đủ tblW, tblInd, tblLayout, gridCol và tcW để
    Word, LibreOffice và Pages hiện cùng một kích thước."""
    t = doc.add_table(rows=so_hang, cols=len(cot))
    t.autofit = False
    tblPr = t._tbl.tblPr
    tblW = tblPr.find(qn("w:tblW"))
    if tblW is None:
        tblW = OxmlElement("w:tblW")
        tblPr.append(tblW)
    tblW.set(qn("w:w"), str(be_ngang or sum(cot)))
    tblW.set(qn("w:type"), "dxa")
    if thut_le is not None:
        ind = OxmlElement("w:tblInd")
        ind.set(qn("w:w"), str(thut_le))
        ind.set(qn("w:type"), "dxa")
        tblPr.append(ind)
    sap_xep(tblPr, THU_TU_TBLPR)  # t.autofit = False đã tự gắn tblLayout cố định
    for i, w in enumerate(cot):
        t.columns[i].width = Twips(w)
        for hang in t.rows:
            hang.cells[i].width = Twips(w)
    return t


# ----------------------------------------------------------------------------
# Ngày tháng theo Nghị định 30
# ----------------------------------------------------------------------------

def ngay_thang_nam(d: date) -> str:
    """Ngày dưới 10 và tháng 1, 2 phải ghi thêm số 0 phía trước (Nghị định 30)."""
    ngay = f"{d.day:02d}" if d.day < 10 else str(d.day)
    thang = f"{d.month:02d}" if d.month < 3 else str(d.month)
    return f"ngày {ngay} tháng {thang} năm {d.year}"


# ----------------------------------------------------------------------------
# Tách phần thân từ bản nháp
# ----------------------------------------------------------------------------

SO_MUC = re.compile(r"^\s*(\d+|[IVXLC]+)[.)]\s+")
GACH = re.compile(r"^\s*[-*•+]\s+")
NHAN_THONG_TIN = re.compile(
    r"^\s*[-*•+]?\s*(Tên cuộc họp|Thời gian|Địa điểm|Chủ trì|Thư ký|Tham dự"
    r"|Thành phần(?: tham dự)?)\s*:", re.IGNORECASE)
PHAN_CUOI = re.compile(
    r"^\s*(Biên bản (kết thúc|được lập)|\(Ký,? ghi rõ họ tên\)|THƯ KÝ(\s{2,}|\t|$))")


def khong_dau(s: str) -> str:
    s = s.replace("đ", "d").replace("Đ", "D")
    return "".join(c for c in unicodedata.normalize("NFD", s)
                   if unicodedata.category(c) != "Mn")


def _sach(dong: str) -> str:
    """Bỏ dấu tiêu đề markdown và cặp ** bọc cả dòng."""
    s = re.sub(r"^\s*#+\s*", "", dong.rstrip())
    m = re.fullmatch(r"\s*\*\*(.+)\*\*\s*:?\s*", s)
    return m.group(1) if m else s


def la_tieu_de(s: str) -> bool:
    s = s.strip()
    if not s or len(s) > 90 or "|" in s:
        return False
    than = SO_MUC.sub("", s).rstrip(":").strip()
    chu_cai = [c for c in than if c.isalpha()]
    return len(chu_cai) >= 3 and all(c.isupper() for c in chu_cai)


def _la_dong_bang(s: str) -> bool:
    return s.count("|") >= 2


def _la_dong_ke_bang(s: str) -> bool:
    """Dòng |---|---| của bảng markdown."""
    return "-" in s and not re.sub(r"[|\-:\s]", "", s)


def _tach_o(s: str, kieu_markdown: bool) -> list[str]:
    s = s.strip()
    if kieu_markdown:
        s = s[1:] if s.startswith("|") else s
        s = s[:-1] if s.endswith("|") else s
    return [o.strip() for o in s.split("|")]


def tach_than_bai(noi_dung: str, ten_cuoc_hop: str = "") -> list[tuple]:
    """Trả danh sách khối: ("muc", chữ) | ("doan", chữ) | ("gach", chữ) |
    ("bang", [hàng...]). Bỏ phần đầu và phần cuối mà khung văn bản tự dựng."""
    dong = [_sach(d) for d in noi_dung.replace("\r\n", "\n").split("\n")]

    # 1. Cắt phần cuối: câu kết và khối chữ ký. Chỉ xét nửa sau cho khỏi cắt nhầm.
    for i in range(len(dong) // 2, len(dong)):
        if PHAN_CUOI.match(dong[i]):
            dong = dong[:i]
            break

    # 2. Bỏ phần đầu: tiêu đề, tên cuộc họp, các dòng thời gian, địa điểm...
    ten = khong_dau(ten_cuoc_hop).lower().strip()
    i = 0
    while i < len(dong):
        s = dong[i].strip()
        tron = s.replace("*", "")  # "**Thời gian:** ..." của markdown vẫn phải nhận ra
        if (not s or tron.upper().startswith("BIÊN BẢN") or NHAN_THONG_TIN.match(tron)
                or (ten and khong_dau(tron).lower().strip(" .:") == ten)):
            i += 1
            continue
        break
    dong = dong[i:]

    # 3. Chia khối
    khoi: list[tuple] = []
    j = 0
    while j < len(dong):
        s = dong[j].strip()
        if not s:
            j += 1
            continue
        if _la_dong_bang(s):
            kieu_md = s.startswith("|") and s.endswith("|")
            hang = []
            while j < len(dong) and _la_dong_bang(dong[j]):
                if not _la_dong_ke_bang(dong[j]):
                    hang.append(_tach_o(dong[j], kieu_md))
                j += 1
            khoi.append(("bang", hang))
            continue
        if la_tieu_de(s):
            khoi.append(("muc", s))
        elif GACH.match(s):
            khoi.append(("gach", GACH.sub("", s)))
        else:
            khoi.append(("doan", s))
        j += 1

    # 4. Bỏ mục THÀNH PHẦN THAM DỰ vì khung đã có, rồi đánh số lại các mục
    sach: list[tuple] = []
    bo_qua = False
    for k in khoi:
        if k[0] == "muc":
            bo_qua = SO_MUC.sub("", k[1]).upper().startswith("THÀNH PHẦN")
        if not bo_qua:
            sach.append(k)
    so = 0
    ket_qua = []
    for loai, gia_tri in sach:
        if loai == "muc" and SO_MUC.match(gia_tri):
            so += 1
            gia_tri = f"{so}. {SO_MUC.sub('', gia_tri)}"
        ket_qua.append((loai, gia_tri))
    return ket_qua


# ----------------------------------------------------------------------------
# Dựng văn bản
# ----------------------------------------------------------------------------

def _le_o(t, tren: int, duoi: int, trai: int, phai: int) -> None:
    le = OxmlElement("w:tblCellMar")
    for canh, gia_tri in (("top", tren), ("left", trai), ("bottom", duoi), ("right", phai)):
        e = OxmlElement(f"w:{canh}")
        e.set(qn("w:w"), str(gia_tri))
        e.set(qn("w:type"), "dxa")
        le.append(e)
    tblPr = t._tbl.tblPr
    tblPr.append(le)
    sap_xep(tblPr, THU_TU_TBLPR)


def be_ngang_trong_o(do_rong_o: int) -> int:
    """Bề ngang chữ thực tế trong ô bảng bố cục: trừ lề trong ô hai bên. Đường kẻ
    trong ô phải tính theo số này, không thì ngắn hơn mẫu."""
    return do_rong_o - 2 * LE_O_BO_CUC


def _dau_van_ban(doc, tt: dict, ngay: date) -> None:
    # Hàng trống dưới cùng, mẫu nào cũng có: tạo khoảng cách tới tên loại văn bản
    t = bang(doc, COT_DAU, so_hang=2, be_ngang=BANG_DAU_BE_NGANG,
             thut_le=BANG_DAU_THUT_LE)
    _vien(t, "nil")
    _le_o(t, 0, 0, LE_O_BO_CUC, LE_O_BO_CUC)
    trai, phai = t.cell(0, 0), t.cell(0, 1)
    giua = WD_ALIGN_PARAGRAPH.CENTER

    p = dinh_dang(doan_moi(trai), can=giua, gian=GIAN_O_BANG)
    chu(p, (tt.get("co_quan_chu_quan") or MAC_DINH["co_quan_chu_quan"]).upper(),
        co=CO_CO_QUAN)
    p = dinh_dang(doan_moi(trai), can=giua, gian=GIAN_O_BANG)
    chu(p, (tt.get("co_quan_ban_hanh") or MAC_DINH["co_quan_ban_hanh"]).upper(),
        co=CO_CO_QUAN, dam=True)
    duong_ke(trai, be_ngang_trong_o(COT_DAU[0]), KE_DUOI_CO_QUAN)
    # Dòng trống ngay dưới đường kẻ bỏ cách trên 3pt, bù cho đoạn kẻ cao 2pt
    dong_trong(trai, CO_CO_QUAN, gian=(1.0, 0, 3))
    p = dinh_dang(doan_moi(trai), can=giua, gian=GIAN_O_BANG)
    chu(p, f"Số:       /{tt.get('ky_hieu') or MAC_DINH['ky_hieu']}", co=CO_CO_QUAN)

    p = dinh_dang(doan_moi(phai), can=giua, gian=GIAN_O_BANG)
    chu(p, "CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM", co=CO_CO_QUAN, dam=True)
    p = dinh_dang(doan_moi(phai), can=giua, gian=GIAN_O_BANG)
    chu(p, "Độc lập - Tự do - Hạnh phúc", co=CO_TIEU_NGU, dam=True)
    duong_ke(phai, be_ngang_trong_o(COT_DAU[1]), KE_DUOI_TIEU_NGU)
    dong_trong(phai, CO_CO_QUAN, gian=(1.0, 0, 3))
    p = dinh_dang(doan_moi(phai), can=giua, gian=GIAN_O_BANG)
    chu(p, f"{tt.get('dia_danh') or MAC_DINH['dia_danh']}, {ngay_thang_nam(ngay)}",
        co=CO_TIEU_NGU, nghieng=True)
    dong_trong(phai, CO_TIEU_NGU)

    dong_trong(t.cell(1, 0), CO_CO_QUAN)
    dong_trong(t.cell(1, 1), CO_TIEU_NGU)


def _bang_du_lieu(doc, hang: list[list[str]], bc: BoiCanh | None = None) -> None:
    so_cot = max(len(h) for h in hang)
    rong = BE_NGANG_CHU // so_cot
    t = bang(doc, [rong] * so_cot, so_hang=len(hang))
    _vien(t, "single", sz=4)  # 0,5pt
    _le_o(t, 40, 40, 80, 80)  # 2pt trên dưới, 4pt hai bên, như công cụ kia
    for r, cac_o in enumerate(hang):
        dong = t.rows[r]
        if r == 0:  # đầu bảng lặp lại khi sang trang
            trPr = dong._tr.get_or_add_trPr()
            trPr.append(OxmlElement("w:tblHeader"))
        for c in range(so_cot):
            noi = cac_o[c] if c < len(cac_o) else ""
            o = dong.cells[c]
            o.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            can = (WD_ALIGN_PARAGRAPH.LEFT if r > 0 and len(noi) > NGUONG_CHU_DAI
                   else WD_ALIGN_PARAGRAPH.CENTER)
            p = dinh_dang(doan_moi(o), can=can, gian=GIAN_CHAT)
            if r == 0:
                chu(p, noi, dam=True)
            else:
                chu_co_danh_dau(p, noi, bc=bc)


def _chu_ky(doc, tt: dict) -> None:
    t = bang(doc, [COT_CHAN, COT_CHAN], thut_le=CHAN_THUT_LE)
    _vien(t, "nil")
    _le_o(t, 0, 0, LE_O_BO_CUC, LE_O_BO_CUC)
    trPr = t.rows[0]._tr.get_or_add_trPr()
    trPr.append(OxmlElement("w:cantSplit"))  # khối chữ ký không bị cắt đôi
    giua = WD_ALIGN_PARAGRAPH.CENTER
    for o, chuc_danh, ten in ((t.cell(0, 0), "THƯ KÝ", tt.get("thu_ky", "")),
                              (t.cell(0, 1), "CHỦ TRÌ", tt.get("chu_tri", ""))):
        chu(dinh_dang(doan_moi(o), can=giua, gian=GIAN_O_BANG, giu_voi_sau=True),
            chuc_danh, dam=True)
        chu(dinh_dang(doan_moi(o), can=giua, gian=GIAN_O_BANG, giu_voi_sau=True),
            "(Ký, ghi rõ họ tên)", co=CO_GHI_CHU_KY, nghieng=True)
        for _ in range(SO_DONG_TRONG_KY):  # chỗ ký
            dong_trong(o).paragraph_format.keep_with_next = True
        chu(dinh_dang(doan_moi(o), can=giua, gian=GIAN_O_BANG), ten.strip(), dam=True)


def _che_do_word(doc) -> None:
    """Mẫu python-docx để chế độ tương thích Word 2010 (14); đổi sang 15 như
    công cụ Chuẩn hóa, để thụt lề bảng hiểu cùng một cách (xem BANG_DAU_THUT_LE)."""
    for e in doc.settings.element.iter(qn("w:compatSetting")):
        if e.get(qn("w:name")) == "compatibilityMode":
            e.set(qn("w:val"), CHE_DO_WORD)
            return
    raise RuntimeError("Mẫu python-docx không có compatibilityMode")


def _so_trang(section) -> None:
    """Số trang giữa lề trên, từ trang 2 trở đi, cỡ 13 (Nghị định 30)."""
    section.different_first_page_header_footer = True
    p = section.header.paragraphs[0]
    dinh_dang(p, can=WD_ALIGN_PARAGRAPH.CENTER, gian=GIAN_SAT)
    for loai, chu_lenh in (("begin", None), (None, " PAGE "), ("separate", None),
                           (None, None), ("end", None)):
        r = chu(p, "2" if (loai is None and chu_lenh is None) else "", co=13)
        if loai:
            fld = OxmlElement("w:fldChar")
            fld.set(qn("w:fldCharType"), loai)
            r._element.append(fld)
        elif chu_lenh:
            instr = OxmlElement("w:instrText")
            instr.set(qn("xml:space"), "preserve")
            instr.text = chu_lenh
            r._element.append(instr)


def dung_bien_ban(noi_dung: str, tt: dict, ngay: date, gio_ket_thuc: str | None,
                  duong_ra: Path, ban_chep_loi: str = "") -> Path:
    """gio_ket_thuc đã định dạng sẵn, ví dụ "9 giờ 28 phút". None thì để chấm cho
    thư ký điền. Việc có ghi kèm dấu cần kiểm tra hay không do nơi gọi quyết. ban_chep_loi:
    bản chép lời của cuộc họp, để bình luận cần kiểm tra trích đúng đoạn làm bằng chứng."""
    doc = Document()
    bc = BoiCanh(doc, ds_nguoi(tt), ban_chep_loi)

    # Kiểu chữ gốc: mọi đoạn không đặt riêng sẽ theo Times 14 chữ đen
    goc = doc.styles["Normal"]
    goc.font.name = FONT
    goc.font.size = Pt(CO_THAN)
    goc.font.color.rgb = DEN
    # Mẫu python-docx để sẵn cách sau 10pt, giãn 1,15; đổi theo thân bài như
    # công cụ Chuẩn hóa để đoạn nào không đặt riêng cũng không lệch mẫu.
    dong, truoc, sau = GIAN_THAN
    goc.paragraph_format.line_spacing = dong
    goc.paragraph_format.space_before = Pt(truoc)
    goc.paragraph_format.space_after = Pt(sau)
    rf = goc.element.get_or_add_rPr().get_or_add_rFonts()
    rf.set(qn("w:eastAsia"), FONT)
    rf.set(qn("w:cs"), FONT)

    s = doc.sections[0]
    s.page_width, s.page_height = Twips(KHO_A4[0]), Twips(KHO_A4[1])
    s.top_margin, s.bottom_margin = Twips(LE["tren"]), Twips(LE["duoi"])
    s.left_margin, s.right_margin = Twips(LE["trai"]), Twips(LE["phai"])
    # Mặc định 1,25cm thì đầu trang lấn qua lề trên 2cm, đẩy cả văn bản thấp
    # hơn mẫu 2mm
    s.header_distance, s.footer_distance = Twips(LE_DAU_TRANG), Twips(0)
    _che_do_word(doc)
    _so_trang(s)

    _dau_van_ban(doc, tt, ngay)

    giua = WD_ALIGN_PARAGRAPH.CENTER
    # Khoảng cách trên "BIÊN BẢN" đã có sẵn nhờ hàng trống của bảng đầu văn bản
    chu(dinh_dang(doc.add_paragraph(), can=giua, gian=GIAN_TIEU_DE),
        "BIÊN BẢN", dam=True)
    chu(dinh_dang(doc.add_paragraph(), can=giua, gian=GIAN_TIEU_DE),
        tt.get("ten_cuoc_hop") or "Cuộc họp", dam=True)
    duong_ke(doc, BE_NGANG_CHU, KE_DUOI_TRICH_YEU)
    dong_trong(doc, gian=(GIAN_TIEU_DE[0], 0, 3))

    def dong_than(text: str):
        p = dinh_dang(doc.add_paragraph(), dau_dong=THUT_DAU_DONG)
        chu_co_danh_dau(p, text, bc=bc)

    def dong_gach(text: str):
        p = dinh_dang(doc.add_paragraph(), trai=THUT_GACH + cm(0.5), treo=cm(0.5))
        chu_co_danh_dau(p, f"- {text}", bc=bc)

    dong_than(f"Thời gian: {tt.get('thoi_gian') or CHAM}")
    dong_than(f"Địa điểm: {tt.get('dia_diem') or CHAM}")
    dong_than("Thành phần tham dự:")
    dong_gach(f"Chủ trì: {tt.get('chu_tri') or CHAM}")
    dong_gach(f"Thư ký: {tt.get('thu_ky') or CHAM}")
    cac_nguoi = [x.strip() for x in (tt.get("tham_du") or "").splitlines() if x.strip()]
    dong_gach(f"Tham dự: {', '.join(cac_nguoi) if cac_nguoi else CHAM}")

    cac_khoi = tach_than_bai(noi_dung, tt.get("ten_cuoc_hop", ""))
    for i, (loai, gia_tri) in enumerate(cac_khoi):
        if loai == "muc":
            p = dinh_dang(doc.add_paragraph(), dau_dong=THUT_DAU_DONG, giu_voi_sau=True)
            chu(p, gia_tri, dam=True)
            # Mục trống, như KẾT LUẬN của khung chưa soạn: chừa chỗ cho thư ký viết
            if i + 1 == len(cac_khoi) or cac_khoi[i + 1][0] == "muc":
                dong_than(CHAM * 8)
        elif loai == "gach":
            dong_gach(gia_tri)
        elif loai == "bang":
            _bang_du_lieu(doc, gia_tri, bc)
        else:
            dong_than(gia_tri)

    dong_than(f"Biên bản kết thúc vào {gio_ket_thuc or f'{CHAM} giờ {CHAM} phút'} cùng ngày.")
    doc.paragraphs[-1].paragraph_format.keep_with_next = True
    dong_than(f"Biên bản được lập thành {CHAM} bản./.")
    doc.paragraphs[-1].paragraph_format.keep_with_next = True
    _chu_ky(doc, tt)

    duong_ra = Path(duong_ra)
    tam = duong_ra.with_suffix(".tam.docx")
    doc.save(tam)
    tam.replace(duong_ra)  # lưu rồi mới đổi tên, tắt máy giữa chừng không để lại tệp hỏng
    return duong_ra


def ten_tep_word(tt: dict, ngay: date) -> str:
    """Theo quy ước đặt tên của kho: YYMMDD_TTC_BienBan_GiaoBanTuan.docx"""
    ten = re.sub(r"^\s*họp\s+", "", tt.get("ten_cuoc_hop") or "", flags=re.IGNORECASE)
    tu = re.sub(r"[^A-Za-z0-9 ]", " ", khong_dau(ten)).split()[:3]
    ngan = "".join(w[:1].upper() + w[1:].lower() for w in tu) or "CuocHop"
    return f"{ngay:%y%m%d}_TTC_BienBan_{ngan}.docx"


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("Cách dùng: tao_word.py bien-ban.txt ra.docx")
    vao = Path(sys.argv[1]).read_text(encoding="utf-8")
    ra = dung_bien_ban(vao, {"ten_cuoc_hop": "Cuộc họp chạy thử"}, date.today(),
                       None, Path(sys.argv[2]))
    print(f"Đã tạo {ra}")
