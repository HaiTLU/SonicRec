#!/usr/bin/env python3
"""Kiểm nhanh sau khi cài SonicRec: khoảng 20 giây, chạy ở cuối mọi trình cài.

Trước 30/9/2026 trình cài chạy cả bộ kiem_thu.py (680 phép, 4 đến 5 phút trên máy thử của
GitHub), chiếm gần hết thời gian cài. PM chốt 30/9/2026: khi cài chỉ kiểm nhanh. Bộ đầy đủ
vẫn chạy ở luồng GitHub trên máy Mac và Windows thật trước mỗi bản phát hành, và chạy tay
được: nút Kiểm tra đầy đủ ở thẻ Cài đặt, hoặc

    cd ~/bien-ban-hop && .venv/bin/python kiem_thu.py
    (Windows: cd %USERPROFILE%\\bien-ban-hop  rồi  .venv\\Scripts\\python -X utf8 kiem_thu.py)

Bước này chỉ hỏi đúng những thứ hay hỏng lúc cài: thiếu thành phần, thiếu ffmpeg, mã không
nạp được, máy chủ không bật được, không dựng được tệp Word, thư mục lưu không ghi được.
Mọi thứ chạy trong thư mục tạm, không đụng cuộc họp thật, không gọi Google.

Dòng cuối là "<đạt>/<tổng> phép đạt", cùng dạng với kiem_thu.py để trình cài đọc chung.
Mã thoát 0 là đạt hết, 1 là có phép trượt.
"""

import json
import os
import shutil
import socket
import struct
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
import warnings
from datetime import date
from pathlib import Path

warnings.filterwarnings("ignore")  # tiếng ồn của thư viện, không liên quan

THU_MUC = Path(__file__).resolve().parent
TAM = Path(tempfile.mkdtemp(prefix="kiem-nhanh-"))
# Như kiem_thu.py: không bao giờ đọc phiên đăng nhập Google thật, không xem kho bản mới,
# không đụng thư mục lưu các cuộc họp thật
os.environ.update(THU_MUC_LUU=str(TAM / "cac-cuoc-hop"), NOTEBOOKLM_HOME=str(TAM / "nlm"),
                  KHO_BAN_MOI="", PYTHONUTF8="1")
os.environ.pop("GHI_AM_NGUON", None)
sys.path.insert(0, str(THU_MUC))

# Các gói ứng dụng cần: (tên gói, tên để nạp). Thêm gói mới vào trình cài thì thêm ở đây.
CAC_GOI = (("fastapi", "fastapi"), ("uvicorn", "uvicorn"), ("httpx", "httpx"),
           ("python-docx", "docx"), ("python-multipart", "multipart"),
           ("notebooklm-py", "notebooklm"), ("playwright", "playwright"),
           ("segno", "segno"))
if sys.platform in ("darwin", "win32"):
    # Trên Mac và Windows, ffmpeg đi kèm gói này (trình cài lấy nó, không cần tải riêng)
    CAC_GOI += (("imageio-ffmpeg", "imageio_ffmpeg"),)

DAT: list[str] = []
TRUOT: list[str] = []
BAT_DAU = time.monotonic()
# CHỈ ĐỂ THỬ BỘ KIỂM (kiem_thu.py cài lỗi cố ý): BBH_KIEM_NHANH_GIA_LOI=ffmpeg,may-chu,word,ma,
# thu-muc,nap-<tên gói> làm phép kiểm đó trượt, để chắc mỗi phép thật sự bắt được lỗi
GIA_LOI = {x for x in os.environ.get("BBH_KIEM_NHANH_GIA_LOI", "").split(",") if x}


def gia_loi(ten: str) -> None:
    if ten in GIA_LOI:
        raise RuntimeError(f"giả lỗi {ten} để thử bước kiểm")


def kiem(ten: str, dat: bool, ghi_chu: str = "") -> None:
    (DAT if dat else TRUOT).append(ten)
    print(f"  [{'DAT ' if dat else 'TRUOT'}] {ten}" + (f": {ghi_chu}" if ghi_chu else ""),
          flush=True)


def chay(ten: str, ham) -> None:
    """Một phép kiểm. ham trả True/False, hoặc (True/False, ghi chú). Lỗi bất kỳ là trượt
    và ghi tên lỗi; các phép sau vẫn chạy để một lần in ra đủ các chỗ hỏng."""
    try:
        ket = ham()
        dat, ghi = ket if isinstance(ket, tuple) else (bool(ket), "")
    except Exception as loi:  # noqa: BLE001 - phép kiểm nào hỏng cũng chỉ là một phép trượt
        dat, ghi = False, f"{type(loi).__name__}: {loi}"
    kiem(ten, dat, ghi)


def mo_khong_qua_proxy(url: str) -> bytes:
    """Gọi máy chủ ngay trên máy này. Không đi qua proxy của hệ thống: máy ở mạng có proxy
    (hay luồng thử chặn mạng bằng proxy giả) sẽ không tới được 127.0.0.1."""
    mo = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with mo.open(url, timeout=8) as r:
        return r.read()


# ----------------------------------------------------------------------------
# 1. Python và các thành phần
# ----------------------------------------------------------------------------
chay("Python 3.10 trở lên, 64 bit",
     lambda: (sys.version_info >= (3, 10) and struct.calcsize("P") == 8, sys.version.split()[0]))


def nap_duoc(ten_nap: str):
    def ham():
        gia_loi("nap-" + ten_nap)
        __import__(ten_nap)
        return True
    return ham


for ten_goi, ten_nap in CAC_GOI:
    chay(f"thành phần {ten_goi} nạp được", nap_duoc(ten_nap))

# Cửa sổ riêng (pywebview) không bắt buộc: thiếu thì ứng dụng mở bằng trình duyệt, vẫn đủ
# chức năng. Chỉ báo, không tính là phép trượt.
if sys.platform in ("darwin", "win32"):
    try:
        import webview  # noqa: F401
        print("  (cửa sổ riêng: nạp được)")
    except Exception as loi:  # noqa: BLE001
        print(f"  (cửa sổ riêng chưa nạp được, ứng dụng sẽ mở bằng trình duyệt: {type(loi).__name__})")

# ----------------------------------------------------------------------------
# 2. Mã ứng dụng và các tệp của gói
# ----------------------------------------------------------------------------
bbh = None


def nap_ma_ung_dung():
    global bbh
    gia_loi("ma")
    import bien_ban_hop
    import kich_hoat
    # Không bao giờ đọc hay ghi mã kích hoạt thật; chạy như chưa bật khoá (như kiem_thu.py)
    kich_hoat.TEP_KICH_HOAT = TAM / "kich-hoat.json"
    kich_hoat.KHOA_CONG_KHAI = ()
    bbh = bien_ban_hop
    return True, f"{bbh.TEN_BAN}, mã {bbh.PHIEN_BAN}"


chay("mã ứng dụng nạp được", nap_ma_ung_dung)


def du_tep():
    thieu = [t for t in (bbh.TEP_PHIEN_BAN if bbh else ()) if not (THU_MUC / t).is_file()]
    thieu += [t for t in ("thong_tin_cuoc_hop.json", "tai_nguyen/hinh/bieu-tuong.png",
                          "tai_nguyen/phong/BeVietnamPro-400-latin.woff2")
              if not (THU_MUC / t).is_file()]
    return not thieu and bbh is not None, ("thiếu " + ", ".join(thieu)) if thieu else ""


chay("đủ các tệp của gói", du_tep)

# ----------------------------------------------------------------------------
# 3. ffmpeg (phần ghi âm)
# ----------------------------------------------------------------------------
FFMPEG = [None]


def chay_ffmpeg(doi_so: list[str], han: int = 30) -> subprocess.CompletedProcess:
    return subprocess.run([FFMPEG[0], "-hide_banner", *doi_so], capture_output=True, timeout=han,
                          creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))


def co_ffmpeg():
    # Tìm đúng như ứng dụng tìm: thư mục ffmpeg cạnh mã trước, rồi PATH
    gia_loi("ffmpeg")
    import ung_dung
    ung_dung.them_duong_tim()
    FFMPEG[0] = shutil.which("ffmpeg")
    if not FFMPEG[0]:
        return False, "không thấy ffmpeg"
    ra = chay_ffmpeg(["-version"])
    dong = ra.stdout.decode("utf-8", "replace").splitlines()[:1]
    return ra.returncode == 0 and "ffmpeg version" in " ".join(dong), " ".join(dong)[:60]


chay("ffmpeg chạy được", co_ffmpeg)


def ma_hoa_aac():
    """Đúng lệnh ghi âm của ghi_am.py: mã hoá tiếng vào AAC dạng ADTS."""
    if not FFMPEG[0]:
        return False, "chưa có ffmpeg"
    ra = chay_ffmpeg(["-loglevel", "error", "-f", "lavfi", "-i",
                      "sine=frequency=440:sample_rate=16000:duration=1", "-ac", "1", "-ar", "16000",
                      "-c:a", "aac", "-b:a", "48k", "-f", "adts", "pipe:1"])
    du_lieu = ra.stdout
    # Tệp ADTS bắt đầu bằng dấu đồng bộ 12 bit 1
    return (ra.returncode == 0 and len(du_lieu) > 300 and du_lieu[0] == 0xFF
            and (du_lieu[1] & 0xF0) == 0xF0), f"{len(du_lieu)} byte"


chay("ffmpeg mã hoá được tiếng thành AAC như lúc ghi âm", ma_hoa_aac)


def co_thu_micro():
    if not FFMPEG[0]:
        return False, "chưa có ffmpeg"
    cach = {"darwin": "avfoundation", "win32": "dshow"}.get(sys.platform)
    if cach is None:
        return True, "máy này không phải Mac hay Windows: bỏ qua"
    ra = chay_ffmpeg(["-devices"])
    return cach in ra.stdout.decode("utf-8", "replace"), cach


chay("ffmpeg có phần thu micro của máy này", co_thu_micro)

# ----------------------------------------------------------------------------
# 4. Máy chủ, tệp Word, thư mục lưu
# ----------------------------------------------------------------------------


def may_chu_bat_duoc():
    gia_loi("may-chu")
    import uvicorn
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        cong = s.getsockname()[1]
    may = uvicorn.Server(uvicorn.Config(bbh.app, host="127.0.0.1", port=cong, log_level="error"))
    luong = threading.Thread(target=may.run, daemon=True)
    luong.start()
    het = time.monotonic() + 25
    try:
        while not may.started:
            if not luong.is_alive() or time.monotonic() > het:
                return False, "máy chủ không bật được"
            time.sleep(0.05)
        thong_tin = json.loads(mo_khong_qua_proxy(f"http://127.0.0.1:{cong}/may/thong-tin"))
        trang = mo_khong_qua_proxy(f"http://127.0.0.1:{cong}/").decode("utf-8", "replace")
    finally:
        may.should_exit = True
        luong.join(5)
    return "truong" in thong_tin and "<html" in trang.lower() and "SonicRec" in trang, ""


chay("máy chủ bật được và trả trang giao diện", may_chu_bat_duoc)


def xuat_word_duoc():
    gia_loi("word")
    import tao_word
    from docx import Document
    tt = {"ten_cuoc_hop": "Họp thử", "thoi_gian": "8 giờ 30", "dia_diem": "Phòng họp",
          "chu_tri": "Anh A", "thu_ky": "Chị B", "tham_du": "Chị Lan\nAnh Bình"}
    noi_dung = ("## 2. NỘI DUNG\nChị Lan báo cáo khoá MOS có 32 học viên.\n"
                "## 3. PHÂN CÔNG\n| Việc | Người phụ trách | Hạn hoàn thành |\n|---|---|---|\n"
                "| Hoàn thiện hồ sơ khoá MOS | Chị Lan | 30/9 |\n")
    ra = tao_word.dung_bien_ban(noi_dung, tt, date(2026, 9, 30), "9 giờ 28 phút", TAM / "thu.docx")
    chu = "\n".join(p.text for p in Document(str(ra)).paragraphs)
    return "BIÊN BẢN" in chu and "Chị Lan báo cáo" in chu, f"{ra.stat().st_size} byte"


chay("dựng được tệp Word biên bản rồi đọc lại đúng", xuat_word_duoc)


def thu_muc_luu_ghi_duoc():
    gia_loi("thu-muc")
    try:
        chon = str(json.loads((THU_MUC / "cau-hinh-may.json").read_text(encoding="utf-8"))
                   .get("thu_muc_luu") or "").strip()
    except (OSError, ValueError, AttributeError):
        chon = ""
    thu = Path(chon) if chon else THU_MUC / "cac-cuoc-hop"
    if not thu.is_dir():
        thu = thu.parent  # chưa có thư mục thì thử chỗ sẽ tạo nó, không tạo thừa
    tep = thu / f".kiem-nhanh-{os.getpid()}"
    tep.write_bytes(b"x")
    tep.unlink()
    return True, str(thu)


chay("thư mục lưu các cuộc họp ghi được", thu_muc_luu_ghi_duoc)

# ----------------------------------------------------------------------------
shutil.rmtree(TAM, ignore_errors=True)
print(f"\nKiểm nhanh xong sau {time.monotonic() - BAT_DAU:.0f} giây.")
print(f"{len(DAT)}/{len(DAT) + len(TRUOT)} phép đạt")
if TRUOT:
    print("TRƯỢT: " + "; ".join(TRUOT))
sys.exit(1 if TRUOT else 0)
