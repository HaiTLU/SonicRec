#!/usr/bin/env python3
"""Mở ứng dụng SonicRec (trước 28/9/2026 tên Biên bản họp): bật máy chủ trong nền rồi
mở cửa sổ riêng.

Trên Mac, "SonicRec.app" (do tao_ung_dung.py dựng) chạy tệp này. Trên
Windows, biểu tượng SonicRec ở màn hình (do trình cài tạo) chạy
.venv\\Scripts\\pythonw.exe -X utf8 ung_dung.py. Chạy tay để dò lỗi:
    cd ~/bien-ban-hop && .venv/bin/python ung_dung.py                 cửa sổ riêng
    cd ~/bien-ban-hop && .venv/bin/python ung_dung.py --trinh-duyet   mở bằng trình duyệt

Không mở được cửa sổ riêng (thiếu pywebview, máy không hỗ trợ) thì tự mở bằng
trình duyệt, vẫn dùng đủ mọi chức năng.
"""

import json
import os
import shutil
import socket
import subprocess
import sys
import threading
import time
import traceback
import urllib.request
import webbrowser
from pathlib import Path

THU_MUC = Path(__file__).resolve().parent
TEN = "SonicRec"  # tên ứng dụng, PM đặt 28/9/2026
BIEU_TUONG = THU_MUC / "tai_nguyen" / "hinh" / "bieu-tuong.png"
BIEU_TUONG_MAC = THU_MUC / "tai_nguyen" / "hinh" / "bieu-tuong.icns"
BIEU_TUONG_WIN = THU_MUC / "tai_nguyen" / "hinh" / "bieu-tuong.ico"
LA_MAC = sys.platform == "darwin"

# Chữ trên hộp hỏi và thanh trình đơn của cửa sổ (pywebview mặc định tiếng Anh)
VIET = {
    "global.quitConfirmation": ("Đang ghi âm hoặc đang soạn biên bản. Đóng bây giờ thì việc "
                                "đó dừng lại; phần đã ghi vẫn giữ, lần mở sau bấm Làm lại "
                                "được. Vẫn đóng?"),
    "global.ok": "Đồng ý", "global.quit": "Đóng", "global.cancel": "Thôi",
    "global.saveFile": "Lưu tệp",
    "cocoa.menu.about": "Giới thiệu", "cocoa.menu.services": "Dịch vụ",
    "cocoa.menu.view": "Xem", "cocoa.menu.edit": "Sửa", "cocoa.menu.hide": "Ẩn",
    "cocoa.menu.hideOthers": "Ẩn các ứng dụng khác", "cocoa.menu.showAll": "Hiện tất cả",
    "cocoa.menu.quit": "Thoát", "cocoa.menu.fullscreen": "Toàn màn hình",
    "cocoa.menu.cut": "Cắt", "cocoa.menu.copy": "Chép", "cocoa.menu.paste": "Dán",
    "cocoa.menu.selectAll": "Chọn tất cả",
}


def them_duong_tim() -> None:
    """Mở từ Finder thì PATH chỉ có /usr/bin:/bin. Trình cài đặt ffmpeg ngay trong thư
    mục ứng dụng: Windows ở ffmpeg\\bin, Mac ở ffmpeg (từ 28/9/2026, đi kèm gói
    imageio-ffmpeg, không cần Homebrew). Máy Mac cài bản trước vẫn tìm được ffmpeg của
    Homebrew."""
    if os.name == "nt":
        os.environ["PATH"] = os.pathsep.join([str(THU_MUC / "ffmpeg" / "bin"),
                                              os.environ.get("PATH", "")])
        return
    cu = os.environ.get("PATH") or "/usr/bin:/bin:/usr/sbin:/sbin"
    os.environ["PATH"] = os.pathsep.join([str(THU_MUC / "ffmpeg"), "/opt/homebrew/bin",
                                          "/usr/local/bin", cu])


def ghi_nhat_ky_vao_tep() -> None:
    """Windows mở ứng dụng bằng pythonw, không có cửa sổ lệnh nên chữ in ra bị
    mất. Đưa chữ in và lỗi vào nhat-ky-ung-dung.txt, như trình mở trên Mac làm.
    Tiến trình con (đăng nhập NotebookLM) cũng đọc chữ bằng UTF-8."""
    os.environ.setdefault("PYTHONUTF8", "1")
    if sys.stdout is None or sys.stderr is None:
        tep = open(THU_MUC / "nhat-ky-ung-dung.txt", "a", encoding="utf-8", buffering=1)  # noqa: SIM115
        sys.stdout = sys.stderr = tep


def la_ung_dung_nay(cong: int) -> bool:
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{cong}/may/thong-tin", timeout=2) as r:
            return "truong" in json.load(r)
    except (OSError, ValueError):
        return False


def cong_trong(cong: int) -> bool:
    with socket.socket() as s:
        try:
            s.bind(("127.0.0.1", cong))
            return True
        except OSError:
            return False


def chon_cong() -> tuple[int, bool]:
    """(cổng, đã có một bản đang chạy ở đó chưa). Cổng 8787 bị thứ khác chiếm
    thì dùng cổng kế tiếp, thay vì báo lỗi rồi thôi."""
    goc = int(os.environ.get("CONG", "8787"))
    for cong in range(goc, goc + 20):
        if la_ung_dung_nay(cong):
            return cong, True
        if cong_trong(cong):
            return cong, False
    raise SystemExit(f"Các cổng {goc} tới {goc + 19} đều bận")


def bat_may_chu(cong: int):
    import uvicorn

    import bien_ban_hop as bbh
    so = bbh.nap_lai_lich_su()
    print(f"Các cuộc họp lưu ở {bbh.THU_MUC_LUU} ({so} cuộc họp). Cổng {cong}.")
    may = uvicorn.Server(uvicorn.Config(bbh.app, host="127.0.0.1", port=cong,
                                        log_level="warning"))
    luong = threading.Thread(target=may.run, daemon=True)
    luong.start()
    het = time.monotonic() + 30  # có hạn: máy chủ không lên thì nói ra, đừng đứng chờ mãi
    while not may.started:
        if not luong.is_alive() or time.monotonic() > het:
            raise SystemExit("Máy chủ của ứng dụng không bật được, xem các dòng lỗi phía trên")
        time.sleep(0.05)
    return bbh, may, luong


def giu_may_thuc() -> None:
    """Không cho máy ngủ vì để lâu không đụng bàn phím, trong lúc ứng dụng còn mở:
    ngủ giữa buổi họp là ngừng ghi âm. caffeinate tự tắt theo ứng dụng. Windows
    thì báo hệ thống "đang cần máy" cho tới khi luồng chính (tức ứng dụng) tắt;
    gập máy thì vẫn ngủ, như trên Mac."""
    if os.name == "nt":
        import ctypes
        ES_CONTINUOUS, ES_SYSTEM_REQUIRED = 0x80000000, 0x00000001
        ctypes.windll.kernel32.SetThreadExecutionState(ES_CONTINUOUS | ES_SYSTEM_REQUIRED)
    elif shutil.which("caffeinate"):
        subprocess.Popen(["caffeinate", "-i", "-w", str(os.getpid())])


def dat_ten_ung_dung() -> None:
    """Cửa sổ chạy bằng Python riêng (ứng dụng dựng kiểu gọi riêng, hay mở bằng tệp
    .command) thì Dock hiện hình tên lửa và tên "Python" (PM gửi ảnh 27/9/2026). Đặt
    hình trên Dock bằng biểu tượng SonicRec, đổi tên trên thanh trình đơn. Tên
    phải đổi TRƯỚC khi tạo NSApplication. Không được thì thôi: chỉ là hình thức."""
    if not LA_MAC:
        return
    try:
        from Foundation import NSBundle
        goi = NSBundle.mainBundle()
        cac_info = (goi.infoDictionary(), goi.localizedInfoDictionary())
    except Exception:  # noqa: BLE001 - chỉ là hình thức
        cac_info = ()
    for info in cac_info:
        try:
            if info is not None and info.get("CFBundleName") in (None, "Python"):
                info["CFBundleName"] = TEN
        except Exception:  # noqa: BLE001 - bảng chỉ đọc thì bỏ qua bảng đó
            pass
    try:
        from AppKit import NSApplication, NSImage
        hinh = NSImage.alloc().initWithContentsOfFile_(str(BIEU_TUONG_MAC))
        if hinh is not None:
            NSApplication.sharedApplication().setApplicationIconImage_(hinh)
    except Exception:  # noqa: BLE001 - chỉ là hình thức
        pass


def bieu_tuong_cua_so(nen: str = sys.platform) -> Path:
    """Windows nạp biểu tượng cửa sổ bằng System.Drawing.Icon, chỉ nhận tệp .ico: đưa PNG
    vào thì .NET ném lỗi ở luồng riêng, sập cả ứng dụng và không lùi về trình duyệt được
    (máy Windows của PM, 1/10/2026). Các nền khác nhận PNG."""
    return BIEU_TUONG_WIN if nen == "win32" else BIEU_TUONG


def mo_cua_so(url: str, bbh=None) -> bool:
    """Mở cửa sổ riêng và chờ tới khi đóng. Trả False nếu không mở được."""
    try:
        import webview
    except ImportError:
        print("Chưa cài pywebview, mở bằng trình duyệt thay thế.")
        return False
    dat_ten_ung_dung()
    cua_so = webview.create_window(TEN, url, width=1200, height=820, min_size=(960, 680),
                                   text_select=True, background_color="#f4f8f8")
    if bbh is not None:
        def khi_dong():
            # Chỉ hỏi lại khi đóng giữa lúc đang ghi hay đang soạn; lúc rảnh thì đóng luôn
            cua_so.confirm_close = bool(bbh.MAY_GHI.tt or any(
                v["trang_thai"] not in bbh.XONG for v in bbh.VIEC.values()))
        cua_so.events.closing += khi_dong
        bbh.KHI_TAT = cua_so.destroy  # nút Tắt ứng dụng trong thẻ Cài đặt
    try:
        webview.start(icon=str(bieu_tuong_cua_so()), localization=VIET)
    except Exception:  # noqa: BLE001 - hỏng gì cũng lùi về trình duyệt
        traceback.print_exc()
        return False
    return True


def mo_trinh_duyet(url: str, luong: threading.Thread | None) -> None:
    webbrowser.open(url)
    if luong is None:
        return
    print(f"Đang chạy ở {url}. Tắt bằng nút Tắt ứng dụng trong thẻ Cài đặt, hoặc Ctrl-C.")
    try:
        while luong.is_alive():
            luong.join(1)
    except KeyboardInterrupt:
        pass


def tu_kiem() -> None:
    """tao_ung_dung.py chạy lệnh này để chắc trình mở vừa dựng gọi được đúng
    Python của ~/bien-ban-hop, với đủ các gói."""
    import bien_ban_hop  # noqa: F401
    if sys.platform in ("darwin", "win32"):
        import webview  # noqa: F401
    print(f"TU-KIEM-DAT {sys.executable} {sys.prefix}")


def main() -> None:
    os.chdir(THU_MUC)
    sys.path.insert(0, str(THU_MUC))
    ghi_nhat_ky_vao_tep()
    them_duong_tim()
    if "--tu-kiem" in sys.argv:
        tu_kiem()
        return
    print(f"\n=== Mở lúc {time.strftime('%Y-%m-%d %H:%M:%S')} ===", flush=True)
    trinh_duyet = "--trinh-duyet" in sys.argv
    cong, da_chay = chon_cong()
    url = f"http://127.0.0.1:{cong}/"
    if da_chay:
        # Đã có một bản đang chạy (ví dụ bật từ Terminal): mở thêm cửa sổ vào đó
        if trinh_duyet or not mo_cua_so(url):
            mo_trinh_duyet(url, None)
        return

    bbh, may, luong = bat_may_chu(cong)
    giu_may_thuc()
    try:
        if trinh_duyet or not mo_cua_so(url, bbh):
            bbh.KHI_TAT = lambda: setattr(may, "should_exit", True)
            mo_trinh_duyet(url, luong)
    finally:
        bbh.don_dep()
        may.should_exit = True
        luong.join(5)
        print("Đã tắt.", flush=True)


if __name__ == "__main__":
    main()
