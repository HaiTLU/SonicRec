"""SonicRec: lối vào. Mã ứng dụng đã dịch nằm ở ung_dung.pyc cùng thư mục; tệp này chỉ nạp
tệp đó, để trình mở, lối tắt và tệp Bat Bien Ban Hop vẫn gọi đúng tên cũ."""
import sys
from importlib.machinery import SourcelessFileLoader
from importlib.util import MAGIC_NUMBER, module_from_spec, spec_from_loader
from pathlib import Path

_TEP = Path(__file__).resolve().with_name("ung_dung.pyc")
with open(_TEP, "rb") as _f:
    if _f.read(4) != MAGIC_NUMBER:
        raise SystemExit("SonicRec cần đúng bản Python đi kèm trình cài (máy đang chạy Python "
                         + sys.version.split()[0] + "). Chạy lại trình cài đặt SonicRec.")
_NAP = SourcelessFileLoader(__name__, str(_TEP))
_MO = module_from_spec(spec_from_loader(__name__, _NAP))
sys.modules[__name__] = _MO
_NAP.exec_module(_MO)
