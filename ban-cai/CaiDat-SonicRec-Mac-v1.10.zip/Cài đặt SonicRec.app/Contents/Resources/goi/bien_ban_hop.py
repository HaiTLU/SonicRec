# SonicRec: tệp mốc để máy cài bản v1.6 trở xuống nhận ra gói cài này. Không phải mã ứng
# dụng (mã đã dịch nằm ở bien_ban_hop.pyc); trình cài không chép tệp này vào máy.
SO_BAN = "1.10"
MA_NGUON = "7c0615ad35ae0e682ea2bf89825a413ecfc2e0a4"
