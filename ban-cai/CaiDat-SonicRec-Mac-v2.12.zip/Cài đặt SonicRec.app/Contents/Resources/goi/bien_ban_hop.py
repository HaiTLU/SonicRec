# SonicRec: tệp mốc để máy cài bản v1.6 trở xuống nhận ra gói cài này. Không phải mã ứng
# dụng (mã đã dịch nằm ở bien_ban_hop.pyc); trình cài không chép tệp này vào máy.
SO_BAN = "2.12"
MA_NGUON = "836a1f1b408e6780b8863108420fd3a5ba5402b5"
