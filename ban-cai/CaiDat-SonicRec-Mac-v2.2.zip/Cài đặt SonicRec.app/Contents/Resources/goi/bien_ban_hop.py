# SonicRec: tệp mốc để máy cài bản v1.6 trở xuống nhận ra gói cài này. Không phải mã ứng
# dụng (mã đã dịch nằm ở bien_ban_hop.pyc); trình cài không chép tệp này vào máy.
SO_BAN = "2.2"
MA_NGUON = "4e69b73e73d0ced59246cc9b0039d58c9097b694"
