#!/bin/bash
# ĐƯỜNG DỰ PHÒNG. Bình thường mở ứng dụng SonicRec trong thư mục Ứng dụng.
#
# Bấm đúp vào tệp này khi ứng dụng không mở được, hoặc khi ứng dụng không thu
# được tiếng dù đã cho phép micro. Chạy từ Terminal thì macOS hỏi quyền micro
# cho Terminal, một đường khác hẳn với ứng dụng.
#
# Muốn dừng: đóng cửa sổ SonicRec, hoặc bấm Ctrl-C trong cửa sổ Terminal này.

cd "$(dirname "$0")" || exit 1

cho_bam_enter_roi_thoat() {
  echo ""
  echo "Bấm Enter để đóng cửa sổ này."
  read -r _
  exit 1
}

clear
echo "================================================"
echo "  SONICREC - mở bằng đường dự phòng"
echo "================================================"
echo ""

if [ ! -x ".venv/bin/python" ]; then
  echo "CHƯA CÀI XONG. Chạy lại trình cài đặt SonicRec."
  cho_bam_enter_roi_thoat
fi

.venv/bin/python ung_dung.py || cho_bam_enter_roi_thoat
