"""Ghi âm thẳng trên laptop (Mac hoặc Windows) bằng ffmpeg, kèm đo mức âm để vẽ
vạch âm lượng. Mac lấy micro qua avfoundation, Windows qua dshow; mọi phần khác
dùng chung.

Vì sao ghi ra AAC dạng ADTS mà không ra m4a: m4a ghi phần "mục lục" ở CUỐI
tệp, máy tắt ngang giữa buổi là mất cả tệp. ADTS là chuỗi khung độc lập, cắt
ở đâu cũng đọc được tới đó. Nhờ vậy:
  - máy sập giữa buổi thì phần đã ghi vẫn còn nguyên trên ổ đĩa;
  - tạm dừng chỉ là đóng đoạn đang ghi, tiếp tục là mở đoạn mới;
  - dừng hẳn thì nối các đoạn bằng cách nối byte, không phải mã hoá lại.

Mỗi lần mở đoạn, ffmpeg chạy với HAI đầu ra: tệp AAC để lưu, và luồng âm
thanh thô 8000 mẫu/giây đẩy về cho Python đo mức âm từng 0,1 giây.

Thử khi không có micro (máy Linux, máy chủ kiểm thử): đặt GHI_AM_NGUON, ví dụ
    GHI_AM_NGUON="-re -f lavfi -i sine=frequency=440:sample_rate=48000"
    GHI_AM_NGUON="-re -f lavfi -i anullsrc=r=48000"   (giả lập micro bị chặn)
"""

import array
import math
import os
import re
import shlex
import shutil
import subprocess
import sys
import threading
import time
from collections import deque
from pathlib import Path

MAU_MUC = 8000                 # mẫu mỗi giây của luồng đo mức âm
KHOI_MUC = MAU_MUC // 10 * 2   # 0,1 giây âm thanh 16 bit
# Micro bị chặn quyền thì macOS đưa về toàn số 0 (-120 dB), nhưng micro chọn
# nhầm (micro của iPhone để gần máy, 24/9/2026) lại cho tiếng rè rất nhỏ, khoảng
# -60 dB, lọt qua ngưỡng cũ -65 dB mà không báo gì. Phòng họp có người thì cứ vài
# giây lại có tiếng động trên -55 dB, nên 10 giây liền dưới mức đó là đáng ngờ.
IM_LANG_DB = -55.0
IM_LANG_GIAY = 10.0
TEP_GHI = "ghi-am.aac"
# Windows: ứng dụng chạy bằng pythonw (không có cửa sổ lệnh), nên mỗi lần gọi
# ffmpeg sẽ bật một cửa sổ lệnh đen nếu không dặn ẩn đi
LA_WINDOWS = os.name == "nt"
AN_CUA_SO = {"creationflags": subprocess.CREATE_NO_WINDOW} if LA_WINDOWS else {}


def nguon_thu() -> list[str]:
    """Nguồn giả thay cho micro, đọc lại mỗi lần để bộ kiểm thử đổi được."""
    return shlex.split(os.environ.get("GHI_AM_NGUON", ""))


def doc_danh_sach_micro(chu: str) -> list[tuple[int, str]]:
    """Tách (số, tên) các micro từ dòng in của: ffmpeg -f avfoundation -list_devices true"""
    ds, trong_muc_am = [], False
    for dong in chu.splitlines():
        if "audio devices" in dong:
            trong_muc_am = True
            continue
        if "video devices" in dong:
            trong_muc_am = False
            continue
        m = re.search(r"\]\s*\[(\d+)\]\s*(.+?)\s*$", dong)
        if trong_muc_am and m:
            ds.append((int(m.group(1)), m.group(2)))
    return ds


def doc_danh_sach_micro_windows(chu: str) -> list[tuple[str, str]]:
    """Tách (mã, tên) các micro từ dòng in của:
        ffmpeg -list_devices true -f dshow -i dummy

    ffmpeg mới ghi loại thiết bị ngay sau tên: "Tên" (audio). ffmpeg cũ chia
    thành mục "DirectShow audio devices". Mã là "tên thay thế" (@device_cm_...)
    nếu có: nó không có dấu hai chấm hay chữ có dấu như tên hiển thị, nên đưa
    vào lệnh ffmpeg không vỡ."""
    ds, muc = [], None
    for dong in chu.splitlines():
        if "DirectShow audio devices" in dong:
            muc = "audio"
            continue
        if "DirectShow video devices" in dong:
            muc = "video"
            continue
        m = re.search(r'Alternative name\s+"(.+)"\s*$', dong)
        if m:
            if ds:
                ds[-1][0] = m.group(1)
            continue
        m = re.search(r'\]\s+"(.+)"(?:\s+\(([^)]*)\))?\s*$', dong)
        if m:
            loai = m.group(2)
            la_am = "audio" in loai if loai is not None else muc == "audio"
            ds.append([m.group(1), m.group(1), la_am])
    return [(ma, ten) for ma, ten, la_am in ds if la_am]


def cac_micro() -> list[tuple]:
    """Các micro trên máy, dạng (mã đưa cho ffmpeg, tên hiển thị)."""
    if nguon_thu():
        return [(0, "Nguồn thử (GHI_AM_NGUON)")]
    if not shutil.which("ffmpeg"):
        return []
    if LA_WINDOWS:
        lenh = ["ffmpeg", "-hide_banner", "-list_devices", "true", "-f", "dshow", "-i", "dummy"]
        doc = doc_danh_sach_micro_windows
    elif sys.platform == "darwin":
        lenh = ["ffmpeg", "-hide_banner", "-f", "avfoundation", "-list_devices", "true", "-i", ""]
        doc = doc_danh_sach_micro
    else:
        return []
    try:
        ra = subprocess.run(lenh, capture_output=True, timeout=15, **AN_CUA_SO)
    except (subprocess.SubprocessError, OSError):
        return []
    # ffmpeg in tên thiết bị bằng UTF-8; Windows mặc định đọc bằng bảng mã khác
    return doc(ra.stderr.decode("utf-8", "replace"))


# Thiết bị âm thanh ẢO do phần mềm họp trực tuyến cài vào. Chúng gần như không
# có tiếng, và "Microsoft Teams Audio" lại chứa chữ "Micr" nên dễ bị chọn nhầm.
# Stereo Mix của Windows thu tiếng máy phát ra, không phải tiếng trong phòng.
MICRO_AO = ("teams", "zoom", "blackhole", "soundflower", "loopback", "virtual",
            "aggregate", "krisp", "obs ", "webex", "discord", "ảo",
            "stereo mix", "trộn âm", "cable output", "vb-audio", "voicemeeter")
# Micro của iPhone, iPad để gần máy (tính năng Continuity của Apple). macOS liệt
# kê nó như một micro thường, nhưng nó chỉ có tiếng khi điện thoại đang nối với
# máy; điện thoại khoá màn hình, ở xa hay có cuộc gọi là mất tiếng. Máy từng chọn
# nhầm nó thay micro của MacBook, bản ghi gần như im lặng, Whisper bịa chữ.
# Tai nghe Bluetooth trên Windows ("Hands-Free") cùng loại: chỉ nghe người đeo.
MICRO_DIEN_THOAI = ("iphone", "ipad", "hands-free")
# Micro gắn trong máy, theo tên macOS và Windows đặt bằng tiếng Anh và tiếng Việt
MICRO_GAN_TRONG = ("macbook", "imac", "built-in", "tích hợp", "studio display",
                   "microphone array", "mảng micrô", "internal", "realtek", "smart sound",
                   "conexant")


def la_micro_ao(ten: str) -> bool:
    return any(a in ten.lower() for a in MICRO_AO)


def hang_micro(ten: str) -> int:
    """Thứ tự ưu tiên khi tự chọn: số nhỏ đứng trước."""
    t = ten.lower()
    if la_micro_ao(ten):
        return 3
    if any(x in t for x in MICRO_DIEN_THOAI):
        return 2
    if any(x in t for x in MICRO_GAN_TRONG):
        return 0
    return 1  # micro rời cắm vào máy


def chon_micro(ds: list[tuple], ten_muon: str | None) -> tuple | None:
    """Micro người dùng đã chọn nếu còn cắm, không thì tự chọn: micro gắn trong
    máy trước, rồi micro rời, rồi micro của điện thoại, cuối cùng thiết bị ảo.

    Chọn theo TÊN chứ không theo số: số thứ tự đổi mỗi khi cắm rút tai nghe."""
    if not ds:
        return None
    for so, ten in ds:
        if ten_muon and ten == ten_muon:
            return so, ten
    return min(ds, key=lambda x: hang_micro(x[1]))  # cùng hạng thì giữ thứ tự của máy


def _dau_vao(ma) -> list[str]:
    if nguon_thu():
        return nguon_thu()
    if LA_WINDOWS:
        return ["-f", "dshow", "-i", f"audio={ma}"]
    return ["-f", "avfoundation", "-i", f":{ma}"]


def muc_db(khoi: bytes) -> float:
    """Mức âm trung bình (RMS) của một khối, tính bằng dB so với mức tối đa."""
    a = array.array("h")
    a.frombytes(khoi[:len(khoi) // 2 * 2])
    if not a:
        return -120.0
    rms = math.sqrt(sum(x * x for x in a) / len(a))
    return 20 * math.log10(rms / 32768) if rms > 0 else -120.0


# Tần số lấy mẫu theo chỉ số ghi trong đầu mỗi khung ADTS
TAN_SO_ADTS = (96000, 88200, 64000, 48000, 44100, 32000, 24000, 22050,
               16000, 12000, 11025, 8000, 7350)


def _do_dai_khung(b: bytes, p: int) -> int:
    """Độ dài khung ADTS bắt đầu ở vị trí p, hoặc 0 nếu ở đó không phải đầu khung."""
    if p + 7 > len(b) or b[p] != 0xFF or (b[p + 1] & 0xF6) != 0xF0:
        return 0
    if (b[p + 2] >> 2) & 0x0F >= len(TAN_SO_ADTS):
        return 0
    dai = ((b[p + 3] & 0x03) << 11) | (b[p + 4] << 3) | (b[p + 5] >> 5)
    return dai if dai >= 7 else 0


def tach_khung_adts(du_lieu: bytes, het: bool = False) -> tuple[bytes, int, float]:
    """Lấy các khung ADTS nguyên vẹn từ đầu du_lieu, để gửi phần vừa ghi đi mà
    không phải ngắt ghi âm. Trả (các khung ghép lại, số byte đã đi qua, số giây).

    Khung cuối đang ghi dở thì dừng trước nó, lần sau đọc tiếp; het=True (đã dừng
    ghi) thì bỏ luôn phần dở đó. Gặp rác, như khung bị cắt cụt khi ffmpeg bị giết
    giữa chừng rồi đoạn sau nối liền vào, thì dò tới đầu khung kế tiếp."""
    n, p, giay = len(du_lieu), 0, 0.0
    ra = bytearray()
    while p < n:
        dai = _do_dai_khung(du_lieu, p)
        if not dai:
            if n - p < 7 and not het:
                break  # chưa đủ byte để đọc đầu khung: chờ lần sau
            p += 1
            continue
        sau = p + dai
        if sau > n:
            if not het:
                break  # khung đang ghi dở
            p += 1
            continue
        if n - sau >= 7 and not _do_dai_khung(du_lieu, sau):
            p += 1  # sau khung này không phải đầu khung: độ dài sai, khung bị cắt cụt
            continue
        ra += du_lieu[p:sau]
        giay += 1024 * ((du_lieu[p + 6] & 0x03) + 1) / TAN_SO_ADTS[(du_lieu[p + 2] >> 2) & 0x0F]
        p = sau
    return bytes(ra), p, giay


def doc_tu_vi_tri(cac_tep: list[Path], vi_tri: int) -> bytes:
    """Đọc các tệp nối liền như thể một tệp, từ vị trí byte vi_tri tới hết."""
    ra = bytearray()
    for tep in cac_tep:
        with tep.open("rb") as f:
            co = f.seek(0, 2)
            if vi_tri >= co:
                vi_tri -= co
                continue
            f.seek(vi_tri)
            ra += f.read()
            vi_tri = 0
    return bytes(ra)


def cat_tu_tep(tep: Path, con_tro: int) -> tuple[bytes, int, float]:
    """Phần còn lại của bản ghi đã dừng (ghi-am.aac), tính từ con_tro. Con trỏ
    dùng chung với MayGhi.cat_phan_moi vì ghi-am.aac là các đoạn nối liền byte."""
    du_lieu = doc_tu_vi_tri([tep], con_tro)
    khung, qua, giay = tach_khung_adts(du_lieu, het=True)
    return khung, con_tro + qua, giay


def noi_doan(thu_muc: Path) -> Path | None:
    """Nối các đoạn doan-01.aac, doan-02.aac... thành ghi-am.aac rồi xoá các đoạn.

    Dùng cả lúc dừng bình thường lẫn lúc cứu bản ghi sau khi máy sập. Chạy lại
    bao nhiêu lần cũng ra cùng kết quả: các đoạn chỉ bị xoá SAU khi tệp nối đã
    nằm yên trên ổ đĩa."""
    doan = sorted(thu_muc.glob("doan-*.aac"))
    dich = thu_muc / TEP_GHI
    if not doan:
        return dich if dich.is_file() and dich.stat().st_size else None
    tam = thu_muc / (TEP_GHI + ".tam")
    with tam.open("wb") as ra:
        for d in doan:
            ra.write(d.read_bytes())
    if not tam.stat().st_size:
        tam.unlink()
        return None
    tam.replace(dich)
    for d in doan:
        d.unlink(missing_ok=True)
    return dich


def _dung_tien_trinh(tien_trinh: subprocess.Popen) -> None:
    """Bấm q cho ffmpeg tự đóng tệp; quá 10 giây thì giết. ADTS không cần
    đóng tệp cho đúng, nên giết cũng không mất phần đã ghi."""
    try:
        tien_trinh.stdin.write(b"q")
        tien_trinh.stdin.flush()
        tien_trinh.stdin.close()
    except (OSError, ValueError):
        pass
    try:
        tien_trinh.wait(timeout=10)
    except subprocess.TimeoutExpired:
        tien_trinh.kill()
        tien_trinh.wait(timeout=5)


def thu_micro(ma, giay: float = 3.0) -> tuple[float | None, str]:
    """Ghi thử vài giây, trả (mức to nhất dB, lỗi). Lần đầu chạy, bước này làm
    macOS hỏi quyền dùng micro: hỏi TRƯỚC buổi họp thì hơn là giữa buổi."""
    lenh = ["ffmpeg", "-hide_banner", "-loglevel", "error", *_dau_vao(ma),
            "-t", str(giay), "-ac", "1", "-ar", str(MAU_MUC), "-f", "s16le", "pipe:1"]
    try:
        # 60 giây: đủ cho người dùng đọc và bấm hộp hỏi quyền của macOS
        ra = subprocess.run(lenh, capture_output=True, timeout=60, **AN_CUA_SO)
    except subprocess.TimeoutExpired:
        return None, "Thử micro quá 60 giây chưa xong. Bấm thử lại."
    except OSError as loi:
        return None, str(loi)
    if not ra.stdout:
        return None, ra.stderr.decode("utf-8", "replace").strip()[-300:] or "ffmpeg không trả âm thanh"
    cao = max(muc_db(ra.stdout[i:i + KHOI_MUC]) for i in range(0, len(ra.stdout), KHOI_MUC))
    return cao, ""


class MayGhi:
    """Một cuộc ghi âm tại một thời điểm. Mọi hàm ở đây chạy ĐỒNG BỘ, máy chủ
    gọi qua asyncio.to_thread vì dừng ffmpeg có thể mất vài giây."""

    def __init__(self) -> None:
        self.khoa = threading.Lock()
        # Giữ khi đọc các tệp đoạn (cắt phần mới) và khi nối chúng lúc dừng, để
        # không đọc trúng tệp đang bị nối rồi xoá
        self.khoa_tep = threading.Lock()
        self.khoa_do = threading.Lock()  # đo số giây âm thanh: mỗi lúc một lượt đếm
        self._dat_lai()

    def _dat_lai(self) -> None:
        self.tt: str | None = None        # None, "ghi" hoặc "tam-dung"
        self.ma: str | None = None
        self.thu_muc: Path | None = None
        self.micro: tuple | None = None   # (mã đưa cho ffmpeg, tên hiển thị)
        self.so_doan = 0
        self.tien_trinh: subprocess.Popen | None = None
        self.giay_truoc = 0.0             # tổng giây các đoạn đã đóng
        self.luc_mo_doan: float | None = None
        self.co_tieng_luc = 0.0           # lần cuối nghe thấy tiếng
        self.muc: deque[float] = deque(maxlen=48)
        self.loi: str | None = None
        self._do_byte, self._do_giay = 0, 0.0  # đã đếm tới byte nào, được bao nhiêu giây

    def bat_dau(self, ma: str, thu_muc: Path, micro: tuple) -> None:
        with self.khoa:
            if self.tt:
                raise RuntimeError("Đang ghi một cuộc họp khác")
            self._dat_lai()
            self.ma, self.thu_muc, self.micro = ma, thu_muc, micro
            self._mo_doan()

    def _mo_doan(self) -> None:
        """Gọi khi đang giữ khoá."""
        self.so_doan += 1
        tep = self.thu_muc / f"doan-{self.so_doan:02d}.aac"
        # Lỗi của ffmpeg ghi ra tệp, không hứng vào ống: ống đầy mà không ai đọc
        # thì ffmpeg đứng lại, tức là ngừng ghi âm mà không ai biết.
        nhat_ky = (self.thu_muc / "ghi-am-nhat-ky.txt").open("ab")
        # -flush_packets 1: ghi từng khung xuống ổ ngay. Thiếu nó, ffmpeg 6.1 giữ âm
        # thanh trong bộ nhớ tới lúc tắt: thử ngày 26/9/2026, ghi 30 giây rồi tắt ngang
        # thì tệp 0 byte, mất sạch. Trợ lý trong buổi họp cũng cần tệp đầy dần để cắt đoạn.
        lenh = ["ffmpeg", "-hide_banner", "-loglevel", "error", *_dau_vao(self.micro[0]),
                "-map", "0:a", "-ac", "1", "-ar", "16000", "-c:a", "aac", "-b:a", "48k",
                "-flush_packets", "1", "-f", "adts", str(tep),
                "-map", "0:a", "-ac", "1", "-ar", str(MAU_MUC), "-f", "s16le", "pipe:1"]
        try:
            tien_trinh = subprocess.Popen(lenh, stdin=subprocess.PIPE,
                                          stdout=subprocess.PIPE, stderr=nhat_ky, **AN_CUA_SO)
        finally:
            nhat_ky.close()
        self.tien_trinh = tien_trinh
        self.luc_mo_doan = self.co_tieng_luc = time.monotonic()
        self.tt, self.loi = "ghi", None
        threading.Thread(target=self._doc_muc, args=(tien_trinh,), daemon=True).start()

    def _dong_doan(self) -> subprocess.Popen | None:
        """Gọi khi đang giữ khoá. Tách tiến trình ra để dừng nó NGOÀI khoá."""
        tien_trinh, self.tien_trinh = self.tien_trinh, None
        if self.luc_mo_doan is not None:
            self.giay_truoc += time.monotonic() - self.luc_mo_doan
            self.luc_mo_doan = None
        return tien_trinh

    def _doc_muc(self, tien_trinh: subprocess.Popen) -> None:
        """Đọc luồng âm thô liên tục. Phải đọc không ngừng, không thì ống đầy
        và ffmpeg đứng lại."""
        while khoi := tien_trinh.stdout.read(KHOI_MUC):
            db = muc_db(khoi)
            with self.khoa:
                if tien_trinh is not self.tien_trinh:
                    continue
                self.muc.append(db)
                if db > IM_LANG_DB:
                    self.co_tieng_luc = time.monotonic()
        tien_trinh.wait()
        with self.khoa:
            if tien_trinh is not self.tien_trinh:
                return  # do mình dừng, không phải lỗi
            # ffmpeg tự tắt giữa chừng: rút micro, máy báo lỗi thiết bị... Tự
            # chuyển sang tạm dừng và NÓI RA, đừng để đồng hồ chạy tiếp như
            # đang ghi trong khi thật ra không ghi gì.
            self._dong_doan()
            self.tt = "tam-dung"
            cuoi = ""
            try:
                cuoi = (self.thu_muc / "ghi-am-nhat-ky.txt").read_text(
                    encoding="utf-8", errors="replace").strip().splitlines()[-1][:200]
            except (OSError, IndexError):
                pass
            self.loi = ("Ghi âm bị ngắt giữa chừng, có thể do micro bị rút ra. Phần đã "
                        "ghi vẫn còn. Kiểm tra micro rồi bấm Ghi tiếp."
                        + (f" Chi tiết: {cuoi}" if cuoi else ""))

    def tam_dung(self) -> None:
        with self.khoa:
            if self.tt != "ghi":
                raise RuntimeError("Không có cuộc ghi âm nào đang chạy")
            tien_trinh = self._dong_doan()
            self.tt = "tam-dung"
        if tien_trinh:
            _dung_tien_trinh(tien_trinh)

    def tiep_tuc(self, micro: tuple | None = None) -> None:
        """micro: micro vừa tìm lại theo tên (máy chủ tìm), vì số thứ tự trong danh
        sách micro đổi mỗi khi cắm rút tai nghe hay iPhone lại gần. None thì giữ như cũ."""
        with self.khoa:
            if self.tt != "tam-dung":
                raise RuntimeError("Không có cuộc ghi âm nào đang tạm dừng")
            if micro:
                self.micro = micro
            self._mo_doan()

    def dung(self) -> tuple[str, Path | None, float]:
        """Dừng hẳn, nối các đoạn. Trả (mã cuộc họp, tệp ghi âm, số giây đã ghi)."""
        with self.khoa:
            if not self.tt:
                raise RuntimeError("Không có cuộc ghi âm nào để dừng")
            tien_trinh = self._dong_doan()
            ma, thu_muc, giay = self.ma, self.thu_muc, self.giay_truoc
            self._dat_lai()
        if tien_trinh:
            _dung_tien_trinh(tien_trinh)
        with self.khoa_tep:
            return ma, noi_doan(thu_muc), giay

    def cat_phan_moi(self, con_tro: int) -> tuple[bytes, int, float]:
        """Phần đã ghi kể từ con_tro, không ngắt ghi âm. Con trỏ là vị trí byte trên
        các tệp doan-01, doan-02... nối liền, đúng như ghi-am.aac lúc dừng, nên sau
        khi dừng thì cắt tiếp bằng cat_tu_tep. Trả (các khung, con trỏ mới, số giây)."""
        with self.khoa:
            thu_muc = self.thu_muc
        if thu_muc is None:
            return b"", con_tro, 0.0
        with self.khoa_tep:
            du_lieu = doc_tu_vi_tri(sorted(thu_muc.glob("doan-*.aac")), con_tro)
        khung, qua, giay = tach_khung_adts(du_lieu)
        return khung, con_tro + qua, giay

    def giay_am_thanh(self) -> float:
        """Số giây âm thanh đã thật sự nằm trong các tệp đoạn, đếm theo khung ADTS như
        mốc của các đoạn gửi lên và của bản chép lời. Khác đồng hồ ghi (trang_thai)
        khi máy rớt tiếng: máy Mac của PM mỗi 5 phút đồng hồ chỉ có khoảng 4 phút 24
        giây âm thanh, nên ghi chú của thư ký gắn mốc theo đồng hồ bị trễ dần, tới
        khoảng 10 phút sau 86 phút (PM báo 28/9/2026: thẻ trợ lý dời người nói). Chỉ
        đọc phần mới từ lần đếm trước."""
        with self.khoa:
            thu_muc = self.thu_muc
        if thu_muc is None:
            return 0.0
        with self.khoa_do:
            with self.khoa_tep:
                du_lieu = doc_tu_vi_tri(sorted(thu_muc.glob("doan-*.aac")), self._do_byte)
            _, qua, giay = tach_khung_adts(du_lieu)
            with self.khoa:
                if self.thu_muc != thu_muc:  # vừa dừng hay chuyển sang cuộc họp khác
                    return 0.0
                self._do_byte += qua
                self._do_giay += giay
                return self._do_giay

    def trang_thai(self) -> dict:
        with self.khoa:
            bay_gio = time.monotonic()
            giay = self.giay_truoc + (bay_gio - self.luc_mo_doan if self.luc_mo_doan else 0)
            return {
                "tt": self.tt, "ma": self.ma, "giay": round(giay, 1),
                "micro": self.micro[1] if self.micro else None,
                "muc": [round(x, 1) for x in self.muc],
                "im_lang": self.tt == "ghi" and bay_gio - self.co_tieng_luc >= IM_LANG_GIAY,
                "loi": self.loi,
            }
