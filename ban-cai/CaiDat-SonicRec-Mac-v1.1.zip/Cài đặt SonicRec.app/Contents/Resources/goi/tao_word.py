#!/usr/bin/env python3
"""Dựng tệp Word biên bản họp theo mẫu chính thức của Văn phòng Trường.

Mọi con số (lề, cỡ chữ, giãn dòng, bảng đầu văn bản, ba đường kẻ) lấy đúng từ
01_Projects/Web_ChuanHoaVanBan/src/lib/docx/chuan-dhtl.ts: bộ số đã đo trực tiếp
từ XML của mẫu do Văn phòng Trường ban hành kèm Quy chế Văn thư - Lưu trữ ngày
08/7/2025. Cách vẽ đường kẻ, gạch đầu dòng và bảng cũng chép theo công cụ đó,
để hai công cụ ra văn bản giống hệt nhau.

Khung văn bản (đầu văn bản, tiêu đề, thời gian, thành phần, chữ ký) dựng từ
thông tin cuộc họp, KHÔNG lấy từ bản nháp của mô hình: mô hình viết khá tự do,
còn các dòng này sẽ được ký nên phải đúng từng chữ. Chỉ phần thân (nội dung,
kết luận, phân công) lấy từ bản nháp.

Chạy thử một mình:   .venv/bin/python tao_word.py bien-ban.txt ra.docx
"""

import re
import sys
import unicodedata
from datetime import date
from pathlib import Path

from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt, RGBColor, Twips

# ----------------------------------------------------------------------------
# Số đo, chép từ chuan-dhtl.ts. Đơn vị twip: 1 cm = 566,93 twip.
# ----------------------------------------------------------------------------

def cm(x: float) -> int:
    return round(x * 566.93)


FONT = "Times New Roman"
DEN = RGBColor(0, 0, 0)  # quy tắc bắt buộc của kho: chữ chỉ màu đen

KHO_A4 = (11906, 16838)
LE = {"tren": cm(2), "phai": 851, "duoi": cm(2), "trai": cm(3)}  # 851 đo từ mẫu
BE_NGANG_CHU = cm(16.5)

COT_DAU = [cm(8), cm(0.5), cm(9.75), cm(0.25)]  # hai cột chữ, hai cột đệm
BANG_DAU_BE_NGANG = 10490                       # rộng hơn vùng chữ, tràn cả hai lề
BANG_DAU_THUT_LE = -743                         # nhờ vậy quốc hiệu không xuống dòng
COT_CHAN = cm(7.94)

KE_DUOI_CO_QUAN = cm(2.78)
KE_DUOI_TIEU_NGU = cm(5.95)
KE_DUOI_TRICH_YEU = cm(4.5)

THUT_DAU_DONG = cm(1.25)
THUT_GACH = cm(0.5)
NGUONG_CHU_DAI = 30  # ô bảng dài hơn thì căn trái, còn lại căn giữa

CO_THAN = 14
CO_CO_QUAN = 13       # cơ quan chủ quản, cơ quan ban hành, số ký hiệu, quốc hiệu
CO_TIEU_NGU = 14      # tiêu ngữ, địa danh ngày tháng
CO_GHI_CHU_KY = 13

# (giãn dòng, cách trước pt, cách sau pt)
GIAN_THAN = (1.2, 3, 3)
GIAN_TIEU_DE = (1.3, 3, 3)
GIAN_CHAT = (1.15, 0, 0)
GIAN_SAT = (1.0, 0, 0)

MAC_DINH = {
    "co_quan_chu_quan": "TRƯỜNG ĐẠI HỌC THĂNG LONG",
    # Xuống dòng sẵn cho cân hai dòng; để máy tự ngắt thì chữ "NGHỆ" rớt một mình
    "co_quan_ban_hanh": "TRUNG TÂM ĐÀO TẠO NGẮN HẠN\nVÀ CHUYỂN GIAO CÔNG NGHỆ",
    "ky_hieu": "BB-TTC",
    "dia_danh": "Hà Nội",
}
CHAM = "....."  # chỗ trống để thư ký tự điền


# ----------------------------------------------------------------------------
# Viên gạch nhỏ
# ----------------------------------------------------------------------------

# Word đòi các thẻ con đứng đúng thứ tự trong lược đồ OOXML. Sai thứ tự thì
# LibreOffice vẫn mở, nhưng Word có lúc báo "nội dung không đọc được".
# python-docx chỉ tự xếp những thẻ nó biết, nên thẻ nào tự gắn thì phải xếp lại.
THU_TU_TBLPR = ["tblStyle", "tblpPr", "tblOverlap", "bidiVisual", "tblStyleRowBandSize",
                "tblStyleColBandSize", "tblW", "jc", "tblCellSpacing", "tblInd",
                "tblBorders", "shd", "tblLayout", "tblCellMar", "tblLook"]
THU_TU_PPR = ["pStyle", "keepNext", "keepLines", "pageBreakBefore", "framePr",
              "widowControl", "numPr", "suppressLineNumbers", "pBdr", "shd", "tabs",
              "suppressAutoHyphens", "kinsoku", "wordWrap", "overflowPunct",
              "topLinePunct", "autoSpaceDE", "autoSpaceDN", "bidi", "adjustRightInd",
              "snapToGrid", "spacing", "ind", "contextualSpacing", "mirrorIndents",
              "suppressOverlap", "jc", "textDirection", "textAlignment",
              "textboxTightWrap", "outlineLvl", "divId", "cnfStyle", "rPr", "sectPr",
              "pPrChange"]


def _ten_the(e) -> str:
    return e.tag.split("}")[-1]


def sap_xep(cha, thu_tu: list[str]) -> None:
    """Xếp lại thẻ con theo lược đồ, giữ nguyên thứ tự giữa các thẻ cùng loại."""
    con = list(cha)
    con.sort(key=lambda e: thu_tu.index(_ten_the(e)) if _ten_the(e) in thu_tu
             else len(thu_tu))
    for e in con:
        cha.remove(e)
    for e in con:
        cha.append(e)

def chu(p, text: str, co: float = CO_THAN, dam: bool = False, nghieng: bool = False):
    if "\n" in text:  # xuống dòng trong cùng một đoạn
        cac_dong = text.split("\n")
        for dong in cac_dong[:-1]:
            chu(p, dong, co, dam, nghieng).add_break()
        return chu(p, cac_dong[-1], co, dam, nghieng)
    r = p.add_run(text)
    f = r.font
    f.name = FONT
    f.size = Pt(co)
    f.bold = True if dam else None
    f.italic = True if nghieng else None
    f.color.rgb = DEN
    # font.name chỉ đặt ascii và hAnsi; đặt nốt để Word máy nào cũng ra Times
    rfonts = r._element.get_or_add_rPr().get_or_add_rFonts()
    rfonts.set(qn("w:eastAsia"), FONT)
    rfonts.set(qn("w:cs"), FONT)
    return r


# Chữ đậm kiểu markdown **...**, và dấu ngoặc vuông cần xem lại như
# [chưa rõ ai nói]. Mốc giờ [00:12] của bản chép lời thì để chữ thường.
DAM = re.compile(r"\*\*[^*]+\*\*")
DANH_DAU = re.compile(r"\[(?!\d)[^\]]+\]")
MANH = re.compile(f"({DAM.pattern}|{DANH_DAU.pattern})")


def chu_co_danh_dau(p, text: str, co: float = CO_THAN) -> None:
    for manh in MANH.split(text):
        if not manh:
            continue
        if DAM.fullmatch(manh):
            chu(p, manh[2:-2], co=co, dam=True)
        elif DANH_DAU.fullmatch(manh):
            # Không tô màu được (quy tắc chữ đen), nên đậm nghiêng cho dễ thấy
            chu(p, manh, co=co, dam=True, nghieng=True)
        else:
            chu(p, manh, co=co)


def dinh_dang(p, can=WD_ALIGN_PARAGRAPH.JUSTIFY, gian=GIAN_THAN, dau_dong=0,
              trai=0, phai=0, treo=0, giu_voi_sau=False):
    pf = p.paragraph_format
    pf.alignment = can
    dong, truoc, sau = gian
    pf.line_spacing = dong
    pf.space_before = Pt(truoc)
    pf.space_after = Pt(sau)
    if dau_dong:
        pf.first_line_indent = Twips(dau_dong)
    if treo:
        pf.first_line_indent = Twips(-treo)
    if trai:
        pf.left_indent = Twips(trai)
    if phai:
        pf.right_indent = Twips(phai)
    if giu_voi_sau:
        pf.keep_with_next = True
    return p


def doan_moi(noi):
    """Đoạn mới. Ô bảng mới tạo đã có sẵn một đoạn rỗng, dùng lại đoạn đó."""
    ps = getattr(noi, "paragraphs", [])
    if hasattr(noi, "_tc") and len(ps) == 1 and not ps[0].text and not ps[0].runs:
        if not getattr(noi, "_da_dung_doan_dau", False):
            noi._da_dung_doan_dau = True
            return ps[0]
    return noi.add_paragraph()


def duong_ke(noi, do_rong_o: int, do_dai: int):
    """Đường kẻ liền nét sát dưới dòng chữ: viền dưới của một đoạn rỗng cao 2pt,
    thụt đều hai bên cho ngắn lại và nằm giữa. Đúng cách của công cụ kia."""
    p = doan_moi(noi)
    thut = max(0, round((do_rong_o - do_dai) / 2))
    pf = p.paragraph_format
    pf.alignment = WD_ALIGN_PARAGRAPH.CENTER
    pf.space_before = Pt(0)
    pf.space_after = Pt(0)
    pf.line_spacing = Pt(2)
    pf.line_spacing_rule = WD_LINE_SPACING.EXACTLY
    pf.left_indent = Twips(thut)
    pf.right_indent = Twips(thut)
    pbdr = OxmlElement("w:pBdr")
    duoi = OxmlElement("w:bottom")
    for k, v in (("w:val", "single"), ("w:sz", "6"), ("w:space", "0"), ("w:color", "000000")):
        duoi.set(qn(k), v)
    pbdr.append(duoi)
    pPr = p._p.get_or_add_pPr()
    pPr.append(pbdr)
    sap_xep(pPr, THU_TU_PPR)
    chu(p, "", co=2)
    return p


def _vien(tbl, kieu: str, sz: int = 0) -> None:
    tblPr = tbl._tbl.tblPr
    cu = tblPr.find(qn("w:tblBorders"))
    if cu is not None:
        tblPr.remove(cu)
    vien = OxmlElement("w:tblBorders")
    for canh in ("top", "left", "bottom", "right", "insideH", "insideV"):
        e = OxmlElement(f"w:{canh}")
        e.set(qn("w:val"), kieu)
        if kieu != "nil":
            e.set(qn("w:sz"), str(sz))
            e.set(qn("w:space"), "0")
            e.set(qn("w:color"), "000000")
        vien.append(e)
    tblPr.append(vien)
    sap_xep(tblPr, THU_TU_TBLPR)


def bang(doc, cot: list[int], so_hang: int = 1, be_ngang: int | None = None,
         thut_le: int | None = None):
    """Bảng bề ngang cố định. Đặt đủ tblW, tblInd, tblLayout, gridCol và tcW để
    Word, LibreOffice và Pages hiện cùng một kích thước."""
    t = doc.add_table(rows=so_hang, cols=len(cot))
    t.autofit = False
    tblPr = t._tbl.tblPr
    tblW = tblPr.find(qn("w:tblW"))
    if tblW is None:
        tblW = OxmlElement("w:tblW")
        tblPr.append(tblW)
    tblW.set(qn("w:w"), str(be_ngang or sum(cot)))
    tblW.set(qn("w:type"), "dxa")
    if thut_le is not None:
        ind = OxmlElement("w:tblInd")
        ind.set(qn("w:w"), str(thut_le))
        ind.set(qn("w:type"), "dxa")
        tblPr.append(ind)
    sap_xep(tblPr, THU_TU_TBLPR)  # t.autofit = False đã tự gắn tblLayout cố định
    for i, w in enumerate(cot):
        t.columns[i].width = Twips(w)
        for hang in t.rows:
            hang.cells[i].width = Twips(w)
    return t


# ----------------------------------------------------------------------------
# Ngày tháng theo Nghị định 30
# ----------------------------------------------------------------------------

def ngay_thang_nam(d: date) -> str:
    """Ngày dưới 10 và tháng 1, 2 phải ghi thêm số 0 phía trước (Nghị định 30)."""
    ngay = f"{d.day:02d}" if d.day < 10 else str(d.day)
    thang = f"{d.month:02d}" if d.month < 3 else str(d.month)
    return f"ngày {ngay} tháng {thang} năm {d.year}"


# ----------------------------------------------------------------------------
# Tách phần thân từ bản nháp
# ----------------------------------------------------------------------------

SO_MUC = re.compile(r"^\s*(\d+|[IVXLC]+)[.)]\s+")
GACH = re.compile(r"^\s*[-*•+]\s+")
NHAN_THONG_TIN = re.compile(
    r"^\s*[-*•+]?\s*(Tên cuộc họp|Thời gian|Địa điểm|Chủ trì|Thư ký|Tham dự"
    r"|Thành phần(?: tham dự)?)\s*:", re.IGNORECASE)
PHAN_CUOI = re.compile(
    r"^\s*(Biên bản (kết thúc|được lập)|\(Ký,? ghi rõ họ tên\)|THƯ KÝ(\s{2,}|\t|$))")


def khong_dau(s: str) -> str:
    s = s.replace("đ", "d").replace("Đ", "D")
    return "".join(c for c in unicodedata.normalize("NFD", s)
                   if unicodedata.category(c) != "Mn")


def _sach(dong: str) -> str:
    """Bỏ dấu tiêu đề markdown và cặp ** bọc cả dòng."""
    s = re.sub(r"^\s*#+\s*", "", dong.rstrip())
    m = re.fullmatch(r"\s*\*\*(.+)\*\*\s*:?\s*", s)
    return m.group(1) if m else s


def la_tieu_de(s: str) -> bool:
    s = s.strip()
    if not s or len(s) > 90 or "|" in s:
        return False
    than = SO_MUC.sub("", s).rstrip(":").strip()
    chu_cai = [c for c in than if c.isalpha()]
    return len(chu_cai) >= 3 and all(c.isupper() for c in chu_cai)


def _la_dong_bang(s: str) -> bool:
    return s.count("|") >= 2


def _la_dong_ke_bang(s: str) -> bool:
    """Dòng |---|---| của bảng markdown."""
    return "-" in s and not re.sub(r"[|\-:\s]", "", s)


def _tach_o(s: str, kieu_markdown: bool) -> list[str]:
    s = s.strip()
    if kieu_markdown:
        s = s[1:] if s.startswith("|") else s
        s = s[:-1] if s.endswith("|") else s
    return [o.strip() for o in s.split("|")]


def tach_than_bai(noi_dung: str, ten_cuoc_hop: str = "") -> list[tuple]:
    """Trả danh sách khối: ("muc", chữ) | ("doan", chữ) | ("gach", chữ) |
    ("bang", [hàng...]). Bỏ phần đầu và phần cuối mà khung văn bản tự dựng."""
    dong = [_sach(d) for d in noi_dung.replace("\r\n", "\n").split("\n")]

    # 1. Cắt phần cuối: câu kết và khối chữ ký. Chỉ xét nửa sau cho khỏi cắt nhầm.
    for i in range(len(dong) // 2, len(dong)):
        if PHAN_CUOI.match(dong[i]):
            dong = dong[:i]
            break

    # 2. Bỏ phần đầu: tiêu đề, tên cuộc họp, các dòng thời gian, địa điểm...
    ten = khong_dau(ten_cuoc_hop).lower().strip()
    i = 0
    while i < len(dong):
        s = dong[i].strip()
        tron = s.replace("*", "")  # "**Thời gian:** ..." của markdown vẫn phải nhận ra
        if (not s or tron.upper().startswith("BIÊN BẢN") or NHAN_THONG_TIN.match(tron)
                or (ten and khong_dau(tron).lower().strip(" .:") == ten)):
            i += 1
            continue
        break
    dong = dong[i:]

    # 3. Chia khối
    khoi: list[tuple] = []
    j = 0
    while j < len(dong):
        s = dong[j].strip()
        if not s:
            j += 1
            continue
        if _la_dong_bang(s):
            kieu_md = s.startswith("|") and s.endswith("|")
            hang = []
            while j < len(dong) and _la_dong_bang(dong[j]):
                if not _la_dong_ke_bang(dong[j]):
                    hang.append(_tach_o(dong[j], kieu_md))
                j += 1
            khoi.append(("bang", hang))
            continue
        if la_tieu_de(s):
            khoi.append(("muc", s))
        elif GACH.match(s):
            khoi.append(("gach", GACH.sub("", s)))
        else:
            khoi.append(("doan", s))
        j += 1

    # 4. Bỏ mục THÀNH PHẦN THAM DỰ vì khung đã có, rồi đánh số lại các mục
    sach: list[tuple] = []
    bo_qua = False
    for k in khoi:
        if k[0] == "muc":
            bo_qua = SO_MUC.sub("", k[1]).upper().startswith("THÀNH PHẦN")
        if not bo_qua:
            sach.append(k)
    so = 0
    ket_qua = []
    for loai, gia_tri in sach:
        if loai == "muc" and SO_MUC.match(gia_tri):
            so += 1
            gia_tri = f"{so}. {SO_MUC.sub('', gia_tri)}"
        ket_qua.append((loai, gia_tri))
    return ket_qua


# ----------------------------------------------------------------------------
# Dựng văn bản
# ----------------------------------------------------------------------------

def _le_o(t, tren: int, duoi: int, trai: int, phai: int) -> None:
    le = OxmlElement("w:tblCellMar")
    for canh, gia_tri in (("top", tren), ("left", trai), ("bottom", duoi), ("right", phai)):
        e = OxmlElement(f"w:{canh}")
        e.set(qn("w:w"), str(gia_tri))
        e.set(qn("w:type"), "dxa")
        le.append(e)
    tblPr = t._tbl.tblPr
    tblPr.append(le)
    sap_xep(tblPr, THU_TU_TBLPR)


def _dau_van_ban(doc, tt: dict, ngay: date) -> None:
    t = bang(doc, COT_DAU, be_ngang=BANG_DAU_BE_NGANG, thut_le=BANG_DAU_THUT_LE)
    _vien(t, "nil")
    # Lề trong ô bằng 0: hai cột đệm hẹp của mẫu đã thay cho lề ô. Để lề mặc
    # định 0,19cm thì dòng quốc hiệu cần khoảng 9,6cm, không vừa cột 9,75cm.
    _le_o(t, 0, 0, 0, 0)
    trai, phai = t.cell(0, 0), t.cell(0, 2)
    giua = WD_ALIGN_PARAGRAPH.CENTER

    p = dinh_dang(doan_moi(trai), can=giua, gian=GIAN_SAT)
    chu(p, (tt.get("co_quan_chu_quan") or MAC_DINH["co_quan_chu_quan"]).upper(),
        co=CO_CO_QUAN)
    p = dinh_dang(doan_moi(trai), can=giua, gian=GIAN_SAT)
    chu(p, (tt.get("co_quan_ban_hanh") or MAC_DINH["co_quan_ban_hanh"]).upper(),
        co=CO_CO_QUAN, dam=True)
    duong_ke(trai, COT_DAU[0], KE_DUOI_CO_QUAN)
    p = dinh_dang(doan_moi(trai), can=giua, gian=(1.0, 6, 0))
    chu(p, f"Số:       /{tt.get('ky_hieu') or MAC_DINH['ky_hieu']}", co=CO_CO_QUAN)

    p = dinh_dang(doan_moi(phai), can=giua, gian=GIAN_SAT)
    chu(p, "CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM", co=CO_CO_QUAN, dam=True)
    p = dinh_dang(doan_moi(phai), can=giua, gian=GIAN_SAT)
    chu(p, "Độc lập - Tự do - Hạnh phúc", co=CO_TIEU_NGU, dam=True)
    duong_ke(phai, COT_DAU[2], KE_DUOI_TIEU_NGU)
    p = dinh_dang(doan_moi(phai), can=giua, gian=(1.0, 6, 0))
    chu(p, f"{tt.get('dia_danh') or MAC_DINH['dia_danh']}, {ngay_thang_nam(ngay)}",
        co=CO_TIEU_NGU, nghieng=True)


def _bang_du_lieu(doc, hang: list[list[str]]) -> None:
    so_cot = max(len(h) for h in hang)
    rong = BE_NGANG_CHU // so_cot
    t = bang(doc, [rong] * so_cot, so_hang=len(hang))
    _vien(t, "single", sz=4)  # 0,5pt
    _le_o(t, 40, 40, 80, 80)  # 2pt trên dưới, 4pt hai bên, như công cụ kia
    for r, cac_o in enumerate(hang):
        dong = t.rows[r]
        if r == 0:  # đầu bảng lặp lại khi sang trang
            trPr = dong._tr.get_or_add_trPr()
            trPr.append(OxmlElement("w:tblHeader"))
        for c in range(so_cot):
            noi = cac_o[c] if c < len(cac_o) else ""
            o = dong.cells[c]
            o.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            can = (WD_ALIGN_PARAGRAPH.LEFT if r > 0 and len(noi) > NGUONG_CHU_DAI
                   else WD_ALIGN_PARAGRAPH.CENTER)
            p = dinh_dang(doan_moi(o), can=can, gian=GIAN_CHAT)
            if r == 0:
                chu(p, noi, dam=True)
            else:
                chu_co_danh_dau(p, noi)


def _chu_ky(doc, tt: dict) -> None:
    t = bang(doc, [COT_CHAN, COT_CHAN])
    _vien(t, "nil")
    _le_o(t, 0, 0, 0, 0)
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    trPr = t.rows[0]._tr.get_or_add_trPr()
    trPr.append(OxmlElement("w:cantSplit"))  # khối chữ ký không bị cắt đôi
    giua = WD_ALIGN_PARAGRAPH.CENTER
    for o, chuc_danh, ten in ((t.cell(0, 0), "THƯ KÝ", tt.get("thu_ky", "")),
                              (t.cell(0, 1), "CHỦ TRÌ", tt.get("chu_tri", ""))):
        chu(dinh_dang(doan_moi(o), can=giua, gian=GIAN_SAT, giu_voi_sau=True),
            chuc_danh, dam=True)
        chu(dinh_dang(doan_moi(o), can=giua, gian=GIAN_SAT, giu_voi_sau=True),
            "(Ký, ghi rõ họ tên)", co=CO_GHI_CHU_KY, nghieng=True)
        for _ in range(4):  # chỗ ký
            dinh_dang(doan_moi(o), can=giua, gian=GIAN_SAT, giu_voi_sau=True)
        chu(dinh_dang(doan_moi(o), can=giua, gian=GIAN_SAT), ten.strip(), dam=True)


def _so_trang(section) -> None:
    """Số trang giữa lề trên, từ trang 2 trở đi, cỡ 13 (Nghị định 30)."""
    section.different_first_page_header_footer = True
    p = section.header.paragraphs[0]
    dinh_dang(p, can=WD_ALIGN_PARAGRAPH.CENTER, gian=GIAN_SAT)
    for loai, chu_lenh in (("begin", None), (None, " PAGE "), ("separate", None),
                           (None, None), ("end", None)):
        r = chu(p, "2" if (loai is None and chu_lenh is None) else "", co=13)
        if loai:
            fld = OxmlElement("w:fldChar")
            fld.set(qn("w:fldCharType"), loai)
            r._element.append(fld)
        elif chu_lenh:
            instr = OxmlElement("w:instrText")
            instr.set(qn("xml:space"), "preserve")
            instr.text = chu_lenh
            r._element.append(instr)


def dung_bien_ban(noi_dung: str, tt: dict, ngay: date, gio_ket_thuc: str | None,
                  duong_ra: Path) -> Path:
    """gio_ket_thuc đã định dạng sẵn, ví dụ "9 giờ 28 phút". None thì để chấm cho
    thư ký điền. Việc có ghi kèm dấu cần kiểm tra hay không do nơi gọi quyết."""
    doc = Document()

    # Kiểu chữ gốc: mọi đoạn không đặt riêng sẽ theo Times 14 chữ đen
    goc = doc.styles["Normal"]
    goc.font.name = FONT
    goc.font.size = Pt(CO_THAN)
    goc.font.color.rgb = DEN
    rf = goc.element.get_or_add_rPr().get_or_add_rFonts()
    rf.set(qn("w:eastAsia"), FONT)
    rf.set(qn("w:cs"), FONT)

    s = doc.sections[0]
    s.page_width, s.page_height = Twips(KHO_A4[0]), Twips(KHO_A4[1])
    s.top_margin, s.bottom_margin = Twips(LE["tren"]), Twips(LE["duoi"])
    s.left_margin, s.right_margin = Twips(LE["trai"]), Twips(LE["phai"])
    _so_trang(s)

    _dau_van_ban(doc, tt, ngay)

    giua = WD_ALIGN_PARAGRAPH.CENTER
    chu(dinh_dang(doc.add_paragraph(), can=giua, gian=(1.3, 18, 0)),
        "BIÊN BẢN", dam=True)
    chu(dinh_dang(doc.add_paragraph(), can=giua, gian=GIAN_TIEU_DE),
        tt.get("ten_cuoc_hop") or "Cuộc họp", dam=True)
    duong_ke(doc, BE_NGANG_CHU, KE_DUOI_TRICH_YEU)
    doc.paragraphs[-1].paragraph_format.space_after = Pt(9)

    def dong_than(text: str):
        p = dinh_dang(doc.add_paragraph(), dau_dong=THUT_DAU_DONG)
        chu_co_danh_dau(p, text)

    def dong_gach(text: str):
        p = dinh_dang(doc.add_paragraph(), gian=(1.2, 0, 3),
                      trai=THUT_GACH + cm(0.5), treo=cm(0.5))
        chu_co_danh_dau(p, f"- {text}")

    dong_than(f"Thời gian: {tt.get('thoi_gian') or CHAM}")
    dong_than(f"Địa điểm: {tt.get('dia_diem') or CHAM}")
    dong_than("Thành phần tham dự:")
    dong_gach(f"Chủ trì: {tt.get('chu_tri') or CHAM}")
    dong_gach(f"Thư ký: {tt.get('thu_ky') or CHAM}")
    cac_nguoi = [x.strip() for x in (tt.get("tham_du") or "").splitlines() if x.strip()]
    dong_gach(f"Tham dự: {', '.join(cac_nguoi) if cac_nguoi else CHAM}")

    cac_khoi = tach_than_bai(noi_dung, tt.get("ten_cuoc_hop", ""))
    for i, (loai, gia_tri) in enumerate(cac_khoi):
        if loai == "muc":
            p = dinh_dang(doc.add_paragraph(), gian=(1.2, 6, 3),
                          dau_dong=THUT_DAU_DONG, giu_voi_sau=True)
            chu(p, gia_tri, dam=True)
            # Mục trống, như KẾT LUẬN của khung chưa soạn: chừa chỗ cho thư ký viết
            if i + 1 == len(cac_khoi) or cac_khoi[i + 1][0] == "muc":
                dong_than(CHAM * 8)
        elif loai == "gach":
            dong_gach(gia_tri)
        elif loai == "bang":
            _bang_du_lieu(doc, gia_tri)
        else:
            dong_than(gia_tri)

    dong_than(f"Biên bản kết thúc vào {gio_ket_thuc or f'{CHAM} giờ {CHAM} phút'} cùng ngày.")
    doc.paragraphs[-1].paragraph_format.keep_with_next = True
    dong_than(f"Biên bản được lập thành {CHAM} bản./.")
    doc.paragraphs[-1].paragraph_format.space_after = Pt(12)
    doc.paragraphs[-1].paragraph_format.keep_with_next = True
    _chu_ky(doc, tt)

    duong_ra = Path(duong_ra)
    tam = duong_ra.with_suffix(".tam.docx")
    doc.save(tam)
    tam.replace(duong_ra)  # lưu rồi mới đổi tên, tắt máy giữa chừng không để lại tệp hỏng
    return duong_ra


def ten_tep_word(tt: dict, ngay: date) -> str:
    """Theo quy ước đặt tên của kho: YYMMDD_TTC_BienBan_GiaoBanTuan.docx"""
    ten = re.sub(r"^\s*họp\s+", "", tt.get("ten_cuoc_hop") or "", flags=re.IGNORECASE)
    tu = re.sub(r"[^A-Za-z0-9 ]", " ", khong_dau(ten)).split()[:3]
    ngan = "".join(w[:1].upper() + w[1:].lower() for w in tu) or "CuocHop"
    return f"{ngay:%y%m%d}_TTC_BienBan_{ngan}.docx"


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("Cách dùng: tao_word.py bien-ban.txt ra.docx")
    vao = Path(sys.argv[1]).read_text(encoding="utf-8")
    ra = dung_bien_ban(vao, {"ten_cuoc_hop": "Cuộc họp chạy thử"}, date.today(),
                       None, Path(sys.argv[2]))
    print(f"Đã tạo {ra}")
