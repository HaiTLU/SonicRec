#!/usr/bin/env python3
"""Khoá kích hoạt của SonicRec (trước 28/9/2026 tên Biên bản họp): máy phải có mã
kích hoạt do người phát hành cấp thì mới ghi âm và soạn biên bản được. PM chốt 28/9/2026:

  - Mã kích hoạt riêng cho từng máy (phương án A). Người phát hành ký mã bằng chìa
    khoá riêng chỉ nằm trên máy của mình; ứng dụng kiểm bằng mã công khai gắn sẵn
    (KHOA_CONG_KHAI). Không cần máy chủ, không cần mạng.
  - Chặn ở lần mở ứng dụng đầu tiên, không chặn trong trình cài.
  - Mã có hạn, mặc định 1 tháng; người phát hành đổi được hạn lúc cấp.
  - Hết hạn: khoá ghi âm, nhận tệp ghi âm và Làm lại; vẫn xem được các cuộc họp cũ.
  - Máy đã có cuộc họp trước khi có khoá: dùng tiếp 30 ngày để kịp xin mã.

Chữ ký Ed25519 (RFC 8032) viết thẳng bằng Python cho khỏi thêm thư viện vào trình
cài; kiểm một mã mất vài chục mili giây. Không khoá nào chặn được hẳn người rành lập
trình (mã Python đọc được): khoá giữ người dùng thường làm đúng, phần còn lại là hợp
đồng bản quyền.

KHOA_CONG_KHAI để trống thì chưa bật khoá: ứng dụng chạy như trước.

Máy người phát hành (tệp "Tao chia khoa cap ma.command" gọi):
    python kich_hoat.py tao-chia-khoa     tạo chìa khoá riêng một lần, hoặc nạp bản sao
    python kich_hoat.py cong-khai         in mã công khai của chìa khoá trên máy này
"""

import base64
import hashlib
import json
import os
import re
import subprocess
import sys
import uuid
from datetime import date, datetime, timedelta
from pathlib import Path

# Mã công khai của người phát hành, dạng CONGKHAI-<43 ký tự>. Để trống: chưa bật khoá.
# Mã của anh Nguyễn Nam Hải, gắn 28/9/2026: từ bản này khoá đã bật
KHOA_CONG_KHAI: tuple[str, ...] = ("CONGKHAI-xVYQl9eSWTC3ZTncliCBOifLnjIVwVwthCC3cN5idoY",)
# Ngày bản có khoá phát hành. Máy có cuộc họp ghi trước ngày này được dùng tiếp
# NGAY_DUNG_TIEP ngày, nhưng không quá TRAN_DUNG_TIEP ngày sau ngày này
NGAY_BAT_KHOA = date(2026, 10, 1)
NGAY_DUNG_TIEP = 30
TRAN_DUNG_TIEP = 60
NHAC_TRUOC = 7  # còn ít hơn chừng này ngày thì nhắc xin mã mới

THU_MUC_GOC = Path(__file__).resolve().parent
TEP_KICH_HOAT = THU_MUC_GOC / "kich-hoat.json"  # mã đã nhập và mốc dùng tiếp của máy này
# Chìa khoá riêng chỉ có trên máy người phát hành, ngoài thư mục cài để cập nhật không đụng tới
THU_MUC_CHIA_KHOA = Path.home() / ".bien-ban-hop-cap-ma"
TEN_CHIA_KHOA = "chia-khoa-rieng.txt"
TEN_DA_CAP = "da-cap.jsonl"

TIEN_TO_MA = "BBH1."
TIEN_TO_CONG_KHAI = "CONGKHAI-"
TIEN_TO_RIENG = "RIENG-"


# ----------------------------------------------------------------------------
# Chữ ký Ed25519, theo đúng mã tham khảo của RFC 8032 mục 6
# ----------------------------------------------------------------------------

_P = 2 ** 255 - 19
_L = 2 ** 252 + 27742317777372353535851937790883648493
_D = -121665 * pow(121666, _P - 2, _P) % _P
_CAN_TRU_1 = pow(2, (_P - 1) // 4, _P)


def _tim_x(y: int, dau: int) -> int | None:
    if y >= _P:
        return None
    x2 = (y * y - 1) * pow(_D * y * y + 1, _P - 2, _P) % _P
    if x2 == 0:
        return None if dau else 0
    x = pow(x2, (_P + 3) // 8, _P)
    if (x * x - x2) % _P:
        x = x * _CAN_TRU_1 % _P
    if (x * x - x2) % _P:
        return None
    return _P - x if (x & 1) != dau else x


_GY = 4 * pow(5, _P - 2, _P) % _P
_GX = _tim_x(_GY, 0)
_G = (_GX, _GY, 1, _GX * _GY % _P)


def _cong(a: tuple, b: tuple) -> tuple:
    p = (a[1] - a[0]) * (b[1] - b[0]) % _P
    q = (a[1] + a[0]) * (b[1] + b[0]) % _P
    r = 2 * a[3] * b[3] * _D % _P
    s = 2 * a[2] * b[2] % _P
    e, f, g, h = q - p, s - r, s + r, q + p
    return e * f % _P, g * h % _P, f * g % _P, e * h % _P


def _nhan(k: int, a: tuple) -> tuple:
    kq = (0, 1, 1, 0)
    while k > 0:
        if k & 1:
            kq = _cong(kq, a)
        a = _cong(a, a)
        k >>= 1
    return kq


def _bang(a: tuple, b: tuple) -> bool:
    return (a[0] * b[2] - b[0] * a[2]) % _P == 0 and (a[1] * b[2] - b[1] * a[2]) % _P == 0


def _nen(a: tuple) -> bytes:
    z = pow(a[2], _P - 2, _P)
    x, y = a[0] * z % _P, a[1] * z % _P
    return int.to_bytes(y | ((x & 1) << 255), 32, "little")


def _mo_nen(s: bytes) -> tuple | None:
    if len(s) != 32:
        return None
    y = int.from_bytes(s, "little")
    dau, y = y >> 255, y & ((1 << 255) - 1)
    x = _tim_x(y, dau)
    return None if x is None else (x, y, 1, x * y % _P)


def _bam(*phan: bytes) -> int:
    return int.from_bytes(hashlib.sha512(b"".join(phan)).digest(), "little") % _L


def _mo_hat(hat: bytes) -> tuple[int, bytes]:
    if len(hat) != 32:
        raise ValueError("Chìa khoá riêng phải dài đúng 32 byte")
    h = hashlib.sha512(hat).digest()
    a = int.from_bytes(h[:32], "little") & ((1 << 254) - 8) | (1 << 254)
    return a, h[32:]


def khoa_cong_khai_tu(hat: bytes) -> bytes:
    return _nen(_nhan(_mo_hat(hat)[0], _G))


def ky(hat: bytes, tin: bytes) -> bytes:
    a, tien_to = _mo_hat(hat)
    khoa = _nen(_nhan(a, _G))
    r = _bam(tien_to, tin)
    rr = _nen(_nhan(r, _G))
    return rr + int.to_bytes((r + _bam(rr, khoa, tin) * a) % _L, 32, "little")


def dung_chu_ky(khoa: bytes, tin: bytes, chu_ky: bytes) -> bool:
    if len(khoa) != 32 or len(chu_ky) != 64:
        return False
    a, r = _mo_nen(khoa), _mo_nen(chu_ky[:32])
    if a is None or r is None:
        return False
    s = int.from_bytes(chu_ky[32:], "little")
    if s >= _L:
        return False
    return _bang(_nhan(s, _G), _cong(r, _nhan(_bam(chu_ky[:32], khoa, tin), a)))


def _b64(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).decode().rstrip("=")


def _mo_b64(s: str) -> bytes:
    if not re.fullmatch(r"[A-Za-z0-9_-]*", s):
        raise ValueError("ký tự lạ")
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def chu_cong_khai(hat: bytes) -> str:
    return TIEN_TO_CONG_KHAI + _b64(khoa_cong_khai_tu(hat))


def _khoa_gan_san() -> list[bytes]:
    ra = []
    for chu in KHOA_CONG_KHAI:
        try:
            khoa = _mo_b64(chu.removeprefix(TIEN_TO_CONG_KHAI))
        except ValueError:
            continue
        if _mo_nen(khoa) is not None:
            ra.append(khoa)
    return ra


def da_bat_khoa() -> bool:
    return bool(KHOA_CONG_KHAI)


# ----------------------------------------------------------------------------
# Mã máy: 12 ký tự tính từ mã phần cứng, không đổi khi cài lại ứng dụng
# ----------------------------------------------------------------------------

# Bảng chữ Crockford: bỏ I, L, O, U cho khỏi đọc nhầm với 1, 0
_CHU = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"


def ma_may_tho() -> str:
    """Mac: số máy của bo mạch (IOPlatformUUID, không đổi khi cài lại macOS).
    Windows: MachineGuid (đổi khi cài lại Windows). Đọc được không cần quyền quản trị.
    Không đọc được thì dùng một số ngẫu nhiên lưu trong thư mục cài."""
    try:
        if sys.platform == "darwin":
            ra = subprocess.run(["/usr/sbin/ioreg", "-rd1", "-c", "IOPlatformExpertDevice"],
                                capture_output=True, text=True, timeout=15)
            if m := re.search(r'"IOPlatformUUID"\s*=\s*"([^"]+)"', ra.stdout):
                return m[1]
        elif os.name == "nt":
            import winreg
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography", 0,
                                winreg.KEY_READ | winreg.KEY_WOW64_64KEY) as k:
                if gia_tri := str(winreg.QueryValueEx(k, "MachineGuid")[0]).strip():
                    return gia_tri
        else:
            for tep in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
                chu = Path(tep).read_text(encoding="utf-8").strip() if Path(tep).is_file() else ""
                if chu:
                    return chu
    except (OSError, subprocess.SubprocessError, ValueError):
        pass
    tep = THU_MUC_GOC / ".ma-may"
    try:
        chu = tep.read_text(encoding="utf-8").strip()
    except OSError:
        chu = ""
    if not chu:
        chu = uuid.uuid4().hex
        try:
            tep.write_text(chu, encoding="utf-8")
        except OSError:
            pass
    return chu


_MA_MAY: list[str] = []


def ma_may() -> str:
    """Dạng XXXX-XXXX-XXXX, đọc một lần rồi nhớ."""
    if not _MA_MAY:
        h = hashlib.sha256(b"bien-ban-hop/ma-may/" + ma_may_tho().encode("utf-8")).digest()
        so = int.from_bytes(h[:8], "big") >> 4  # 60 bit
        chu = "".join(_CHU[(so >> (5 * (11 - i))) & 31] for i in range(12))
        _MA_MAY.append(f"{chu[:4]}-{chu[4:8]}-{chu[8:]}")
    return _MA_MAY[0]


def chuan_ma_may(chu: str) -> str | None:
    """Mã máy người dùng gửi qua Zalo: bỏ dấu cách, gạch; chữ thường thành hoa;
    I, L thành 1, O thành 0. Sai dạng thì None."""
    s = re.sub(r"[\s-]", "", (chu or "").upper()).translate(str.maketrans("ILO", "110"))
    if len(s) != 12 or any(c not in _CHU for c in s):
        return None
    return f"{s[:4]}-{s[4:8]}-{s[8:]}"


# ----------------------------------------------------------------------------
# Mã kích hoạt: BBH1.<nội dung>.<chữ ký>
# ----------------------------------------------------------------------------

def tao_ma(hat: bytes, may: str, cho: str, han: date, so: int, cap: date | None = None) -> str:
    nd = {"v": 1, "may": may, "cho": cho, "han": han.isoformat(),
          "cap": (cap or date.today()).isoformat(), "so": so}
    tin = json.dumps(nd, ensure_ascii=False, separators=(",", ":"), sort_keys=True).encode("utf-8")
    return TIEN_TO_MA + _b64(tin) + "." + _b64(ky(hat, tin))


_DA_KIEM: dict = {}  # giao diện hỏi trạng thái liên tục: mỗi mã chỉ kiểm chữ ký một lần


def doc_ma(chu: str) -> tuple[dict | None, str]:
    """(nội dung, "") nếu mã do người phát hành ký; (None, lý do) nếu không. Nhận cả
    nguyên tin nhắn có mã ở giữa, và mã bị xuống dòng. Chưa so với máy này."""
    m = re.search(r"BBH1\.([A-Za-z0-9_-]+)\.([A-Za-z0-9_-]{86})", re.sub(r"\s+", "", str(chu or "")))
    if not m:
        return None, "Không thấy mã kích hoạt trong chữ vừa dán. Mã bắt đầu bằng BBH1."
    khoa_nho = (m[0], KHOA_CONG_KHAI)
    if khoa_nho not in _DA_KIEM:
        if len(_DA_KIEM) > 50:
            _DA_KIEM.clear()
        _DA_KIEM[khoa_nho] = _doc_ma(m)
    nd, ly_do = _DA_KIEM[khoa_nho]
    return (dict(nd) if nd else None), ly_do


def _doc_ma(m: re.Match) -> tuple[dict | None, str]:
    try:
        tin, chu_ky = _mo_b64(m[1]), _mo_b64(m[2])
    except ValueError:
        return None, "Mã kích hoạt bị thiếu hoặc sai ký tự. Dán lại đủ cả mã."
    if not any(dung_chu_ky(k, tin, chu_ky) for k in _khoa_gan_san()):
        return None, "Mã kích hoạt không đúng. Dán lại đủ cả mã, hoặc xin người phát hành mã mới."
    try:
        nd = json.loads(tin.decode("utf-8"))
        nd["han"] = date.fromisoformat(nd["han"])
        if not (isinstance(nd.get("may"), str) and isinstance(nd.get("cho"), str)):
            raise ValueError
    except (ValueError, KeyError, TypeError, AttributeError):
        return None, "Mã kích hoạt sai dạng. Xin người phát hành mã mới."
    return nd, ""


def _ngay(d: date) -> str:
    return f"{d:%d/%m/%Y}"


def _doc_tep() -> dict:
    try:
        luu = json.loads(TEP_KICH_HOAT.read_text(encoding="utf-8"))
        return luu if isinstance(luu, dict) else {}
    except (OSError, ValueError):
        return {}


def _ghi_tep(luu: dict) -> None:
    tam = TEP_KICH_HOAT.with_name(TEP_KICH_HOAT.name + ".tam")
    tam.write_text(json.dumps(luu, ensure_ascii=False, indent=1), encoding="utf-8")
    tam.replace(TEP_KICH_HOAT)


def trang_thai(co_cuoc_hop_cu=lambda: False, hom_nay: date | None = None) -> dict:
    """Tình trạng kích hoạt của máy này. duoc_dung: được bắt đầu ghi âm, nhận tệp
    ghi âm và Làm lại. co_cuoc_hop_cu(): máy có cuộc họp ghi trước NGAY_BAT_KHOA
    không (chỉ hỏi một lần, khi quyết định có cho dùng tiếp 30 ngày)."""
    hom_nay = hom_nay or date.today()
    tt = {"bat": da_bat_khoa(), "ma_may": ma_may(), "duoc_dung": True, "tinh_trang": "khong_khoa",
          "cho": "", "han": "", "con_ngay": None, "ly_do": "", "phat_hanh": False}
    if not tt["bat"]:
        return tt
    ph = may_phat_hanh()
    tt["phat_hanh"] = ph["khop"]
    if ph["khop"]:
        tt["tinh_trang"] = "phat_hanh"
        return tt
    luu = _doc_tep()
    if luu.get("ma"):
        nd, ly_do = doc_ma(luu["ma"])
        if nd and nd["may"] != tt["ma_may"]:
            nd, ly_do = None, "Mã kích hoạt đã nhập là của máy khác."
        if nd:
            con = (nd["han"] - hom_nay).days
            tt.update(cho=nd["cho"], han=_ngay(nd["han"]), con_ngay=con, duoc_dung=con >= 0,
                      tinh_trang="het_han" if con < 0 else
                      "sap_het_han" if con < NHAC_TRUOC else "da_kich_hoat")
            return tt
        # Đã từng nhập mã (mã chỉ được lưu khi đúng máy này) mà nay không dùng được: thư mục
        # cài bị chép sang máy khác, hay đổi chìa khoá. Không cho 30 ngày dùng tiếp nữa
        tt.update(ly_do=ly_do, tinh_trang="chua_kich_hoat", duoc_dung=False)
        return tt
    # Chưa từng có mã: máy đã dùng trước khi có khoá thì cho dùng tiếp. Quyết một lần
    # rồi ghi lại, để cuộc họp ghi sau này không mở thêm hạn dùng tiếp
    if "dung_tiep_tu" not in luu:
        luu["dung_tiep_tu"] = hom_nay.isoformat() if co_cuoc_hop_cu() else ""
        try:
            _ghi_tep(luu)
        except OSError:
            pass
    if luu["dung_tiep_tu"]:
        try:
            tu = date.fromisoformat(luu["dung_tiep_tu"])
        except (TypeError, ValueError):
            tu = hom_nay
        het = min(tu + timedelta(days=NGAY_DUNG_TIEP), NGAY_BAT_KHOA + timedelta(days=TRAN_DUNG_TIEP))
        con = (het - hom_nay).days
        if con >= 0:
            tt.update(tinh_trang="dung_tiep", han=_ngay(het), con_ngay=con)
            return tt
        tt["tinh_trang"] = "het_dung_tiep"
    else:
        tt["tinh_trang"] = "chua_kich_hoat"
    tt["duoc_dung"] = False
    return tt


def nhap_ma(chu: str, hom_nay: date | None = None) -> tuple[dict | None, str]:
    """Người dùng dán mã kích hoạt: đúng thì lưu, trả (nội dung, ""); sai thì (None, lý do)."""
    hom_nay = hom_nay or date.today()
    if not da_bat_khoa():
        return None, "Bản này chưa bật khoá kích hoạt, không cần nhập mã."
    nd, ly_do = doc_ma(chu)
    if not nd:
        return None, ly_do
    if nd["may"] != ma_may():
        return None, (f"Mã kích hoạt này cấp cho máy {nd['may']}, không phải máy này "
                      f"({ma_may()}). Gửi đúng mã máy này cho người phát hành.")
    if nd["han"] < hom_nay:
        return None, f"Mã kích hoạt này đã hết hạn ngày {_ngay(nd['han'])}. Xin người phát hành mã mới."
    m = re.search(r"BBH1\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]{86}", re.sub(r"\s+", "", chu))
    luu = _doc_tep()
    luu["ma"] = m[0]
    _ghi_tep(luu)
    return nd, ""


# ----------------------------------------------------------------------------
# Máy người phát hành: chìa khoá riêng, cấp mã, danh sách đã cấp
# ----------------------------------------------------------------------------

def _doc_chia_khoa() -> bytes | None:
    try:
        dong = [d.strip() for d in (THU_MUC_CHIA_KHOA / TEN_CHIA_KHOA).read_text(encoding="utf-8")
                .splitlines() if d.strip() and not d.lstrip().startswith("#")]
        hat = _mo_b64(dong[-1].removeprefix(TIEN_TO_RIENG))
    except (OSError, ValueError, IndexError):
        return None
    return hat if len(hat) == 32 else None


_PHAT_HANH: dict = {}


def may_phat_hanh() -> dict:
    """co: máy này có tệp chìa khoá riêng; khop: chìa khoá đó ứng với một mã công khai
    gắn sẵn (chỉ khi đó mới cấp được mã, và máy này không cần mã kích hoạt)."""
    tep = THU_MUC_CHIA_KHOA / TEN_CHIA_KHOA
    try:
        dau = (str(tep), tep.stat().st_mtime_ns, KHOA_CONG_KHAI)
    except OSError:
        return {"co": False, "khop": False, "cong_khai": ""}
    if _PHAT_HANH.get("dau") != dau:
        hat = _doc_chia_khoa()
        ck = chu_cong_khai(hat) if hat else ""
        _PHAT_HANH.clear()
        _PHAT_HANH.update(dau=dau, kq={"co": bool(hat), "khop": bool(ck) and ck in KHOA_CONG_KHAI,
                                       "cong_khai": ck})
    return dict(_PHAT_HANH["kq"])


def ds_da_cap(so_dong: int = 30) -> list[dict]:
    try:
        dong = (THU_MUC_CHIA_KHOA / TEN_DA_CAP).read_text(encoding="utf-8").splitlines()
    except OSError:
        return []
    ra = []
    for d in dong:
        try:
            ra.append(json.loads(d))
        except ValueError:
            continue
    return ra[::-1][:so_dong]


def cap_ma(may: str, cho: str, han: date, hom_nay: date | None = None) -> str:
    """Người phát hành cấp mã cho một máy. Ghi vào danh sách đã cấp trên máy này."""
    hom_nay = hom_nay or date.today()
    if not may_phat_hanh()["khop"]:
        raise PermissionError("Máy này không có chìa khoá cấp mã của bản cài này.")
    may_chuan = chuan_ma_may(may)
    if not may_chuan:
        raise ValueError("Mã máy sai dạng. Mã máy có 12 ký tự, dạng XXXX-XXXX-XXXX.")
    cho = " ".join((cho or "").split())
    if not cho or len(cho) > 80:
        raise ValueError("Điền tên đơn vị hoặc người được cấp (tối đa 80 ký tự).")
    if han < hom_nay:
        raise ValueError("Ngày hết hạn phải từ hôm nay trở đi.")
    tep = THU_MUC_CHIA_KHOA / TEN_DA_CAP
    try:
        so = sum(1 for d in tep.read_text(encoding="utf-8").splitlines() if d.strip()) + 1
    except OSError:
        so = 1
    ma = tao_ma(_doc_chia_khoa(), may_chuan, cho, han, so, hom_nay)
    with tep.open("a", encoding="utf-8") as f:
        f.write(json.dumps({"luc": datetime.now().isoformat(timespec="seconds"), "so": so,
                            "may": may_chuan, "cho": cho, "han": han.isoformat(), "ma": ma},
                           ensure_ascii=False) + "\n")
    return ma


def tao_chia_khoa() -> str:
    """Tạo chìa khoá riêng một lần. Không bao giờ ghi đè chìa khoá đã có: ghi đè là
    mất quyền cấp mã cho bản cài đang gắn mã công khai cũ."""
    tep = THU_MUC_CHIA_KHOA / TEN_CHIA_KHOA
    if tep.exists():
        raise FileExistsError(str(tep))
    return _ghi_chia_khoa(os.urandom(32))


def nap_ban_sao(chu: str) -> str:
    tep = THU_MUC_CHIA_KHOA / TEN_CHIA_KHOA
    if tep.exists():
        raise FileExistsError(str(tep))
    m = re.search(r"RIENG-([A-Za-z0-9_-]{43})", re.sub(r"\s+", "", chu or ""))
    if not m:
        raise ValueError("Không thấy bản sao chìa khoá (bắt đầu bằng RIENG-).")
    return _ghi_chia_khoa(_mo_b64(m[1]))


def _ghi_chia_khoa(hat: bytes) -> str:
    THU_MUC_CHIA_KHOA.mkdir(mode=0o700, parents=True, exist_ok=True)
    tep = THU_MUC_CHIA_KHOA / TEN_CHIA_KHOA
    noi_dung = ("# Chìa khoá riêng để cấp mã kích hoạt SonicRec.\n"
                "# KHÔNG gửi tệp này hay dòng dưới cho ai, kể cả người làm phần mềm.\n"
                + TIEN_TO_RIENG + _b64(hat) + "\n")
    fd = os.open(tep, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(noi_dung)
    return chu_cong_khai(hat)


def ban_sao_chia_khoa() -> str:
    hat = _doc_chia_khoa()
    return TIEN_TO_RIENG + _b64(hat) if hat else ""


# ----------------------------------------------------------------------------
# Chạy riêng trên máy người phát hành
# ----------------------------------------------------------------------------

def _hoi(chu: str, nut: list[str], mac_dinh: str = "", o_nhap: bool = False) -> tuple[str, str]:
    """Hộp thoại macOS (osascript). Trả (nút đã bấm, chữ đã nhập)."""
    def q(s: str) -> str:
        return '"' + s.replace("\\", "\\\\").replace('"', '\\"') + '"'
    lenh = (f"display dialog {q(chu)} buttons {{{', '.join(q(n) for n in nut)}}} "
            f"default button {q(nut[-1])} with title {q('Chìa khoá cấp mã SonicRec')}")
    if o_nhap:
        lenh += f" default answer {q(mac_dinh)}"
    ra = subprocess.run(["osascript", "-e", lenh], capture_output=True, text=True)
    bam = re.search(r"button returned:(.*?)(, text returned:|$)", ra.stdout.strip())
    nhap = re.search(r"text returned:(.*)$", ra.stdout.strip())
    return (bam[1] if bam else ""), (nhap[1] if nhap else "")


def _chep(chu: str) -> None:
    subprocess.run(["pbcopy"], input=chu.encode("utf-8"), check=False)


def _tao_chia_khoa_hoi() -> None:
    tep = THU_MUC_CHIA_KHOA / TEN_CHIA_KHOA
    if tep.exists():
        hat = _doc_chia_khoa()
        ck = chu_cong_khai(hat) if hat else ""
        if not ck:
            _hoi(f"Tệp chìa khoá {tep} bị hỏng. Không xoá tệp này; báo người làm phần mềm.", ["Đóng"])
            return
        _chep(ck)
        print("Mã công khai:", ck)
        _hoi("Máy này đã có chìa khoá cấp mã, không tạo lại.\n\nMã công khai (đã chép sẵn, "
             f"dán gửi cho người làm phần mềm):\n\n{ck}", ["Xong"])
        return
    bam, _ = _hoi("Tạo chìa khoá cấp mã kích hoạt SonicRec trên máy này.\n\nChỉ làm MỘT lần. "
                  "Đã có bản sao chìa khoá từ máy khác thì chọn Nạp bản sao.",
                  ["Thoát", "Nạp bản sao", "Tạo mới"])
    if bam == "Tạo mới":
        ck = tao_chia_khoa()
        _chep(ban_sao_chia_khoa())
        _hoi("Đã tạo chìa khoá.\n\nBước 1: bản sao chìa khoá riêng vừa được chép sẵn. Mở ứng dụng "
             "Mật khẩu (hoặc Ghi chú có khoá), dán vào và lưu lại. Mất máy mà không có bản sao thì "
             "không cấp mã được nữa.\n\nKHÔNG gửi bản sao này cho ai, kể cả người làm phần mềm.",
             ["Đã lưu bản sao"])
    elif bam == "Nạp bản sao":
        _, chu = _hoi("Dán bản sao chìa khoá riêng (bắt đầu bằng RIENG-):", ["Thoát", "Nạp"], o_nhap=True)
        try:
            ck = nap_ban_sao(chu)
        except ValueError as loi:
            _hoi(str(loi), ["Đóng"])
            return
    else:
        return
    _chep(ck)
    print("Mã công khai:", ck)
    _hoi("Bước 2: mã công khai đã được chép sẵn. Dán gửi cho người làm phần mềm để gắn vào bản "
         f"cài (mã này gửi được, không phải bí mật):\n\n{ck}", ["Xong"])


if __name__ == "__main__":
    lenh = sys.argv[1] if len(sys.argv) > 1 else ""
    if lenh == "tao-chia-khoa":
        _tao_chia_khoa_hoi()
    elif lenh == "cong-khai":
        hat = _doc_chia_khoa()
        print(chu_cong_khai(hat) if hat else "Máy này chưa có chìa khoá cấp mã.")
    else:
        print(__doc__)
