#!/usr/bin/env python3
"""Dựng "SonicRec.app" trong ~/Applications (trước 28/9/2026 tên "Biên bản họp.app"; dựng
xong thì xoá ứng dụng tên cũ). Trình cài Mac (trinh_cai/cai_dat_mac.sh)
gọi tệp này; chạy lại bao nhiêu lần cũng được, mỗi lần dựng mới hoàn toàn.

    cd ~/bien-ban-hop && .venv/bin/python tao_ung_dung.py

Cấu tạo:
    SonicRec.app/Contents/
        Info.plist                 tên, biểu tượng, lời xin quyền dùng micro
        MacOS/bien-ban-hop         trình mở nhỏ viết bằng C
        Resources/bieu-tuong.icns

Trình mở chạy ung_dung.py trong ~/bien-ban-hop. Mã chương trình vẫn nằm ở đó,
nên cập nhật mã xong không phải dựng lại ứng dụng.

Từ 28/9/2026 trình mở DỰNG SẴN (tệp trinh-mo-mac, dựng trên máy Mac của GitHub bằng
luồng bien-ban-hop-mac.yml, chạy được cả chip Apple lẫn Intel): máy người dùng không
phải dịch gì, nên không cần công cụ dòng lệnh của Apple. Lúc chạy, nó tính đường dẫn
từ thư mục nhà và nạp Python đi kèm (~/bien-ban-hop/python) để chạy kiểu nhúng; không
nạp được thì chạy kiểu gọi riêng. Không có tệp dựng sẵn, hoặc tệp đó chạy thử không
đạt, thì mới dịch trên máy như trước (chỉ khi máy có công cụ của Apple).

Hai kiểu trình mở, thử kiểu thứ nhất trước:
  1. NHÚNG: Python chạy ngay bên trong trình mở. Dock và Cmd-Tab hiện đúng tên
     và biểu tượng SonicRec; macOS hỏi quyền micro đúng tên ứng dụng.
  2. GỌI RIÊNG: trình mở gọi Python thành tiến trình con. Dùng khi kiểu 1 không
     dịch được (máy thiếu tệp phát triển của Python). Mọi chức năng vẫn đủ; hình
     trên Dock do ung_dung.py tự đặt lại, nhưng rê chuột vào có thể vẫn ghi "Python".
     Lý do không dựng được kiểu 1 được in ra nhật ký cài.
Mỗi kiểu dựng xong đều được CHẠY THỬ; kiểu nào chạy thử không đạt thì bỏ.

Vì sao trình mở là tệp chạy thật chứ không phải tệp lệnh: macOS hỏi và nhớ
quyền micro theo ứng dụng chịu trách nhiệm về tiến trình ghi âm. Tệp chạy thật,
có Info.plist và chữ ký riêng, thì quyền gắn với chính SonicRec.
"""

import hashlib
import plistlib
import shutil
import subprocess
import sys
import sysconfig
import tempfile
from pathlib import Path

THU_MUC = Path(__file__).resolve().parent
TEN_APP = "SonicRec.app"
TEN_APP_CU = "Biên bản họp.app"  # tên trước 28/9/2026: dựng xong tên mới thì xoá
TEN_CHAY = "bien-ban-hop"
TEN_SAN = "trinh-mo-mac"   # trình mở dựng sẵn, trình cài chép vào ~/bien-ban-hop

MA_C = r"""
/* Trình mở của SonicRec. Do tao_ung_dung.py sinh ra, đừng sửa tay. */
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <pwd.h>
#include <signal.h>
#include <spawn.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>
#if defined(NHUNG_PYTHON) || defined(NHUNG_DONG)
#include <Python.h>
#endif
#ifdef NHUNG_DONG
#include <dlfcn.h>
#endif

/* Dịch ngay trên máy thì đường dẫn ghi sẵn vào đây. Bản dựng sẵn (DUNG_SAN) để trống:
   lúc chạy tính từ thư mục nhà của người dùng */
#define PYTHON_GHI @PYTHON@
#define UNG_DUNG_GHI @UNG_DUNG@
#define THU_MUC_GHI @THU_MUC@
#define NHAT_KY_GHI @NHAT_KY@

#ifdef DUNG_SAN
/* Dấu mã nguồn: bộ tự kiểm so dấu này với mã hiện tại, để bản dựng sẵn không cũ hơn mã */
__attribute__((used)) static const char DAU_MA_NGUON[] = "BBH-MA-NGUON=" MA_NGUON;
#endif

extern char **environ;
static pid_t con = 0;
static char PYTHON[PATH_MAX], UNG_DUNG[PATH_MAX], THU_MUC[PATH_MAX], NHAT_KY[PATH_MAX];

static void duong_dan(void) {
    if (THU_MUC_GHI[0]) {
        snprintf(PYTHON, sizeof PYTHON, "%s", PYTHON_GHI);
        snprintf(UNG_DUNG, sizeof UNG_DUNG, "%s", UNG_DUNG_GHI);
        snprintf(THU_MUC, sizeof THU_MUC, "%s", THU_MUC_GHI);
        snprintf(NHAT_KY, sizeof NHAT_KY, "%s", NHAT_KY_GHI);
        return;
    }
    const char *nha = getenv("HOME");
    if (!nha || !nha[0]) {
        struct passwd *pw = getpwuid(getuid());
        nha = pw ? pw->pw_dir : "/";
    }
    snprintf(THU_MUC, sizeof THU_MUC, "%s/bien-ban-hop", nha);
    snprintf(PYTHON, sizeof PYTHON, "%s/.venv/bin/python", THU_MUC);
    snprintf(UNG_DUNG, sizeof UNG_DUNG, "%s/ung_dung.py", THU_MUC);
    snprintf(NHAT_KY, sizeof NHAT_KY, "%s/nhat-ky-ung-dung.txt", THU_MUC);
}

static void chuyen_tin_hieu(int so) { if (con > 0) kill(con, so); }

static void bao_loi(void) {
    execl("/usr/bin/osascript", "osascript", "-e",
          "display alert \"SonicRec chưa cài xong\" message "
          "\"Chạy lại trình cài đặt SonicRec. "
          "Chi tiết lỗi ở ~/bien-ban-hop/nhat-ky-ung-dung.txt\"",
          (char *)NULL);
}

#ifdef NHUNG_DONG
/* Nạp Python lúc chạy từ ~/bien-ban-hop/python (bản Python dựng sẵn trình cài tải về),
   không liên kết lúc dịch: nhờ vậy dựng sẵn được trên máy khác */
#define HAM(ten) static __typeof__(&ten) p_##ten
HAM(PyConfig_InitPythonConfig);
HAM(PyConfig_SetBytesString);
HAM(PyConfig_SetBytesArgv);
HAM(Py_InitializeFromConfig);
HAM(PyConfig_Clear);
HAM(Py_RunMain);
HAM(PyStatus_Exception);
HAM(Py_ExitStatusException);
#define LAY(h, ten) (p_##ten = (__typeof__(p_##ten))dlsym(h, #ten))
static int nap_python(void) {
    char tv[PATH_MAX];
    snprintf(tv, sizeof tv, "%s/python/lib/%s", THU_MUC, TEN_THU_VIEN);
    void *h = dlopen(tv, RTLD_NOW | RTLD_GLOBAL);
    return h && LAY(h, PyConfig_InitPythonConfig) && LAY(h, PyConfig_SetBytesString)
        && LAY(h, PyConfig_SetBytesArgv) && LAY(h, Py_InitializeFromConfig)
        && LAY(h, PyConfig_Clear) && LAY(h, Py_RunMain) && LAY(h, PyStatus_Exception)
        && LAY(h, Py_ExitStatusException);
}
#define GOI(ten) p_##ten
#else
#define GOI(ten) ten
#endif

#if defined(NHUNG_PYTHON) || defined(NHUNG_DONG)
static int chay_nhung(int tu_kiem) {
    PyStatus st;
    PyConfig c;
    GOI(PyConfig_InitPythonConfig)(&c);
    c.parse_argv = 0;
    /* Trỏ executable vào python của .venv: Python tìm thấy pyvenv.cfg cạnh nó
       và dùng đúng các gói đã cài trong ~/bien-ban-hop/.venv */
    st = GOI(PyConfig_SetBytesString)(&c, &c.executable, PYTHON);
    if (GOI(PyStatus_Exception)(st)) goto hong;
    st = GOI(PyConfig_SetBytesString)(&c, &c.program_name, PYTHON);
    if (GOI(PyStatus_Exception)(st)) goto hong;
    st = GOI(PyConfig_SetBytesString)(&c, &c.run_filename, UNG_DUNG);
    if (GOI(PyStatus_Exception)(st)) goto hong;
    char *doi_so[] = {UNG_DUNG, tu_kiem ? "--tu-kiem" : NULL, NULL};
    st = GOI(PyConfig_SetBytesArgv)(&c, tu_kiem ? 2 : 1, doi_so);
    if (GOI(PyStatus_Exception)(st)) goto hong;
    st = GOI(Py_InitializeFromConfig)(&c);
    if (GOI(PyStatus_Exception)(st)) goto hong;
    GOI(PyConfig_Clear)(&c);
    return GOI(Py_RunMain)();
hong:
    GOI(PyConfig_Clear)(&c);
    if (!tu_kiem) bao_loi();
    GOI(Py_ExitStatusException)(st);
    return 1;
}
#endif

#ifndef NHUNG_PYTHON
static int chay_rieng(int tu_kiem) {
    char *doi_so[] = {PYTHON, UNG_DUNG, tu_kiem ? "--tu-kiem" : NULL, NULL};
    signal(SIGTERM, chuyen_tin_hieu);
    signal(SIGINT, chuyen_tin_hieu);
    signal(SIGHUP, chuyen_tin_hieu);
    /* Tiến trình CON chứ không thay thế mình, để Python và ffmpeg bên dưới vẫn
       tính là của SonicRec khi macOS hỏi quyền micro */
    if (posix_spawn(&con, PYTHON, NULL, NULL, doi_so, environ) != 0) {
        if (!tu_kiem) bao_loi();
        return 1;
    }
    int tt = 0;
    while (waitpid(con, &tt, 0) < 0 && errno == EINTR) {}
    return WIFEXITED(tt) ? WEXITSTATUS(tt) : 1;
}
#endif

int main(int argc, char **argv) {
    int tu_kiem = argc > 1 && strcmp(argv[1], "--tu-kiem") == 0;
    duong_dan();
    if (chdir(THU_MUC) != 0) { bao_loi(); return 1; }
    /* Mở từ Finder thì không có Terminal: chữ in và lỗi ghi vào tệp nhật ký */
    if (!tu_kiem) {
        int f = open(NHAT_KY, O_WRONLY | O_CREAT | O_APPEND, 0644);
        if (f >= 0) { dup2(f, 1); dup2(f, 2); close(f); }
    }
    setenv("PYTHONUTF8", "1", 1);
    /* Lúc chạy thử, in kiểu đang chạy để tao_ung_dung.py ghi Info.plist cho khớp */
#ifdef NHUNG_PYTHON
    if (tu_kiem) { puts("KIEU=nhung"); fflush(stdout); }
    return chay_nhung(tu_kiem);
#else
#ifdef NHUNG_DONG
    if (nap_python()) {
        if (tu_kiem) { puts("KIEU=nhung"); fflush(stdout); }
        return chay_nhung(tu_kiem);
    }
#endif
    if (tu_kiem) { puts("KIEU=goi-rieng"); fflush(stdout); }
    return chay_rieng(tu_kiem);
#endif
}
"""


def chuoi_c(s: str) -> str:
    """Chuỗi C an toàn cho mọi đường dẫn: byte nào ngoài chữ số thường thì viết
    dạng bát phân, nên dấu cách, dấu nháy, chữ có dấu đều không làm hỏng mã."""
    ra = []
    for b in s.encode("utf-8"):
        c = chr(b)
        ra.append(c if (c.isalnum() and b < 128) or c in "/._-~ " else f"\\{b:03o}")
    return '"' + "".join(ra) + '"'


def co_nhung() -> list[str] | None:
    """Cờ dịch để nhúng Python, lấy từ python3.X-config cạnh Python gốc của .venv."""
    phien_ban = sysconfig.get_config_var("VERSION")
    goc = Path(getattr(sys, "_base_executable", sys.executable)).parent
    for ten in (f"python{phien_ban}-config", "python3-config"):
        cau_hinh = goc / ten
        if not cau_hinh.exists():
            continue
        try:
            cf = subprocess.run([str(cau_hinh), "--cflags"], capture_output=True, text=True,
                                timeout=30, check=True).stdout.split()
            ld = subprocess.run([str(cau_hinh), "--ldflags", "--embed"], capture_output=True,
                                text=True, timeout=30, check=True).stdout.split()
        except (subprocess.SubprocessError, OSError):
            return None
        # Bỏ cờ tối ưu và cảnh báo của lúc dựng Python, chỉ giữ đường tìm tệp
        cf = [x for x in cf if x.startswith(("-I", "-D", "-F"))]
        thu_vien = sysconfig.get_config_var("LIBDIR")
        rpath = [f"-Wl,-rpath,{thu_vien}"] if thu_vien and sys.platform != "darwin" else []
        return ["-DNHUNG_PYTHON", *cf, *ld, *rpath]
    return None


def dich(dich_den: Path, co: list[str], python: Path, ung_dung: Path) -> str:
    """Dịch trình mở. Trả chuỗi rỗng nếu được, không thì trả lỗi."""
    ma = (MA_C.replace("@PYTHON@", chuoi_c(str(python)))
              .replace("@UNG_DUNG@", chuoi_c(str(ung_dung)))
              .replace("@THU_MUC@", chuoi_c(str(ung_dung.parent)))
              .replace("@NHAT_KY@", chuoi_c(str(ung_dung.parent / "nhat-ky-ung-dung.txt"))))
    with tempfile.TemporaryDirectory() as tam:
        nguon = Path(tam) / "trinh_mo.c"
        nguon.write_text(ma, encoding="utf-8")
        # co_nhung() đặt thư viện sau tệp nguồn: một số trình liên kết cần đúng thứ tự đó
        cf = [x for x in co if not x.startswith(("-l", "-L", "-Wl", "-framework"))]
        ld = [x for x in co if x not in cf]
        lenh = ["cc", "-O2", *cf, str(nguon), "-o", str(dich_den), *ld]
        try:
            ra = subprocess.run(lenh, capture_output=True, text=True, timeout=120)
        except (subprocess.SubprocessError, OSError) as loi:
            return str(loi)
    return "" if ra.returncode == 0 else (ra.stderr.strip()[-600:] or "cc báo lỗi")


def chay_thu(chay: Path) -> tuple[str, str]:
    """Chạy trình mở với --tu-kiem. Trả (lỗi, kiểu đang chạy); lỗi rỗng là đạt."""
    try:
        ra = subprocess.run([str(chay), "--tu-kiem"], capture_output=True, text=True,
                            timeout=120)
    except (subprocess.SubprocessError, OSError) as loi:
        return str(loi), ""
    kieu = "nhúng" if "KIEU=nhung" in ra.stdout else "gọi riêng"
    if ra.returncode == 0 and "TU-KIEM-DAT" in ra.stdout:
        return "", kieu
    return (ra.stderr or ra.stdout).strip()[-600:] or f"mã thoát {ra.returncode}", kieu


def co_cong_cu() -> bool:
    """Máy dịch được C không. Trên Mac, /usr/bin/cc lúc nào cũng có, nhưng máy chưa cài
    công cụ dòng lệnh của Apple thì gọi nó sẽ bật hộp thoại đòi cài: phải hỏi xcode-select."""
    if not shutil.which("cc"):
        return False
    if sys.platform != "darwin":
        return True
    try:
        return subprocess.run(["xcode-select", "-p"], capture_output=True,
                              timeout=30).returncode == 0
    except (subprocess.SubprocessError, OSError):
        return False


def dau_ma_nguon() -> str:
    """Dấu của MA_C. Trình mở dựng sẵn mang dấu này (BBH-MA-NGUON=...)."""
    return hashlib.sha1(MA_C.encode("utf-8")).hexdigest()


def dung_san(ra: Path, bao_gom: dict[str, Path]) -> None:
    """Dựng trình mở dựng sẵn cho mọi máy Mac, trên một máy Mac có công cụ của Apple
    (luồng GitHub bien-ban-hop-mac.yml gọi qua trinh_cai/dung_trinh_mo_mac.sh).
    bao_gom: kiến trúc (arm64, x86_64) -> thư mục include/python3.X của bản Python dựng
    sẵn cùng kiến trúc; chỉ lấy tệp đầu (Python.h), không liên kết gì."""
    ma = MA_C
    for cho in ("@PYTHON@", "@UNG_DUNG@", "@THU_MUC@", "@NHAT_KY@"):
        ma = ma.replace(cho, '""')
    with tempfile.TemporaryDirectory() as tam:
        nguon = Path(tam) / "trinh_mo.c"
        nguon.write_text(ma, encoding="utf-8")
        cac_lat = []
        for kien_truc, bao in bao_gom.items():
            lat = Path(tam) / f"trinh-mo-{kien_truc}"
            thu_vien = f"lib{bao.name}.dylib"   # include/python3.12 -> libpython3.12.dylib
            subprocess.run(["cc", "-arch", kien_truc, "-mmacosx-version-min=11.0", "-O2",
                            "-DDUNG_SAN", "-DNHUNG_DONG", f'-DMA_NGUON="{dau_ma_nguon()}"',
                            f'-DTEN_THU_VIEN="{thu_vien}"', f"-I{bao}", str(nguon), "-o", str(lat)],
                           check=True)
            cac_lat.append(str(lat))
        subprocess.run(["lipo", "-create", "-output", str(ra), *cac_lat], check=True)


def info_plist(nhung: bool) -> dict:
    ds = {
        "CFBundleName": "SonicRec",
        "CFBundleDisplayName": "SonicRec",
        "CFBundleIdentifier": "vn.edu.thanglong.ttc.bienbanhop",
        "CFBundleExecutable": TEN_CHAY,
        "CFBundleIconFile": "bieu-tuong",
        "CFBundlePackageType": "APPL",
        "CFBundleShortVersionString": "1.0",
        "CFBundleVersion": "1",
        "LSMinimumSystemVersion": "12.0",
        "LSApplicationCategoryType": "public.app-category.productivity",
        "NSHighResolutionCapable": True,
        # Nói đúng nơi bản ghi đi tới: từ 26/9/2026 không còn xử lý tại máy
        "NSMicrophoneUsageDescription": ("Ghi âm cuộc họp để làm biên bản. Bản ghi được gửi "
                                         "lên dịch vụ trực tuyến của Google hay chỉ lưu trên "
                                         "máy là tuỳ lựa chọn ở thẻ Cài đặt."),
    }
    if not nhung:
        # Kiểu gọi riêng: trình mở không có cửa sổ, ẩn nó khỏi Dock; cửa sổ của
        # Python con tự hiện biểu tượng
        ds["LSUIElement"] = True
    return ds


def dung(noi_dat: Path) -> tuple[Path, str]:
    python = THU_MUC / ".venv" / "bin" / "python"
    ung_dung = THU_MUC / "ung_dung.py"
    if not python.exists():
        raise SystemExit(f"Không thấy {python}. Chạy trình cài đặt SonicRec trước.")

    noi_dat.mkdir(parents=True, exist_ok=True)
    app = noi_dat / TEN_APP
    tam = noi_dat / (TEN_APP + ".dang-dung")
    shutil.rmtree(tam, ignore_errors=True)
    (tam / "Contents" / "MacOS").mkdir(parents=True)
    (tam / "Contents" / "Resources").mkdir()
    shutil.copy(THU_MUC / "tai_nguyen" / "hinh" / "bieu-tuong.icns",
                tam / "Contents" / "Resources" / "bieu-tuong.icns")
    chay = tam / "Contents" / "MacOS" / TEN_CHAY
    plist = tam / "Contents" / "Info.plist"

    loi_cac_kieu = []
    kieu = None
    san = THU_MUC / TEN_SAN
    if san.is_file():
        shutil.copy(san, chay)
        chay.chmod(0o755)
        plist.write_bytes(plistlib.dumps(info_plist(True)))
        ky_ten(tam)
        loi, kieu_chay = chay_thu(chay)
        if loi:
            loi_cac_kieu.append(f"dựng sẵn: {loi}")
        else:
            if kieu_chay != "nhúng":
                # Không nạp được Python đi kèm nên chạy kiểu gọi riêng: ẩn trình mở khỏi Dock
                plist.write_bytes(plistlib.dumps(info_plist(False)))
                ky_ten(tam)
            kieu = f"dựng sẵn, {kieu_chay}"
    if not kieu:
        if not co_cong_cu():
            shutil.rmtree(tam, ignore_errors=True)
            raise SystemExit("Không dựng được ứng dụng: " + ("; ".join(loi_cac_kieu)
                             or f"thiếu tệp {TEN_SAN}") + ". Máy chưa có công cụ dòng lệnh "
                             "của Apple nên không dịch lại được. Chạy lại trình cài đặt.")
        co = co_nhung()
        cac_kieu = ([("nhúng", True, co)] if co else []) + [("gọi riêng", False, [])]
        if not co:
            loi_cac_kieu.append("nhúng: không thấy python3-config")
        for ten, nhung, cac_co in cac_kieu:
            plist.write_bytes(plistlib.dumps(info_plist(nhung)))
            loi = dich(chay, cac_co, python, ung_dung)
            if not loi:
                ky_ten(tam)
                loi = chay_thu(chay)[0]
            if not loi:
                kieu = ten
                break
            loi_cac_kieu.append(f"{ten}: {loi}")
    if not kieu:
        shutil.rmtree(tam, ignore_errors=True)
        raise SystemExit("Không dựng được ứng dụng.\n" + "\n".join(loi_cac_kieu))
    if "nhúng" not in kieu:
        # Kiểu gọi riêng thì Dock ghi "Python": in lý do vào nhật ký cài để còn sửa
        print("Chưa dựng được kiểu nhúng nên dùng kiểu gọi riêng. " + "; ".join(loi_cac_kieu),
              flush=True)

    # Thay ứng dụng cũ bằng bản mới dựng. Trong .app không có dữ liệu họp nào; ứng dụng
    # tên cũ (Biên bản họp.app) cũng xoá, để máy không còn hai biểu tượng
    shutil.rmtree(app, ignore_errors=True)
    tam.rename(app)
    if TEN_APP_CU != TEN_APP:
        shutil.rmtree(noi_dat / TEN_APP_CU, ignore_errors=True)
    if sys.platform == "darwin":
        # Báo Finder và Launchpad có ứng dụng mới, cho biểu tượng hiện ngay
        subprocess.run(["touch", str(app)], check=False)
    return app, kieu


def ky_ten(app: Path) -> None:
    """Ký tại máy (không cần tài khoản Apple). Có chữ ký thì macOS nhớ quyền
    micro đã cho, và máy chip Apple mới chịu chạy."""
    if shutil.which("codesign"):
        subprocess.run(["codesign", "--force", "--sign", "-", str(app)],
                       capture_output=True, timeout=120, check=False)


if __name__ == "__main__":
    if sys.argv[1:2] == ["--dung-san"]:
        # python3 tao_ung_dung.py --dung-san <tệp ra> <include arm64> <include x86_64>
        dung_san(Path(sys.argv[2]), {"arm64": Path(sys.argv[3]), "x86_64": Path(sys.argv[4])})
        print(f"Đã dựng {sys.argv[2]} (dấu mã nguồn {dau_ma_nguon()})")
    else:
        noi = Path(sys.argv[1]) if len(sys.argv) > 1 else Path.home() / "Applications"
        app, kieu = dung(noi)
        print(f"Đã dựng {app} (kiểu {kieu})")
