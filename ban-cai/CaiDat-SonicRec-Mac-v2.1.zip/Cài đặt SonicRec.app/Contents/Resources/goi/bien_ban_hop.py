# SonicRec: tệp mốc để máy cài bản v1.6 trở xuống nhận ra gói cài này. Không phải mã ứng
# dụng (mã đã dịch nằm ở bien_ban_hop.pyc); trình cài không chép tệp này vào máy.
SO_BAN = "2.1"
MA_NGUON = "a8cefffa44fce1ccdc600dd37bdd5be214b7a0ac"
